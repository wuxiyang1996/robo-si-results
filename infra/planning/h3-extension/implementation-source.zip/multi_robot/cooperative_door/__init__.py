"""H3 heterogeneous cooperation development; evidence is scoped per configuration."""
