# H3 跨机器人实施与证据

当前完成的是双 G1 历史见证复核、Stretch 4 有界驱动与真实物理前置探针、六配置证据页。新组合尚无完整搬运见证，正式准入为 false。

六配置状态以 [`implementation.json`](../../infra/planning/h3-extension/implementation.json) 为准；[实施看板](../../infra/planning/h3-extension/implementation.html) 提供专家方案、阶段与轨迹映射、视频和失败记录。完整要求见 [任务清单](../../infra/planning/h3-extension/README.md)。

## 已实现

- H3-01/02：验证完整封存包与每运行 626 个文件的 SHA-256，使用与封存版本一致的评分器重新检查 200 Hz 物理记录。高／低层标签是对已执行专家的事后解释，不是新的规划器评测。
- Stretch 4：固定 SE4/francis/SG4 来源；有界轮速和关节驱动、伸缩臂 mimic 耦合、自由底盘、真实接触；不在运行中重设位置、注入底盘力或吸附包裹。
- `probe_stretch4.py`：分阶段移动与停稳测试，200 Hz 原始状态、10 fps 原生视频和执行前门槛。
- `probe_grasp.py`：对原尺寸 0.20 × 0.18 × 0.16 m、0.4 kg 包裹做接近、夹紧、抬升、放下与释放测试。至少 2 s 稳定离桌、随后 1.5 s 稳定释放才通过。
- `tools/monitor.py`：只查询本目录作业，汇总队列与结果；不是后台常驻服务。
- `tools/collect_progress.py`：校验各运行封存哈希、共享时钟和移动门槛；保留所有失败，生成逐配置页面及视频阶段定位。

## 运行与复核

从仓库根目录执行，仿真使用本机 Genesis 环境和 GPU：

```bash
H3_WHEEL_MODEL=rollers sbatch multi_robot/cooperative_door/tools/probe_stretch4.sbatch
python -m multi_robot.cooperative_door.tools.monitor
/fs/gamma-projects/vlm-robot/conda/envs/genesis/bin/python -B -m multi_robot.cooperative_door.probe_grasp --out /absolute/new/grasp-run
/fs/gamma-projects/vlm-robot/conda/envs/genesis/bin/python -B -m multi_robot.cooperative_door.tools.collect_legacy
python -m multi_robot.cooperative_door.tools.collect_progress
python infra/planning/render_h3_extension.py
```

输出目录必须是新目录。原始大轨迹、视频和派生 URDF 留在 `validation/<run>/`；网站证据目录含对应下载副本。`files.json` 封存运行产物，后处理审计另存；不能修改原失败记录来替代复测。

## 已发现的问题与边界

原 URDF 的 lift／arm effort 为零；驱动参数按官方 MuJoCo 模型补充并注明来源，轮驱动力矩仍是未校准的实验上限。Genesis 的标量接触摩擦不能直接复现官方 omniwheel 各向异性摩擦；新增的被动滚子模型属于明确记录的近似。早期半径 0.072 m 忽略了 footprint 的 0.028 m 高度偏移，造成底盘承重；后续已按官方接触半径修订为 0.1 m。

滚子模型还暴露了原地中立位碰撞过滤的缺口：轮子转动后，新的滚子与底盘轮腔碰撞。`configure_collision_filter` 在构建前将官方 base／wheel 排除规则扩展到滚子，保留轮子与地面、外部场景及其他机器人部件的碰撞；必须以复测结果判断是否有效。

夹爪指尖中心距 0.188 m 不等于可夹持内间距。原始接近与横向对齐复测均未稳定抬升原包裹；失败不能推出所有策略都物理不可能。禁止只缩小 Stretch 配置的包裹来获得通过。

## 未完成

H3-03/04/05 共享前置检查，不把同一探针重复计为三个任务运行。双机异构世界、通用接触组、全过程门区评分、隔离接口、工具发现和可信故障恢复仍待实现。H3-06 只有 Go2 资产预检，Z1 安装、联合惯量、负载步态与机械臂控制尚未验证。新配置的时间预算尚未冻结。
