"""Report only H3-owned jobs and immutable results; never cancels other work."""
import argparse,json,re,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path);a=p.parse_args()
 logs=sorted((BASE/'validation').glob('*.log'));ids=sorted({m.group(1) for f in logs if (m:=re.search(r'-(\d+)\.log$',f.name))})
 s=subprocess.run(['squeue','-h','-j',','.join(ids),'-o','%i|%T|%M|%R'],text=True,capture_output=True) if ids else None
 completed=[]
 for file in sorted((BASE/'validation').glob('*/result.json')):
  r=json.loads(file.read_text());completed.append(dict(run=file.parent.name,job_id=r.get('slurm_job_id'),status=r['status'],seconds=r.get('seconds'),task_success=r.get('task_success'),probe_success=r.get('probe_success')))
 report=dict(schema='h3-monitor/1',owned_job_ids=ids,queue=s.stdout.strip().splitlines() if s and s.stdout.strip() else [],queue_query_error=s.stderr if s and s.returncode else None,results=completed)
 text=json.dumps(report,indent=2)
 if a.out:a.out.write_text(text+'\n')
 print(text)
if __name__=='__main__':main()
