"""Build per-configuration H3 evidence from sealed references without new runs."""
from pathlib import Path
import hashlib,json,zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
ARCHIVE=ROOT.parent/'robo-si-data/releases/H3/cooperative-20261024/h3-cooperative-reference-20261024.zip'
ARCHIVE_SHA='49f3efc5fffd7e3d79ab70e6249a224631936b539188b875d6c806245bf05b3b'
DEST=ROOT/'infra/planning/h3-extension/evidence'
FULL='https://huggingface.co/datasets/IntelligenceLab/robo-si/resolve/2cf4ebc452aeb859d9003104718c920dd99b0bc9/releases/H3/cooperative-20261024/h3-cooperative-reference-20261024.zip'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def group(phase):
 if phase=='init':return 'initialize'
 if phase.startswith(('bar_','arm_pull')):return 'open_door'
 if phase.startswith('dual_door'):return 'maintain_door_support'
 if phase.startswith(('crate_','unassisted_')):return 'transfer_support_to_crate'
 if phase=='peer_carry_parcel':return 'carry_through_door'
 if phase in ['peer_place_parcel','peer_released_table_dwell']:return 'release_and_settle'
 if phase in ['peer_tuck_before_pickup','to_box','realign','pickup','hold']:return 'pick_up_parcel'
 if phase.startswith('peer_wait'):return 'wait_for_support'
 if phase.startswith('peer_clear'):return 'clear_parcel_route'
 return 'position_heavy_prop'

def main():
 assert sha(ARCHIVE.read_bytes())==ARCHIVE_SHA
 with zipfile.ZipFile(ARCHIVE) as z:
  for case,run in [('H3-01','no-prop-delivery-07'),('H3-02','heavy-delivery-05')]:
   out=DEST/case;out.mkdir(parents=True,exist_ok=True)
   pre='reference/runtime/multi_robot/dual_g1_self_closing_door/runs/'+run+'/'
   seal=json.loads(z.read(pre+'files.json'));verified=0
   for path,digest in seal.items():
    assert sha(z.read(pre+path))==digest,(run,path)
    verified+=1
   rows=json.loads(z.read(pre+'trace.json'));commands=json.loads(z.read(pre+'commands.json'));result=json.loads(z.read(pre+'result.json'))
   assert len(rows)==len(commands)+1
   assert np.max(np.abs(np.diff([r['t'] for r in rows])-.02))<1e-7
   phases=[]
   for name in ['g1_a','g1_b']:
    begin=0
    for i in range(1,len(commands)+1):
     if i==len(commands) or commands[i][name]['phase']!=commands[begin][name]['phase']:
      phase=commands[begin][name]['phase']
      phases.append(dict(robot=name,high_level=group(phase),low_level_phase=phase,start_s=rows[begin]['t'],end_s=rows[i]['t'],command_index_start=begin,command_index_end_exclusive=i,trace_row_start=begin,trace_row_end=i,action='43 bounded joint targets plus optional native leg torques; see commands.json'))
      begin=i
   physics=[p for r in rows[1:] for p in r['physics']]
   assert len(physics)==4*len(commands)
   assert np.max(np.abs(np.diff([p['t'] for p in physics])-.005))<1e-7
   # The current scorer must match the archived scorer exactly before replay.
   for rel in ['multi_robot/dual_g1_self_closing_door/scoring.py','multi_robot/dual_g1_self_closing_door/task_spec.py']:
    assert sha((ROOT/rel).read_bytes())==sha(z.read('reference/runtime/'+rel)),rel
   from multi_robot.dual_g1_self_closing_door.scoring import DeliveryScore
   from multi_robot.dual_g1_self_closing_door.task_spec import TaskConfig
   score=DeliveryScore(TaskConfig(variant=result['variant']))
   for p in physics:score.update(p)
   assert score.info()['success'] and result['task_success']
   mapping=dict(schema='h3-high-low-trajectory-map/1',configuration=case,run=run,mapping_kind='retrospective interpretation of an executed expert; not a newly evaluated general planner',clock='shared episode seconds',command_interval='commands[i] applies from trace[i].t to trace[i+1].t',segments=phases,events=score.info()['events'])
   (out/'planning-trajectory.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
   preview=[dict(t=r['t'],door_angle=r['door'][0],parcel=r['objects']['box']['pos'],robots={n:v['root_pos'] for n,v in r['robots'].items()},door_forces=r['robot_door_force_N'],crate_door_force=r['crate_door_force_N']) for r in rows[::10]]
   (out/'trajectory-preview.json').write_text(json.dumps(preview,separators=(',',':'))+'\n')
   for name in ['result.json','configuration.json','initial.png','final.png','motion.mp4']:(out/name).write_bytes(z.read(pre+name))
   # Keep expert entry source next to evidence; the full frozen runtime supplies imports.
   (out/'expert_open_probe.py').write_bytes(z.read('reference/runtime/multi_robot/dual_g1_self_closing_door/open_probe.py'))
   audit=json.loads((ROOT/f'infra/h3-release/{run}-audit.json').read_text())
   (out/'physical-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
   receipt=dict(schema='h3-configuration-delivery/1',configuration=case,status='complete_witness',run=run,legacy_reference=True,new_physics_runs=0,formal_admission=False,archive_url=FULL,archive_sha256=ARCHIVE_SHA,verified_sealed_files=verified,control_steps=len(commands),physics_steps=len(physics),seconds=rows[-1]['t'],independent_scorer_replay=score.info(),high_low_plan='planning-trajectory.json',trajectory='trajectory-preview.json',full_trajectory_member=pre+'trace.json',commands_member=pre+'commands.json',expert='expert_open_probe.py',expert_runtime_member='reference/runtime',video='motion.mp4',physical_audit='physical-audit.json',limitations=['Privileged-state native expert, not a public-sensor agent evaluation','Historical support audit retains its original sampling and geometry scope','Retrospective high/low mapping is not a new online planner evaluation'])
   (out/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n')
   import matplotlib
   matplotlib.use('Agg')
   import matplotlib.pyplot as plt
   t=np.array([r['t'] for r in rows]);fig,ax=plt.subplots(3,1,figsize=(11,7),sharex=True)
   ax[0].plot(t,[r['door'][0] for r in rows],label='Door angle');ax[0].set_ylabel('Angle (rad)');ax[0].legend(loc='upper right')
   ax[1].plot(t,[r['objects']['box']['pos'][0] for r in rows],label='Parcel x')
   for n in ['g1_a','g1_b']:ax[1].plot(t,[r['robots'][n]['root_pos'][0] for r in rows],label=n+' x',alpha=.7)
   ax[1].axhline(3.,color='black',linestyle='--',label='Door plane');ax[1].set_ylabel('Position (m)');ax[1].legend(loc='upper left',ncol=2)
   for n in ['g1_a','g1_b']:ax[2].plot(t,[r['robot_door_force_N'][n] for r in rows],label=n+' / door')
   ax[2].plot(t,[r['crate_door_force_N'] for r in rows],label='Crate / door');ax[2].set_ylabel('Contact force (N)');ax[2].set_xlabel('Shared episode time (s)');ax[2].legend(loc='upper right')
   for a in ax:
    a.grid(alpha=.2)
    for event in score.info()['events']:a.axvline(event['t'],color='#b8860b',alpha=.45)
   fig.suptitle(case+' | '+run+' | Historical native witness (not a new run)');fig.tight_layout();fig.savefig(out/'trajectory.png',dpi=145);plt.close(fig)
   (out/'files.json').write_text(json.dumps({p.name:sha(p.read_bytes()) for p in out.iterdir() if p.is_file() and p.name!='files.json'},indent=2)+'\n')
   print(case,len(physics),'native samples independently rescored; sealed files',verified,flush=True)
if __name__=='__main__':main()
