"""Check independent evidence seals, clocks, admission claims and video lengths."""
import gzip,hashlib,json,subprocess
from pathlib import Path
import imageio.v2 as imageio
from bs4 import BeautifulSoup
from urllib.parse import urlsplit,unquote
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'infra/planning/h3-extension'
def main():
 d=json.loads((OUT/'implementation.json').read_text());assert d['formal_admission'] is False and d['new_complete_task_runs']==0
 assert len({x['id'] for x in d['cases']})==6
 assert all(c['task_success'] is None for c in d['cases'][2:])
 assert len({x['job_id'] for x in d['attempts']})==d['new_physics_runs']
 files=0;videos=0
 for p in sorted((OUT/'evidence').iterdir()):
  if not p.is_dir():continue
  seal=json.loads((p/'files.json').read_text())
  for name,h in seal.items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,(p,name);files+=1
  if not (p/'motion.mp4').exists():continue
  r=json.loads((p/'result.json').read_text());mapping=json.loads((p/'planning-trajectory.json').read_text())
  end=max(s['end_s'] for s in mapping['segments']);reader=imageio.get_reader(p/'motion.mp4');meta=reader.get_meta_data();reader.close()
  assert abs(meta['duration']-end)<=.15,(p,meta['duration'],end)
  for s in mapping['segments']:assert 0<=s['start_s']<s['end_s']<=end+1e-7
  if (p/'audit.json').exists():
   a=json.loads((p/'audit.json').read_text());assert a['task_success'] is None
   rows=[json.loads(x) for x in gzip.open(p/'states.jsonl.gz','rt')];assert len(rows)==a['physics_samples']
   assert len(rows)*.005==a['seconds']
  videos+=1
 links=0
 for p in [OUT/'implementation.html',*(OUT/'evidence').glob('*/index.html')]:
  soup=BeautifulSoup(p.read_text(),'html.parser')
  for tag in soup.select('[href], [src]'):
   u=urlsplit(tag.get('href',tag.get('src')))
   if u.scheme or u.netloc:continue
   target=(p.parent/unquote(u.path)).resolve() if u.path else p
   assert target.is_file(),(p,u.path)
   if u.fragment and target.suffix=='.html':assert BeautifulSoup(target.read_text(),'html.parser').find(id=u.fragment),(p,u.fragment)
   links+=1
 # The collision masks must remove only the intended base/wheel interaction.
 groups={'base':(1,5),'wheel':(2,6),'other':(4,7),'external':(65535,65535)}
 for a,(at,aa) in groups.items():
  for b,(bt,ba) in groups.items():assert bool(at&ba or bt&aa)==({a,b}!={'base','wheel'}),(a,b)
 report=dict(schema='h3-evidence-check/1',cases=6,probes=d['new_physics_runs'],sealed_files_checked=files,video_durations_checked=videos,local_links_checked=links,collision_filter_truth_table='passed',admission_claims='passed',browser_visual_qa='not_run_no_browser_preview_available')
 (OUT/'implementation-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
