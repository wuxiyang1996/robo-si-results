"""Audit completed probes and generate six case pages from real artifacts.

No simulation is inferred from a plan, and prerequisite probes never increment
complete-task successes. Failed attempts are retained alongside later revisions.
"""
import gzip, hashlib, html, json, shutil, zipfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'multi_robot/cooperative_door'
OUT=ROOT/'infra/planning/h3-extension'
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def seal(p):dump(p/'files.json',{f.name:digest(f) for f in p.iterdir() if f.is_file() and f.name!='files.json'})
def audit(run):
 p=BASE/'validation'/run;r=json.loads((p/'result.json').read_text());rows=[json.loads(x) for x in gzip.open(p/'states.jsonl.gz','rt')]
 assert rows and all(abs(b['t']-a['t']-.005)<1e-7 for a,b in zip(rows,rows[1:]))
 original=json.loads((p/'files.json').read_text());assert all(digest(p/f)==s for f,s in original.items()),run
 a=dict(run=run,job_id=r['slurm_job_id'],physics_samples=len(rows),seconds=rows[-1]['t'],sample_period_s=.005,sealed_files_verified=len(original),task_success=None,scope=r['scope'],hardware_calibrated=False)
 if 'grasp' in run:
  a.update(status='check_failed' if not r['probe_success'] else 'passed_local_screen',max_airborne_dwell_s=r['max_airborne_dwell_s'],max_released_dwell_s=r['max_released_dwell_s'],reason='No stable lift of the unchanged parcel' if not r['probe_success'] else 'Local grasp screen passed; task execution still required')
 else:
  phases={b['end']['phase']:b['end'] for b in r['phase_boundaries']}
  if 'lateral' in phases:
   f=phases['forward']['displacement'];l=phases['lateral']['displacement'];stop=max(phases[k]['speed'] for k in ['stop_forward','stop_lateral','stop_rotate'])
   passed=f[0]>=.2 and l[1]>=.2 and abs(f[1])<=.15 and abs(l[0])<=.15 and stop<=.03
   a.update(status='passed_local_screen' if passed else 'check_failed',forward_m=f[0],lateral_m=l[1],maximum_stop_speed_mps=stop,minimum_translation_m=.2,reason='Measured against the predeclared mobility gate')
  else:a.update(status='diagnostic_only',reason='Short diagnostic, not a task or complete mobility test',terminal_self_contacts=rows[-1].get('self_contacts',[]))
 out=OUT/'evidence'/run;out.mkdir(parents=True,exist_ok=True)
 for name in ['result.json','plan.json','states.jsonl.gz','motion.mp4','source.py','probe-source.py','binding-source.py','driver-source.py','wheel-geometry.json']:
  if (p/name).exists():shutil.copy2(p/name,out/name)
 shutil.copy2(p/'assets/binding.json',out/'binding.json');dump(out/'audit.json',a)
 seg=[]
 for phase in dict.fromkeys(x['phase'] for x in rows):
  rr=[(i,x) for i,x in enumerate(rows) if x['phase']==phase]
  seg.append(dict(robot='stretch4',high_level='parcel_grasp_gate' if 'grasp' in run else 'mobility_gate',low_level_phase=phase,start_s=round(rr[0][1]['t']-.005,6),end_s=rr[-1][1]['t'],physics_row_start=rr[0][0],physics_row_end_exclusive=rr[-1][0]+1))
 dump(out/'planning-trajectory.json',dict(clock='shared simulation seconds',mapping_kind='predeclared probe phases with measured native states',video_time_offset_s=.1,segments=seg))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(2,1,figsize=(10,6),sharex=True);t=[x['t'] for x in rows]
 if 'grasp' in run:
  ax[0].plot(t,[x['parcel_pos'][2] for x in rows],label='Parcel z');ax[0].axhline(.84,ls='--',color='red',label='Airborne threshold');ax[0].set_ylabel('Height (m)')
  for i,n in enumerate(['Left finger','Right finger']):ax[1].plot(t,[x['finger_contacts_N'][i] for x in rows],label=n)
  ax[1].plot(t,[x['table_contact_N'] for x in rows],label='Table support');ax[1].set_ylabel('Contact force (N)')
 else:
  for i,n in enumerate(['x','y']):ax[0].plot(t,[x['root_pos'][i] for x in rows],label='Root '+n)
  ax[0].set_ylabel('Position (m)');ax[1].plot(t,[np.linalg.norm(x['root_vel']) for x in rows],label='Root speed');ax[1].set_ylabel('Speed (m/s)')
 for axis in ax:
  axis.legend();axis.grid(alpha=.2)
  for s in seg:axis.axvline(s['start_s'],color='grey',alpha=.2)
 ax[1].set_xlabel('Simulation time (s)');fig.suptitle(run+' | '+a['status']+' | prerequisite only');fig.tight_layout();fig.savefig(out/'trajectory.png',dpi=130);plt.close(fig)
 dump(out/'trajectory-preview.json',rows[::20]);seal(out)
 return a

CSS='''body{font:16px/1.65 system-ui,sans-serif;color:#182b3a;background:#f5f8fa;margin:0}main{max-width:1120px;margin:auto;padding:26px;background:white}h1{line-height:1.2}.notice{border-left:5px solid #ae6c0a;background:#fff2d5;padding:16px}video,img{max-width:100%;width:100%;height:auto}table{border-collapse:collapse;width:100%}th,td{padding:10px;border-bottom:1px solid #d9e1e6;text-align:left;vertical-align:top}.scroll{overflow:auto}a{color:#075e72}button{padding:6px 12px;cursor:pointer}article{border:1px solid #d9e1e6;border-radius:8px;padding:18px;margin:24px 0}.row{display:grid;grid-template-columns:1fr 1fr;gap:18px}.active{background:#d8eee9}code{overflow-wrap:anywhere}@media(max-width:700px){.row{grid-template-columns:1fr}main{padding:16px}}'''
def page(title,body):return '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(title)+'</title><style>'+CSS+'</style><main>'+body+'</main></html>'
def bundle_card(name,prefix='evidence/'):
 p=OUT/'evidence'/name;mapping=json.loads((p/'planning-trajectory.json').read_text());segments=mapping['segments'];e=html.escape;path=prefix+name+'/'
 rs=''.join(f'<tr data-start="{s["start_s"]}" data-end="{s["end_s"]}"><td>{e(s["robot"])}</td><td>{e(s["high_level"])}</td><td>{e(s["low_level_phase"])}</td><td><button type="button" data-seek="{s["start_s"]}">{s["start_s"]:.2f}–{s["end_s"]:.2f}s</button></td></tr>' for s in segments)
 links=['planning-trajectory.json','trajectory-preview.json','result.json','files.json']+(['delivery.json','physical-audit.json','expert_open_probe.py'] if name.startswith('H3-') else ['audit.json','binding.json','states.jsonl.gz'])
 if name.startswith('H3-'):
  receipt=json.loads((p/'delivery.json').read_text());extra=f'<p><a href="{receipt["archive_url"]}">完整封存运行时、命令与 200 Hz 轨迹 / Frozen runtime, commands and 200 Hz trace</a></p>'
 else:
  extra='<p>'+' · '.join(f'<a href="{path}{x.name}">{x.name}</a>' for x in sorted(p.glob('*.py')))+'</p>'
 return extra+f'<article><h3>{e(name)}</h3><p>'+ ' · '.join(f'<a href="{path}{x}">{x}</a>' for x in links)+f'</p><div class="row"><video controls preload="metadata" src="{path}motion.mp4" data-offset="{mapping.get("video_time_offset_s",0)}"></video><a href="{path}trajectory.png"><img src="{path}trajectory.png" alt="{e(name)} measured trajectory"></a></div><p class="clock" aria-live="off">视频与阶段使用同一仿真时钟 / Shared simulation clock</p><details><summary>High / low planning → trajectory：点击时间定位视频</summary><div class="scroll"><table><thead><tr><th>Robot</th><th>High level</th><th>Low level</th><th>Interval</th></tr></thead><tbody>{rs}</tbody></table></div></details></article>'
JS='''<script>document.querySelectorAll('article').forEach(a=>{const v=a.querySelector('video');if(!v)return;const off=Number(v.dataset.offset||0);a.querySelectorAll('[data-seek]').forEach(b=>b.onclick=()=>{v.currentTime=Math.max(0,Number(b.dataset.seek)-off)});v.addEventListener('timeupdate',()=>{const t=v.currentTime+off;a.querySelector('.clock').textContent='Simulation '+t.toFixed(2)+' s';a.querySelectorAll('tr[data-start]').forEach(r=>r.classList.toggle('active',t>=Number(r.dataset.start)&&t<Number(r.dataset.end)))})});</script>'''
def main():
 archive=ROOT.parent/'robo-si-data/releases/H3/cooperative-20261024/h3-cooperative-reference-20261024.zip'
 with zipfile.ZipFile(archive) as z:
  for case,run in [('H3-01','no-prop-delivery-07'),('H3-02','heavy-delivery-05')]:
   out=OUT/'evidence'/case;out.joinpath('motion.mp4').write_bytes(z.read('reference/runtime/multi_robot/dual_g1_self_closing_door/runs/'+run+'/motion.mp4'))
   r=json.loads((out/'delivery.json').read_text());r['video']='motion.mp4';dump(out/'delivery.json',r);seal(out)
 runs=[p.name for p in sorted((BASE/'validation').iterdir()) if p.is_dir() and (p/'result.json').exists()]
 audits=[audit(run) for run in runs]
 configs=json.loads((OUT/'task-list.json').read_text())['configurations'];cases=[]
 plans={
 'H3-01':['G1 A 打开并持续扶门；G1 B 搬运包裹、过门、放桌并释放。','已执行原生专家；43 维关节目标、可选腿部力矩，50 Hz 控制；200 Hz 物理采样。'],
 'H3-02':['G1 A 开门；双机摆放重箱并交接门支撑；G1 B 取包裹过门、放桌释放。','已执行原生专家；重箱支撑检查与搬运阶段对应封存命令索引。'],
 'H3-03':['候选方案：G1 开门／扶门，Stretch 4 取包裹并交付；先验证移动和抓取。若单臂抓取失败，须实测角色交换或统一任务修订。','已实现 Stretch 4 有界关节和轮速控制、前置测试与 200 Hz 记录；双机完整控制尚未实现。'],
 'H3-04':['候选方案：Stretch A 开门并发现可用支撑工具，Stretch B 搬运；需验证单臂资源竞争与支撑交接。','共享移动／抓取前置门槛未通过；双 Stretch 门场景、工具控制与完整专家待实现。'],
 'H3-05':['候选方案：先测能力，再分配扶门和搬运；可信故障触发后更新能力预测、换角色或工具并恢复。','共享基础驱动已有实测；可信故障注入、预测日志和在线恢复尚未实现，不能算 L3 试验。'],
 'H3-06':['候选方案：G1 承担高位操作，Go2/Z1 探测可达域并选择推工具或搬运；故障后重新分工。','仅资产预检：本地有 Go2 URDF；尚未建立经验证的 Go2/Z1 安装、动力学和操控组合。无物理运行。']}
 for c in configs:
  id=c['id'];legacy=id in ['H3-01','H3-02'];supported=id in ['H3-03','H3-04','H3-05']
  status='historical_complete_witness' if legacy else 'prerequisite_check_failed' if supported else 'asset_preflight_incomplete'
  cases.append(dict(id=id,robots=c['robots'],level=c['level'],status=status,task_success=True if legacy else None,new_complete_task_runs=0,expert_plan=plans[id][0],low_level=plans[id][1],expert_status='executed_legacy' if legacy else 'proposed_not_end_to_end_implemented',evidence=[id] if legacy else runs if supported else [],formal_admission=False))
  note='历史成功见证；本次重新校验与评分，不是新增物理成功。高层标签是对原专家轨迹的事后映射。' if legacy else '前置检查失败 ≠ 物理不可能。尚无完整任务成功、完整专家轨迹或任务视频。' if supported else '未完成组合资产与控制器，物理可行性未确定；没有视频或轨迹。'
  body=f'<p><a href="../../implementation.html">← 六配置实施看板</a></p><h1>{id} · {html.escape(c["robots"])}</h1><p class="notice"><strong>{status}</strong><br>{note}</p><h2>专家方案 / Expert plan</h2><p>{plans[id][0]}</p><h2>低层实现 / Low-level implementation</h2><p>{plans[id][1]}</p>'
  if legacy:body+=bundle_card(id,'../')
  elif supported:
   body+='<h2>共享前置验证 / Shared prerequisite evidence</h2><p>三个配置依赖同一底盘与夹爪；以下是同一组物理运行的引用，不重复计数。请查看 <a href="../../implementation.html#attempts">全部失败与诊断记录</a>。</p>'
   for run in ['traction-8051240','grasp-8051182']:
    if run in runs:body+=bundle_card(run,'../')
  else:body+='<p><a href="asset-preflight.json">资产预检记录 / Asset preflight</a></p><p>下一门槛：固定 Z1 资产版本和安装变换，核对总质量、重心、碰撞、关节力矩及负载稳定性；之后才能运行组合探针。</p>'
  dest=OUT/'evidence'/id;dest.mkdir(parents=True,exist_ok=True);dump(dest/'case.json',cases[-1]);(dest/'index.html').write_text(page(id,body+JS));seal(dest)
 ledger=dict(schema='h3-implementation/1',updated='2026-10-28',new_physics_runs=len(audits),new_complete_task_runs=0,legacy_witnesses_reaudited=2,formal_admission=False,cases=cases,attempts=audits)
 dump(OUT/'implementation.json',ledger)
 body='<p><a href="../../task-h3-zh.html#h3-execution">← H3 任务页</a> · <a href="index-zh.html">完整要求</a> · <a href="implementation.json">机器可读状态</a></p><h1>H3 · 实施与物理证据</h1><p class="notice"><strong>先看实测，再判定可行性。</strong><br>2026-10-28：复核 2 个历史完整见证；新增 '+str(len(audits))+' 次前置／诊断仿真，新增完整任务运行 0。H3-03–06 尚无完整成功见证，正式准入 false。</p><div class="scroll"><table><thead><tr><th>配置</th><th>机器人</th><th>状态</th><th>专家解 · 规划 · 轨迹 · 物理 · 视频</th></tr></thead><tbody>'
 for c in cases:body+=f'<tr><td>{c["id"]}</td><td>{html.escape(c["robots"])}</td><td>{c["status"]}</td><td><a href="evidence/{c["id"]}/index.html">查看配置证据与待办</a></td></tr>'
 body+='</tbody></table></div><h2>明确的下一步</h2><ol><li>修复并验证 Stretch 4 轮接触；所有失败记录保留。</li><li>测夹爪真实内间距、接近姿态和抬升；不把指尖中心距当可抓宽度，不缩小单个配置的包裹。</li><li>通过前置门槛后实现 G1 + Stretch 双机世界、统一控制时钟与评分。</li><li>完整基线通过后接工具发现、可信故障与在线恢复。</li><li>Go2/Z1 完成资产、安装和负载控制检查后再运行。</li></ol><h2 id="attempts">全部尝试 / All attempts</h2>'
 for a in audits:body+=f'<p><strong>{a["run"]} · {a["status"]}</strong> · {a["physics_samples"]} samples · {a["seconds"]} s</p>'+bundle_card(a['run'])
 (OUT/'implementation.html').write_text(page('H3 implementation evidence',body+JS));print(json.dumps(dict(probes=len(audits),cases=len(cases),samples=sum(a['physics_samples'] for a in audits))))
if __name__=='__main__':main()
