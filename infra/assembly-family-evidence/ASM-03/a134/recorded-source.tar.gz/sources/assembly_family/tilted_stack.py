"""Transfer load to a real stand edge before opening an undergrasp."""
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from humanoid.g1_gear_assembly.solution.skills import smooth


def receive(c,grip,goal,pose):
    name,side=grip.name,grip.side;p0,R0,_=pose(c,name)
    initial_hand,initial_rotation=c.hand_pose(side)
    local_p=R0.T@(initial_hand-p0);local_R=R0.T@initial_rotation
    brace=c.object_state('brace');half=np.asarray(c.env.specs[name]['size'])/2
    top=brace['pos'][2]+c.env.specs['brace']['size'][2]/2
    angle=np.deg2rad(40.);target=np.asarray(goal).copy()
    target[2]=top+half[0]*np.sin(angle)+half[2]*np.cos(angle)+.001
    desired_R=Rotation.from_euler('y',angle).as_matrix()
    orientation=Slerp([0,1],Rotation.from_matrix(np.stack([R0,desired_R])))
    cp=np.zeros(3);cr=np.zeros(3)
    c.event('shim_receive_tilted_edge_on_actual_stand',target=target.tolist(),angle_degrees=40.,dimensions=(2*half).tolist())
    def track(point,Rd):
        nonlocal cp,cr
        p,R,state=pose(c,name)
        if not state['hand_contact']:raise RuntimeError('shim: undergrasp lost before the receiving edge was loaded')
        cp=np.clip(cp+np.clip(.045*(point-p),-.0003,.0003),-.025,.025)
        rv=Rotation.from_matrix(Rd@R.T).as_rotvec();cr=np.clip(cr+np.clip(.02*rv,-.001,.001),-.15,.15)
        command_R=Rotation.from_rotvec(cr).as_matrix()@Rd
        c.reach({side:('palm',point+cp+command_R@local_p,command_R@local_R)},feedback=.5,iters=20);c.step()
    # The fixed-height rotation is unreachable on the loaded wrist branch.
    # Check the coupled descent from measured joints before executing it.
    seed=c.actual_q();samples=[]
    for a in np.linspace(0.,1.,21):
        point=p0+a*(target-p0);Rd=orientation(a).as_matrix();want=Rd@local_R
        seed,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,
            {side:('palm',point+Rd@local_p,want)},iters=150,damping=.015,w_rot=.5,max_step=.05)
        angle=float(np.linalg.norm(Rotation.from_matrix(want@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec()))
        samples.append(dict(fraction=float(a),position_error=errors[side],rotation_error=angle))
        if errors[side]>.004 or angle>.04:
            c.event('shim_setdown_path_unreachable',samples=samples)
            raise RuntimeError('shim: coupled edge setdown has no continuous reachable wrist path')
    c.event('shim_setdown_path_screened',samples=samples)
    for i in range(200):
        a=smooth(min(1.,(i+1)/175));track(p0+a*(target-p0),orientation(a).as_matrix())
    stable=0
    for _ in range(90):
        p,R,state=pose(c,name)
        stable=stable+1 if state['support_forces'].get('brace',0)>.60*c.env.specs[name]['mass']*9.81 else 0
        if stable>=10:break
        if stable==0:target[2]-=.00010
        track(target,desired_R)
    p,R,state=pose(c,name)
    c.event('shim_receiving_edge_load_measurement',position=p.tolist(),rotation=R.tolist(),supports=state['support_forces'])
    if stable<10 or np.linalg.norm(p[:2]-target[:2])>.015:
        raise RuntimeError('shim: receiving edge did not establish a stable measured stand load')
    return target,desired_R
