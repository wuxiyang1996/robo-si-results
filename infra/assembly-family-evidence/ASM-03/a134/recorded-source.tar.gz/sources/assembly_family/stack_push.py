"""Use the real index side as a high-wrist pusher while holding the hinge open."""
import numpy as np
import itertools
from scipy.spatial.transform import Rotation


def support(c,original,*args,**kwargs):
    # Push inside the 40 mm stand face with a curled index and a high wrist.
    kwargs['push_height']=.035
    kwargs['hover_offsets']=[(0.,.17),(0.,.19)]
    if getattr(c,'efficient_clear_staging',False):kwargs['push_steps']=350
    # Leave room for measured settling during the unloaded waist rebranch.
    c.ik.set_limit('waist_pitch_joint',-.46,.46)
    c.ik.set_limit('waist_roll_joint',-.46,.46)
    hand_pose,reach,hands,solve,preset,joints=c.hand_pose,c.reach,c.move_hands,c.ik.solve,c.hand_preset,c.move_joints
    def tip_pose(side,kind='palm'):
        if side!='left' or kind!='thumb':return hand_pose(side,kind)
        c.ik._set(c.env.base_position,(1,0,0,0),c.actual_q())
        return (c.ik.point(c.ik.m.body('left_hand_index_1_link').id,[.04,0,0]).copy(),
                c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3).copy())
    def convert(tasks):
        converted=tasks
        if 'right' in tasks:
            kind,point,rotation=tasks['right'];point=np.asarray(point)
            expected_x=c.env.cfg.fixture_pivot_xy[0]-.16
            if kind=='palm' and abs(point[0]-expected_x)<1e-8 and rotation is not None:
                down=Rotation.from_euler('x',-np.pi/2).as_matrix()
                if np.linalg.norm(np.asarray(rotation)-down)<1e-6:
                    point=point.copy();point[0]-=.025
                    converted=dict(tasks,right=(kind,point,rotation))
        if 'left' not in tasks or tasks['left'][0]!='thumb':return converted
        _,point,_=tasks['left'];point=np.asarray(point)
        # Start with a long finger for lateral reach, then curl it as the
        # stand approaches the plate. Both the moving fingertip and wrist
        # remain continuously reachable; the middle finger stays out of the way.
        fraction=float(np.clip((.36-point[1])/.14,0.,1.))
        rotation=Rotation.from_euler('y',35.+5.*fraction,degrees=True).as_matrix()
        virtual=c.actual_q();virtual[c.index['left_hand_index_0_joint']]=-.25-.65*fraction
        c.ik._set(c.env.base_position,(1,0,0,0),virtual)
        tip=c.ik.point(c.ik.m.body('left_hand_index_1_link').id,[.04,0,0])
        palm=c.ik.hand_point('left','palm')
        wrist=c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3)
        local=wrist.T@(palm-tip)
        c.ik.set_limit('waist_pitch_joint',-.48,.48)
        c.ik.set_limit('waist_roll_joint',-.48,.48)
        return dict(converted,left=('palm',point+rotation@local,rotation))
    def solve_index(root_pos,root_quat,q,tasks,*a,**kw):
        converted=convert(tasks)
        if tasks.get('left',(None,))[0]=='thumb' and 'right'in tasks and kw.get('iters',0)>=100:
            dz=float(tasks['left'][1][2]-c.env.cfg.table_height-kwargs.get('push_height',.020))
            low=dict(converted);kind,point,rotation=low['left'];low['left']=(kind,np.asarray(point)-[0,0,dz],rotation)
            for wy,sy,ry,el,re in [(-1.2,1.5,1.5,-.6,-.6),(0.,1.5,-1.5,1.2,-.6),(1.2,1.5,1.5,1.2,-.6),(-1.2,-1.5,-1.5,-.6,1.2)]:
                seed=q.copy();seed[c.index['waist_yaw_joint']]=wy
                for side,yaw,elbow in [('left',sy,el),('right',ry,re)]:
                    seed[c.index[side+'_shoulder_yaw_joint']]=yaw;seed[c.index[side+'_elbow_joint']]=elbow
                seed,errors=solve(root_pos,root_quat,seed,low,iters=500,damping=.015,w_rot=.5,max_step=.05)
                valid=max(errors.values())<.003
                for fraction in np.linspace(0.,1.,21) if valid else ():
                    current=dict(low,left=(kind,low['left'][1]+[0,0,fraction*dz],rotation))
                    seed,errors=solve(root_pos,root_quat,seed,current,iters=150,damping=.015,w_rot=.5,max_step=.05)
                    angle=max(np.linalg.norm(Rotation.from_matrix(t[2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())for s,t in current.items()if t[2]is not None)
                    if max(errors.values())>.003 or angle>.04:valid=False;break
                if valid:
                    c.event('stack_contact_to_hover_branch',seed=[wy,sy,ry,el,re],contact_height=c.env.cfg.table_height+kwargs.get('push_height',.020),hover_q=seed.tolist(),errors=errors)
                    return seed,errors
        pushing=tasks.get('left',(None,))[0]=='thumb' or c.phase in ('thumb_lower','brace_push_feedback','brace_push_fine_alignment')
        if kw.get('iters',0)<=30 and 'left'in converted and 'right'in converted and pushing:
            from .held_ik import solve as held_solve
            return held_solve(c.ik,root_pos,root_quat,q,converted,'right',*a,**kw)
        result=solve(root_pos,root_quat,q,converted,*a,**kw)
        if converted is not tasks and max(result[1].values())>.003 and kw.get('iters',0)>=100:
            candidates=[result]
            for wy,sy,donor_yaw,elbow,donor_elbow in itertools.product((-1.2,0.,1.2),(-1.5,0.,1.5),(-1.5,1.5),(-.6,1.2),(-.6,1.2)):
                seed=q.copy();seed[c.index['waist_yaw_joint']]=wy
                seed[c.index['waist_pitch_joint']]=0.;seed[c.index['waist_roll_joint']]=0.
                seed[c.index['left_shoulder_pitch_joint']]=-1.
                seed[c.index['left_shoulder_yaw_joint']]=sy;seed[c.index['left_elbow_joint']]=elbow
                seed[c.index['right_shoulder_yaw_joint']]=donor_yaw;seed[c.index['right_elbow_joint']]=donor_elbow
                candidate=solve(root_pos,root_quat,seed,converted,*a,**kw);candidates.append(candidate)
                angles=[np.linalg.norm(Rotation.from_matrix(t[2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())for s,t in converted.items()if t[2]is not None]
                if max(candidate[1].values())<.001 and max(angles,default=0.)<.01:
                    c.event('stack_index_reachable_joint_branch',seed=[wy,sy,donor_yaw,elbow,donor_elbow],errors=candidate[1],rotation_errors=[float(x)for x in angles])
                    return candidate
            result=min(candidates,key=lambda item:max(item[1].values()))
        return result
    def hover_guard(solution,tasks):
        converted=convert(tasks);kind,point,rotation=converted['left']
        dz=float(tasks['left'][1][2]-c.env.cfg.table_height-kwargs.get('push_height',.020));seed=solution.copy()
        for fraction in np.linspace(0.,1.,21):
            current=dict(converted,left=(kind,np.asarray(point)-[0,0,fraction*dz],rotation))
            seed,errors=solve(c.env.base_position,(1,0,0,0),seed,current,iters=150,damping=.015,w_rot=.5,max_step=.05)
            angle=max(np.linalg.norm(Rotation.from_matrix(t[2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())for s,t in current.items()if t[2]is not None)
            if max(errors.values())>.004 or angle>.04:return False
        return True
    def set_hand(side,name,seconds=.5):
        result=preset(side,name,seconds=seconds)
        if side=='left' and name=='open':
            q=c.q.copy()
            for joint,value in [('index_0',-.25),('index_1',-.05),('middle_0',-1.5),('middle_1',-.05),('thumb_0',1.),('thumb_1',.8),('thumb_2',.03)]:
                q[c.index['left_hand_'+joint+'_joint']]=value
            c.event('stack_push_index_side_preshape');c.move_joints(q,seconds=.8)
        return result
    def move_hands(tasks,*a,**kw):
        converted=convert(tasks);result=hands(converted,*a,**kw)
        if c.phase=='thumb_lower' and tasks.get('left',(None,))[0]=='thumb':
            wanted=np.asarray(tasks['left'][1]);correction=np.zeros(3)
            _,palm,rotation=converted['left']
            for _ in range(200):
                tip,actual_R=tip_pose('left','thumb');error=wanted-tip
                if np.linalg.norm(error)<.004 and np.linalg.norm(Rotation.from_matrix(rotation@actual_R.T).as_rotvec())<.04:break
                correction=np.clip(correction+np.clip(.04*error,-.0003,.0003),-.06,.06)
                reach(dict(converted,left=('palm',palm+correction,rotation)),feedback=.5,iters=24);c.step()
            tip,actual_R=tip_pose('left','thumb')
            c.event('stack_actual_index_contact_hover',position=tip.tolist(),target=wanted.tolist(),position_error=float(np.linalg.norm(wanted-tip)),position_correction=correction.tolist())
            if np.linalg.norm(wanted-tip)>.008:raise RuntimeError('stack pusher: index did not physically reach the north contact hover')
            if c.object_state('shim')['support_forces'].get('brace',0)<.05:
                raise RuntimeError('stack pusher: lowering disturbed the composed stand')
        return result
    def move_joints(target,seconds=1.):
        if c.phase=='press_restore_safe_branch':
            from .approach_path import move as planned_move
            for side in ('right','left'):
                hp,hR=hand_pose(side)
                if hp[2]<1.0:
                    c.event('stack_push_clear_'+side+'_hand_before_posture_change')
                    high=hp.copy();high[2]=1.10
                    hands({side:('palm',high,hR)},seconds=2.,feedback=.5)
                    if hand_pose(side)[0][2]<1.0:raise RuntimeError('stack pusher: hand remains below safe posture-change height')
            desired=np.asarray(target).copy()
            desired[c.ik.upper]=np.clip(desired[c.ik.upper],c.ik.lo,c.ik.hi)
            for side in ('right','left'):
                branch=c.q.copy()
                active=[i for i in c.ik.upper if i in [c.index[n]for n in c.index if n.startswith(('waist',side+'_'))]]
                branch[active]=desired[active]
                c.event('stack_push_plan_'+side+'_return_with_measured_fingers')
                planned_move(c,branch,side,protected=('shim','brace'))
            final=c.q.copy()
            for name,index in c.index.items():
                if '_hand_'in name:final[index]=desired[index]
            c.event('stack_push_set_press_hands_above_table')
            return joints(final,seconds=max(seconds,2.))
        if c.phase!='thumb_hover_branch':return joints(target,seconds=seconds)
        # The direct joint chord swept the folded middle finger through the
        # table. Lift and rotate the unloaded hand in Cartesian space instead.
        c.ik._set(c.env.base_position,(1,0,0,0),np.asarray(target))
        goal=c.ik.hand_point('left','palm').copy()
        rotation=c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3).copy()
        rp,rR=hand_pose('right');lp,lR=hand_pose('left');saved=c.ik.solve
        from .held_ik import solve as held_solve
        def keep_right(root_pos,root_quat,q,tasks,*a,**kw):
            return held_solve(c.ik,root_pos,root_quat,q,dict(tasks,right=('palm',rp,rR)),'right',*a,**kw)
        c.ik.solve=keep_right
        try:
            high=lp.copy();high[2]=max(lp[2],1.15)
            c.event('stack_push_raise_index_before_wrist_turn')
            hands({'left':('palm',high,lR)},seconds=2.,feedback=.5)
            if hand_pose('left')[0][2]<1.08:raise RuntimeError('stack pusher: unloaded wrist did not clear the table before turning')
            c.event('stack_push_turn_index_at_safe_height')
            hands({'left':('palm',goal,rotation)},seconds=2.,feedback=.5)
            correction=np.zeros(3);rotation_correction=np.zeros(3)
            for _ in range(250):
                actual,actual_R=hand_pose('left')
                error=goal-actual;rv=Rotation.from_matrix(rotation@actual_R.T).as_rotvec()
                if np.linalg.norm(error)<.004 and np.linalg.norm(rv)<.025:break
                correction=np.clip(correction+np.clip(.04*error,-.0003,.0003),-.06,.06)
                rotation_correction=np.clip(rotation_correction+np.clip(.02*rv,-.001,.001),-.15,.15)
                reach({'left':('palm',goal+correction,Rotation.from_rotvec(rotation_correction).as_matrix()@rotation)},feedback=.5,iters=24);c.step()
            actual,actual_R=hand_pose('left')
            c.event('stack_push_actual_index_hover',position=actual.tolist(),target=goal.tolist(),position_error=float(np.linalg.norm(actual-goal)),rotation_error=float(np.linalg.norm(Rotation.from_matrix(rotation@actual_R.T).as_rotvec())),position_correction=correction.tolist())
            if np.linalg.norm(actual-goal)>.008 or np.linalg.norm(Rotation.from_matrix(rotation@actual_R.T).as_rotvec())>.04:
                raise RuntimeError('stack pusher: actual high approach did not reach the index branch')
        finally:c.ik.solve=saved

    def shaped_reach(tasks,*a,**kw):
        if tasks.get('left',(None,))[0]=='thumb':
            fraction=float(np.clip((.36-tasks['left'][1][1])/.14,0.,1.))
            c.q[c.index['left_hand_index_0_joint']]=-.25-.65*fraction
        return reach(convert(tasks),*a,**kw)
    c.hand_pose=tip_pose;c.reach=shaped_reach
    c.move_hands=move_hands
    c.ik.solve=solve_index;c.hand_preset=set_hand;c.move_joints=move_joints
    c.event('stack_push_with_index_side_and_measured_wrist_clearance')
    try:return original(c,*args,hover_guard=hover_guard,**kwargs)
    finally:c.hand_pose,c.reach,c.move_hands,c.ik.solve,c.hand_preset,c.move_joints=hand_pose,reach,hands,solve,preset,joints
