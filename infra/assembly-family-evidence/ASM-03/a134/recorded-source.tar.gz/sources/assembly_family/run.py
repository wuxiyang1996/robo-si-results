"""Continuous, monitored expert runs. No source task or historical evidence edits."""
import argparse
import faulthandler
import gzip
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from dataclasses import asdict
import numpy as np

from .contracts import plan, ROOT, VELOCITY_SOURCE, VELOCITY_SHA
from .contact_audit import VERSION as CONTACT_VERSION, geometry_catalog, forbidden, violations
from .source_loading import loaded_bytes,observe_imports

def plain(v):
    if hasattr(v,'detach'):return v.detach().cpu().numpy().tolist()
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [plain(x) for x in v]
    return v

def write(p,v):
    p=Path(p);temporary=p.with_name(p.name+'.writing')
    temporary.write_text(json.dumps(plain(v),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    temporary.replace(p)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def snapshot_loaded(output,snapshots):
    for module in list(sys.modules.values()):
        path=getattr(module,'__file__',None)
        if path and Path(path).suffix=='.py' and Path(path).is_relative_to(ROOT):
            p=Path(path);rel=p.relative_to(ROOT)
            if str(rel) in snapshots:continue
            raw=loaded_bytes(p)
            if raw is None:raise RuntimeError('Task source was not captured at import: '+str(rel))
            target=output/'sources'/rel
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
            snapshots[str(rel)]=hashlib.sha256(raw).hexdigest()
    write(output/'sources.json',snapshots)
    write(output/'source-load-manifest.json',{'method':'compile_and_capture_source_at_import','files':snapshots})


def velocity_limits(names):
    assert sha(VELOCITY_SOURCE)==VELOCITY_SHA
    values={j.get('name'):float(j.find('limit').get('velocity')) for j in ET.parse(VELOCITY_SOURCE).iter('joint')
            if j.find('limit') is not None and j.find('limit').get('velocity')}
    return np.array([values[n] for n in names])

class Monitor:
    def __init__(self,env,output,contract):
        self.e=env;self.out=output;self.contract=contract;self.controller=None
        self.dt=getattr(env,'sim_dt',.0025 if contract['family']=='GEAR' else .005)
        from humanoid.g1_tabletop.genesis_env import JOINT_NAMES
        self.names=list(JOINT_NAMES);self.velocity=velocity_limits(self.names)
        self.steps=0;self.controls=[];self.phases=[];self.high=[];self.events=[];self.mapping=[]
        self.q=[];self.qd=[];self.times=[];self.physq=[];self.physqd=[];self.tau=[]
        self.trace=gzip.open(output/'physics.jsonl.gz','wt',encoding='utf8')
        self.low=open(output/'low_plan.jsonl','w',encoding='utf8')
        self.live_events=open(output/'events-live.jsonl','w',encoding='utf8')
        self.actions=gzip.open(output/'action_plan.jsonl.gz','wt',encoding='utf8')
        self.contact_trace=gzip.open(output/'contacts.jsonl.gz','wt',encoding='utf8')
        self.control_start=[];self.control_end=[]
        self.guards=[];self.violations=[];self.last_torque=np.zeros(len(self.names));self.forbidden_contacts=[]
        self.step0=env.scene.step;self.force0=env.robot.control_dofs_force
        self.control0=env.step_targets
        self.update0=env.evaluator.update
        self.high_id=contract['high_level'][0]['id']
        self.contact_peaks={};self.contact_peak_context={}
        self.qlo=np.asarray(plain(env.lo));self.qhi=np.asarray(plain(env.hi));self.max_overrun=0.;self.overrun_joint=None;self.max_speed_ratio=0.
        self.robot_links={link.idx:link.name for link in env.robot.links}
        self.robot_geoms=geometry_catalog(env.robot);self.geom_peaks={}
        write(output/'robot_collision_geometries.json',self.robot_geoms)
        self.owners=dict(env.link_owners)
        from humanoid.g1_support_retrieval.solution.step_up.video import VideoWriter
        self.video=VideoWriter(output/'video.mp4',fps=5)
        self.frame_count=0;self.next_frame=0.;self.started=time.time()
        write(output/'config.json',asdict(env.cfg))
        import genesis,torch,platform
        from humanoid.g1_tabletop.genesis_env import anchored_robot_xml
        body_path=anchored_robot_xml()
        provenance={'python':platform.python_version(),'genesis':getattr(genesis,'__version__',None),'torch':torch.__version__,
                    'body_file':str(body_path),'body_sha256':sha(body_path),'rigid_options':env.scene.rigid_solver._options.model_dump()}
        (output/'runtime.json').write_text(json.dumps(plain(provenance),default=str,indent=2)+'\n')
        write(output/'initial_state.json',self.state())
        write(output/'environment.json',{'physics':getattr(env,'physics_metadata',{}),'specs':getattr(env,'specs',{}),'base_position':env.base_position,'body_model':contract['implementation_body']})
        write(output/'limits.json',{'names':self.names,'lo':plain(env.lo),'hi':plain(env.hi),
                'effort':plain(env.effort),'velocity':self.velocity,'physics_dt':self.dt})

    def state(self):return self.e.state() if self.contract['family']=='ASM' else self.e.trusted_state()

    def guard(self,obj,name):
        if not hasattr(obj,name):return
        value=getattr(obj,name);owned=name in obj.__dict__
        def deny(*a,**kw):
            self.violations.append({'method':name,'step':self.steps});raise RuntimeError('Forbidden runtime state/parameter write: '+name)
        setattr(obj,name,deny);self.guards.append((obj,name,value,owned))

    def start(self):
        from humanoid.g1_gear_assembly.solution.recording import EpisodeAudit
        for entity in self.e.scene.entities:
            for name in EpisodeAudit.ENTITY_METHODS+('set_friction','set_mass','set_dofs_kp','set_dofs_kv','set_dofs_damping','set_dofs_stiffness'):self.guard(entity,name)
        for obj,names in [(self.e,['reset']),(self.e.scene,['reset','set_state','add_entity']),
                          (self.e.scene.rigid_solver,['set_state','add_weld_constraint','delete_weld_constraint'])]:
            for name in names:self.guard(obj,name)
        def force(torque,*a,**kw):
            self.last_torque=np.asarray(plain(torque));return self.force0(torque,*a,**kw)
        self.e.robot.control_dofs_force=force
        def scene_step(*a,**kw):
            result=self.step0(*a,**kw);self.steps+=1
            q=np.asarray(plain(self.e.robot.get_dofs_position(self.e.dofs)))
            v=np.asarray(plain(self.e.robot.get_dofs_velocity(self.e.dofs)))
            self.physq.append(q);self.physqd.append(v);self.tau.append(self.last_torque.copy())
            overrun=np.maximum(self.qlo-q,q-self.qhi);j=int(np.argmax(overrun))
            if overrun[j]>self.max_overrun:self.max_overrun=float(overrun[j]);self.overrun_joint=self.names[j]
            self.max_speed_ratio=max(self.max_speed_ratio,float(np.max(np.abs(v)/self.velocity)))
            contacts=self.e.robot.get_contacts()
            contact_rows=[]
            for la,lb,ga,gb,force in zip(plain(contacts['link_a']),plain(contacts['link_b']),plain(contacts['geom_a']),plain(contacts['geom_b']),plain(contacts['force_a'])):
                la,lb=int(la),int(lb)
                if la in self.robot_links and lb in self.robot_links:continue
                robot,other=(la,lb) if la in self.robot_links else (lb,la)
                if robot not in self.robot_links:continue
                link=self.robot_links[robot];owner=self.owners.get(other,'fixed_environment')
                magnitude=float(np.linalg.norm(force));key=link+'|'+owner
                geom=int(ga if la in self.robot_links else gb);geom_key=str(geom)+'|'+owner
                contact_rows.append([geom,owner,magnitude])
                self.geom_peaks[geom_key]=max(magnitude,self.geom_peaks.get(geom_key,0.))
                if magnitude>self.contact_peaks.get(key,0.):
                    self.contact_peaks[key]=magnitude
                    self.contact_peak_context[key]={'time':self.steps*self.dt,'phase':self.controller.phase,'high_level':self.high_id}
            self.contact_trace.write(json.dumps({'step':self.steps,'contacts':contact_rows},separators=(',',':'),allow_nan=False)+'\n')
            return result
        self.e.scene.step=scene_step
        def update(state,dt):
            result=self.update0(state,dt)
            self.trace.write(json.dumps({'step':self.steps,'time':self.steps*self.dt,'state':plain(state),
                    'stage':result.get('stage'), 'status':result},separators=(',',':'),allow_nan=False)+'\n')
            return result
        self.e.evaluator.update=update
        def control(target):
            margin=self.contract.get('joint_target_interior_margin',0.)
            lo,hi=np.asarray(plain(self.e.lo)),np.asarray(plain(self.e.hi))
            target=np.asarray(target).copy()
            if self.contract.get('joint_limit_damping'):
                q=np.asarray(plain(self.e.robot.get_dofs_position(self.e.dofs)))
                v=np.asarray(plain(self.e.robot.get_dofs_velocity(self.e.dofs)))
                hand_mask=np.array(['_hand_' in n for n in self.names])
                near_high=hand_mask&(q>hi-.12)&(v>0);near_low=hand_mask&(q<lo+.12)&(v<0)
                # Proprioceptive braking through the same joint-target API.
                # Gains/effort/friction and physics are unchanged.
                target[near_high]=np.minimum(target[near_high],(q-.10*v)[near_high])
                target[near_low]=np.maximum(target[near_low],(q-.10*v)[near_low])
            if margin:target=np.clip(target,lo+margin,hi-margin)
            if self.contract['family']=='ASM' and self.high_id in ('support','sleeve','cap'):
                self.high_id=['support','sleeve','cap'][min(2,self.e.status.get('stage',0))]
            self.actions.write(json.dumps({'action_id':len(self.controls),'physics_start':self.steps,'high_level':self.high_id,'phase':self.controller.phase,'target_q':plain(target)},allow_nan=False)+'\n');self.actions.flush()
            self.control_start.append(self.steps)
            result=self.control0(target)
            self.control_end.append(self.steps)
            self.controls.append(np.asarray(plain(target)));self.q.append(np.asarray(plain(self.e.robot.get_dofs_position(self.e.dofs))))
            self.qd.append(np.asarray(plain(self.e.robot.get_dofs_velocity(self.e.dofs))))
            self.times.append(self.steps*self.dt);self.phases.append(self.controller.phase if self.controller else 'init');self.high.append(self.high_id)
            now=self.steps*self.dt
            if now+1e-8>=self.next_frame:
                from PIL import Image
                frame=np.asarray(Image.fromarray(self.e.render()).resize((640,450)))
                self.video.append_data(frame);self.frame_count+=1;self.next_frame=now+.2
            if len(self.controls)%10==0:
                self.trace.flush()
                faulthandler.dump_traceback_later(180,repeat=True)
                write(self.out/'heartbeat.json',{'time':now,'stage':self.e.status.get('stage'),'phase':self.phases[-1],
                    'completed':self.e.status.get('completed',[]),'credited_angles_rad':self.e.status.get('credited_angles_rad'),
                    'wall_seconds':time.time()-self.started,'physics_steps':self.steps,'commands':len(self.controls),
                    'max_joint_overrun':self.max_overrun,'max_position_joint':self.overrun_joint,'max_velocity_ratio':self.max_speed_ratio,
                    'forbidden_contact_peak':max((v for k,v in self.geom_peaks.items() if forbidden(self.robot_geoms[k.split('|')[0]],k.split('|')[1])),default=0.),'contact_audit_version':CONTACT_VERSION})
            if self.contract.get('stop_on_physics_violation'):
                bad_contacts=violations(self.geom_peaks,self.robot_geoms)
                if self.max_overrun>.001 or self.max_speed_ratio>1.001 or bad_contacts:
                    raise RuntimeError(f'Physical audit early stop: joint={self.overrun_joint}, overrun={self.max_overrun:.6f}, speed={self.max_speed_ratio:.4f}, contacts={bad_contacts}')
            return result
        self.e.step_targets=control

    def instrument(self,c):
        self.controller=c
        def event(phase,**metadata):
            c.phase=phase;c.events.append(dict(phase=phase,time=self.steps*self.dt,**metadata))
            self.live_events.write(json.dumps(plain(c.events[-1]),allow_nan=False)+'\n');self.live_events.flush()
        c.event=event
        for name in ['move_hands','move_joints','hold']:
            original=getattr(c,name)
            def call(*args,_name=name,_fn=original,**kwargs):
                # Parameterized motion is frozen before its first control action.
                index=len(self.mapping);start=len(self.controls)
                row={'segment_id':index,'high_level':self.high_id,'primitive':_name,'phase':c.phase,
                     'args':plain(args),'kwargs':plain(kwargs),'start_step':start,'entry_state':self.state()}
                self.low.write(json.dumps(row,allow_nan=False)+'\n');self.low.flush()
                self.mapping.append(dict(row,end_step=None))
                try:return _fn(*args,**kwargs)
                finally:
                    self.mapping[index].update(end_step=len(self.controls),exit_state=self.state())
            setattr(c,name,call)
        original=c.move_joints
        def slow(target,seconds=1.):
            speed_scale=np.array([self.contract.get('hand_speed_scale',.45) if '_hand_' in name else .45 for name in self.names])
            needed=1.875*float(np.max(np.abs(np.asarray(target)-c.q)/(speed_scale*self.velocity)))
            return original(target,seconds=max(seconds,needed))
        c.move_joints=slow

    def finish(self,error):
        self.trace.close();self.low.close();self.actions.close();self.live_events.close();self.contact_trace.close()
        try:self.video.close()
        except Exception:
            video_error=traceback.format_exc();write(self.out/'video_error.json',{'error':video_error})
            error=(error or '')+'\nVideo finalization failed: '+video_error
        self.e.scene.step=self.step0;self.e.robot.control_dofs_force=self.force0
        self.e.step_targets=self.control0;self.e.evaluator.update=self.update0
        for obj,name,value,owned in reversed(self.guards):
            if owned:setattr(obj,name,value)
            else:delattr(obj,name)
        np.savez_compressed(self.out/'trajectory.npz',target_q=self.controls,q=self.q,qd=self.qd,time=self.times,
                phase=np.array(self.phases),high_level=np.array(self.high),physics_q=self.physq,physics_qd=self.physqd,
                physics_torque=self.tau,control_physics_start=self.control_start,control_physics_end=self.control_end)
        write(self.out/'mapping.json',self.mapping)
        write(self.out/'events.json',self.controller.events if self.controller else [])
        bad_contacts=violations(self.geom_peaks,self.robot_geoms)
        write(self.out/'contact_summary.json',{'audited':True,'version':CONTACT_VERSION,'per_physics_step':True,'peak_force_n':self.contact_peaks,'geometry_peak_force_n':self.geom_peaks,'peak_context':self.contact_peak_context,'forbidden':bad_contacts})
        write(self.out/'execution.json',{'final_status':self.e.status,'physics_steps':self.steps,'control_steps':len(self.controls),
             'error':error,'api_violations':self.violations,'video_frames':self.frame_count,'video_fps':5,
             'real_time_claim':False,'wall_seconds':time.time()-self.started,'job_id':os.environ.get('SLURM_JOB_ID')})
        from PIL import Image
        Image.fromarray(self.e.render()).save(self.out/'final.png')

def run(task,output,policy=None,backend='gpu',joint_margin=0.,joint_limit_damping=False,hand_speed_scale=.45,stop_on_physics_violation=False):
    if not np.isfinite(hand_speed_scale) or not .02<=hand_speed_scale<=.45:raise ValueError('hand_speed_scale must be in [.02,.45]')
    if not np.isfinite(joint_margin) or not 0<=joint_margin<=.10:raise ValueError('joint margin must be in [0, .10] rad')
    faulthandler.dump_traceback_later(180,repeat=True)
    output=Path(output).resolve();output.mkdir(parents=True,exist_ok=False)
    contract=plan(task);contract['contact_audit_version']=CONTACT_VERSION;contract['backend']=backend;contract['stop_on_physics_violation']=stop_on_physics_violation;contract['policy_entry']=policy or task.lower().replace('-','_');contract['hand_speed_scale']=hand_speed_scale;contract['joint_target_interior_margin']=joint_margin;contract['joint_limit_damping']=joint_limit_damping;contract['damping_scope']='hand joints only';write(output/'plan.json',contract)
    contract['source_recording']='import_bytes_v1';write(output/'plan.json',contract)
    if policy=='gear_handoff':
        contract['high_level'][1]['low_level']=['rim_grasp','extract','flip_with_receiver_ready','hub_handoff','reseat','release_check']
        write(output/'plan.json',contract)
    if policy=='gear_late_handoff':
        contract['high_level'][1]['low_level']=['prepare_receiving_fingers','rim_grasp','extract','flip','jointly_reachable_hub_handoff','reseat','release_check']
        write(output/'plan.json',contract)
    if policy in ('gear_table_pivot','gear_table_pivot_settled_drive','gear_table_pivot_top_drive','gear_table_pivot_soft_top_drive','gear_table_pivot_supported_top_drive','gear_table_pivot_gentle_top_drive','gear_parallel_top_drive'):
        contract['high_level'][1]['low_level']=['rim_grasp','axis_aligned_extraction','explicit_quarter_turn','lower_rim_to_clear_table','verify_actual_table_support','tip_five_degrees_past_vertical','release_and_withdraw','verify_upright_released_gear','regrasp_hub','reseat_and_verify_original_repair']
        write(output/'plan.json',contract)
    if policy=='gear_table_pivot_settled_drive':
        for stage in contract['high_level']:
            if stage['id']=='drive':stage['low_level']=['actual_converged_tool_grasp','measured_lift_check','raise_tooth_tip_four_mm_above_original_path','settle_each_drive_waypoint','ten_bounded_strokes','verify_original_support_contact_and_angle','park_and_release']
        write(output/'plan.json',contract)
    if policy in ('gear_table_pivot_top_drive','gear_table_pivot_soft_top_drive','gear_table_pivot_supported_top_drive','gear_table_pivot_gentle_top_drive','gear_parallel_top_drive'):
        for stage in contract['high_level']:
            if stage['id']=='drive':stage['low_level']=['actual_tool_grasp_and_lift','choose_actual_solid_tooth_face_and_hover_outside_hub_lip','measure_real_downward_contact_force','wait_original_repaired_assembly_credit','bounded_loaded_sweep','lift_tool_after_each_sweep','verify_original_transmission_angle_and_contacts','park_and_release']
        write(output/'plan.json',contract)
    if policy=='gear_unhook':
        contract['high_level'][1]['low_level']=['rim_grasp','axis_aligned_extraction','flip','balanced_pad_release_with_concurrent_palm_retreat','withdraw_supporting_hand','verify_upright_table_support','regrasp_hub','reseat','release_check']
        write(output/'plan.json',contract)
    if policy=='gear_handle_pivot':
        contract['high_level'][1]['low_level']=['rim_grasp','axis_aligned_extraction','complete_physical_flip','choose_existing_positive_y_base_handle','quarter_turn','lower_rim_to_handle','verify_support','pivot_beyond_centre_of_mass','release_outwards_to_table','verify_upright_support','regrasp_hub','reseat','release_check']
        write(output/'plan.json',contract)
    if policy=='gear_regrasp':
        stage=next(x for x in contract['high_level'] if x['id']=='drive')
        stage['low_level']=['park_idle_arm','grasp_tool','two_drive_strokes','park_and_release_tool','regrasp','repeat_up_to_four_cycles','verify_original_transmission_predicate']
        write(output/'plan.json',contract)
    if policy in ('asm_edge','asm_edge_handoff','asm_direct_edge'):
        contract['high_level'][0]['low_level']=['inspect_table_edge_clearance','push_shim_with_fingers','edge_grasp_and_lift_check','table_supported_handoff','left_edge_grasp','stack_on_stand','release_check']
        if policy in ('asm_edge_handoff','asm_direct_edge'):contract['high_level'][0]['low_level']=['push_to_table_front','right_supported_quarter_turn','park_right_hand','left_long_edge_undergrasp','lift_check','collision_checked_level_carry','bounded_stack_release','withdraw_and_verify_support']
        if policy=='asm_direct_edge':contract['high_level'][0]['low_level'][:2]=['direct_supported_pinch','slide_front_then_quarter_turn_clear_of_cap']
        write(output/'plan.json',contract)
    if policy in ('asm_staged_stack','asm_index_stack','asm_index_direct_stack','asm_index_natural_stack','asm_cleared_natural_stack','asm_cleared_fast_stack'):
        contract['high_level'][0]['goal']='Move the empty stand beside the jig, then physically stack and release the shim there'
        contract['high_level'][0]['low_level']=['grasp_empty_stand','carry_and_release_at_staging','verify_table_support','push_shim_to_front','supported_quarter_turn_on_right','table_supported_cross_to_left','verify_released_receiving_side_support','left_push_with_measured_distal_contacts','long_edge_undergrasp','collision_checked_carry_to_staged_stand','open_and_withdraw','verify_released_stack']
        contract['high_level'][1]['low_level']=['verify_staged_composition','press_fixture','table_supported_push_of_stack','release_and_check_original_load_path']
        if policy in ('asm_index_stack','asm_index_direct_stack','asm_index_natural_stack','asm_cleared_natural_stack','asm_cleared_fast_stack'):contract['high_level'][1]['low_level']=['verify_staged_composition','press_fixture','index_side_preshape','screen_dual_hand_approach','increase_wrist_height_during_push','measured_table_supported_push','release_and_check_original_load_path']
        if policy=='asm_index_direct_stack':contract['high_level'][0]['low_level']=['stage_and_release_empty_stand','push_shim_to_front','right_table_supported_quarter_turn','high_park_left','right_own_side_undergrasp','measured_lift_check','collision_checked_high_carry','open_and_withdraw','verify_released_stack']
        if policy in ('asm_index_natural_stack','asm_cleared_natural_stack','asm_cleared_fast_stack'):contract['high_level'][0]['low_level']=['stage_and_release_empty_stand','push_shim_front_without_turning','high_park_left','protected_right_front_undergrasp','measured_lift_check','collision_checked_level_carry_without_yaw_change','open_and_withdraw','verify_released_stack']
        if policy in ('asm_cleared_natural_stack','asm_cleared_fast_stack'):
            contract['high_level'][0]['low_level'][:0]=['raise_unloaded_hands','slide_sleeve_forward_with_table_support','verify_released_upright_sleeve_and_untouched_support_parts']
            contract['cartesian_motion_duration_scale']=.60 if policy=='asm_cleared_fast_stack' else .70
            if policy=='asm_cleared_fast_stack':contract['planned_joint_rates_rad_s']={'loaded':.35,'unloaded':1.};contract['support_push_steps']=350
            contract['duration_exceptions']=['initial_ready','joint_space_transitions','fixed_contact_feedback_loops','dwell_checks']
            for stage in contract['high_level']:
                if stage['id']=='sleeve':stage['low_level'][:0]=['screen_continuous_grasp_lift_and_insertion_branch','collision_checked_unloaded_approach']
        write(output/'plan.json',contract)
    if policy=='asm_sleeve_slide_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='Original-scene supported sleeve slide and released clearance check; no support assembly or complete task claim'
        contract['high_level']=[{'id':'compose_support','goal':'Clear the actual sleeve from the later support-pushing route','low_level':['raise_unloaded_hands','positive_elbow_posture','side_contact_approach','table_supported_slide','withdraw','verify_released_upright_support_and_untouched_loose_parts']}]
        write(output/'plan.json',contract)
    if policy=='asm_sleeve_clear_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='Relocate the original sleeve to clear the stand route; not complete assembly'
        contract['high_level']=[{'id':'compose_support','goal':'Remove the actual sleeve obstruction with its existing physical grasp','low_level':['raise_hands','park_idle_arm','grasp_sleeve','measured_lift_check','carry_to_front_corridor','set_down','release_check','return_unloaded_hand']}]
        write(output/'plan.json',contract)
    if policy=='asm_stack_push':
        contract['high_level'][0]['goal']='Stack and release the shim on the nearby stand'
        contract['high_level'][0]['low_level']=['push_shim_to_front','supported_quarter_turn','long_edge_undergrasp','near_stand_carry','open_and_withdraw','verify_released_stack']
        contract['high_level'][1]['low_level']=['push_lower_stand_west_clear_of_sleeve','verify_real_two_body_support','push_lower_stand_north_to_staging_y','verify_released_stack','complete_west_alignment','press_fixture','push_stack_under_fixture','verify_original_load_path']
        write(output/'plan.json',contract)
    if policy in ('asm_slide','asm_pinch_slide'):
        contract['high_level'][0]['low_level']=['push_shim_to_front','slide_with_table_support','park_right_hand','left_edge_grasp','stack_on_stand','release_check']
        if policy=='asm_pinch_slide':contract['high_level'][0]['low_level']=['push_shim_to_front','right_pinch_slide_with_quarter_turn','park_right_hand','collision_checked_left_approach','left_reversed_pinch','lift_check','collision_checked_carry_past_fixture_and_post','level_carry_directly_above_stand','half_turn_stack_setdown','release_check']
        write(output/'plan.json',contract)
    if policy in ('ref_board_probe','ref_board_place_probe','ref_right_probe'):
        component='bottom_shelf' if policy.startswith('ref_board') else 'right_frame'
        steps=(['side_grasp','clear_rack_beam','extract_horizontally','lift_check','return_to_rack','release']
               if policy=='ref_board_probe' else ['near_upright_grasp','lift_check','reorient','hold_check'])
        if policy=='ref_board_place_probe':steps=['side_grasp','clear_rack_beam','extract_horizontally','lift_check','rotate','table_edge_set_down','release_check']
        contract['run_kind']='component_probe'
        contract['evidence_scope']='Fresh original scene, one component diagnostic; not a complete shelf solution'
        contract['high_level']=[{'id':component,'goal':'Test physical manipulation of '+component,'low_level':steps}]
        write(output/'plan.json',contract)
    if policy in ('ref_fixture_probe','ref_fixture_slide_probe'):
        contract['run_kind']='component_probe';contract['evidence_scope']='Fixture handling diagnostic in the original REF-02 scene; not a complete assembly'
        contract['high_level']=[{'id':'deploy_fixture','goal':'Verify fixture grasp and released relocation','low_level':['fitted_grasp','lift_check','relocate','set_down','release_check']}]
        if policy=='ref_fixture_slide_probe':contract['high_level'][0]['low_level']=['fitted_grasp','slide_with_table_support','support_check','release_check']
        write(output/'plan.json',contract)
    if policy=='ref_frame_pivot_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='Table-supported frame pivot and handoff diagnostic; not a complete shelf solution'
        contract['high_level']=[{'id':'right_frame','goal':'Expose the upper rail and transfer a physical grasp','low_level':['push_to_front_overhang','near_post_grasp','partial_pivot','upper_rail_handoff','lift','reorient_check']}]
        write(output/'plan.json',contract)
    if policy in ('ref_crossbar_probe','ref_crossbar_table_probe','ref_crossbar_top_probe','ref_crossbar_vertical_probe','ref_crossbar_side_handoff_probe'):
        contract['run_kind']='component_probe';contract['evidence_scope']='Exposed carrier grasp and orientation diagnostic; not a complete shelf solution'
        contract['high_level']=[{'id':'lower_crossbar','goal':'Acquire and rotate an exposed interchangeable carrier','low_level':['select_highest_supply','near_end_tie_grasp','supported_forward_slide','withdraw_while_opening','released_support_check','horizontal_end_tie_regrasp','lift_check','reorient_check']}]
        write(output/'plan.json',contract)
    if policy in ('ref_crossbar_table_probe','ref_crossbar_top_probe','ref_crossbar_vertical_probe','ref_crossbar_side_handoff_probe'):
        contract['high_level']=[{'id':'left_frame','goal':'Assemble the required first frame to clear its supply area','low_level':['grasp','reorient','seat','release']},{'id':'lower_crossbar','goal':'Extract onto the table and acquire its central rail','low_level':['end_tie_grasp','pull_clear_of_rack','release_to_table','verify_flat_support','central_rail_regrasp','lift','reorient_check']}]
        write(output/'plan.json',contract)
        if policy in ('ref_crossbar_top_probe','ref_crossbar_vertical_probe','ref_crossbar_side_handoff_probe'):
            contract['high_level'][1]['goal']='Extract an exposed carrier and test the original frame-style top rail grasp'
            contract['high_level'][1]['low_level']=['end_tie_grasp','pull_clear_of_rack','release_to_table','verify_flat_support','top_hook_grasp_of_long_rail','vertical_lift','measured_hold_check']
            write(output/'plan.json',contract)
        if policy in ('ref_crossbar_vertical_probe','ref_crossbar_side_handoff_probe'):
            contract['high_level'][1]['low_level']+=['lift_hanging_carrier_above_obstacles','yaw_while_suspended','verify_measured_vertical_carry']
            write(output/'plan.json',contract)
        if policy=='ref_crossbar_side_handoff_probe':
            contract['high_level'][1]['low_level']+=['move_to_screened_full_joint_workspace','prioritize_loaded_left_grasp_in_bounded_ik','screen_complete_loaded_receiver_path_for_self_and_part_collisions','measured_donor_pose_feedback_during_receiver_motion','side_receiver_approach','verify_right_contacts','release_left','plan_carried_geometry_around_robot_and_scene','guard_actual_clearance_during_low_side_flattening','measured_hold_check']
            write(output/'plan.json',contract)
    if policy=='ref_idle_high_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='Empty-hand rack clearance and joint-limit diagnostic; no assembly completion'
        contract['high_level']=[{'id':'clearance','goal':'Check high idle-arm postures during shared-waist turns','low_level':['raise_hands','fold_elbows','park_wrist_above_rack','waist_sweep','measure_clearance_and_audit_contacts']}]
        write(output/'plan.json',contract)
    if policy in ('ref_crossbar_tilt_probe','ref_constrained_tilt_probe'):
        contract['run_kind']='component_probe'
        contract['evidence_scope']='Two frames and one gravity-leveled carrier diagnostic; five shelf parts remain unassembled'
        contract['high_level']=[
            {'id':'left_frame','goal':'Install and release the first frame','low_level':['rail_grasp','reorient','seat','release_check']},
            {'id':'right_frame','goal':'Install and release the second frame','low_level':['near_post_pivot','rail_handoff','reorient','seat','release_check']},
            {'id':'lower_crossbar','goal':'Tilt the exposed carrier between the two frames and release onto real supports','low_level':['extract_to_table','top_hook_grasp','vertical_carry','tilt_outside_assembly','descend_in_front','enter_lower_gap','verify_both_frame_contacts','open_and_withdraw','verify_original_released_predicate']}]
        write(output/'plan.json',contract)
    if policy in ('ref_crossbar_fitted_probe','ref_crossbar_fitted_integrated_probe','ref_crossbar_parallel_probe'):
        contract['run_kind']='component_probe'
        contract['evidence_scope']='One frame and horizontal carrier grasp/transfer diagnostic; not complete assembly'
        contract['high_level']=[{'id':'left_frame','goal':'Install the first frame','low_level':['rail_grasp','reorient','seat','release']},
            {'id':'lower_crossbar','goal':'Extract the exposed carrier and maintain a horizontal fitted top grasp','low_level':['end_tie_grasp','pull_clear_of_supply','release_to_table','fit_top_grasp_along_long_rail','screen_self_clear_hover','lift_with_measured_contact','flat_yaw_and_transfer','check_actual_pose_and_contact']}]
        if policy=='ref_crossbar_parallel_probe':
            contract['high_level'][1]['low_level']=['extract_and_release_exposed_carrier','select_overhanging_rail_segment','screen_hover','converge_measured_palm_before_closure','parallel_pad_feedback','lift_without_changing_pad_angle','verify_horizontal_hold','flat_yaw_and_transfer','check_actual_pose_and_contact']
        if policy=='ref_crossbar_fitted_integrated_probe':
            contract['evidence_scope']='Two installed frames followed by a held horizontal carrier transfer; not complete assembly'
            contract['high_level'].insert(1,{'id':'right_frame','goal':'Install and release the second frame','low_level':['near_post_pivot','measured_rail_handoff','reorient','seat','release']})
        write(output/'plan.json',contract)
    if policy=='ref_frame_hang_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='One frame gravity orientation and insertion diagnostic; not complete shelf assembly'
        contract['high_level']=[{'id':'left_frame','goal':'Keep a top bar pinch while gravity orients the frame, then insert it','low_level':['cradle_top_bar_grasp','high_lift_with_fixed_wrist','verify_gravity_orientation_and_load','measured_slot_hover','align_and_insert_feet','seat','release_and_original_predicate_check']}]
        write(output/'plan.json',contract)
    if policy in ('ref_frames_gravity_probe','ref_constrained_gravity_probe'):
        contract['run_kind']='component_probe';contract['evidence_scope']='Two frames installed through measured gravity orientation; six shelf parts remain unassembled'
        contract['high_level']=[{'id':name,'goal':'Gravity orient and install '+name,'low_level':['clear_idle_hand','stage_rail_if_right','fit_fine_rail_pinch_if_right','lift_flat_until_table_clear_if_right','change_to_cradle_above_table_if_right','high_lift_fixed_wrist','verify_upright_load','measured_slot_transfer','align_insert_release','check_original_predicate']} for name in ('left_frame','right_frame')]
        if policy=='ref_constrained_gravity_probe':contract['high_level'].insert(0,{'id':'deploy_fixture','goal':'Clear the actual fixture from the constrained frame supply route','low_level':['grasp_fixture','table_slide','release_and_verify']})
        write(output/'plan.json',contract)
    if policy in ('ref_crossbar_bimanual_probe','ref_crossbar_bimanual_clearance_probe','ref_crossbar_table_pivot_probe'):
        contract['run_kind']='component_probe';contract['evidence_scope']='One installed frame, table staging and balanced carrier lift/transfer; not complete assembly'
        contract['high_level']=[{'id':'left_frame','goal':'Install the first frame','low_level':['grasp','reorient','insert','release']},
            {'id':'lower_crossbar','goal':'Use table support to stage the carrier, then balance its load across both end ties','low_level':['extract_and_release_to_table','far_end_tie_grasp','table_drag_and_half_turn','verify_real_table_support','second_hand_acquisition_with_loaded_hand_projection','verify_both_hand_contacts','flat_lift','flat_transfer_check']}]
        write(output/'plan.json',contract)
    if policy=='ref_crossbar_supply_pair_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='One installed frame, supported carrier extraction, lateral table slide, and measured balanced lift; no carrier placement or complete assembly claim'
        contract['high_level']=[{'id':'left_frame','goal':'Install and release first frame','low_level':['grasp','reorient','insert','release']},{'id':'lower_crossbar','goal':'Acquire both real end ties while the near tie overhangs the table','low_level':['extract_to_table','force_controlled_near_tie_pinch','fixed_wrist_edge_lift','lateral_table_slide','loaded_hand_projected_far_tie_acquisition','measure_two_hand_contact','balanced_lift_check']}]
        write(output/'plan.json',contract)
    if policy=='ref_crossbar_near_table_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='One installed frame plus supported carrier extraction, table translation, turn and released staging; no carrier assembly or balanced lift claim'
        contract['high_level']=[{'id':'left_frame','goal':'Install and release the first frame','low_level':['grasp','reorient','insert','release']},
            {'id':'lower_crossbar','goal':'Stage the carrier using a free near-tie hook and real table support','low_level':['extract_to_table','converged_near_tie_pinch','hook_in_front_overhang','fixed_wrist_edge_lift','translate_and_turn_with_passive_payload_roll','release_above_table','verify_released_flat_table_support']}]
        write(output/'plan.json',contract)
    if policy=='ref_crossbar_table_pivot_probe':
        contract['high_level'][1]['low_level']=['extract_and_release_to_table','park_idle_hand_high','far_end_tie_parallel_pinch','tip_front_edge_about_real_table_pivot','translate_inboard_before_turn','turn_while_front_edge_is_raised','cross_midline_inside_table_boundary','flatten_on_table','acquire_second_end_tie','verify_real_bimanual_lift_and_transfer']
        write(output/'plan.json',contract)
    if policy=='ref_fixture_use_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='One measured released frame/fixture load path; second use and full assembly remain unverified'
        contract['high_level']=[{'id':'deploy_fixture','goal':'Relocate the support on the table','low_level':['fitted_grasp','table_slide','release_check']},{'id':'left_frame','goal':'Establish an original measured fixture-use predicate','low_level':['rail_grasp','lift','align_with_fixture','lower','release','verify_support_dwell']}]
        write(output/'plan.json',contract)
    if policy in ('ref_fixture_recover_probe','ref_fixture_fast_probe'):
        contract['run_kind']='component_probe';contract['evidence_scope']='One credited fixture use followed by installation of the same left frame; second use and complete shelf remain pending'
        contract['high_level']=[{'id':'deploy_fixture','goal':'Establish a released left-frame load and slide the support out of the grasp area','low_level':['relocate_fixture','grasp_left_frame','release_on_fixture','verify_original_use_dwell','slide_fixture_clear','verify_released_relocation']},{'id':'left_frame','goal':'Reacquire the exposed upper rail and install the same frame','low_level':['regrasp_upper_rail','lift_check','measured_pose_reorient','settled_transfer_then_faster_aligned_foot_insertion' if policy=='ref_fixture_fast_probe' else 'align_and_insert_feet','release_and_verify']}]
        write(output/'plan.json',contract)
    if policy in ('ref_fixture_two_frames_probe','ref_fixture_two_frames_original_probe'):
        contract['run_kind']='component_probe'
        contract['evidence_scope']='Two frames, two distinct measured uses of the same fixture and parking diagnostic; six shelf parts remain unassembled'
        contract['high_level']=[{'id':'deploy_fixture','goal':'Use the same support at two distinct positions','low_level':['left_frame_fixture_use','install_left_frame','relocate_same_fixture']},{'id':'left_frame','goal':'Install the first frame after real support use','low_level':['reacquire','align','insert','release']},{'id':'right_frame','goal':'Use the moved fixture and install the second frame','low_level':['post_pivot','upper_rail_handoff','reorient','lower_one_foot_onto_fixture','verify_real_contact','release_and_verify_second_use','reacquire','install_and_release']},{'id':'park_fixture','goal':'Return the released support to its original parking region','low_level':['grasp_fixture','table_slide','release_check']}]
        write(output/'plan.json',contract)
    if policy in ('ref_frames_integrated','ref_frames_direct','ref_frames_turn','ref_frames_replay','ref_frames_fast_probe','ref_constrained_frames_probe'):
        contract['run_kind']='component_probe';contract['evidence_scope']='Two-frame continuous assembly diagnostic; six shelf parts remain unassembled'
        contract['high_level']=[{'id':'right_frame','goal':'Assemble and release right frame before left-frame scoring','low_level':['push_to_overhang','partial_pivot','upper_rail_handoff','park_idle_arm','reorient','align_feet','insert','release']},
                                {'id':'left_frame','goal':'Assemble left frame and verify both original slot predicates','low_level':['grasp','lift','reorient','align_feet','insert','release']}]
        if policy=='ref_frames_direct':contract['high_level'][0]['low_level']=['push_to_front','park_idle_arm','direct_upper_rail_grasp','lift_check','reorient','align_feet','insert','release']
        if policy=='ref_frames_turn':contract['high_level'][0]['low_level']=['push_to_front','near_post_grasp','table_supported_quarter_turn','release','overhanging_upper_rail_grasp','lift_check','reorient','align_feet','insert','release']
        if policy in ('ref_frames_replay','ref_frames_fast_probe','ref_constrained_frames_probe'):
            contract['high_level'].reverse()
            contract['high_level'][0]['goal']='Assemble and release the required first frame'
            contract['high_level'][1]['goal']='Assemble right frame after the original left-frame predicate'
        if policy=='ref_constrained_frames_probe':
            contract['high_level'].insert(0,dict(id='deploy_fixture',goal='Slide the obstructing optional fixture away from the measured frame grasp',low_level=['fitted_grasp','table_supported_slide','release_and_verify']))
        write(output/'plan.json',contract)
    write(output/'started.json',{'wall_time':time.time(),'job_id':os.environ.get('SLURM_JOB_ID'),'task_id':task})
    env=mon=None;error=None;snapshots={}
    def persist_import(path,raw):
        if not path.is_relative_to(ROOT):return
        rel=path.relative_to(ROOT);digest=hashlib.sha256(raw).hexdigest()
        if str(rel) in snapshots:
            if snapshots[str(rel)]!=digest:raise RuntimeError('Task source changed across imports: '+str(rel))
            return
        target=output/'sources'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        snapshots[str(rel)]=digest
        write(output/'sources.json',snapshots)
        write(output/'source-load-manifest.json',{'method':'compile_and_capture_source_at_import','files':snapshots})
    remove_import_observer=observe_imports(persist_import)
    contract['source_capture_scope']='persist_every_import_including_policy_lazy_imports';write(output/'plan.json',contract)
    try:
        # Freeze candidate imports and their source bytes before slow scene build.
        from . import policies
        snapshot_loaded(output,snapshots)
        from .portable import make_env
        env=make_env(task,output,backend=backend)
        if hasattr(env,'sensor_cam'):env.sensor_cam=None  # privileged expert; spectator video remains enabled
        if task.startswith('ASM'):
            from humanoid.g1_tabletop_assembly.solution.controller import Controller
        else:
            from humanoid.g1_gear_assembly.solution.controller import Controller
        from . import policies
        fn=getattr(policies,policy or task.lower().replace('-','_'))
        c=Controller(env)
        snapshot_loaded(output,snapshots)
        mon=Monitor(env,output,contract);mon.instrument(c);mon.start()
        fn(c,mon)
    except (Exception,KeyboardInterrupt):
        error=traceback.format_exc();print(error,flush=True);write(output/'error.json',{'error':error})
    finally:
        try:snapshot_loaded(output,snapshots)
        except Exception:
            source_error=traceback.format_exc();write(output/'source_capture_error.json',{'error':source_error})
            error=(error or '')+'\nSource finalization failed: '+source_error
        remove_import_observer()
        if mon:
            try:mon.finish(error)
            except Exception:write(output/'recording_error.json',{'error':traceback.format_exc()})
        if env:env.close()
        faulthandler.cancel_dump_traceback_later()
    if mon:
        import subprocess
        checked=subprocess.run([sys.executable,'-m','assembly_family.verify',str(output)],check=False)
        if checked.returncode:
            write(output/'outcome.json',{'task_id':task,'body':contract['body'],'state':'audit_failed','goal_met':False,'error':'Independent audit failed; inspect error.json, recording_error.json and the Slurm log','verifier_exit_code':checked.returncode})
    else:write(output/'outcome.json',{'state':'setup_failed','goal_met':False,'error':error})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--task',required=True);p.add_argument('--output',required=True)
    p.add_argument('--policy');p.add_argument('--stop-on-physics-violation',action='store_true');p.add_argument('--hand-speed-scale',type=float,default=.45);p.add_argument('--joint-limit-damping',action='store_true');p.add_argument('--joint-margin',type=float,default=0.);p.add_argument('--backend',default='gpu',choices=['cpu','gpu']);a=p.parse_args()
    run(a.task,a.output,a.policy,a.backend,a.joint_margin,a.joint_limit_damping,a.hand_speed_scale,a.stop_on_physics_violation)
