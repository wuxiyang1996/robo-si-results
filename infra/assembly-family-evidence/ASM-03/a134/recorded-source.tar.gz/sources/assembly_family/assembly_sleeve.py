"""Choose a grasp branch that also reaches the sleeve's insertion workspace."""
import numpy as np
from scipy.spatial.transform import Rotation
from .approach_path import move


def approach(c, tasks):
    from humanoid.g1_tabletop_assembly.solution.sleeve import grasp_pose
    palm, rotation = grasp_pose(c)
    c.ik.set_limit('left_wrist_pitch_joint', -1.45, 1.45)
    c.ik.set_limit('left_wrist_yaw_joint', -1.45, 1.45)
    c.ik.set_limit('left_shoulder_roll_joint', .03, 1.5)
    high = np.asarray(tasks['left'][1])
    part = np.asarray(c.object_state('sleeve')['pos'])
    above = np.array([*c.env.cfg.base_center, part[2] + .25]) + palm - part
    insertion = np.array([*c.env.cfg.base_center, c.env.cfg.post_top+c.env.cfg.sleeve_height/2+.012]) + palm-part
    route = [palm, palm+[0, 0, .08], high, palm + [0, 0, .25], above, insertion]
    hover = None
    diagnostics = []; rejected = []
    for yaw, shoulder in [(-1.2, 1.5), (0., 1.5), (-1.8, 1.5), (-1.2, 0.), (0., -1.5)]:
        seed = c.actual_q().copy()
        seed[c.index['waist_yaw_joint']] = yaw
        seed[c.index['left_shoulder_yaw_joint']] = shoulder
        seed[c.index['left_elbow_joint']] = 1.2
        valid = True; candidate_hover = None; diagnostics = []
        for index, goal in enumerate(route):
            start = route[max(0, index-1)]
            for fraction in np.linspace(0., 1., 21):
                point = start + fraction*(goal-start)
                seed, errors = c.ik.solve(c.env.base_position, (1, 0, 0, 0), seed,
                                         {'left': ('palm', point, rotation)},
                                         iters=300, damping=.015, w_rot=.5, max_step=.05)
                angle = float(np.linalg.norm(Rotation.from_matrix(
                    rotation @ c.ik.d.xmat[c.ik.wrist['left']].reshape(3, 3).T).as_rotvec()))
                if errors['left'] > .003 or angle > .03:
                    rejected.append(dict(seed=[yaw, shoulder], segment=index, fraction=float(fraction),
                                         position_error=errors['left'], rotation_error=angle))
                    valid = False; break
            if not valid: break
            diagnostics.append(dict(segment=index, position_error=errors['left'], rotation_error=angle))
            if index == 2: candidate_hover = seed.copy()
        if valid:
            hover = candidate_hover; break
    c.event('sleeve_screened_grasp_and_carry_branch', samples=diagnostics, rejected=rejected)
    if hover is None:
        raise RuntimeError('sleeve: grasp-to-insertion branch is not continuously reachable')
    target = c.q.copy()
    target[c.ik.upper] = hover[c.ik.upper]
    move(c, target, 'left', protected=('brace', 'shim', 'cap'))
