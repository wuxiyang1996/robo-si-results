"""Fit the original brace pinch to the thinner stand using wrist pitch."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_tabletop_assembly.solution import closed_loop


def place(c,staging_y_offset=0.):
    original_hands,original_reach=c.move_hands,c.reach
    pitch=Rotation.from_euler('y',np.deg2rad(10.)).as_matrix()
    def fitted(tasks):
        if c.phase not in ('brace_hover','brace_lower','brace_lift','brace_transfer_feedback'):return tasks
        tasks=dict(tasks)
        if 'left' in tasks:
            kind,p,R=tasks['left'];p=np.asarray(p).copy()
            if c.phase=='brace_lift':p[2]-=.04
            tasks['left']=(kind,p,pitch@R if R is not None else None)
        return tasks
    def hands(tasks,*args,**kwargs):
        # The nested reach calls already receive the fitted hand target.
        c.reach=original_reach
        try:return original_hands(fitted(tasks),*args,**kwargs)
        finally:c.reach=reach
    def reach(tasks,*args,**kwargs):return original_reach(fitted(tasks),*args,**kwargs)
    c.move_hands,c.reach=hands,reach
    c.event('fit_thin_stand_pinch',wrist_pitch_degrees=10.,lift_reduction=.04)
    try:return closed_loop.preposition_brace(c,staging_y_offset=staging_y_offset)
    finally:c.move_hands,c.reach=original_hands,original_reach
