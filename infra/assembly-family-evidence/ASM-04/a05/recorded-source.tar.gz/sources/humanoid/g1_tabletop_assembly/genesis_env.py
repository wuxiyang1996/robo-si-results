"""G1 tool-assisted, staged tabletop assembly entrypoint."""
from humanoid.g1_tabletop.genesis_env import G1TabletopGenesis


class G1TabletopAssemblyGenesis(G1TabletopGenesis):
    def __init__(self, **kwargs):
        super().__init__(task="assembly", **kwargs)
