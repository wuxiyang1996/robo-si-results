"""Convex wooden insertion wedge; all dimensions are physical metres."""
import hashlib
import json
import math
from pathlib import Path

from humanoid.g1_tabletop.assets import _atomic_text


def wedge_geometry(spec):
    length,width,height=map(float,spec['size'])
    tip,ramp=float(spec['tip_height']),float(spec['ramp_length'])
    if not all(math.isfinite(v) and v>0 for v in (length,width,height,tip,ramp)):
        raise ValueError('wedge dimensions must be finite and positive')
    if tip>=height or ramp>=length:
        raise ValueError('wedge tip and ramp must fit the body')
    profile=[(-length/2,-height/2),(length/2,-height/2),
             (length/2,tip-height/2),(length/2-ramp,height/2),(-length/2,height/2)]
    vertices=[(x,y,z) for y in (-width/2,width/2) for x,z in profile]
    faces=[(0,1,2),(0,2,3),(0,3,4),(5,7,6),(5,8,7),(5,9,8)]
    for i in range(5):
        j=(i+1)%5
        faces.extend(((i,i+5,j+5),(i,j+5,j)))
    volume=width*(length*height-.5*ramp*(height-tip))
    return vertices,faces,volume


def write_wedge(spec,folder):
    vertices,faces,volume=wedge_geometry(spec)
    text=''.join('v '+' '.join(format(v,'.15g') for v in point)+'\n' for point in vertices)
    text+=''.join('f '+' '.join(str(i+1) for i in face)+'\n' for face in faces)
    digest=hashlib.sha256(text.encode()).hexdigest()[:20]
    path=Path(folder)/f'support_wedge_{digest}.obj'
    _atomic_text(path,text)
    return path,volume
