"""Load-transfer block extraction development task."""
