"""Public, bounded body variations used by both tabletop scene generators."""
import math

ARM_PARTS = ("shoulder", "elbow", "wrist")


def validate_body(scale, offsets):
    if isinstance(scale, bool) or not math.isfinite(scale) or not .85 <= scale <= 1.:
        raise ValueError("arm_torque_scale must be within the public range [0.85, 1]")
    values = tuple(float(v) for v in offsets)
    if len(values) not in (0, 14) or any(not math.isfinite(v) or abs(v) > .05 for v in values):
        raise ValueError("initial_arm_offsets must be empty or 14 finite angles within +/-0.05 rad")
    return values


def arm_indices(names):
    return [i for i, name in enumerate(names) if any(part in name for part in ARM_PARTS)]
