"""Physical candidates; every motion goes through the registered joint interface."""
import numpy as np
from scipy.spatial.transform import Rotation
from .box_grasp import pick_place as profile_pick_place
from .edge_support import push_to_edge,edge_pick,slide_to_left
from .reference_grasp import board_grasp,board_release
from .pose_carry import move as pose_carry
from . import table_slide,reach_screen,reference_place,approach_path,repair_axis,supported_carry,fixture_reuse
from humanoid.g1_tabletop_assembly.solution import closed_loop
from humanoid.g1_gear_assembly.solution.stage_base_hook import run_base, HOOK_PROFILE
from humanoid.g1_gear_assembly.solution.stage_gears import run_large_held,run_medium_held,run_small_held
from humanoid.g1_gear_assembly.solution.stage_cover_rail import run_cover_handle
from humanoid.g1_gear_assembly.solution.stage_drive import run_drive
from humanoid.g1_gear_assembly.solution.expert import await_stage
from humanoid.g1_gear_assembly.solution.skills import Pinch,pose,shift_hands,raise_hands,configure_ik,goto

def run_assembly_candidate(c,release_strategy="simultaneous",stack_grasp=False):
    # The table-supported brace release is the sole fast opening that caused
    # measured finger overshoot. Slow that maneuver, preserving the 120 s task.
    # Grasp the lower support at its measured height; lifting the grasp by
    # half the shim thickness put the pads on the loose shim instead.
    original=c.move_joints;original_hands=c.move_hands
    def hands(tasks,*args,**kwargs):
        if stack_grasp and c.phase=='brace_hover':
            state=c.object_state('brace')
            yaw=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_euler('xyz')[2]
            turn=Rotation.from_euler('z',yaw).as_matrix()
            point=np.asarray(state['pos'])+turn@np.array([.001,0,.08375])
            _,hover,rotation=tasks['left']
            return reach_screen.approach_from_contact(c,'left',point,rotation,height=float(hover[2]-point[2]))
        return original_hands(tasks,*args,**kwargs)
    c.move_hands=hands
    def move(target,seconds=1.):
        if stack_grasp and c.phase=='lift_hands_before_table':
            target=np.asarray(target).copy();j=c.index['right_hand_thumb_1_joint']
            target[j]=np.clip(target[j],c.lo[j]+.15,c.hi[j]-.15)
            seconds=max(seconds,2.)
        if c.phase=='brace_confirm_table_support':
            if release_strategy=='thumb_first':
                partial=c.q.copy();i=c.index['left_hand_thumb_1_joint'];partial[i]=target[i]
                c.event('brace_release_thumb');original(partial,seconds=1.)
                c.event('brace_release_fingers')
            seconds=max(seconds,1.5)
        return original(target,seconds=seconds)
    c.move_joints=move
    try:return closed_loop.run(c)
    finally:c.move_joints=original;c.move_hands=original_hands

def asm_01(c,m):
    return run_assembly_candidate(c)

def asm_02(c,m):
    # Inspect actual geometry and current access, not the semantic object name.
    target_height=c.env.cfg.fixture_pivot_height-c.env.cfg.fixture_size[2]/2
    rows=[]
    for name,spec in c.env.specs.items():
        if spec['kind']!='box':continue
        state=c.object_state(name)
        row={'name':name,'height':spec['size'][2],'required_height':target_height,
             'height_matches':abs(spec['size'][2]-target_height)<.004,
             'mass':spec['mass'],'position':state['pos'],
             'route_screen':'nominal near-side grasp/push primitive is calibrated only for x < 0.65'}
        row['candidate']=row['height_matches'] and state['pos'][0]<.65
        rows.append(row)
    m.events.append({'candidate_screen':rows});c.event('inspect_support_candidates',candidates=rows)
    selected=[x for x in rows if x['candidate']]
    if len(selected)!=1 or selected[0]['name']!='brace':
        raise RuntimeError('No uniquely screened support supported by the current grasp primitive')
    return run_assembly_candidate(c,release_strategy='thumb_first')

def gear_01(c,m,late_park=False,drive_chunks=False):
    for name,fn in [('base',run_base),('large_gear',run_large_held),('medium_gear',run_medium_held),
                    ('small_gear',run_small_held),('cover',run_cover_handle)]:
        m.high_id=name
        if name=='base':fn(c)
        else:fn(c,ready=True)
        await_stage(c,name)
    m.high_id='drive'
    if drive_chunks:drive_with_regrasp(c)
    else:drive_until_verified(c,park_before=not late_park)
    m.high_id='release';c.hold(2.5)

def drive_until_verified(c,park_before=True):
    from humanoid.g1_gear_assembly.solution.stage_drive import pick_tool,drive,park_tool
    raise_hands(c)
    if park_before:park_unused_arm(c,'right')
    grip,held,_=pick_tool(c)
    # The original five strokes produced only 1.30–1.33 credited radians in
    # the continuous audited runs. Keep stroking until the original scorer
    # credits its required angle/contact/ratio predicates, with a finite cap.
    result=drive(c,held,strokes=10)
    if not park_before:park_unused_arm(c,'right')
    park_tool(c,grip,held);c.hold(2.5)
    c.event('drive_result',**result,success=c.env.status['success'])
    if 'drive_test' not in c.env.status['completed']:
        raise RuntimeError('Gear drive did not satisfy the original measured transmission predicates')

def drive_with_regrasp(c):
    from humanoid.g1_gear_assembly.solution.stage_drive import pick_tool,drive,park_tool
    for cycle in range(4):
        raise_hands(c);park_unused_arm(c,'right')
        grip,held,_=pick_tool(c)
        c.event('drive_regrasp_cycle',cycle=cycle,maximum_strokes=2)
        result=drive(c,held,strokes=2)
        park_tool(c,grip,held);c.hold(.6)
        if 'drive_test' in c.env.status['completed']:
            c.hold(2.5);c.event('drive_result',**result,success=c.env.status['success']);return
    raise RuntimeError('Gear drive did not reach its original angle after four regrasp cycles')

def prepare_interior_hands(c):
    # Keep unloaded fingers away from zero stops before moving the shoulders.
    # This is an ordinary, time-scaled joint command from the normal reset.
    q=c.q.copy()
    for side,sign in [('left',-1.),('right',1.)]:
        for finger in ('index','middle'):
            q[c.index[f'{side}_hand_{finger}_0_joint']]=sign*.18
            q[c.index[f'{side}_hand_{finger}_1_joint']]=sign*.12
        q[c.index[f'{side}_hand_thumb_2_joint']]=-sign*.12
    c.event('prepare_interior_hand_posture');c.move_joints(q,seconds=1.)

def park_unused_arm(c,side):
    """Fold the idle arm behind the working plane before moving the waist."""
    q=c.q.copy();q[c.index[side+'_shoulder_roll_joint']]=1.1 if side=='left' else -1.1
    c.event('park_'+side+'_arm_outward');c.move_joints(q,seconds=1.)
    for joint,value in [('shoulder_pitch',1.3),('shoulder_yaw',0.),('elbow',1.5)]:q[c.index[side+'_'+joint+'_joint']]=value
    c.event('park_'+side+'_arm_behind');c.move_joints(q,seconds=1.5)

def reposition_right_frame(c,target_y=-.25):
    """Push its upper rail into a region where the reversed hook is reachable."""
    p,R,yaw,_=pose(c,'right_frame');rz=Rotation.from_euler('z',yaw).as_matrix();mirror=np.diag([1.,-1.,1.])
    local=np.array([-np.tan(yaw)*.0773333333,-.00329093125,.0773333333])
    if abs(local[0])>.045:raise RuntimeError('right frame: push point outside usable rail span')
    palm=p+R@local+rz@mirror@HOOK_PROFILE['offset'];rot=rz@mirror@HOOK_PROFILE['rotation']@mirror
    q=c.q.copy()
    for j,v in HOOK_PROFILE['hand'].items():q[c.index['right_hand_'+j+'_joint']]=v if j=='thumb_0' else -v
    q[c.index['right_hand_thumb_0_joint']]=0.;q[c.index['right_hand_thumb_1_joint']]=-1.;q[c.index['right_hand_thumb_2_joint']]=-1.45
    c.event('right_frame_push_preshape');c.move_joints(q,seconds=1.2)
    c.event('right_frame_push_approach');goto(c,{'right':('palm',palm+[0,0,.12],rot)},seconds=3.)
    c.move_hands({'right':('palm',palm,rot)},seconds=2.5,feedback=.5)
    target=palm+np.array([0,target_y-p[1],0])
    c.event('right_frame_push_to_reachable_region');c.move_hands({'right':('palm',target,rot)},seconds=4.,feedback=.5)
    c.move_hands({'right':('palm',target+[0,0,.12],rot)},seconds=1.5);c.hold(.3)
    if abs(pose(c,'right_frame')[0][1]-target_y)>.045:raise RuntimeError('right frame: rail push missed staging region')

def ref_01(c,m,slots=None,fit_profiles=False,park_idle=False):
    """First shelf candidate: rail pinches, measured-pose reorientation and seating.

    This is a candidate, not a certified grasp. Failed grasps abort and retain
    the continuous trace rather than initializing a successfully held part.
    """
    if c.steps==0:prepare_interior_hands(c)
    configure_ik(c,waist_pitch=.5)
    for name in (slots or c.env.cfg.sequence):
        m.high_id=name;raise_hands(c,seconds=2.)
        if name=='right_frame':reposition_right_frame(c)
        state=c.object_state(name);side='left' if state['position'][1]>0 else 'right'
        if park_idle:park_unused_arm(c,'right' if side=='left' else 'left')
        part=c.env.catalog['parts'][name]
        p,R,part_yaw,_=pose(c,name)
        if name.endswith('frame'):
            # The two CAD frames are mirrored: their rails have opposite y offsets.
            # Use the inner flat rail, avoiding the unreachable outer supply edge.
            local=np.array([0.,.003303960702,.0773333333]) if name=='left_frame' else np.array([0.,-.00329093125,.0773333333])
        elif name.endswith('crossbar'):
            local=np.array([.08349098346,0.,0.])
        else:
            # Edge pinch leaves most of the board free and relies on measured contact.
            local=np.array([0., .145 if side=='left' else -.145,0.])
        # Pinch.target applies the observed yaw itself. Store the anchor in
        # that yaw frame, and rotate the wrist profile once to match the rail.
        anchor=Rotation.from_euler('z',-part_yaw).as_matrix()@R@local
        grasp_yaw=part_yaw+(np.pi if name=='right_frame' else 0.)
        profile=HOOK_PROFILE
        fit=m.contract.get('grasp_profiles',{}).get('frame') if name.endswith('frame') and fit_profiles else None
        if fit:
            from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,release
            profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset']),hand=fit['hand_joints'],squeeze=.30,hook=0.)
            grip=HubGrip(c,name,side,grasp_yaw,profile=profile,anchor=anchor)
            grip.grasp()
        else:
            grip=Pinch(c,name,side,profile,anchor=anchor,azimuth=grasp_yaw,squeeze=.55,opening=.4)
            grip.grasp(hover=.12)
        before=pose(c,name)[0]
        lift=max(.08,c.env.cfg.table_height+.165-before[2]) if name.endswith('frame') else .08
        c.event(name+'_lift_probe');shift_hands(c,[side],[0.,0.,lift],seconds=3.)
        c.hold(.4)
        after,R,_,state=pose(c,name)
        if after[2]<before[2]+.035 or state['robot_contact_force']<.05:
            raise RuntimeError(name+': no sustained physical grasp in the lift probe')
        c.event(name+'_reorient')
        # Rotate the held part toward its upright goal using the current pose.
        for _ in range(24):
            p,R,_,state=pose(c,name)
            if state['robot_contact_force']<.05:raise RuntimeError(name+': grasp lost during reorientation')
            vec=Rotation.from_matrix(R.T).as_rotvec();angle=np.linalg.norm(vec)
            if angle<.02:break
            delta=Rotation.from_rotvec(vec*min(1.,.12/angle)).as_matrix()
            shift_hands(c,[side],[0.,0.,0.],seconds=.6,pivot=p,rot=delta)
        goal=np.asarray(c.env.cfg.origin)+part['goal_local']
        c.event(name+'_transfer')
        for height in ([.08,.032] if name.endswith('frame') else [.08,.03,.002]):
            for _ in range(8):
                p,R,_,state=pose(c,name)
                if state['robot_contact_force']<.05:raise RuntimeError(name+': grasp lost during placement')
                error=goal+[0.,0.,height]-p
                rotation=Rotation.from_matrix(R.T).as_rotvec()
                if np.linalg.norm(error)<.0005 and np.linalg.norm(rotation)<.006:break
                # Slot clearance is submillimetric; correct yaw as well as translation.
                correction=Rotation.from_rotvec(rotation*min(1.,.10/max(np.linalg.norm(rotation),1e-9))).as_matrix()
                shift_hands(c,[side],np.clip(error,-.04,.04),seconds=1.2,pivot=p,rot=correction)
        if name.endswith('frame'):
            # The jig accepts the two feet, not the frame centre. Compensate
            # the measured lean before entering its 24 mm high slot walls.
            c.event(name+'_align_feet')
            for _ in range(8):
                p,R,_,state=pose(c,name)
                foot=p+R@np.array([0.,0.,-.125])
                delta=np.r_[goal[:2]-foot[:2],0.]
                if np.linalg.norm(delta)<.00025:break
                shift_hands(c,[side],np.clip(delta,-.004,.004),seconds=.6)
            c.event(name+'_insert_feet')
            for _ in range(70):
                p,R,_,state=pose(c,name)
                if p[2]<goal[2]+.003:break
                foot=p+R@np.array([0.,0.,-.125])
                xy=goal[:2]-foot[:2]
                yaw=float(Rotation.from_matrix(R).as_euler('xyz')[2])
                # Both legs must clear the narrow slots before descending.
                # Centre alignment alone leaves a yawed foot on a slot wall.
                feet_error=max(np.linalg.norm(xy+np.array([x,0.])-(R@np.array([x,0.,0.]))[:2]) for x in (-.0841,.0841))
                dz=-.0015 if feet_error<.00040 and abs(yaw)<.002 else 0.
                delta=np.r_[np.clip(.6*xy,-.0008,.0008),dz]
                shift_hands(c,[side],delta,seconds=.6,pivot=p,yaw=np.clip(-.6*yaw,-.008,.008))
        c.event(name+'_release')
        if fit:release(c,grip,seconds=1.)
        else:grip.release(seconds=1.,rise=.10)
        c.hold(.8)
        if name not in c.env.status['completed']:
            raise RuntimeError(name+': placement did not meet original release/support predicate')
    m.high_id='release';raise_hands(c,seconds=2.);c.hold(2.5)


def pick_place_support(c,name,goal):
    """Candidate top pinch on the 70 mm support, with a measured lift test."""
    from humanoid.g1_tabletop_assembly.solution.tool import safe_ready
    safe_ready(c)
    state=c.object_state(name);p=np.asarray(state['pos']);side='left' if p[1]>0 else 'right'
    sign=1 if side=='left' else -1
    rot=Rotation.from_euler('x',sign*np.pi/2).as_matrix()
    q=c.q.copy()
    for finger in ('index','middle'):
        q[c.index[f'{side}_hand_{finger}_0_joint']]=-sign*1.15
        q[c.index[f'{side}_hand_{finger}_1_joint']]=0.
    q[c.index[f'{side}_hand_thumb_0_joint']]=0.
    q[c.index[f'{side}_hand_thumb_1_joint']]=-sign*.70
    q[c.index[f'{side}_hand_thumb_2_joint']]=0.
    c.event(name+'_preshape');c.move_joints(q,seconds=1.)
    palm=p+[.001,0,.08375]
    for height in [.16,0.]:
        c.event(name+'_approach');c.move_hands({side:('palm',palm+[0,0,height],rot)},seconds=3.)
    q=c.q.copy()
    for finger in ('index','middle'):
        q[c.index[f'{side}_hand_{finger}_0_joint']]=-sign*1.4
        q[c.index[f'{side}_hand_{finger}_1_joint']]=-sign*.5
    q[c.index[f'{side}_hand_thumb_1_joint']]=-sign*.10
    q[c.index[f'{side}_hand_thumb_2_joint']]=sign*.5
    # Establish the far-side finger stop before the thumb advances. Closing
    # both together pushed the thin shim out of the reachable grasp envelope.
    fingers=q.copy()
    for joint in ('thumb_0','thumb_1','thumb_2'):
        i=c.index[f'{side}_hand_{joint}_joint'];fingers[i]=c.q[i]
    c.event(name+'_close_fingers_first');c.move_joints(fingers,seconds=1.5)
    c.event(name+'_close_thumb');c.move_joints(q,seconds=1.5)
    c.event(name+'_lift');c.move_hands({side:('palm',palm+[0,0,.12],rot)},seconds=3.)
    actual=c.object_state(name)
    if not actual['hand_contact'] or actual['pos'][2]<p[2]+.03:
        raise RuntimeError(name+': support pinch failed physical lift test')
    for height in [.12,.04,.002]:
        for _ in range(3):
            state=c.object_state(name)
            if not state['hand_contact']:raise RuntimeError(name+': grasp lost in transfer')
            hand,R=c.hand_pose(side);delta=np.asarray(goal)+[0,0,height]-state['pos']
            c.event(name+'_transfer');c.move_hands({side:('palm',hand+delta,R)},seconds=2.)
    q=c.q.copy()
    for finger in ('index','middle'):q[c.index[f'{side}_hand_{finger}_0_joint']]=0.
    q[c.index[f'{side}_hand_thumb_1_joint']]=-sign*.70
    c.event(name+'_release');c.move_joints(q,seconds=1.)
    hand,R=c.hand_pose(side);c.move_hands({side:('palm',hand+[0,0,.16],R)},seconds=2.);c.hold(.6)
    state=c.object_state(name)
    if state['robot_contact'] or np.linalg.norm(np.asarray(state['pos'])-goal)>.012:
        raise RuntimeError(name+': released placement is not stable at planned support pose')

def asm_03(c,m):
    m.high_id='compose_support'
    brace=np.asarray(c.object_state('brace')['pos'])
    goal=brace+[0,0,(.04+.0225)/2]
    c.event('plan_support_stack',objects=['brace','shim'],total_height=.0625,goal=goal.tolist())
    fit=m.contract.get('grasp_profiles',{}).get('shim')
    if fit:
        c.event('plan_two_grasp_handoff',staging=[.24,0.,c.env.cfg.table_height+.01125])
        profile_pick_place(c,'shim',[.24,0.,c.env.cfg.table_height+.01125],fit,side='right')
        profile_pick_place(c,'shim',goal,fit,side='left')
    else:pick_place_support(c,'shim',goal)
    m.high_id='support';run_assembly_candidate(c,stack_grasp=True)


def asm_04(c,m):
    # Initial G1 reference-body probe. Official matched-body comparison is separate.
    specs=c.env.specs
    rows=[dict(name=n,kind=specs[n]['kind'],size=specs[n]['size'],position=c.object_state(n)['pos'])
          for n in ('brace','short_stand','shim','wedge')]
    c.event('support_method_screen',candidates=rows,selected='grasp_place_stand',
            reason='Existing reference-body pinch/push route; other methods require independent probes')
    run_assembly_candidate(c)

def asm_edge(c,m):
    m.high_id='compose_support';fit=m.contract['grasp_profiles']['shim']
    c.event('plan_edge_supported_handoff',front_edge_x=.20,staging_x=.215)
    lo,hi=c.ik.lo.copy(),c.ik.hi.copy()
    try:
        push_to_edge(c,fit)
        c.ik.set_limit('waist_pitch_joint',-.4,.42);c.ik.set_limit('waist_roll_joint',-.42,.42)
        edge_pick(c,[.215,-.14,c.env.cfg.table_height+.01125],'right')
        c.event('shim_handoff_park_right_hand')
        goto(c,{'right':('palm',np.array([.06,-.45,1.10]),None)},seconds=2.)
        brace=np.asarray(c.object_state('brace')['pos'])
        edge_pick(c,brace+[-.02,0.,(.04+.0225)/2],'left')
    finally:c.ik.lo[:]=lo;c.ik.hi[:]=hi
    m.high_id='support';run_assembly_candidate(c,stack_grasp=True)


def gear_02(c,m,repair_fn=None):
    m.high_id='diagnose';prepare_interior_hands(c);raise_hands(c,seconds=2.);c.hold(.3)
    rows=[]
    for name in ('base','large_gear','medium_gear','small_gear'):
        p,R,_,_=pose(c,name);goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][name]['goal_local']
        rows.append(dict(name=name,position_error_m=float(np.linalg.norm(p-goal)),upright=float(R[2,2])))
    bad=[x for x in rows if x['position_error_m']>.006 or x['upright']<.97]
    c.event('diagnose_from_measured_geometry',evidence=rows,suspects=bad)
    if len(bad)!=1 or bad[0]['name']!='medium_gear':
        raise RuntimeError('Diagnosis is not the single middle-gear fault supported by this repair candidate')
    m.high_id='extract_reseat'
    repaired=False
    if bad[0]['upright']<0.:
        repaired=(repair_fn(c,'medium_gear',m.contract.get('grasp_profiles',{}).get('inverted_gear')) if repair_fn else repair_inverted_gear(c,'medium_gear',m.contract.get('grasp_profiles',{}).get('inverted_gear'),shaft_release=True))
    if not repaired:run_medium_held(c,ready=True)
    c.hold(1.8)
    if 'medium_gear' not in c.env.status.get('completed',[]):raise RuntimeError('Repair did not pass measured extraction and reseating gates')
    m.high_id='cover';run_cover_handle(c,ready=True);await_stage(c,'cover')
    m.high_id='drive';drive_until_verified(c);m.high_id='release';c.hold(2.5)

def asm_slide(c,m):
    m.high_id='compose_support';fit=m.contract['grasp_profiles']['shim']
    c.event('plan_table_supported_transfer')
    push_to_edge(c,fit,target_x=.222);slide_to_left(c,fit)
    goto(c,{'right':('palm',np.array([.06,-.45,1.10]),None)},seconds=2.)
    push_to_edge(c,fit,side='left',target_x=.215,ready=False)
    brace=np.asarray(c.object_state('brace')['pos'])
    edge_pick(c,brace+[-.02,0.,(.04+.0225)/2],'left')
    m.high_id='support';run_assembly_candidate(c,stack_grasp=True)

def asm_pinch_slide(c,m):
    from .table_slide import shim
    m.high_id='compose_support';fit=m.contract['grasp_profiles']['shim']
    push_to_edge(c,fit,target_x=.222);shim(c,fit)
    goto(c,{'right':('palm',np.array([.06,-.45,1.10]),None)},seconds=2.)
    brace=np.asarray(c.object_state('brace')['pos']);goal=brace+[-.02,0,(.04+.0225)/2]
    shim(c,fit,goal=goal,side='left',goal_yaw=np.pi,support='brace')
    m.high_id='support';run_assembly_candidate(c,stack_grasp=True)

def asm_edge_handoff(c,m,direct=False):
    from .table_slide import shim
    m.high_id='compose_support';fit=m.contract['grasp_profiles']['shim']
    original_ik_limits=(c.ik.lo.copy(),c.ik.hi.copy())
    if direct:
        from humanoid.g1_tabletop_assembly.solution.tool import safe_ready
        safe_ready(c);shim(c,fit,goal=(.235,-.27),front_first=True)
    else:
        push_to_edge(c,fit,target_x=.222);shim(c,fit,goal=(.235,-.27))
    goto(c,{'right':('palm',np.array([.06,-.45,1.10]),None)},seconds=2.)
    brace=np.asarray(c.object_state('brace')['pos']);goal=brace+[0,-.025,(.04+.0225)/2]
    edge_pick(c,goal,'left',long_edge=True)
    c.ik.lo[:],c.ik.hi[:]=original_ik_limits
    # The unused right thumb retained the thin-plate opening near its upper
    # stop. Retract it before the shared-waist return to the assembly posture.
    c.event('shim_stack_retract_idle_thumb')
    q=c.q.copy();j=c.index['right_hand_thumb_1_joint'];q[j]=min(q[j],c.hi[j]-.20)
    c.move_joints(q,seconds=1.)
    m.high_id='support';run_assembly_candidate(c,stack_grasp=True)

def asm_direct_edge(c,m):
    return asm_edge_handoff(c,m,direct=True)

def asm_staged_stack(c,m):
    original_move=c.move_joints
    def safe_hand_transition(target,seconds=1.):
        if c.phase=='lift_hands_before_table':
            target=np.asarray(target).copy();j=c.index['right_hand_thumb_1_joint']
            target[j]=np.clip(target[j],c.lo[j]+.15,c.hi[j]-.15);seconds=max(seconds,2.)
        return original_move(target,seconds=seconds)
    c.move_joints=safe_hand_transition
    try:return _asm_staged_stack(c,m)
    finally:c.move_joints=original_move

def _asm_staged_stack(c,m):
    """Move the empty stand first, then compose the support beside the jig."""
    from humanoid.g1_tabletop_assembly.solution.tool import safe_ready
    m.high_id='compose_support';safe_ready(c)
    q=c.q.copy();q[c.index['right_hand_thumb_1_joint']]=0.;q[c.index['right_hand_thumb_2_joint']]=-.30
    c.event('prepare_idle_hand_for_outboard_park');c.move_joints(q,seconds=1.5)
    park_unused_arm(c,'right')
    initial_limits=(c.ik.lo.copy(),c.ik.hi.copy())
    fit=m.contract['grasp_profiles']['shim']
    staging=np.array([c.env.cfg.brace_goal_xy[0]-.013,
                      c.env.cfg.fixture_pivot_xy[1]+c.env.cfg.fixture_size[1]/2+c.env.cfg.brace_size[1]/2+.042,
                      c.object_state('brace')['pos'][2]])
    table_slide.shim(c,fit,goal=staging,side='left',goal_yaw=0.,name='brace',entry_turn=-np.pi/2)
    c.ik.lo[:],c.ik.hi[:]=initial_limits
    stand=c.object_state('brace')
    if stand['robot_contact'] or stand['support_forces'].get('table',0)<.05:
        raise RuntimeError('stand staging requires released table support')
    c.event('empty_stand_staging_verified',position=stand['pos'])
    # Clear the folded idle thumb before the shared waist rotates its wrist.
    # Keeping the press posture during that motion caused self-contact to
    # deflect the actual thumb through its lower stop despite an interior target.
    q=c.q.copy();q[c.index['right_hand_thumb_1_joint']]=0.;q[c.index['right_hand_thumb_2_joint']]=-.30
    c.event('clear_idle_thumb_before_waist_return')
    if np.max(np.abs(q-c.q))>.02:c.move_joints(q,seconds=1.5)
    original_limits=(c.ik.lo.copy(),c.ik.hi.copy())
    fit=m.contract['grasp_profiles']['shim']
    push_to_edge(c,fit,target_x=.222,ready=False);table_slide.shim(c,fit,goal=(.235,-.27))
    goto(c,{'right':('palm',np.array([.06,-.45,1.10]),None)},seconds=2.)
    goal=np.asarray(c.object_state('brace')['pos'])+[0,0.,(.04+.0225)/2]
    edge_pick(c,goal,'left',long_edge=True)
    c.ik.lo[:],c.ik.hi[:]=original_limits
    q=c.q.copy();j=c.index['right_hand_thumb_1_joint'];q[j]=min(q[j],c.hi[j]-.20)
    c.event('staged_stack_retract_idle_thumb');c.move_joints(q,seconds=1.)
    preposition,ready=closed_loop.preposition_brace,closed_loop.safe_ready
    def verify_staged(controller):
        brace=controller.object_state('brace');shim=controller.object_state('shim')
        if brace['robot_contact'] or shim['robot_contact'] or shim['support_forces'].get('brace',0)<.05:
            raise RuntimeError('staged composition lost its released support path')
        controller.event('reuse_physically_staged_composition')
    closed_loop.preposition_brace=verify_staged
    closed_loop.safe_ready=lambda controller:controller.event('continue_from_measured_staged_support')
    m.high_id='support'
    try:return run_assembly_candidate(c,stack_grasp=True)
    finally:closed_loop.preposition_brace=preposition;closed_loop.safe_ready=ready

def gear_03(c,m):
    rows=[dict(name=n,position=c.object_state(n)['position']) for n in ('turning_tool','thin_tool','wide_tool')]
    c.event('candidate_tools',candidates=rows,selected='turning_tool',
            reason='Collared handle has a calibrated reference-body pinch; comparison bodies remain independent configurations')
    gear_01(c,m,late_park=True)

def gear_regrasp(c,m):
    c.event('candidate_tools',selected='turning_tool',reason='Collared handle; renew physical grip between short drive batches')
    return gear_01(c,m,drive_chunks=True)


def move_fixture(c,goal):
    from .reference_extension import FixtureEvaluator
    from humanoid.g1_gear_assembly.solution.stage_drive import TOOL_PROFILE
    name='temporary_fixture';p,R,_,_=pose(c,name);side='left' if p[1]>0 else 'right'
    # This is a candidate pinch of the short edge; lift/contact validation is mandatory.
    grip=Pinch(c,name,side,TOOL_PROFILE,squeeze=.35)
    grip.grasp(hover=.12);before=pose(c,name)[0]
    shift_hands(c,[side],[0,0,.08],seconds=3.);c.hold(.3)
    after,_,_,state=pose(c,name)
    if after[2]<before[2]+.03 or state['robot_contact_force']<=.05:
        raise RuntimeError('temporary fixture: failed sustained lift probe')
    for dz in (.08,.025,.002):
        for _ in range(3):
            p,_,_,_=pose(c,name);shift_hands(c,[side],np.asarray(goal)+[0,0,dz]-p,seconds=2.)
    grip.release(seconds=1.,rise=.12);c.hold(.7)

def ref_02(c,m):
    # Topological schedule: each frame first receives the one reusable fixture.
    if c.steps==0:prepare_interior_hands(c)
    for name in ('left_frame','right_frame'):
        m.high_id='deploy_fixture'
        goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][name]['goal_local']
        target=[goal[0],goal[1]+.003304,c.env.cfg.table_height+.015]
        move_fixture(c,target)
        ref_01(c,m,slots=[name]);c.hold(.7)
    m.high_id='park_fixture';move_fixture(c,[.30,.30,c.env.cfg.table_height+.015])
    remaining=[n for n in c.env.cfg.sequence if not n.endswith('frame')]
    ref_01(c,m,slots=remaining)

def ref_03(c,m):
    c.event('plan_constrained_workspace',wall=c.object_state('access_wall')['position'],
            method='front approach with released passive frame slots; optional movable fixture remains available')
    ref_01(c,m)


def repair_inverted_gear(c,name,fit=None,shaft_release=False,late_receiver=False,unhook=False,handle_pivot=False):
    """Rim pinch, physical lift/flip, park upright, then use the regular hub grasp."""
    p,R,_,_=pose(c,name)
    if late_receiver:
        from humanoid.g1_gear_assembly.solution.stage_gears import COLLAR_PROFILE
        receiver=Pinch(c,name,'left',COLLAR_PROFILE,azimuth=np.pi,squeeze=.4,finger_squeeze=.15)
        c.event('repair_prepare_receiving_fingers')
        c.move_joints(receiver.curled(-receiver.opening),seconds=1.)
    if fit and not shaft_release:
        from humanoid.g1_gear_assembly.solution.stage_gears import COLLAR_PROFILE
        top=Pinch(c,name,'left',COLLAR_PROFILE,azimuth=np.pi,squeeze=.4,finger_squeeze=.15)
        receiver_start=np.array([.28,.02,1.14])
        receiver_R=Rotation.from_euler('z',np.pi).as_matrix()@COLLAR_PROFILE['rotation']
        receiver_offset=Rotation.from_euler('z',np.pi).as_matrix()@COLLAR_PROFILE['offset']
        c.event('repair_preposition_receiver')
        c.move_joints(top.curled(-top.opening),seconds=1.)
        from .reach_screen import goto as screened_goto
        screened_goto(c,{'left':('palm',receiver_start,receiver_R)},seconds=2.5)
        receiver_solve=c.ik.solve
        def follow_receiver(root_pos,root_quat,q,tasks,*args,**kwargs):
            object_p,object_R,_,_=pose(c,name)
            amount=float(np.clip((object_R[2,2]+.8)/1.7,0.,1.))
            endpoint=object_p+receiver_offset+[0,0,.035]
            endpoint[2]=max(1.10,endpoint[2])
            target=receiver_start+amount*(endpoint-receiver_start)
            return receiver_solve(root_pos,root_quat,q,dict(tasks,left=('palm',target,receiver_R)),*args,**kwargs)
        c.ik.solve=follow_receiver
    if fit:
        from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,release
        shape=dict(fit['hand_joints'])
        shape['thumb_1']+=.08;shape['thumb_2']-=.08
        for finger in ('index','middle'):
            shape[finger+'_0']+=.25;shape[finger+'_1']-=.25
        # The outer teeth forced the fully open thumb against its stop in a05.
        # Approach with the palm offset toward that thumb, opening the opposing
        # fingers instead; closure then stays inside the thumb's working range.
        # The inverted rim has free space below it, above the base plate.
        # Contact lower on the tooth faces so modest slip cannot eject the
        # index fingertip over their upper edge during extraction.
        # Recorded mesh distances put all three loaded contacts about 14 mm
        # to one side of the gear COM. Centre their support polygon before
        # lifting; merely curling harder did not prevent the subsequent roll.
        profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])+[.014,-.008,-.012],
                     hand=shape,squeeze=.65,hook=0.)
        # Oppose the disk rim along x so the fingertips clear its neighbours
        # along y. The inverted tooth disk occupies z=[0,.025] locally.
        grip=HubGrip(c,name,'right',np.pi/2,profile=profile)
        grip.grasp()
    else:
        grip=Pinch(c,name,'right',HOOK_PROFILE,anchor=R@np.array([0.,-.045,0.]),squeeze=.4)
        grip.grasp(hover=.12)
    if fit:
        from humanoid.g1_gear_assembly.solution.stage_gears import gear_seat
        start,R0,yaw,_=pose(c,name);hp,hR=c.hand_pose('right')
        local_p=R0.T@(hp-start);local_R=R0.T@hR
        seat,_=gear_seat(c,name);goal=np.r_[seat[:2],start[2]+.065]
        desired_R=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi).as_matrix()
        cp=np.zeros(3);cr=np.zeros(3)
        c.event('repair_axis_aligned_extraction')
        for i in range(250):
            fraction=min(1.,(i+1)/200);a=fraction**3*(10-15*fraction+6*fraction*fraction)
            desired=start+a*(goal-start);actual,actual_R,_,_=pose(c,name)
            # Once the shaft is clear, curl the distal pads gradually into
            # the rim. Recorded contact geometry showed all pads migrating
            # to the top edge during the centred but flat pinch.
            if actual[2]>start[2]+.04:grip.hook=min(.15,grip.hook+.003)
            cp=np.clip(cp+np.clip(.06*(desired-actual),-.0004,.0004),-.035,.035)
            error=Rotation.from_matrix(desired_R@actual_R.T).as_rotvec()
            cr=np.clip(cr+np.clip(.03*error,-.001,.001),-.20,.20)
            command_R=Rotation.from_rotvec(cr).as_matrix()@desired_R
            c.reach({'right':('palm',desired+cp+command_R@local_p,command_R@local_R)},feedback=.4,rotation_feedback=.3,iters=12)
            c.step()
    else:shift_hands(c,['right'],[0,0,.12],seconds=3.)
    c.hold(.3)
    current,R,_,s=pose(c,name)
    if s['robot_contact_force']<=.05 or current[2]<p[2]+.04:
        raise RuntimeError('inverted gear: rim grasp failed extraction probe')
    if fit:
        # Rotate while leaving the shaft, instead of spending the available
        # rim hold lifting the inverted part to a 1.10 m clearance waypoint.
        # This keeps the palm lower and ends with it supporting the disk below.
        flip_goal=[.34,0.,1.04] if late_receiver else [.38,-.18,1.02]
        if shaft_release:
            pose_carry(c,grip,flip_goal,np.eye(3),6.,'repair_transfer_and_flip')
        else:
            c.ik.set_limit('waist_roll_joint',-.38,.38)
            pose_carry(c,grip,[.38,-.18,1.02],np.eye(3),6.,'repair_transfer_and_flip',
                       stop_when=lambda p,R,s:R[2,2]>.97 and p[2]>.92 and s['robot_contact_force']>5.)
        # The rim can rotate slightly inside the pinch during the half-turn.
        # Re-estimate the measured hand/part transform before the final trim.
        for attempt in range(3):
            if pose(c,name)[1][2,2]>.97:break
            pose_carry(c,grip,flip_goal,np.eye(3),2.,'repair_measured_flip_trim',
                       stop_when=(lambda p,R,s:R[2,2]>.99 and s['robot_contact_force']>5.) if late_receiver else None)
        if handle_pivot:return repair_axis.pivot_on_base_handle(c,grip)
        if late_receiver:return repair_axis.handoff_upright(c,grip,receiver)
        if unhook:return repair_axis.release_with_distals(c,grip)
        if shaft_release:return repair_axis.release_on_table(c,grip)
    for _ in range(0 if fit else 24):
        current,R,_,s=pose(c,name)
        if s['robot_contact_force']<=.05:raise RuntimeError('inverted gear: grasp lost during flip')
        vec=Rotation.from_matrix(R.T).as_rotvec()
        if np.linalg.norm(vec)<.05:break
        rot=Rotation.from_rotvec(vec*min(1.,.16/np.linalg.norm(vec))).as_matrix()
        shift_hands(c,['right'],[0,0,0],seconds=.8,pivot=current,rot=rot)
    if fit:
        from humanoid.g1_gear_assembly.solution.stage_gears import Held,insert_held,COLLAR_PROFILE
        c.ik.solve=receiver_solve
        if pose(c,name)[1][2,2]<.95:raise RuntimeError('inverted gear: incomplete physical flip')
        # Keep the supporting hand in world coordinates while the other hand
        # acquires the now exposed hub. Only the normal IK targets are merged.
        solve=c.ik.solve
        keep_side='right';hp,hR=c.hand_pose(keep_side)
        def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
            actual_p,actual_R=c.hand_pose(keep_side)
            corrected_p=hp+np.clip(.6*(hp-actual_p),-.015,.015)
            error=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
            corrected_R=Rotation.from_rotvec(.4*error).as_matrix()@hR
            return solve(root_pos,root_quat,q,dict(tasks,**{keep_side:('palm',corrected_p,corrected_R)}),*args,**kwargs)
        c.ik.solve=keep
        try:
            c.event('repair_handoff_grasp_hub')
            held_position=pose(c,name)[0]
            _,errors=c.ik.solve(c.env.base_position,(1,0,0,0),c.q,top.target(),iters=300,damping=.02,w_rot=.5,max_step=.08)
            if max(errors.values())>.004:raise RuntimeError('repair: receiving hover is not jointly reachable')
            # Joint interpolation moved the supporting hand away from its
            # world target midway through an otherwise reachable approach.
            # Track both hands throughout the Cartesian approach instead.
            c.event('repair_receiving_cartesian_approach',errors=errors)
            c.move_hands(top.target(),seconds=.8,feedback=.5,rotation_feedback=.3)
            c.event('repair_receiving_collar_close');c.move_joints(top.curled(.4),seconds=.8)
            from humanoid.g1_gear_assembly.solution.skills import side_forces
            receiving=side_forces(c,name)
            c.event('repair_handoff_contact_check',forces=receiving)
            current,current_R,_,_=pose(c,name)
            if receiving['left']<.5 or np.linalg.norm(current-held_position)>.025 or current_R[2,2]<.95:
                raise RuntimeError('repair: receiving hand has not acquired the upright suspended gear')
            keep_side='left';hp,hR=c.hand_pose(keep_side)
            c.event('repair_handoff_release_rim')
            grip.closed=False;q=c.q.copy()
            for j in ('thumb_0','thumb_1','middle_0','index_0'):q[grip.joint(j)]=grip.open[j]
            c.move_joints(q,seconds=1.3)
            right_p,right_R=c.hand_pose('right')
            c.move_hands({'right':('palm',right_p+[0,-.12,-.06],right_R)},seconds=2.)
            c.joint_feedback.pop(grip.key,None)
        finally:c.ik.solve=solve
        held=Held(top)
        start=pose(c,name)[0];held.move(start+[0,0,.04],pose(c,name)[2],seconds=2.,settle=.3)
        if pose(c,name)[3]['robot_contact_force']<.05:raise RuntimeError('repair: hub handoff lost the gear')
        insert_held(c,name,held);top.release(seconds=1.2,rise=.10);c.hold(.8)
        return True
    goal=np.array([.35,-.38,c.env.cfg.table_height+c.env.catalog['parts'][name]['size'][2]/2+.003])
    for dz in (.08,.02,0.):
        current,R,_,s=pose(c,name)
        if s['robot_contact_force']<=.05:raise RuntimeError('inverted gear: grasp lost before staging')
        shift_hands(c,['right'],goal+[0,0,dz]-current,seconds=2.)
    if fit:release(c,grip,seconds=1.)
    else:grip.release(seconds=1.,rise=.12)
    c.hold(.6)
    if pose(c,name)[1][2,2]<.95:raise RuntimeError('inverted gear: not upright after physical flip')

def ref_geometry(c,m):
    return ref_01(c,m,fit_profiles=True)

def ref_crossbar_probe(c,m):
    """Acquire the near end tie symmetrically, then clear its supply beam."""
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.);park_unused_arm(c,'right')
    candidates=[n for n in c.env.catalog['parts'] if n.endswith('crossbar')]
    name=max(candidates,key=lambda n:pose(c,n)[0][2]);m.high_id='lower_crossbar'
    p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,.1485,0.])
    c.event('select_exposed_supply_crossbar',selected=name)
    from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip
    fit=m.contract['grasp_profiles']['frame']
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])+[0,0,-.001],hand=fit['hand_joints'],squeeze=.45,hook=.12)
    grip=HubGrip(c,name,'left',yaw-np.pi,profile=profile,anchor=anchor)
    from .reach_screen import goto as screened_goto
    grip.preshape(seconds=1.)
    screened_goto(c,grip.target(.06),seconds=2.5)
    c.event('crossbar_short_hover_descend')
    closing_target=grip.target()
    c.move_hands(closing_target,seconds=2.,feedback=.7,rotation_feedback=.3)
    grip.closed=True;start=c.q.copy()
    active=[grip.joint(j) for j in ('thumb_1','middle_0','index_0')]
    from humanoid.g1_gear_assembly.solution.skills import smooth
    c.event('crossbar_centered_rail_close')
    for i in range(60):
        c.q[active]=start[active]+smooth(min(1.,(i+1)/40))*np.array([1.,-1.,-1.])*grip.squeeze
        c.reach(closing_target,feedback=.7,rotation_feedback=.3);c.step()
    before,R,_,_=pose(c,name)
    # Slide first: the remote centre of mass otherwise peels the end-tie
    # pinch open during lift. The lower supply frame receives the weight.
    pose_carry(c,grip,before+[-.08,0,0],R,3.,'crossbar_supported_forward_slide')
    hp,hR=c.hand_pose('left');grip.closed=False;q=c.q.copy()
    for j in ('thumb_0','thumb_1','middle_0','index_0'):q[grip.joint(j)]=grip.open[j]
    c.event('crossbar_staging_release');start=c.q.copy()
    for i in range(50):
        a=smooth((i+1)/50)
        for j in ('thumb_0','thumb_1','middle_0','index_0'):
            k=grip.joint(j);c.q[k]=start[k]+a*(q[k]-start[k])
        c.reach({'left':('palm',hp+[-.07*a,0,.03*a],hR)},feedback=.5,rotation_feedback=.3);c.step()
    c.joint_feedback.pop(grip.key,None)
    c.move_hands({'left':('palm',hp+[-.07,0,.10],hR)},seconds=1.5);c.hold(.7)
    p,R,yaw,state=pose(c,name)
    if abs(p[0]-(before[0]-.08))>.025 or R[2,2]<.95 or sum(state['support_forces'].values())<.05:
        raise RuntimeError('crossbar: forward staging lacks a stable supported pose')
    c.event('crossbar_horizontal_end_tie_regrasp')
    grip=board_grasp(c,name,'left',fit,world_anchor=R@np.array([0.,.1435,0.]),entry_yaw=0.,squeeze=.30,follow_tilt=True)
    before,R,_,_=pose(c,name)
    pose_carry(c,grip,before+[0,0,.10],R,3.,'crossbar_lift')
    p,_,_,state=pose(c,name)
    if p[2]<before[2]+.035 or state['robot_contact_force']<.05:
        raise RuntimeError('crossbar: inner rail failed sustained lift')
    pose_carry(c,grip,[.40,.20,1.04],np.eye(3),4.,'crossbar_reorient')
    p,R,_,state=pose(c,name)
    if state['robot_contact_force']<.05 or R[2,2]<.95:
        raise RuntimeError('crossbar: grip lost during reorientation')
    c.event('crossbar_probe_success',position=p.tolist())
    return grip

def ref_board_place_probe(c,m):
    return ref_board_probe(c,m,park=True)

def ref_board_probe(c,m,park=False):
    """Fresh-scene component diagnostic; never a complete shelf witness."""
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.)
    park_unused_arm(c,'left')
    # Boards are interchangeable. Use the exposed top supply level first;
    # selecting by semantic slot name trapped the hand beneath other boards.
    candidates=[n for n in c.env.catalog['parts'] if n.endswith('shelf')]
    name=max(candidates,key=lambda n:pose(c,n)[0][2]);m.high_id='bottom_shelf'
    c.event('select_exposed_supply_board',selected=name,candidates=[{'name':n,'height':float(pose(c,n)[0][2])} for n in candidates])
    grip=board_grasp(c,name,'right',m.contract['grasp_profiles']['frame'])
    before,R,_,_=pose(c,name);c.event('board_probe_clear_rack_rail')
    pose_carry(c,grip,before+[0,0,.015],R,1.5,'board_clear_rail_cartesian')
    c.event('board_probe_extract_from_rack')
    pose_carry(c,grip,before+[-.28,0,.015],R,3.,'board_extract_cartesian')
    c.event('board_probe_lift');pose_carry(c,grip,before+[-.28,0,.115],R,3.,'board_lift_cartesian');c.hold(.4)
    p,_,_,s=pose(c,name)
    c.event('board_probe_measurement',lift=float(p[2]-before[2]),force=s['robot_contact_force'])
    if p[2]<before[2]+.04 or s['robot_contact_force']<.05:raise RuntimeError('Board side-entry grasp failed lift probe')
    if park:
        goal_R=Rotation.from_euler('z',np.pi).as_matrix()
        pose_carry(c,grip,[.40,-.20,.96],goal_R,4.,'board_rotate_to_front_grasp')
        pose_carry(c,grip,[.38,-.20,.82],goal_R,3.,'board_lower_to_front_corridor')
        goal=np.array([.25,-.20,c.env.cfg.table_height+.004])
        pose_carry(c,grip,goal+[0,0,.025],goal_R,3.,'board_front_edge_approach')
        pose_carry(c,grip,goal,goal_R,2.,'board_front_edge_set_down')
        p,_,_,s=pose(c,name)
        if np.linalg.norm(p-goal)>.02 or s['support_forces'].get('table',0)<.05:
            raise RuntimeError('board: table landing has not established support')
        grip.front=goal_R@R.T@grip.front
        board_release(c,grip);c.hold(1.)
        p,_,_,s=pose(c,name)
        if np.linalg.norm(p-goal)>.02 or s['robot_contact_force']>.05 or s['support_forces'].get('table',0)<.05:
            raise RuntimeError('board: released table placement is not stable')
        c.event('board_place_probe_success',position=p.tolist());return
    pose_carry(c,grip,before+[-.28,0,.025],R,3.,'board_return_clearance')
    pose_carry(c,grip,before+[0,0,.025],R,3.,'board_return_rack')
    pose_carry(c,grip,before,R,2.,'board_return_set_down')
    p,_,_,s=pose(c,name)
    if np.linalg.norm(p-before)>.015 or s['support_forces'].get('supply_rack',0)<.05:
        raise RuntimeError('board: return did not establish rack support before release')
    board_release(c,grip);c.hold(1.)
    p,_,_,s=pose(c,name)
    if np.linalg.norm(p-before)>.02 or s['robot_contact_force']>.05 or s['support_forces'].get('supply_rack',0)<.05:
        raise RuntimeError('board: released return is not stable on the rack')
    c.event('board_probe_success',position=p.tolist())

def ref_right_probe(c,m):
    """Check the accessible near upright instead of the outer horizontal rail."""
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.)
    push_right_frame_front(c)
    name='right_frame';m.high_id=name;p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([-.0841,-.00329093125,0.])
    grip=Pinch(c,name,'right',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi/2,squeeze=.55,opening=.4)
    grip.grasp(hover=.12)
    before=pose(c,name)[0];c.event('right_frame_upright_lift_probe')
    hand,rotation=c.hand_pose('right')
    c.move_hands({'right':('palm',hand+[0,0,.20],rotation)},seconds=3.,feedback=.5,rotation_feedback=.3);c.hold(.4)
    p,R,_,state=pose(c,name)
    if p[2]<before[2]+.04 or state['robot_contact_force']<.05:
        raise RuntimeError('right frame near upright failed sustained lift probe')
    c.event('right_frame_upright_reorient_probe')
    for _ in range(24):
        p,R,_,state=pose(c,name)
        if state['robot_contact_force']<.05:raise RuntimeError('right frame upright grip slipped during rotation')
        vec=Rotation.from_matrix(R.T).as_rotvec();angle=np.linalg.norm(vec)
        if angle<.02:break
        delta=Rotation.from_rotvec(vec*min(1.,.12/angle)).as_matrix()
        shift_hands(c,['right'],[0,0,0],seconds=.6,pivot=p,rot=delta)
    c.hold(.5);c.event('right_frame_upright_probe_result',upright=float(pose(c,name)[1][2,2]))

def ref_frame_pivot_probe(c,m):
    """Lift only the near post, then acquire the upper rail with the other hand."""
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.)
    push_right_frame_front(c)
    name='right_frame';m.high_id=name;p,R,yaw,_=pose(c,name);flat_height=p[2]
    # The centre of this upright carries a receiver socket. Grip the clear
    # straight span above it so the three pads do not land on different walls.
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([-.0841,-.00329093125,.035])
    right=Pinch(c,name,'right',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi/2,squeeze=.55,opening=.4)
    right.grasp(hover=.12)
    p,R,_,_=pose(c,name)
    # Closing the cradle can already lift the overhanging post. Preserve that
    # supported pose instead of commanding a second rigid-body rotation.
    if p[2]<flat_height+.012:
        hp,hR=c.hand_pose('right');c.event('right_frame_table_supported_pivot')
        c.move_hands({'right':('palm',hp+[0,0,.025],hR)},seconds=1.5,feedback=.5,rotation_feedback=.3)
    actual,R,yaw,state=pose(c,name)
    if actual[2]<flat_height+.012 or state['robot_contact_force']<.05:
        raise RuntimeError('right frame: partial pivot failed to expose upper rail')
    solve=c.ik.solve;keep_side='right';hp,hR=c.hand_pose(keep_side)
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        measured_p,measured_R=c.hand_pose(keep_side)
        corrected_p=hp+np.clip(.6*(hp-measured_p),-.015,.015)
        rv=Rotation.from_matrix(hR@measured_R.T).as_rotvec()
        corrected_R=Rotation.from_rotvec(.4*rv).as_matrix()@hR
        return solve(root_pos,root_quat,q,dict(tasks,**{keep_side:('palm',corrected_p,corrected_R)}),*args,**kwargs)
    c.ik.solve=keep
    try:
        anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,-.00329093125,.0773333333])
        left=Pinch(c,name,'left',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi,squeeze=.55,opening=.4)
        c.event('right_frame_upper_rail_handoff')
        c.move_joints(left.curled(-left.opening),seconds=.6)
        c.move_hands(left.target(.12),seconds=2.5,feedback=.5,rotation_feedback=.3)
        closing_target=left.target()
        c.move_hands(closing_target,seconds=2.,feedback=.7,rotation_feedback=.3)
        from humanoid.g1_gear_assembly.solution.skills import smooth,side_forces
        start=c.q.copy();goal=left.curled(left.squeeze_amount);indices=[left.joint(j) for j in left.shape]
        for i in range(60):
            c.q[indices]=start[indices]+smooth((i+1)/60)*(goal[indices]-start[indices])
            c.reach(closing_target,feedback=.7,rotation_feedback=.3);c.step()
        forces=side_forces(c,name);c.event('right_frame_handoff_contact_check',forces=forces)
        if forces['left']<.5 or pose(c,name)[0][2]<flat_height+.01:
            raise RuntimeError('right frame: receiving hand did not acquire the exposed rail')
        keep_side='left';hp,hR=c.hand_pose(keep_side)
        right.release(seconds=1.3,rise=.10)
        rp,rR=c.hand_pose('right');c.event('right_frame_clear_released_hand')
        c.move_hands({'right':('palm',rp+[0,0,.15],rR)},seconds=1.5,feedback=.5,rotation_feedback=.3)
        c.move_hands({'right':('palm',rp+[0,-.18,.15],rR)},seconds=1.5,feedback=.5,rotation_feedback=.3)
        park_unused_arm(c,'right')
    finally:c.ik.solve=solve
    p,R,_,_=pose(c,name)
    pose_carry(c,left,p+[0,0,.15],R,3.,'right_frame_upper_rail_lift')
    p,R,_,state=pose(c,name)
    if state['robot_contact_force']<.05:raise RuntimeError('right frame: handoff lost physical grasp')
    pose_carry(c,left,[.30,0.,1.02],np.eye(3),6.,'right_frame_handoff_reorient')
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 or state['robot_contact_force']<.05:
        raise RuntimeError('right frame: handoff did not achieve held upright pose')
    c.event('right_frame_pivot_probe_success',position=p.tolist())
    return left

def ref_frames_integrated(c,m):
    """Keep the fresh-scene right-frame pickup, then acquire the left frame."""
    grip=ref_frame_pivot_probe(c,m)
    from .reference_place import frame
    frame(c,grip,'right_frame');c.hold(1.)
    ref_01(c,m,slots=['left_frame'],park_idle=True)
    if 'right_frame' not in c.env.status['completed']:
        raise RuntimeError('right frame: integrated placement did not meet original support/release predicates')
    c.event('two_frames_integrated_success')

def ref_frames_direct(c,m):
    """Use the left hand directly once table pushes expose the right rail."""
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.)
    push_right_frame_front(c)
    hp,hR=c.hand_pose('right');c.event('right_frame_clear_push_hand')
    c.move_hands({'right':('palm',hp+[0,0,.20],hR)},seconds=1.5,feedback=.5)
    c.move_hands({'right':('palm',hp+[0,-.20,.20],hR)},seconds=1.5,feedback=.5)
    name='right_frame';m.high_id=name;p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,-.00329093125,.0773333333])
    grip=Pinch(c,name,'left',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi,squeeze=.55,opening=.4)
    grip.grasp(hover=.12)
    before=pose(c,name)[0];hp,hR=c.hand_pose('left')
    c.event('right_frame_direct_upper_rail_lift')
    c.move_hands({'left':('palm',hp+[0,0,.17],hR)},seconds=3.,feedback=.5,rotation_feedback=.3)
    p,R,_,state=pose(c,name)
    if p[2]<before[2]+.035 or state['robot_contact_force']<.05:
        raise RuntimeError('right frame: direct upper rail pickup failed lift check')
    pose_carry(c,grip,[.30,0.,1.02],np.eye(3),6.,'right_frame_direct_reorient')
    if pose(c,name)[1][2,2]<.95:raise RuntimeError('right frame: direct pickup did not reach upright orientation')
    from .reference_place import frame
    frame(c,grip,name);c.hold(1.)
    ref_01(c,m,slots=['left_frame'],park_idle=True)
    if name not in c.env.status['completed']:raise RuntimeError('right frame: direct route did not satisfy original placement predicate')
    c.event('two_frames_direct_integrated_success')

def ref_frames_turn(c,m):
    """Turn the flat frame so its entire upper rail overhangs the table."""
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.)
    push_right_frame_front(c)
    name='right_frame';m.high_id=name;p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[-.0841,-.00329093125,.035]
    grip=Pinch(c,name,'right',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi/2,squeeze=.55,opening=.4)
    grip.grasp(hover=.12)
    desired_R=Rotation.from_euler('z',-np.pi/2).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
    pose_carry(c,grip,[.235,-.25,c.env.cfg.table_height+.0076],desired_R,5.,'right_frame_supported_quarter_turn')
    grip.release(seconds=1.3,rise=.12);c.hold(.5)
    p,R,yaw,state=pose(c,name);rail=p+R@[0,-.00329093125,.0773333333]
    if rail[0]>.17 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('right frame: complete upper rail overhang is not supported')
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0,-.00329093125,.0773333333]
    grip=Pinch(c,name,'right',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi,squeeze=.55,opening=.4)
    grip.grasp(hover=.12);before=pose(c,name)[0];hp,hR=c.hand_pose('right')
    c.event('right_frame_overhanging_rail_lift')
    c.move_hands({'right':('palm',hp+[0,0,.17],hR)},seconds=3.,feedback=.5,rotation_feedback=.3)
    p,R,_,state=pose(c,name)
    if p[2]<before[2]+.035 or state['robot_contact_force']<.05:raise RuntimeError('right frame: overhanging upper rail failed lift')
    pose_carry(c,grip,[.30,-.15,1.02],np.eye(3),6.,'right_frame_overhanging_rail_reorient')
    if pose(c,name)[1][2,2]<.95:raise RuntimeError('right frame: overhanging pickup is not upright')
    from .reference_place import frame
    frame(c,grip,name);c.hold(1.)
    ref_01(c,m,slots=['left_frame'],park_idle=True)
    if name not in c.env.status['completed']:raise RuntimeError('right frame: turned route missed original placement predicate')
    c.event('two_frames_turn_integrated_success')

def push_right_frame_front(c):
    """Expose the near upright beyond the real table edge before pinching it."""
    reposition_right_frame(c,target_y=-.25)
    p,R,yaw,_=pose(c,'right_frame');mirror=np.diag([1.,-1.,1.])
    turn=Rotation.from_euler('z',yaw+np.pi/2).as_matrix()
    local=np.array([.0841,-.00329093125,np.tan(yaw)*.0841])
    palm=p+R@local+turn@mirror@HOOK_PROFILE['offset'];rot=turn@mirror@HOOK_PROFILE['rotation']@mirror
    q=c.q.copy()
    for j,v in HOOK_PROFILE['hand'].items():q[c.index['right_hand_'+j+'_joint']]=v if j=='thumb_0' else -v
    q[c.index['right_hand_thumb_0_joint']]=0.;q[c.index['right_hand_thumb_1_joint']]=-1.;q[c.index['right_hand_thumb_2_joint']]=-1.45
    c.event('right_frame_front_push_preshape');c.move_joints(q,seconds=1.2)
    goto(c,{'right':('palm',palm+[0,0,.12],rot)},seconds=3.)
    c.move_hands({'right':('palm',palm,rot)},seconds=2.5,feedback=.5)
    # Leave clearance for the entire opposing fingertip, not just the rail
    # centre. A 0.24 m frame centre left that finger over the table edge.
    target=palm+np.array([.215-p[0],0,0])
    c.event('right_frame_push_overhang');c.move_hands({'right':('palm',target,rot)},seconds=2.5,feedback=.5)
    c.move_hands({'right':('palm',target+[0,0,.12],rot)},seconds=1.5);c.hold(.3)
    p,R,_,state=pose(c,'right_frame');near=p+R@[-.0841,-.00329093125,0.]
    if near[0]>.15 or p[0]<.19 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('right frame: supported front overhang not achieved')

def ref_fixture_slide_probe(c,m):
    return ref_fixture_probe(c,m,slide=True)

def ref_fixture_use_probe(c,m):
    """Check a released frame genuinely loads the relocated reusable support."""
    ref_fixture_probe(c,m,slide=True)
    name='left_frame';m.high_id='left_frame'
    p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,.003303960702,.0773333333])
    grip=Pinch(c,name,'left',HOOK_PROFILE,anchor=anchor,azimuth=yaw,squeeze=.55,opening=.4)
    grip.grasp(hover=.12)
    hp,hR=c.hand_pose('left');c.event('fixture_use_lift_frame')
    c.move_hands({'left':('palm',hp+[0,0,.08],hR)},seconds=3.,feedback=.5,rotation_feedback=.3)
    fixture=pose(c,'temporary_fixture')[0]
    p,R,_,_=pose(c,name);rail=p+R@[0.,.003303960702,.0773333333]
    hp,hR=c.hand_pose('left');target=hp+fixture+[0,0,.0125+.004345+.04]-rail
    c.event('fixture_use_align_rail');c.move_hands({'left':('palm',target,hR)},seconds=4.,feedback=.5,rotation_feedback=.3)
    c.event('fixture_use_lower_rail')
    hp,hR=c.hand_pose('left');contact=False
    for i in range(200):
        p,R,_,state=pose(c,name)
        if state['support_forces'].get('temporary_fixture',0)>.10:contact=True;break
        rail=p+R@[0.,.003303960702,.0773333333]
        command=hp+[0,0,-.0004*(i+1)]
        command[:2]+=np.clip(fixture[:2]-rail[:2],-.02,.02)
        if command[2]<c.env.cfg.table_height+.05:break
        c.reach({'left':('palm',command,hR)},feedback=.5,rotation_feedback=.3);c.step()
    if not contact:
        p,R,_,_=pose(c,name);rail=p+R@[0.,.003303960702,.0773333333]
        fixture=pose(c,'temporary_fixture')[0];gap=rail[2]-.004345-(fixture[2]+.0125)
        if np.linalg.norm(rail[:2]-fixture[:2])>.015 or not 0<=gap<.035:
            raise RuntimeError('fixture: rail is outside the bounded gravity-seating envelope')
        c.event('fixture_use_gravity_seat',rail_gap=gap)
    grip.release(seconds=1.5,rise=.12);c.hold(1.5)
    if name not in c.env.status.get('fixture_uses',{}):
        raise RuntimeError('fixture: released frame did not establish the original measured support dwell')
    c.event('fixture_use_probe_success',uses=c.env.status['fixture_uses'])

def ref_fixture_recover_probe(c,m):
    """Keep the credited fixture use and install that same released frame."""
    ref_fixture_use_probe(c,m)
    name='left_frame';m.high_id=name;p,R,yaw,_=pose(c,name)
    # Keep the credited support in place and reacquire the original upper
    # rail beside its footprint. The perpendicular near-post hover proved
    # unreachable in the recorded a15 state; this rail pose is reachable.
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([.055,.003303960702,.0773333333])
    grip=Pinch(c,name,'left',HOOK_PROFILE,anchor=anchor,azimuth=yaw,squeeze=.55,opening=.4)
    grip.grasp(hover=.12);before=pose(c,name)[0];hp,hR=c.hand_pose('left')
    c.event('fixture_supported_rail_lift')
    c.move_hands({'left':('palm',hp+[0,0,.12],hR)},seconds=4.,feedback=.5,rotation_feedback=.3)
    p,R,_,state=pose(c,name)
    if p[2]<before[2]+.035 or state['robot_contact_force']<.5:
        raise RuntimeError('fixture: supported rail did not establish a sustained lift')
    pose_carry(c,grip,[.30,.20,1.02],np.eye(3),6.,'fixture_supported_frame_reorient')
    reference_place.frame(c,grip,name)
    if 'left_frame' not in c.env.status['completed'] or 'left_frame' not in c.env.status.get('fixture_uses',{}):
        raise RuntimeError('fixture: credited use and left-frame installation did not survive the relocation')
    c.event('fixture_use_left_frame_integrated_success',uses=c.env.status['fixture_uses'])

def ref_fixture_probe(c,m,slide=False):
    """Fresh-scene fixture handling diagnostic, with no assembly success claim."""
    from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,Held,release
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.)
    park_unused_arm(c,'right')
    m.high_id='deploy_fixture';name='temporary_fixture';fit=m.contract['grasp_profiles']['fixture']
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])-[0,0,.006],hand=fit['hand_joints'],squeeze=.55 if slide else .80,hook=0.)
    p,_,yaw,_=pose(c,name);side='left' if p[1]>0 else 'right'
    # The fixture is 70 mm along x and 55 mm along y. This fitted 55 mm
    # aperture already opposes y; rotating it by 90 degrees hits the top edge.
    grip=HubGrip(c,name,side,yaw,profile=profile);grip.grasp()
    if slide:
        held=Held(grip,level=True);goal=p+[0,-.12,0]
        c.event('fixture_table_supported_slide');held.move(goal,yaw,seconds=4.,settle=.3)
        actual,_,_,state=pose(c,name)
        if np.linalg.norm(actual-goal)>.015 or state['support_forces'].get('table',0)<.05:
            raise RuntimeError('fixture: supported slide missed the destination')
        release(c,grip,seconds=1.);c.hold(.8)
        actual,_,_,state=pose(c,name)
        if state['robot_contact_force']>.05 or np.linalg.norm(actual-goal)>.015 or state['support_forces'].get('table',0)<.05:
            raise RuntimeError('fixture: released slide is not stable on the table')
        c.event('fixture_slide_probe_success',position=actual.tolist());return
    held=Held(grip,level=True);c.event('fixture_probe_lift')
    held.move(p+[0,0,.07],yaw,seconds=3.,settle=.3)
    actual,_,_,state=pose(c,name)
    if actual[2]<p[2]+.035 or state['robot_contact_force']<.05:
        raise RuntimeError('temporary fixture: fitted grasp failed lift probe')
    hp,hR=c.hand_pose(side);c.event('fixture_curl_after_table_clearance')
    for i in range(50):
        grip.hook=.12*(i+1)/50
        c.reach({side:('palm',hp,hR)},feedback=.5,rotation_feedback=.3);c.step()
    c.event('fixture_probe_relocate')
    goal=p+[0,-.12,.07];held.move(goal,yaw,seconds=3.,settle=.3)
    held.move(goal-[0,0,.068],yaw,seconds=2.,settle=.3)
    release(c,grip,seconds=1.);c.hold(.8)
    actual,_,_,state=pose(c,name)
    if state['robot_contact_force']>.05 or np.linalg.norm(actual-(goal-[0,0,.07]))>.015:
        raise RuntimeError('temporary fixture: released relocation missed target')
    c.event('fixture_probe_success',position=actual.tolist())

def ref_frames_replay(c,m):
    """Lift only the near post, then acquire the upper rail with the other hand."""
    ref_01(c,m,slots=['left_frame'],park_idle=True)
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.)
    push_right_frame_front(c)
    name='right_frame';m.high_id=name;p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([-.0841,-.00329093125,0.])
    right=Pinch(c,name,'right',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi/2,squeeze=.55,opening=.4)
    right.grasp(hover=.12)
    p,R,_,_=pose(c,name);pivot=p+R@[.0841,-.00329093125,0.]
    delta=Rotation.from_rotvec(-R[:,2]*.30).as_matrix()
    pose_carry(c,right,pivot+delta@(p-pivot),delta@R,2.5,'right_frame_table_supported_pivot')
    actual,R,yaw,state=pose(c,name)
    if actual[2]<p[2]+.012 or state['robot_contact_force']<.05:
        raise RuntimeError('right frame: partial pivot failed to expose upper rail')
    solve=c.ik.solve;keep_side='right';hp,hR=c.hand_pose(keep_side)
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        return solve(root_pos,root_quat,q,dict(tasks,**{keep_side:('palm',hp,hR)}),*args,**kwargs)
    c.ik.solve=keep
    try:
        anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,-.00329093125,.0773333333])
        left=Pinch(c,name,'left',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi,squeeze=.55,opening=.4)
        c.event('right_frame_upper_rail_handoff');left.grasp(hover=.12)
        keep_side='left';hp,hR=c.hand_pose(keep_side)
        right.release(seconds=1.3,rise=.10)
        park_unused_arm(c,'right')
    finally:c.ik.solve=solve
    p,R,_,_=pose(c,name)
    pose_carry(c,left,p+[0,0,.15],R,3.,'right_frame_upper_rail_lift')
    p,R,_,state=pose(c,name)
    if state['robot_contact_force']<.05:raise RuntimeError('right frame: handoff lost physical grasp')
    pose_carry(c,left,[.30,0.,1.02],np.eye(3),6.,'right_frame_handoff_reorient')
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 or state['robot_contact_force']<.05:
        raise RuntimeError('right frame: handoff did not achieve held upright pose')
    c.event('right_frame_pivot_probe_success',position=p.tolist())
    from .reference_place import frame
    frame(c,left,name);c.hold(1.)
    if name not in c.env.status['completed']:raise RuntimeError('right frame: restored handoff failed original placement predicate')
    c.event('two_frames_replay_integrated_success')


def gear_handoff(c,m):
    return gear_02(c,m,repair_fn=repair_inverted_handoff)

def gear_late_handoff(c,m):
    return gear_02(c,m,repair_fn=lambda c,n,f:repair_inverted_gear(c,n,f,shaft_release=True,late_receiver=True))

def gear_unhook(c,m):
    return gear_02(c,m,repair_fn=lambda c,n,f:repair_inverted_gear(c,n,f,shaft_release=True,unhook=True))

def gear_handle_pivot(c,m):
    return gear_02(c,m,repair_fn=lambda c,n,f:repair_inverted_gear(c,n,f,shaft_release=True,handle_pivot=True))

def repair_inverted_handoff(c,name,fit=None):
    """Rim pinch, physical lift/flip, park upright, then use the regular hub grasp."""
    p,R,_,_=pose(c,name)
    if fit:
        from humanoid.g1_gear_assembly.solution.stage_gears import COLLAR_PROFILE
        top=Pinch(c,name,'left',COLLAR_PROFILE,azimuth=np.pi,squeeze=.4,finger_squeeze=.15)
        receiver_start=np.array([.28,.02,1.14])
        receiver_R=Rotation.from_euler('z',np.pi).as_matrix()@COLLAR_PROFILE['rotation']
        receiver_offset=Rotation.from_euler('z',np.pi).as_matrix()@COLLAR_PROFILE['offset']
        c.event('repair_preposition_receiver')
        c.move_joints(top.curled(-top.opening),seconds=1.)
        from .reach_screen import goto as screened_goto
        screened_goto(c,{'left':('palm',receiver_start,receiver_R)},seconds=2.5)
        receiver_solve=c.ik.solve
        def follow_receiver(root_pos,root_quat,q,tasks,*args,**kwargs):
            object_p,object_R,_,_=pose(c,name)
            amount=float(np.clip((object_R[2,2]+.8)/1.7,0.,1.))
            endpoint=object_p+receiver_offset+[0,0,.035]
            endpoint[2]=max(1.14,endpoint[2])
            target=receiver_start+amount*(endpoint-receiver_start)
            return receiver_solve(root_pos,root_quat,q,dict(tasks,left=('palm',target,receiver_R)),*args,**kwargs)
        c.ik.solve=follow_receiver
        from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,release
        shape=dict(fit['hand_joints'])
        shape['thumb_1']+=.08;shape['thumb_2']-=.08
        for finger in ('index','middle'):
            shape[finger+'_0']+=.25;shape[finger+'_1']-=.25
        # The outer teeth forced the fully open thumb against its stop in a05.
        # Approach with the palm offset toward that thumb, opening the opposing
        # fingers instead; closure then stays inside the thumb's working range.
        # The inverted rim has free space below it, above the base plate.
        # Contact lower on the tooth faces so modest slip cannot eject the
        # index fingertip over their upper edge during extraction.
        # Recorded mesh distances put all three loaded contacts about 14 mm
        # to one side of the gear COM. Centre their support polygon before
        # lifting; merely curling harder did not prevent the subsequent roll.
        profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])+[.014,-.008,-.012],
                     hand=shape,squeeze=.65,hook=0.)
        # Oppose the disk rim along x so the fingertips clear its neighbours
        # along y. The inverted tooth disk occupies z=[0,.025] locally.
        grip=HubGrip(c,name,'right',np.pi/2,profile=profile)
        grip.grasp()
    else:
        grip=Pinch(c,name,'right',HOOK_PROFILE,anchor=R@np.array([0.,-.045,0.]),squeeze=.4)
        grip.grasp(hover=.12)
    if fit:
        from humanoid.g1_gear_assembly.solution.stage_gears import gear_seat
        start,R0,yaw,_=pose(c,name);hp,hR=c.hand_pose('right')
        local_p=R0.T@(hp-start);local_R=R0.T@hR
        seat,_=gear_seat(c,name);goal=np.r_[seat[:2],start[2]+.065]
        desired_R=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi).as_matrix()
        cp=np.zeros(3);cr=np.zeros(3)
        c.event('repair_axis_aligned_extraction')
        for i in range(250):
            fraction=min(1.,(i+1)/200);a=fraction**3*(10-15*fraction+6*fraction*fraction)
            desired=start+a*(goal-start);actual,actual_R,_,_=pose(c,name)
            # Once the shaft is clear, curl the distal pads gradually into
            # the rim. Recorded contact geometry showed all pads migrating
            # to the top edge during the centred but flat pinch.
            if actual[2]>start[2]+.04:grip.hook=min(.15,grip.hook+.003)
            cp=np.clip(cp+np.clip(.06*(desired-actual),-.0004,.0004),-.035,.035)
            error=Rotation.from_matrix(desired_R@actual_R.T).as_rotvec()
            cr=np.clip(cr+np.clip(.03*error,-.001,.001),-.20,.20)
            command_R=Rotation.from_rotvec(cr).as_matrix()@desired_R
            c.reach({'right':('palm',desired+cp+command_R@local_p,command_R@local_R)},feedback=.4,rotation_feedback=.3,iters=12)
            c.step()
    else:shift_hands(c,['right'],[0,0,.12],seconds=3.)
    c.hold(.3)
    current,R,_,s=pose(c,name)
    if s['robot_contact_force']<=.05 or current[2]<p[2]+.04:
        raise RuntimeError('inverted gear: rim grasp failed extraction probe')
    if fit:
        # Rotate while leaving the shaft, instead of spending the available
        # rim hold lifting the inverted part to a 1.10 m clearance waypoint.
        # This keeps the palm lower and ends with it supporting the disk below.
        pose_carry(c,grip,[.38,-.18,1.02],np.eye(3),6.,'repair_transfer_and_flip')
        # The rim can rotate slightly inside the pinch during the half-turn.
        # Re-estimate the measured hand/part transform before the final trim.
        for attempt in range(3):
            if pose(c,name)[1][2,2]>.97:break
            pose_carry(c,grip,[.38,-.18,1.02],np.eye(3),2.,'repair_measured_flip_trim')
    for _ in range(0 if fit else 24):
        current,R,_,s=pose(c,name)
        if s['robot_contact_force']<=.05:raise RuntimeError('inverted gear: grasp lost during flip')
        vec=Rotation.from_matrix(R.T).as_rotvec()
        if np.linalg.norm(vec)<.05:break
        rot=Rotation.from_rotvec(vec*min(1.,.16/np.linalg.norm(vec))).as_matrix()
        shift_hands(c,['right'],[0,0,0],seconds=.8,pivot=current,rot=rot)
    if fit:
        from humanoid.g1_gear_assembly.solution.stage_gears import Held,insert_held,COLLAR_PROFILE
        c.ik.solve=receiver_solve
        if pose(c,name)[1][2,2]<.95:raise RuntimeError('inverted gear: incomplete physical flip')
        # Keep the supporting hand in world coordinates while the other hand
        # acquires the now exposed hub. Only the normal IK targets are merged.
        solve=c.ik.solve
        keep_side='right';hp,hR=c.hand_pose(keep_side)
        def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
            actual_p,actual_R=c.hand_pose(keep_side)
            corrected_p=hp+np.clip(.6*(hp-actual_p),-.015,.015)
            error=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
            corrected_R=Rotation.from_rotvec(.4*error).as_matrix()@hR
            return solve(root_pos,root_quat,q,dict(tasks,**{keep_side:('palm',corrected_p,corrected_R)}),*args,**kwargs)
        c.ik.solve=keep
        try:
            c.event('repair_handoff_grasp_hub')
            held_position=pose(c,name)[0]
            _,errors=c.ik.solve(c.env.base_position,(1,0,0,0),c.q,top.target(),iters=300,damping=.02,w_rot=.5,max_step=.08)
            if max(errors.values())>.004:raise RuntimeError('repair: receiving hover is not jointly reachable')
            # Joint interpolation moved the supporting hand away from its
            # world target midway through an otherwise reachable approach.
            # Track both hands throughout the Cartesian approach instead.
            c.event('repair_receiving_cartesian_approach',errors=errors)
            c.move_hands(top.target(),seconds=1.,feedback=.5,rotation_feedback=.3)
            c.event('repair_receiving_collar_close');c.move_joints(top.curled(.4),seconds=1.)
            from humanoid.g1_gear_assembly.solution.skills import side_forces
            receiving=side_forces(c,name)
            c.event('repair_handoff_contact_check',forces=receiving)
            current,current_R,_,_=pose(c,name)
            if receiving['left']<.5 or np.linalg.norm(current-held_position)>.025 or current_R[2,2]<.95:
                raise RuntimeError('repair: receiving hand has not acquired the upright suspended gear')
            keep_side='left';hp,hR=c.hand_pose(keep_side)
            c.event('repair_handoff_release_rim')
            grip.closed=False;q=c.q.copy()
            for j in ('thumb_0','thumb_1','middle_0','index_0'):q[grip.joint(j)]=grip.open[j]
            c.move_joints(q,seconds=1.3)
            right_p,right_R=c.hand_pose('right')
            c.move_hands({'right':('palm',right_p+[0,-.12,-.06],right_R)},seconds=2.)
            c.joint_feedback.pop(grip.key,None)
        finally:c.ik.solve=solve
        held=Held(top)
        start=pose(c,name)[0];held.move(start+[0,0,.04],pose(c,name)[2],seconds=2.,settle=.3)
        if pose(c,name)[3]['robot_contact_force']<.05:raise RuntimeError('repair: hub handoff lost the gear')
        insert_held(c,name,held);top.release(seconds=1.2,rise=.10);c.hold(.8)
        return True
    goal=np.array([.35,-.38,c.env.cfg.table_height+c.env.catalog['parts'][name]['size'][2]/2+.003])
    for dz in (.08,.02,0.):
        current,R,_,s=pose(c,name)
        if s['robot_contact_force']<=.05:raise RuntimeError('inverted gear: grasp lost before staging')
        shift_hands(c,['right'],goal+[0,0,dz]-current,seconds=2.)
    if fit:release(c,grip,seconds=1.)
    else:grip.release(seconds=1.,rise=.12)
    c.hold(.6)
    if pose(c,name)[1][2,2]<.95:raise RuntimeError('inverted gear: not upright after physical flip')

def ref_crossbar_table_probe(c,m):
    """Acquire the near end tie symmetrically, then clear its supply beam."""
    ref_01(c,m,slots=['left_frame'],park_idle=True)
    prepare_interior_hands(c);configure_ik(c);raise_hands(c,seconds=2.);park_unused_arm(c,'right')
    candidates=[n for n in c.env.catalog['parts'] if n.endswith('crossbar')]
    name=max(candidates,key=lambda n:pose(c,n)[0][2]);m.high_id='lower_crossbar'
    p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,.1485,0.])
    c.event('select_exposed_supply_crossbar',selected=name)
    from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip
    fit=m.contract['grasp_profiles']['frame']
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])+[0,0,-.001],hand=fit['hand_joints'],squeeze=.45,hook=.12)
    grip=HubGrip(c,name,'left',yaw-np.pi,profile=profile,anchor=anchor)
    from .reach_screen import goto as screened_goto
    grip.preshape(seconds=1.)
    screened_goto(c,grip.target(.06),seconds=2.5)
    c.event('crossbar_short_hover_descend')
    closing_target=grip.target()
    c.move_hands(closing_target,seconds=2.,feedback=.7,rotation_feedback=.3)
    grip.closed=True;start=c.q.copy()
    active=[grip.joint(j) for j in ('thumb_1','middle_0','index_0')]
    from humanoid.g1_gear_assembly.solution.skills import smooth
    c.event('crossbar_centered_rail_close')
    for i in range(60):
        c.q[active]=start[active]+smooth(min(1.,(i+1)/40))*np.array([1.,-1.,-1.])*grip.squeeze
        c.reach(closing_target,feedback=.7,rotation_feedback=.3);c.step()
    hp,hR=c.hand_pose('left')
    c.event('crossbar_pull_clear_of_supply_rack')
    c.move_hands({'left':('palm',hp+[-.32,0,0],hR)},seconds=6.,feedback=.5,rotation_feedback=.3)
    from humanoid.g1_gear_assembly.solution.stage_gears import release
    release(c,grip,seconds=1.)
    hp,hR=c.hand_pose('left');c.move_hands({'left':('palm',hp+[0,0,.12],hR)},seconds=1.5);c.hold(1.5)
    p,R,yaw,state=pose(c,name)
    c.event('crossbar_table_stage_measurement',position=p.tolist(),upright=float(R[2,2]),supports=state['support_forces'])
    if not .20<p[0]<.38 or R[2,2]<.95 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('crossbar: full rack extraction did not settle on the table')
    # The near half of this rail now overhangs the table. Enter from its
    # inner side so the opposed pads can close below the rail, rather than
    # pinching its upper corners against the tabletop.
    # Recorded a66 mesh contacts all stayed on the near face. Advance 6 mm
    # past that face before closing, so thumb and fingers oppose top/bottom.
    # In a76 the thumb migrated to x=-0.0879, the rail's outer edge,
    # before peeling away. Enter another 4 mm so its loaded top contact
    # has lateral margin while the two fingers support the underside.
    rail_point=R@np.array([-.07349098346,.074,0.])
    grip=board_grasp(c,name,'left',fit,world_anchor=rail_point,
                     entry_yaw=yaw,squeeze=.25,follow_tilt=True,opening=.15)
    p,R,_,_=pose(c,name)
    hp,hR=c.hand_pose('left');c.event('crossbar_central_rail_lift')
    from humanoid.g1_gear_assembly.solution.skills import smooth
    for i in range(200):
        actual,_,_,state=pose(c,name)
        if actual[2]>p[2]+.015:grip.hook=min(.12,grip.hook+.003)
        c.reach({'left':('palm',hp+[0,0,.10*smooth((i+1)/200)],hR)},feedback=.5,rotation_feedback=.3);c.step()
    lifted,lift_R,_,state=pose(c,name)
    if lifted[2]<p[2]+.035 or state['robot_contact_force']<.5 or lift_R[2,2]<.90:
        raise RuntimeError('crossbar: central undergrasp failed the slow vertical lift')
    # Preserve the small loaded deflection of the thin rail. Trying to
    # flatten it in free space twists the opposed pads off the 8.9 mm bar.
    pose_carry(c,grip,[.28,.32,lifted[2]],lift_R,4.,'crossbar_front_clearance_transfer',integrate=False)
    carrier_p,loaded_R,loaded_yaw,_=pose(c,name)
    carrier_R=Rotation.from_euler('z',-loaded_yaw).as_matrix()@loaded_R
    pose_carry(c,grip,carrier_p,carrier_R,5.,'crossbar_table_reorient',integrate=False)
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 or state['robot_contact_force']<.05:raise RuntimeError('crossbar: table regrasp did not achieve a held level carrier')
    c.event('crossbar_table_probe_success',position=p.tolist())
    return grip
