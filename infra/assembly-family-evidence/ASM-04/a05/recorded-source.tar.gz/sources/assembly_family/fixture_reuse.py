"""Relocate the released temporary support with measured table contact."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import pose
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,Held,release


def slide(c,fit,goal):
    name='temporary_fixture';p,_,yaw,_=pose(c,name)
    side='left' if p[1]>0 else 'right'
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])-[0,0,.006],
                 hand=fit['hand_joints'],squeeze=.55,hook=0.)
    grip=HubGrip(c,name,side,yaw,profile=profile);grip.grasp()
    held=Held(grip,level=True)
    c.event('reuse_fixture_table_slide',goal=np.asarray(goal).tolist())
    held.move(goal,yaw,seconds=4.,settle=.3)
    release(c,grip,seconds=1.);c.hold(.8)
    p,_,_,state=pose(c,name)
    if np.linalg.norm(p-goal)>.015 or state['robot_contact_force']>.05 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('fixture: repeated relocation lacks stable released table support')
    c.event('reuse_fixture_released',position=p.tolist())
