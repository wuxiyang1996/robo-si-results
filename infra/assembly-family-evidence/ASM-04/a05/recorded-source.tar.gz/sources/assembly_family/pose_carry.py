"""Measured pose servo for a held part, including inverted orientations."""
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from humanoid.g1_gear_assembly.solution.skills import pose,smooth


def move(c,grip,goal,rotation,seconds,phase,stop_when=None,integrate=True):
    name,side=grip.name,grip.side
    p0,R0,_,_=pose(c,name);hp,hR=c.hand_pose(side)
    local_p=R0.T@(hp-p0);local_R=R0.T@hR
    orientation=Slerp([0.,1.],Rotation.from_matrix(np.stack([R0,rotation])))
    cp=np.zeros(3);cr=np.zeros(3);weak=0;n=max(1,round(seconds/.02))
    c.event(phase,goal_position=np.asarray(goal).tolist(),goal_rotation=np.asarray(rotation).tolist())
    for i in range(n+30):
        a=smooth(min(1.,(i+1)/n));desired=p0+a*(np.asarray(goal)-p0);Rd=orientation(a).as_matrix()
        actual,R,_,state=pose(c,name)
        if stop_when is not None and stop_when(actual,R,state):
            c.event(phase+'_handoff_ready',position=actual.tolist())
            return
        weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>10:raise RuntimeError(name+': grasp lost during '+phase)
        if integrate:
            cp=np.clip(cp+np.clip(.045*(desired-actual),-.0003,.0003),-.035,.035)
            error=Rotation.from_matrix(Rd@R.T).as_rotvec()
            cr=np.clip(cr+np.clip(.025*error,-.001,.001),-.22,.22)
        Rc=Rotation.from_rotvec(cr).as_matrix()@Rd
        c.reach({side:('palm',desired+cp+Rc@local_p,Rc@local_R)},feedback=.4,rotation_feedback=.3,iters=12)
        c.step()
