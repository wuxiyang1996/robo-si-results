"""Versioned extension scenes and read-only load-path scoring.

These do not change the released three-object task. Composition credit requires
actual forces through TWO distinct released support bodies; a height sum alone
never earns support credit. Single-piece necessity is not claimed.
"""
from dataclasses import dataclass
from math import cos,radians
from humanoid.g1_tabletop_assembly.task_spec import TaskConfig as OriginalConfig,Evaluator as OriginalEvaluator,_norm

@dataclass(frozen=True)
class ExtensionConfig(OriginalConfig):
    extension: str = 'ASM-03'
    max_episode_seconds: float = 180.
    def __post_init__(self):
        # Original dimension validation runs on the unchanged nominal geometry.
        names=self.measurement_names
        object.__setattr__(self,'measurement_names',('brace','sleeve','cap','fixture'))
        object.__setattr__(self,'brace_size',(.07,.18,.0625))
        super().__post_init__()
        if self.extension not in ('ASM-03','ASM-04'):raise ValueError(self.extension)
        if self.extension=='ASM-03':
            object.__setattr__(self,'brace_size',(.07,.18,.04))
            object.__setattr__(self,'measurement_names',('brace','sleeve','cap','fixture','shim'))
        else:object.__setattr__(self,'measurement_names',('brace','sleeve','cap','fixture','shim','short_stand','wedge'))

    def scene_objects(self):
        specs=super().scene_objects()
        def box(name,size,xy,color):
            return dict(name=name,kind='box',size=size,pos=(*xy,self.table_height+size[2]/2+.001),
                        mass=.18,friction=.7,color=color,fixed=False)
        specs.append(box('shim',(.07,.18,.0225),(.43,-.46),(.56,.23,.75,1.)))
        if self.extension=='ASM-04':
            specs.append(box('short_stand',(.07,.18,.04),(.70,-.40),(.90,.70,.13,1.)))
            specs.append(dict(name='wedge',kind='support_wedge',size=(.14,.10,.0625),
                tip_height=.008,ramp_length=.06,pos=(.72,.40,self.table_height+.03125),
                mass=.30,friction=.7,color=(.20,.70,.36,1.),fixed=False))
        return specs

class ExtensionEvaluator(OriginalEvaluator):
    def update(self,states,dt):
        self.measured=states
        result=super().update(states,dt)
        result['support_path']=getattr(self,'path',[])
        return result
    def _brace_supported(self,brace,fixture):
        cfg=self.cfg;self.path=[]
        if not all(fixture['rotation'][i][i]>=cos(radians(cfg.max_fixture_tilt_degrees)) for i in range(3)):return False
        if not all(abs(fixture['pos'][i]-cfg.fixture_center[i])<=cfg.height_tolerance for i in range(3)):return False
        if not self._slow_released(fixture):return False
        allowed={'brace','shim'} if cfg.extension=='ASM-03' else {'brace','shim','short_stand','wedge'}
        def path(name,seen):
            raw=self.measured[name]
            if raw['robot_contact'] or raw['hand_contact']:return None
            if _norm(raw['linear_velocity'])>cfg.linear_speed_max or _norm(raw['angular_velocity'])>cfg.angular_speed_max:return None
            for support,force in raw['support_forces'].items():
                if force<=.05:continue
                if support=='table':
                    if cfg.extension=='ASM-03' and len(seen)<2:continue
                    return list(seen)+['table']
                if support in allowed and support not in seen:
                    found=path(support,seen+[support])
                    if found:return found
        for name,force in self.measured['fixture']['support_forces'].items():
            if name in allowed and force>.05:
                found=path(name,[name])
                if found:self.path=['fixture']+found;return True
        return False
