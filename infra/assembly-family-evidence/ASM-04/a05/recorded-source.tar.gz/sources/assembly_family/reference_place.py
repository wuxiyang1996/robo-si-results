"""Measured frame alignment and release into the unchanged original fixture."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,shift_hands

def frame(c,grip,slot):
    name,side=grip.name,grip.side
    goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    c.event(name+'_transfer_to_frame_slot',slot=slot)
    for height in (.08,.032):
        for _ in range(8):
            p,R,_,state=pose(c,name)
            if state['robot_contact_force']<.05:raise RuntimeError(name+': grasp lost before frame placement')
            error=goal+[0,0,height]-p
            rv=Rotation.from_matrix(R.T).as_rotvec()
            if np.linalg.norm(error)<.0005 and np.linalg.norm(rv)<.006:break
            correction=Rotation.from_rotvec(rv*min(1.,.10/max(np.linalg.norm(rv),1e-9))).as_matrix()
            shift_hands(c,[side],np.clip(error,-.04,.04),seconds=1.2,pivot=p,rot=correction)
    c.event(name+'_align_feet')
    for _ in range(8):
        p,R,_,_=pose(c,name);foot=p+R@[0,0,-.125]
        delta=np.r_[goal[:2]-foot[:2],0.]
        if np.linalg.norm(delta)<.00025:break
        shift_hands(c,[side],np.clip(delta,-.004,.004),seconds=.6)
    c.event(name+'_insert_feet')
    for _ in range(70):
        p,R,_,_=pose(c,name)
        if p[2]<goal[2]+.003:break
        foot=p+R@[0,0,-.125];xy=goal[:2]-foot[:2]
        yaw=Rotation.from_matrix(R).as_euler('xyz')[2]
        feet_error=max(np.linalg.norm(xy+np.array([x,0])-(R@[x,0,0])[:2]) for x in (-.0841,.0841))
        dz=-.0015 if feet_error<.00040 and abs(yaw)<.002 else 0.
        shift_hands(c,[side],np.r_[np.clip(.6*xy,-.0008,.0008),dz],seconds=.6,pivot=p,yaw=np.clip(-.6*yaw,-.008,.008))
    grip.release(seconds=1.,rise=.10);c.hold(.8)
