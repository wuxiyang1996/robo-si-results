"""FFmpeg pipe with explicit handles, including under Windows redirected sessions."""

import subprocess
from datetime import datetime
import numpy as np
import imageio_ffmpeg


def recording_directory(path):
    """Preserve previous videos together with their matching execution evidence."""
    if path.exists() and any(path.iterdir()):
        path = path.with_name(path.name + "-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
    path.mkdir(parents=True, exist_ok=True)
    print(f"Recording and evidence: {path.resolve()}", flush=True)
    return path


class VideoWriter:
    def __init__(self, path, fps=25):
        self.path = path
        self.fps = fps
        self.process = None

    def append_data(self, frame):
        frame = np.ascontiguousarray(frame, dtype=np.uint8)
        if self.process is None:
            h, w = frame.shape[:2]
            self.log = open(self.path.with_suffix(".ffmpeg.log"), "wb")
            self.process = subprocess.Popen(
                [
                    imageio_ffmpeg.get_ffmpeg_exe(),
                    "-y",
                    "-f",
                    "rawvideo",
                    "-vcodec",
                    "rawvideo",
                    "-s",
                    f"{w}x{h}",
                    "-pix_fmt",
                    "rgb24",
                    "-r",
                    str(self.fps),
                    "-i",
                    "-",
                    "-an",
                    "-vcodec",
                    "libx264",
                    "-pix_fmt",
                    "yuv420p",
                    str(self.path),
                ],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=self.log,
            )
        self.process.stdin.write(frame.tobytes())

    def close(self):
        if self.process:
            self.process.stdin.close()
            code = self.process.wait()
            self.log.close()
            if code:
                raise RuntimeError(f"FFmpeg exited {code}")
