"""Validated explicit step-up solution; see README.md for scope and evidence."""
