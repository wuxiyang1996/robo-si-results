"""Expert oracle for the G1 support-retrieval task: plan from the episode, then run skills."""
