"""H6: physical G1 box transport up stairs."""
