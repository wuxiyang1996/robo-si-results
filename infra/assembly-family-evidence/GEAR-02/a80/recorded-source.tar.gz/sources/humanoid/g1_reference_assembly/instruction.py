"""Public episode instructions, independent of physics and private scoring.

A local bundle contains ``bundle.json`` and PNG assets. Its complete JSON schema
is::

    {"schema_version": 1, "title": "Build the reference assembly",
     "goal_image": "goal.png",
     "steps": [{"id": "base", "text": "Place the base.", "depends_on": []},
               {"id": "cap", "text": "Fit the cap.",
                "depends_on": ["base"], "image": "steps/cap.png"}]}

Dependencies must name earlier steps. The order and dependencies are authored
instructions, not evaluator progress. There are deliberately no fields for
target poses, random seeds, hidden object state, scores, or completed steps.
Images and text are public assets and must be authored without private truth.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, ClassVar

import numpy as np
from PIL import Image, UnidentifiedImageError


class InstructionValidationError(ValueError):
    """A reference bundle does not satisfy the public instruction contract."""


def _text(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise InstructionValidationError(f"{name} must be a nonempty string")
    return value


def _png_rgb(path: Path) -> np.ndarray:
    if path.suffix.lower() != ".png":
        raise InstructionValidationError(f"Image must be a PNG: {path.name}")
    try:
        with Image.open(path) as image:
            if image.format != "PNG":
                raise InstructionValidationError(f"Image is not PNG content: {path.name}")
            # Composite transparency against white so every consumer receives
            # the same visible reference, including palette PNGs with alpha.
            rgba = image.convert("RGBA")
            background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
            rgb = Image.alpha_composite(background, rgba).convert("RGB")
            result = np.array(rgb, dtype=np.uint8, copy=True)
    except (OSError, UnidentifiedImageError) as exc:
        raise InstructionValidationError(f"Cannot read PNG: {path}") from exc
    result.setflags(write=False)
    return result


def _keys(value: Any, *, required: set[str], optional: set[str], name: str) -> dict:
    if not isinstance(value, dict):
        raise InstructionValidationError(f"{name} must be an object")
    missing = required - value.keys()
    unknown = value.keys() - required - optional
    if missing:
        raise InstructionValidationError(f"{name} missing fields: {', '.join(sorted(missing))}")
    if unknown:
        raise InstructionValidationError(f"{name} has unsupported fields: {', '.join(sorted(unknown))}")
    return value


def _asset_path(bundle_root: Path, value: Any, name: str) -> Path:
    value = _text(value, name)
    windows_path = PureWindowsPath(value)
    relative = PurePosixPath(value.replace("\\", "/"))
    if windows_path.drive or windows_path.root or relative.is_absolute() or ".." in relative.parts:
        raise InstructionValidationError(f"{name} must be a relative path inside the bundle")
    candidate = (bundle_root / Path(*relative.parts)).resolve()
    if not candidate.is_relative_to(bundle_root):
        raise InstructionValidationError(f"{name} resolves outside the bundle")
    return candidate


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise InstructionValidationError(f"Duplicate JSON field: {key}")
        result[key] = value
    return result


@dataclass(frozen=True)
class InstructionStep:
    """One public step, with an optional illustrative PNG and explicit inputs."""

    id: str
    text: str
    depends_on: tuple[str, ...] = ()
    image: Path | None = None
    _image_rgb: np.ndarray | None = field(init=False, repr=False, compare=False, default=None)

    def __post_init__(self) -> None:
        _text(self.id, "step.id")
        _text(self.text, "step.text")
        if not isinstance(self.depends_on, (list, tuple)):
            raise InstructionValidationError("step.depends_on must be a list or tuple of step IDs")
        dependencies = tuple(_text(item, "step.depends_on entry") for item in self.depends_on)
        if len(set(dependencies)) != len(dependencies):
            raise InstructionValidationError(f"Step {self.id!r} has duplicate dependencies")
        object.__setattr__(self, "depends_on", dependencies)
        if self.image is not None:
            image_path = Path(self.image).resolve()
            object.__setattr__(self, "image", image_path)
            object.__setattr__(self, "_image_rgb", _png_rgb(image_path))

    def image_rgb(self) -> np.ndarray | None:
        """Return an independent RGB copy, or None when this step has no image."""
        return None if self._image_rgb is None else self._image_rgb.copy()

    def public_observation(self) -> dict[str, Any]:
        result = {"id": self.id, "text": self.text, "depends_on": list(self.depends_on)}
        if self._image_rgb is not None:
            result["image"] = self.image_rgb()
        return result


@dataclass(frozen=True)
class ReferenceInstruction:
    """An immutable public episode goal and its ordered construction steps.

    Loading caches decoded images. Subsequent changes to source files or arrays
    returned to a policy cannot alter this episode's reference instruction.
    Private recipe geometry and evaluator state belong to another object.
    """

    title: str
    goal_image: Path
    steps: tuple[InstructionStep, ...]
    schema_version: ClassVar[int] = 1
    _goal_image_rgb: np.ndarray = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        _text(self.title, "title")
        if not isinstance(self.steps, (list, tuple)) or not self.steps:
            raise InstructionValidationError("steps must be a nonempty ordered list or tuple")
        steps = tuple(self.steps)
        seen = set()
        for step in steps:
            if not isinstance(step, InstructionStep):
                raise InstructionValidationError("Every step must be an InstructionStep")
            if step.id in seen:
                raise InstructionValidationError(f"Duplicate step ID: {step.id}")
            missing = set(step.depends_on) - seen
            if missing:
                raise InstructionValidationError(
                    f"Step {step.id!r} dependencies must name earlier steps: {', '.join(sorted(missing))}"
                )
            seen.add(step.id)
        object.__setattr__(self, "steps", steps)
        goal_path = Path(self.goal_image).resolve()
        object.__setattr__(self, "goal_image", goal_path)
        object.__setattr__(self, "_goal_image_rgb", _png_rgb(goal_path))

    @classmethod
    def load(cls, bundle: str | Path) -> ReferenceInstruction:
        """Load a local bundle directory or manifest, rejecting unknown fields.

        Every step explicitly supplies ``depends_on``, including an empty list
        for a starting step. All asset paths are confined to the manifest's
        directory, including after resolving symbolic links.
        """
        manifest = Path(bundle).resolve()
        if manifest.is_dir():
            manifest = manifest / "bundle.json"
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"), object_pairs_hook=_unique_json_object)
        except (OSError, json.JSONDecodeError, UnicodeError) as exc:
            raise InstructionValidationError(f"Cannot read reference manifest: {manifest}") from exc
        data = _keys(data, required={"schema_version", "title", "goal_image", "steps"}, optional=set(), name="bundle")
        if type(data["schema_version"]) is not int or data["schema_version"] != cls.schema_version:
            raise InstructionValidationError("Unsupported schema_version; expected integer 1")
        if not isinstance(data["steps"], list) or not data["steps"]:
            raise InstructionValidationError("steps must be a nonempty ordered JSON array")
        steps = []
        for index, raw_step in enumerate(data["steps"]):
            raw_step = _keys(raw_step, required={"id", "text", "depends_on"}, optional={"image"}, name=f"steps[{index}]")
            if not isinstance(raw_step["depends_on"], list):
                raise InstructionValidationError(f"steps[{index}].depends_on must be a JSON array")
            image_path = None
            if "image" in raw_step:
                image_path = _asset_path(manifest.parent, raw_step["image"], f"steps[{index}].image")
            steps.append(InstructionStep(raw_step["id"], raw_step["text"], raw_step["depends_on"], image_path))
        return cls(
            title=data["title"],
            goal_image=_asset_path(manifest.parent, data["goal_image"], "goal_image"),
            steps=tuple(steps),
        )

    def goal_rgb(self) -> np.ndarray:
        """Return the final goal PNG decoded as an independent uint8 HxWx3 array."""
        return self._goal_image_rgb.copy()

    @property
    def steps_text(self) -> tuple[str, ...]:
        return tuple(step.text for step in self.steps)

    def public_observation(self) -> dict[str, Any]:
        """Return only authored public inputs, with no filesystem paths or GT."""
        return {
            "title": self.title,
            "goal_image": self.goal_rgb(),
            "steps": [step.public_observation() for step in self.steps],
        }
