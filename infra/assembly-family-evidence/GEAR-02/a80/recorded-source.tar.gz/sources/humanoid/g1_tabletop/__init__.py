"""Shared physical infrastructure for G1 tabletop manipulation tasks."""
