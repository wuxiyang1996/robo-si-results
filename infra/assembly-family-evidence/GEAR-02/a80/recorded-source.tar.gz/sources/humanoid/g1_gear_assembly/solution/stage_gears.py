"""Gear stages: hub grasp, carry above the journal, align bore and tooth phase, insert, release.

Privileged expert skill: measured gear and base poses close the loop on the
held part. Joint targets are the only actions. The bore stays clear; the hand
holds the exposed hub from above with the fingers pointing away from the robot,
so no finger lies between neighbouring gears.
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from .controller import CONTROL_DT
from .skills import Pinch, configure_ik, goto, pose, raise_hands, rot_z, smooth, wrap

MIRROR = np.diag((1., -1., 1.))
# Left-hand hub profile in the gear frame (origin at the hub bottom), palm down.
# Every gear has the same 40 mm hub with a collar at its top. One left-hand pinch
# (search_hub_grasp.py --radius 0.02 --height 0.025 --lip 0.0025 0.004,
# dev_runs/hublip_small) puts all three fingertips 12 mm up the hub, under the
# collar: a gear that creeps down in the pinch comes to rest on the fingertips.
COLLAR_PROFILE = dict(rotation=np.array([[0.0, 0.0, 1.0000000000000002], [0.9413312149696923, 0.337484138477179, 0.0], [-0.337484138477179, 0.9413312149696923, 0.0]]),
                      offset=np.array([4.386080879379137e-05, 0.00331037002323592, 0.09545508411302829]),
                      hand={'thumb_0': 0.00411285925305063, 'thumb_1': -0.40845631012811395, 'thumb_2': 1.3893398244703141, 'middle_0': -1.0144511449348284, 'middle_1': -1.1367735891126383, 'index_0': -1.0143992812969282, 'index_1': -1.1358039308486956},
                      squeeze=.3, hook=0.)
PROFILES = {name: COLLAR_PROFILE for name in ("small_gear", "medium_gear", "large_gear")}
FINGER_PAIRS = (("thumb", 1, 2), ("middle", 0, 1), ("index", 0, 1))
NEIGHBOR = {"medium_gear": "large_gear", "small_gear": "medium_gear"}


def gear_seat(c, name):
    """Seated gear origin from the measured base frame (catalog goal offsets)."""
    p, R, _, _ = pose(c, "base")
    parts = c.env.catalog["parts"]
    local = np.asarray(parts[name]["goal_local"]) - np.asarray(parts["base"]["goal_local"])
    return p + R @ local, R


def mesh_yaw(c, name, yaw):
    """Nearest yaw (relative to the base) that meshes with the measured neighbour."""
    neighbor = NEIGHBOR.get(name)
    if neighbor is None:
        return yaw
    _, _, base_yaw, _ = pose(c, "base")
    _, _, other_yaw, _ = pose(c, neighbor)
    n = c.env.catalog["parts"][name]["teeth"]
    m = c.env.catalog["parts"][neighbor]["teeth"]
    phase = n * (yaw - base_yaw) + m * (other_yaw - base_yaw)
    return yaw - math.atan2(math.sin(phase), math.cos(phase)) / n


class HubGrip:
    """Top pinch around a round feature; `anchor` locates it in the part's yaw frame."""

    def __init__(self, c, name, side, azimuth, profile=None, anchor=(0., 0., 0.)):
        self.c, self.name, self.side = c, name, side
        self.anchor = np.asarray(anchor, dtype=float)
        profile = profile or PROFILES[name]
        R, offset = profile["rotation"], profile["offset"]
        if side == "right":
            R, offset = MIRROR @ R @ MIRROR, MIRROR @ offset
        Rz = rot_z(azimuth)
        self.rotation, self.offset = Rz @ R, Rz @ offset
        self.sign = 1. if side == "left" else -1.
        self.open = {j: (v if side == "left" or j == "thumb_0" else -v) for j, v in profile["hand"].items()}
        self.sums = {f: self.open[f"{f}_{a}"] + self.open[f"{f}_{b}"] for f, a, b in FINGER_PAIRS}
        self.squeeze, self.hook = profile["squeeze"], profile.get("hook", 0.)
        self.key = f"{side}_hub"
        self.closed = False

    def joint(self, j):
        return self.c.index[f"{self.side}_hand_{j}_joint"]

    def feedback(self, c):
        actual = c.actual_q()
        for finger, a, b in FINGER_PAIRS:
            ia, ib = self.joint(f"{finger}_{a}"), self.joint(f"{finger}_{b}")
            desired = self.sums[finger]
            if self.closed:
                desired += self.sign * self.hook * (1. if finger == "thumb" else -1.)
            error = desired - actual[ia] - actual[ib]
            c.q[ib] = np.clip(desired - actual[ia] + .5 * error, c.lo[ib] + 1e-5, c.hi[ib] - 1e-5)

    def target(self, height=0.):
        p, _, yaw, _ = pose(self.c, self.name)
        p = p + rot_z(yaw) @ self.anchor
        return {self.side: ("palm", p + self.offset + [0., 0., height], self.rotation)}

    def preshape(self, seconds=.6):
        c = self.c
        c.joint_feedback.pop(self.key, None)
        q = c.q.copy()
        for j, v in self.open.items():
            q[self.joint(j)] = v
        c.move_joints(q, seconds)
        c.joint_feedback[self.key] = self.feedback

    def grasp(self, lift=.06):
        c = self.c
        c.event(f"{self.name}_preshape", side=self.side)
        self.preshape()
        hover = self.target(.12)
        c.event(f"{self.name}_approach")
        goto(c, hover, seconds=2.5)
        c.move_hands(hover, seconds=.4, feedback=.6, settle=.3, rotation_feedback=.3)
        c.event(f"{self.name}_descend")
        tasks = self.target()
        c.move_hands(tasks, seconds=1.8, feedback=.7, settle=.3, rotation_feedback=.3)
        c.event(f"{self.name}_close")
        self.closed = True
        start = c.q.copy()
        active = [self.joint(j) for j in ("thumb_1", "middle_0", "index_0")]
        delta = np.array([self.sign, -self.sign, -self.sign]) * self.squeeze
        for i in range(round(1.2 / CONTROL_DT)):
            a = smooth((i + 1) * CONTROL_DT / .8)
            c.q[active] = start[active] + a * delta
            c.reach(tasks, feedback=.8, iters=12, rotation_feedback=.3)
            c.step()
        return tasks


class Held:
    """Track a desired level pose of the held gear from its measured pose."""

    def __init__(self, grip, level=False):
        self.grip, self.c = grip, grip.c
        self.level = level  # integrate tilt as well as yaw (twisting a pinch loosens it)
        p, R, _, _ = pose(self.c, grip.name)
        hp, hR = self.c.hand_pose(grip.side)
        self.local = (R.T @ (hp - p), R.T @ hR)
        self.corr_p, self.corr_r = np.zeros(3), np.zeros(3)

    def track(self, p_des, yaw_des, gain=.05, max_step=.0005, rot_gain=.03, integrate=True):
        rot_gain = rot_gain if self.level else .03
        c, name = self.c, self.grip.name
        p, R, yaw, state = pose(c, name)
        # Contact can read zero for a step while still held; require a sustained loss.
        self.weak = getattr(self, "weak", 0) + 1 if state["robot_contact_force"] < .05 else 0
        if self.weak > 25:
            raise RuntimeError(f"{name}: grasp lost")
        R_des = rot_z(yaw_des)
        if integrate:
            self.corr_p = np.clip(self.corr_p + np.clip(gain * (p_des - p), -max_step, max_step), -.05, .05)
            error = Rotation.from_matrix(R_des @ R.T).as_rotvec()
            if not self.level:
                error[:2] = 0.
            self.corr_r = np.clip(self.corr_r + np.clip(rot_gain * error, -.002, .002), -.3, .3)
        R_cmd = Rotation.from_rotvec(self.corr_r).as_matrix() @ R_des
        lp, lR = self.local
        c.reach({self.grip.side: ("palm", p_des + self.corr_p + R_cmd @ lp, R_cmd @ lR)},
                rate=.8, feedback=.3, iters=12, rotation_feedback=.3)
        c.step()
        return p, R, yaw

    def move(self, p_goal, yaw_goal, seconds, settle=0., **kwargs):
        p0, _, yaw0, _ = pose(self.c, self.grip.name)
        p_goal = np.asarray(p_goal, dtype=float)
        dyaw = math.atan2(math.sin(yaw_goal - yaw0), math.cos(yaw_goal - yaw0))
        count = max(1, math.ceil(seconds / CONTROL_DT))
        for i in range(count):
            a = smooth((i + 1) / count)
            self.track(p0 + a * (p_goal - p0), yaw0 + a * dyaw, **kwargs)
        for _ in range(math.ceil(settle / CONTROL_DT)):
            self.track(p_goal, yaw0 + dyaw, **kwargs)
        p, R, yaw, _ = pose(self.c, self.grip.name)
        return dict(position_error_m=float(np.linalg.norm(p - p_goal)),
                    xy_error_m=float(np.linalg.norm((p - p_goal)[:2])),
                    yaw_error_rad=float(abs(math.atan2(math.sin(yaw - yaw0 - dyaw), math.cos(yaw - yaw0 - dyaw)))),
                    tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))))


def insert(c, name, held, *, tries=4, release_on_engage=False):
    """Bore onto the journal, mesh the teeth, lower to the plate; returns seated height error.

    Heights are relative to the measured seat: the journal top is one tooth/hub
    height `h` above the seated gear origin and the bore bottom `h` below it.
    """
    meta = c.env.catalog["gear_meta"]
    h = (meta["shaft_top"] - meta["shaft_bottom"]) / 2
    seat, _ = gear_seat(c, name)
    _, _, yaw, _ = pose(c, name)
    c.event(f"{name}_carry_above_journal", seat=seat.tolist())
    held.move(seat + [0., 0., 2 * h + .04], mesh_yaw(c, name, yaw), seconds=4., settle=.6)
    for attempt in range(tries):
        seat, _ = gear_seat(c, name)
        _, _, yaw, _ = pose(c, name)
        target_yaw = mesh_yaw(c, name, yaw)
        c.event(f"{name}_align_bore", attempt=attempt)
        # The pinch cannot hold the gear away from its hanging attitude (twisting it
        # slips the grasp), so only position and yaw are servoed here.
        result = held.move(seat + [0., 0., 2 * h + .02], target_yaw, seconds=1., settle=1., gain=.08)
        result = held.move(seat + [0., 0., 2 * h + .006], target_yaw, seconds=.8, settle=1.2, gain=.08)
        c.event(f"{name}_aligned", **result)
        c.event(f"{name}_engage_bore", attempt=attempt)
        held.move(seat + [0., 0., 2 * h - .006], target_yaw, seconds=1.5, settle=.3)
        p, _, _, _ = pose(c, name)
        if p[2] - seat[2] > 2 * h - .002:
            c.event(f"{name}_bore_stalled", height=float(p[2] - seat[2]))
            held.move(seat + [0., 0., 2 * h + .012], target_yaw, seconds=.6)
            continue
        if release_on_engage:
            c.event(f"{name}_engaged_release", height=float(p[2] - seat[2]))
            return float(p[2] - seat[2])
        c.event(f"{name}_phase_above_mesh")
        _, _, yaw, _ = pose(c, name)
        target_yaw = mesh_yaw(c, name, yaw)
        held.move(seat + [0., 0., h + .004], target_yaw, seconds=1.2, settle=.6)
        c.event(f"{name}_seat")
        held.move(seat + [0., 0., -.002], mesh_yaw(c, name, pose(c, name)[2]), seconds=1.5, settle=.4)
        p, _, _, _ = pose(c, name)
        c.event(f"{name}_seat_result", height=float(p[2] - seat[2]))
        if p[2] - seat[2] < .004:
            return float(p[2] - seat[2])
        held.move(seat + [0., 0., h + .006], target_yaw + math.pi / c.env.catalog["parts"][name]["teeth"] * .5,
                  seconds=.8, settle=.3)
    raise RuntimeError(f"{name}: insertion did not seat")


def release(c, grip, seconds=.7):
    c.event(f"{grip.name}_release")
    palm, rot = c.hand_pose(grip.side)
    grip.closed = False
    start = c.q.copy()
    for i in range(math.ceil(seconds / CONTROL_DT)):
        a = smooth((i + 1) * CONTROL_DT / seconds)
        for j in ("thumb_0", "thumb_1", "middle_0", "index_0"):
            k = grip.joint(j)
            c.q[k] = start[k] + a * (grip.open[j] - start[k])
        c.reach({grip.side: ("palm", palm, rot)}, feedback=.6, rotation_feedback=.3)
        c.step()
    c.event(f"{grip.name}_withdraw")
    c.move_hands({grip.side: ("palm", palm + [0., 0., .10], rot)}, seconds=1.5, feedback=.5, settle=.2)
    c.joint_feedback.pop(grip.key, None)


def place_gear(c, name, side, azimuth, ready=False, dz=0., squeeze=None, style="hub", pitch_deg=0.,
               release_on_engage=False):
    configure_ik(c)
    if ready:
        raise_hands(c)
    profile = dict(PROFILES[name])
    # A pitch of the hand about the profile x axis (world y after the azimuth) sets
    # how the gear hangs in the pinch; tuned so the bore hangs close to vertical.
    R_extra = Rotation.from_euler("x", pitch_deg, degrees=True).as_matrix()
    profile["rotation"] = R_extra @ np.asarray(profile["rotation"])
    profile["offset"] = R_extra @ np.asarray(profile["offset"]) + np.array((0., 0., dz))
    if squeeze is not None:
        profile["squeeze"] = squeeze
    if style == "hub":
        grip = HubGrip(c, name, side, azimuth, profile=profile)
    else:
        grip = Pinch(c, name, side, profile, azimuth=azimuth, squeeze=profile["squeeze"])
    grip.grasp()
    held = Held(grip)
    p, _, yaw, _ = pose(c, name)
    c.event(f"{name}_lift")
    held.move(p + [0., 0., .09], yaw, seconds=1.8, settle=.5)
    height = insert(c, name, held, release_on_engage=release_on_engage)
    if style == "hub":
        release(c, grip)
    else:
        grip.release(rise=.10)
    if release_on_engage:
        c.hold(1.5)
        seat, _ = gear_seat(c, name)
        height = float(pose(c, name)[0][2] - seat[2])
        c.event(f"{name}_dropped_onto_seat", height=height)
    p, R, yaw, state = pose(c, name)
    seat, _ = gear_seat(c, name)
    result = dict(seated_height_m=height, position_error=(p - seat).tolist(), stage=c.env.status["stage_name"],
                  completed=list(c.env.status["completed"]), conditions=c.env.status["conditions"].get(name))
    c.event(f"{name}_result", **result)
    return result


def run_large(c, ready=True, **kwargs):
    options = dict(style="pinch", pitch_deg=10., dz=-.003, release_on_engage=True)
    options.update(kwargs)
    return place_gear(c, "large_gear", "right", math.pi / 2, ready, **options)


def run_medium(c, ready=True, **kwargs):
    return place_gear(c, "medium_gear", "left", -math.pi / 2, ready, **kwargs)


def run_small(c, ready=True, **kwargs):
    return place_gear(c, "small_gear", "right", math.pi / 2, ready, **kwargs)



HUB_RADIUS = {"large_gear": .0175 * 2.5, "medium_gear": .015 * 2.5}


STAGING = {"large_gear": ("right", math.pi / 2, (.27, -.12)), "medium_gear": ("left", -math.pi / 2, (.27, .12))}


def slide_gear(c, name, xy):
    """One-hand hub pinch that slides the gear on the table to (x, y) without lifting it."""
    side, azimuth, _ = STAGING[name]
    profile = PROFILES[name]
    grip = HubGrip(c, name, side, azimuth, profile=profile)
    grip.grasp()
    held = Held(grip)
    p, _, yaw, _ = pose(c, name)
    c.event(f"{name}_slide", target=list(xy))
    held.move([xy[0], xy[1], p[2] + .001], yaw, seconds=3., settle=.4)
    release(c, grip)
    return pose(c, name)[0]


def place_gear_bimanual(c, name, ready=True, palm_height=.05, force=30., stage=True):
    """Slide the gear in front of the robot (no arm crosses the body there), squeeze the hub
    from +-y with both palms (folded thumbs over the hub top), lift, insert, release."""
    from .skills import PADDLE, PALM_FACE, Bimanual, set_shape
    configure_ik(c)
    if ready:
        raise_hands(c)
    if stage:
        slide_gear(c, name, STAGING[name][2])
    set_shape(c, PADDLE)
    r = HUB_RADIUS[name] + PALM_FACE
    grip = Bimanual(c, name, {"left": (0., r, palm_height), "right": (0., -r, palm_height)}, psi=0., force=force)
    grip.approach(gap=.03, lift=.10)
    grip.squeeze()
    p, _, yaw, _ = pose(c, name)
    c.event(f"{name}_lift")
    grip.move(p + [0., 0., .09], yaw, seconds=2., settle=.5)
    height = insert(c, name, grip)
    grip.release(gap=.03)
    c.hold(.6)
    p, R, yaw, state = pose(c, name)
    seat, _ = gear_seat(c, name)
    result = dict(seated_height_m=height, position_error=(p - seat).tolist(), stage=c.env.status["stage_name"],
                  completed=list(c.env.status["completed"]), conditions=c.env.status["conditions"].get(name))
    c.event(f"{name}_result", **result)
    return result


def run_large_bimanual(c, ready=True, **kwargs):
    return place_gear_bimanual(c, "large_gear", ready, **kwargs)


def probe_hang(c, name="large_gear", side="right", azimuth=math.pi / 2, dz=0., pitch_deg=0., squeeze=None):
    """Development probe: pinch the hub, lift 5 cm, hold, report how the gear hangs."""
    configure_ik(c)
    raise_hands(c)
    profile = dict(PROFILES[name])
    # profile frame: the azimuth turns profile x into world -y for the right hand, so a
    # world-y pitch of the hand is a rotation about profile x here.
    R_extra = Rotation.from_euler("x", pitch_deg, degrees=True).as_matrix()
    profile["rotation"] = R_extra @ np.asarray(profile["rotation"])
    profile["offset"] = R_extra @ np.asarray(profile["offset"]) + np.array((0., 0., dz))
    grip = Pinch(c, name, side, profile, azimuth=azimuth,
                 squeeze=profile["squeeze"] if squeeze is None else squeeze)
    grip.grasp()
    palm, rot = c.hand_pose(side)
    c.move_hands({side: ("palm", palm + [0., 0., .05], rot)}, seconds=1.5, feedback=.5, settle=2.)
    p, R, yaw, state = pose(c, name)
    rpy = Rotation.from_matrix(R).as_euler("xyz", degrees=True)
    return dict(dz=dz, pitch_deg=pitch_deg, z=float(p[2]), roll=float(rpy[0]), pitch=float(rpy[1]),
                contact=state["robot_contact_force"])


def place_gear_rigid(c, name, side, azimuth, ready=False, pitch_deg=10., dz=-.003, lift=.09,
                     engage=.006, tol=.0003, phase=True):
    """One-hand pinch; every move is a converged-IK shift of the commanded hand pose.

    Lift, carry and alignment shift the hand by the measured gear error (no per-step
    integrators that twist the pinch); the bore is engaged a few millimetres on the
    journal, the tooth phase matched to the neighbour, and gravity seats the gear.
    """
    from .skills import shift_hands
    configure_ik(c)
    if ready:
        raise_hands(c)
    profile = dict(PROFILES[name])
    R_extra = Rotation.from_euler("x", pitch_deg, degrees=True).as_matrix()
    profile["rotation"] = R_extra @ np.asarray(profile["rotation"])
    profile["offset"] = R_extra @ np.asarray(profile["offset"]) + np.array((0., 0., dz))
    grip = Pinch(c, name, side, profile, azimuth=azimuth, squeeze=profile["squeeze"])
    grip.grasp()
    meta = c.env.catalog["gear_meta"]
    h = (meta["shaft_top"] - meta["shaft_bottom"]) / 2
    c.event(f"{name}_lift")
    shift_hands(c, [side], [0., 0., lift], seconds=1.5)
    c.hold(.4)
    seat, _ = gear_seat(c, name)
    above = seat + [0., 0., 2 * h + .03]
    c.event(f"{name}_carry", seat=seat.tolist())
    for _ in range(12):
        p, _, _, state = pose(c, name)
        step = above - p
        dist = np.linalg.norm(step)
        if dist < .01:
            break
        step = step * min(1., .03 / dist)
        shift_hands(c, [side], step, seconds=.5)
    c.hold(.4)

    def align(height, tolerance, rounds=8):
        for _ in range(rounds):
            seat_now, _ = gear_seat(c, name)
            p, R, yaw, _ = pose(c, name)
            target = seat_now + [0., 0., height]
            error = target - p
            yaw_error = wrap(mesh_yaw(c, name, yaw) - yaw) if phase else 0.
            if np.linalg.norm(error[:2]) < tolerance and abs(error[2]) < .002 and abs(yaw_error) < .003:
                return error, yaw_error, R
            shift_hands(c, [side], error, seconds=.6, yaw=yaw_error, pivot=p)
            c.hold(.3)
        return error, yaw_error, R

    c.event(f"{name}_align_bore")
    error, yaw_error, R = align(2 * h + .008, tol)
    c.event(f"{name}_aligned", xy_error=float(np.linalg.norm(error[:2])), yaw_error=float(yaw_error),
            tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))))
    c.event(f"{name}_engage_bore")
    p, _, _, _ = pose(c, name)
    seat, _ = gear_seat(c, name)
    shift_hands(c, [side], seat + [0., 0., 2 * h - engage] - p, seconds=1.2)
    c.hold(.5)
    p, _, _, _ = pose(c, name)
    c.event(f"{name}_engaged", height=float(p[2] - seat[2]))
    grip.release(rise=.10)
    c.hold(1.5)
    p, R, yaw, state = pose(c, name)
    seat, _ = gear_seat(c, name)
    result = dict(height=float(p[2] - seat[2]), position_error=(p - seat).tolist(),
                  tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))),
                  stage=c.env.status["stage_name"], completed=list(c.env.status["completed"]),
                  conditions=c.env.status["conditions"].get(name))
    c.event(f"{name}_result", **result)
    return result


def run_large_rigid(c, ready=True, **kwargs):
    return place_gear_rigid(c, "large_gear", "right", math.pi / 2, ready, **kwargs)


def insert_compliant(c, name, held, *, engage=.006, tol=.0004, carry_seconds=2.5):
    """Engage the bore on the journal from a pinch that holds the gear nearly level.

    The bore *bottom* (not the gear origin) is centred over the journal axis with
    slow moves, lowered until it is `engage` on the journal, and the caller then
    opens the hand: the journal guides the gear and gravity seats it.
    """
    meta = c.env.catalog["gear_meta"]
    h = (meta["shaft_top"] - meta["shaft_bottom"]) / 2
    seat, _ = gear_seat(c, name)
    _, _, yaw, _ = pose(c, name)
    c.event(f"{name}_carry_above_journal", seat=seat.tolist())
    held.move(seat + [0., 0., 2 * h + .04], mesh_yaw(c, name, yaw), seconds=carry_seconds, settle=.3)

    def centre(z_origin, seconds, rounds):
        err = None
        for _ in range(rounds):
            seat_now, _ = gear_seat(c, name)
            p, R, yaw, _ = pose(c, name)
            bb = p + R @ np.array((0., 0., -h))
            err = seat_now[:2] - bb[:2]
            target = np.array((p[0] + err[0], p[1] + err[1], seat_now[2] + z_origin))
            held.move(target, mesh_yaw(c, name, yaw), seconds=seconds, settle=.4, gain=.05)
            if np.linalg.norm(err) < tol:
                break
        p, R, _, _ = pose(c, name)
        return float(np.linalg.norm(err)), float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1))))

    c.event(f"{name}_centre_bore_bottom")
    err, tilt = centre(2 * h + .015, 1.5, 1)
    err, tilt = centre(2 * h + .015, .6, 4)
    c.event(f"{name}_bore_centred", error_m=err, tilt_deg=tilt)
    err, tilt = centre(2 * h - engage, 1.5, 1)
    p, _, _, _ = pose(c, name)
    height = float(p[2] - gear_seat(c, name)[0][2])
    c.event(f"{name}_bore_engaged", height=height, error_m=err, tilt_deg=tilt)
    return height


def run_large_compliant(c, ready=True, pitch_deg=0., dz=0., squeeze=.45, finger_squeeze=.15, carry_seconds=2.5):
    configure_ik(c)
    if ready:
        raise_hands(c)
    name, side = "large_gear", "right"
    profile = dict(PROFILES[name])
    R_extra = Rotation.from_euler("x", pitch_deg, degrees=True).as_matrix()
    profile["rotation"] = R_extra @ np.asarray(profile["rotation"])
    profile["offset"] = R_extra @ np.asarray(profile["offset"]) + np.array((0., 0., dz))
    grip = Pinch(c, name, side, profile, azimuth=math.pi / 2, squeeze=squeeze, finger_squeeze=finger_squeeze)
    grip.grasp()
    held = Held(grip)
    p, _, yaw, _ = pose(c, name)
    held.move(p + [0., 0., .09], yaw, seconds=1.2, settle=.2)
    insert_compliant(c, name, held, carry_seconds=carry_seconds)
    grip.release(rise=.10)
    c.hold(1.5)
    p, R, _, _ = pose(c, name)
    seat, _ = gear_seat(c, name)
    result = dict(height=float(p[2] - seat[2]), position_error=(p - seat).tolist(),
                  tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))))
    c.event(f"{name}_result", **result)
    return result


def bore_error(c, name, h):
    """Horizontal offset of the bore bottom from the journal axis, and the gear tilt."""
    seat, _ = gear_seat(c, name)
    p, R, _, _ = pose(c, name)
    bottom = p + R @ np.array((0., 0., -h))
    return seat[:2] - bottom[:2], float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1))))


def servo_down(c, name, held, h, z_from, z_to, seconds):
    """Lower the gear origin from z_from to z_to above the seat while servoing the
    measured bore bottom onto the journal axis at every control step."""
    count = max(1, math.ceil(seconds / CONTROL_DT))
    _, _, yaw0, _ = pose(c, name)
    yaw_goal = mesh_yaw(c, name, yaw0)
    for i in range(count):
        z = z_from + smooth((i + 1) / count) * (z_to - z_from)
        err, _ = bore_error(c, name, h)
        p, _, _, _ = pose(c, name)
        seat, _ = gear_seat(c, name)
        held.track(np.array((p[0] + err[0], p[1] + err[1], seat[2] + z)), yaw_goal, gain=.05)
    for _ in range(15):
        err, _ = bore_error(c, name, h)
        p, _, _, _ = pose(c, name)
        seat, _ = gear_seat(c, name)
        held.track(np.array((p[0] + err[0], p[1] + err[1], seat[2] + z_to)), yaw_goal, gain=.05)
    p, _, _, _ = pose(c, name)
    return float(p[2] - gear_seat(c, name)[0][2])


def insert_held(c, name, held, *, tol=.0004, carry_seconds=2.5, engage=.008):
    """Bore bottom over the journal, engage, phase the teeth above the neighbour, seat, all in hand.

    Heights are relative to the measured seat: the journal top is `2h` above the
    seated gear origin, the bore bottom `h` below the origin, and the teeth clear
    the neighbour's teeth while the origin is more than `h` above the seat.
    """
    meta = c.env.catalog["gear_meta"]
    h = (meta["shaft_top"] - meta["shaft_bottom"]) / 2
    seat, _ = gear_seat(c, name)
    _, _, yaw, _ = pose(c, name)
    c.event(f"{name}_carry_above_journal", seat=seat.tolist())
    held.move(seat + [0., 0., 2 * h + .04], mesh_yaw(c, name, yaw), seconds=carry_seconds, settle=.3)

    def centre(z, seconds, rounds, gain=.05):
        err = tilt = None
        for _ in range(rounds):
            err, tilt = bore_error(c, name, h)
            p, _, yaw, _ = pose(c, name)
            seat_now, _ = gear_seat(c, name)
            held.move((p[0] + err[0], p[1] + err[1], seat_now[2] + z), mesh_yaw(c, name, yaw),
                      seconds=seconds, settle=.3, gain=gain)
            err, tilt = bore_error(c, name, h)
            if np.linalg.norm(err) < tol:
                break
        return float(np.linalg.norm(err)), tilt

    c.event(f"{name}_centre_bore")
    err, tilt = centre(2 * h + .006, 1.2, 1)
    err, tilt = centre(2 * h + .006, .6, 5)
    c.event(f"{name}_bore_centred", error_m=err, tilt_deg=tilt)
    for attempt in range(3):
        # One fixed target per move: re-aiming every step couples through the
        # gear's tilt in the pinch and oscillates (dev_runs/v12_desc_servo).
        err, _ = bore_error(c, name, h)
        p, _, yaw, _ = pose(c, name)
        seat, _ = gear_seat(c, name)
        held.move((p[0] + err[0], p[1] + err[1], seat[2] + 2 * h - engage), mesh_yaw(c, name, yaw),
                  seconds=2., settle=.4)
        p, _, _, _ = pose(c, name)
        height = float(p[2] - seat[2])
        err, tilt = bore_error(c, name, h)
        c.event(f"{name}_bore_engaged", attempt=attempt, height=height, error_m=float(np.linalg.norm(err)),
                tilt_deg=tilt)
        if height < 2 * h - .003:
            break
        err, tilt = centre(2 * h + .006, .6, 4)
    else:
        raise RuntimeError(f"{name}: bore stalled on the journal top at {height:.4f}")
    if name in NEIGHBOR:
        c.event(f"{name}_phase_above_mesh")
        err, tilt = centre(h + .004, 1.2, 1)
        _, _, yaw, _ = pose(c, name)
        seat, _ = gear_seat(c, name)
        p, _, _, _ = pose(c, name)
        held.move(p, mesh_yaw(c, name, yaw), seconds=.6, settle=.6, gain=.05)
    c.event(f"{name}_seat")
    seat, _ = gear_seat(c, name)
    p, _, yaw, _ = pose(c, name)
    held.move((p[0], p[1], seat[2] - .002), mesh_yaw(c, name, yaw), seconds=1.5, settle=.4)
    p, _, _, _ = pose(c, name)
    height = float(p[2] - seat[2])
    c.event(f"{name}_seat_result", height=height)
    return height


def place_held(c, name, side, azimuth, *, ready=False, squeeze=.45, finger_squeeze=.15, pitch_deg=0., dz=0.,
               lift=.09, carry_seconds=2.5):
    configure_ik(c)
    if ready:
        raise_hands(c)
    profile = dict(PROFILES[name])
    R_extra = Rotation.from_euler("x", pitch_deg, degrees=True).as_matrix()
    profile["rotation"] = R_extra @ np.asarray(profile["rotation"])
    profile["offset"] = R_extra @ np.asarray(profile["offset"]) + np.array((0., 0., dz))
    grip = Pinch(c, name, side, profile, azimuth=azimuth, squeeze=squeeze, finger_squeeze=finger_squeeze)
    grip.grasp()
    held = Held(grip)
    p, _, yaw, _ = pose(c, name)
    c.event(f"{name}_lift")
    held.move(p + [0., 0., lift], yaw, seconds=1.2, settle=.2)
    height = insert_held(c, name, held, carry_seconds=carry_seconds)
    # Open slowly: a quick release kicks the gear's yaw onto a neighbour's tooth flank.
    grip.release(seconds=1.2, rise=.10)
    c.hold(.6)
    p, R, yaw, state = pose(c, name)
    seat, _ = gear_seat(c, name)
    result = dict(height=float(p[2] - seat[2]), held_height=height, position_error=(p - seat).tolist(),
                  tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))),
                  conditions=c.env.status.get("conditions", {}).get(name))
    c.event(f"{name}_result", **result)
    return result


def run_large_held(c, ready=True, **kwargs):
    return place_held(c, "large_gear", "right", math.pi / 2, ready=ready, **kwargs)


def run_medium_held(c, ready=False, **kwargs):
    options = dict(squeeze=.4, finger_squeeze=.15)
    options.update(kwargs)
    return place_held(c, "medium_gear", "right", math.pi / 2, ready=ready, **options)


def run_small_held(c, ready=False, **kwargs):
    options = dict(squeeze=.25, finger_squeeze=.1)
    options.update(kwargs)
    return place_held(c, "small_gear", "left", -math.pi / 2, ready=ready, **options)
