"""Build a contact-driven, open-bore gear mechanism from NVIDIA/NIST CAD.

Original Factory triangles supply the visible gears and base. Each gear's real
mid-plane CAD outline is decomposed into individual convex teeth and annular
sectors. No whole-gear convex hull, gear equality, joint coupling, or attachment
is created. The cover, corner posts, locating jig, turning tool and visible
rotation witness marks are explicitly authored additions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import numpy as np
from scipy.spatial import ConvexHull
import trimesh


HERE = Path(__file__).resolve().parent
ASSET_ROOT = HERE / "assets"
SOURCE_FALLBACK = Path("D:/rsi_vla/asset_research/nvidia_factory_gears/isaacgymenvs")
COMMIT = "aeed298638a1f7b5421b38f5f3cc2d1079b6d9c3"
BUILD_VERSION = 12
SCALE = 2.5
K = SCALE / 3.  # authored layout lengths below were drawn for the earlier 3x build
SECTORS = 32
PROFILE_TOLERANCE = .00005
BORE_RADIUS = .005 * SCALE
SHAFT_CLEARANCE = .00035  # nominal radial journal clearance, kept absolute
SHAFT_RADIUS = BORE_RADIUS - SHAFT_CLEARANCE
TEETH_HEIGHT = .010 * SCALE  # straight-sided CAD teeth; the upper hub adds the same again
PLATE_TOP = .005 * SCALE
HUB_TOP = PLATE_TOP + 2 * TEETH_HEIGHT
COVER_AXIAL_CLEARANCE = .001
# Self-guiding lead-ins (common assembly features): the task asks for the right
# order and handling, not sub-millimetre alignment. A part released within a few
# millimetres of its fit slides home under gravity.
JOURNAL_LEAD, JOURNAL_TAPER = .008, .004   # tapered journal tip: length, radius reduction
BORE_CHAMFER = .002                        # 45-degree bore-entry chamfer
POST_PILOT, POST_TIP = .006, .002          # cover-post pilot: tapered length, tip width
CUP_CHAMFER = .002                         # inner bottom edge of each cover locating cup
JIG_CHAMFER, JIG_CHAMFER_HEIGHT = .003, .006  # locator-wall inner top chamfer, steep enough to slide at friction 0.8
HUB_LIP_HEIGHT, HUB_LIP_WIDTH = .004, .0025   # collar round each hub top: a pinched gear that creeps
                                           # down comes to rest on the fingertips
COVER_HANDLE_Y = .008                      # cover lifting handle over its centre of mass
TOOTH_FACE_INSET = {}                      # per-gear tooth face-width inset at each end (diagnostic)
COVER_BOTTOM = HUB_TOP + COVER_AXIAL_CLEARANCE
FIXTURE_CLEARANCE = .0015
POST_CLEARANCE = .0005
POLYMER_DENSITY = 1100.
GEARS = {
    # One 40 mm hub (1.6x the bore) on every gear: a hand-sized grip with the same
    # collar, instead of 75-88 mm hubs that a Dex3 pinch barely spans.
    "small_gear": dict(source="small", cx=.0505, teeth=20, hub_radius=.008 * SCALE),
    "medium_gear": dict(source="medium", cx=.0200, teeth=40, hub_radius=.008 * SCALE),
    "large_gear": dict(source="large", cx=-.0305, teeth=60, hub_radius=.008 * SCALE),
}
NAMES = ("base", "small_gear", "medium_gear", "large_gear", "cover", "turning_tool")
DISPLAY = {"base": "三轴底座", "small_gear": "小齿轮", "medium_gear": "中齿轮",
           "large_gear": "大齿轮", "cover": "开窗轴承桥盖", "turning_tool": "拨转杆"}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _nums(values):
    return " ".join(f"{float(v):.10g}" for v in values)


def _rot90(points):
    points = np.asarray(points, float)
    return np.column_stack((-points[:, 1], points[:, 0], points[:, 2]))


def fixture_morph(gs, spec, pos, **kwargs):
    """Genesis morph for a fixed locator wall: its chamfered mesh, or the plain box."""
    if spec.get("mesh"):
        return gs.morphs.Mesh(file=spec["mesh"], pos=tuple(pos), fixed=True, convexify=True, decimate=False, **kwargs)
    return gs.morphs.Box(size=tuple(spec["size"]), pos=tuple(pos), fixed=True, **kwargs)


def _box(pos, size, role):
    return dict(kind="box", pos=list(pos), size=list(size), role=role)


def _cylinder(pos, radius, length, role, rpy=(0., 0., 0.)):
    return dict(kind="cylinder", pos=list(pos), radius=float(radius), length=float(length),
                rpy=list(rpy), role=role)


def _primitive_mesh(spec):
    if spec["kind"] == "box":
        mesh = trimesh.creation.box(extents=spec["size"])
    elif spec["kind"] == "cylinder":
        mesh = trimesh.creation.cylinder(radius=spec["radius"], height=spec["length"], sections=64)
    else:
        return trimesh.load_mesh(spec["mesh"], process=False)
    if "rpy" in spec:
        mesh.apply_transform(trimesh.transformations.euler_matrix(*spec["rpy"], axes="sxyz"))
    mesh.apply_translation(spec["pos"])
    return mesh


def _prism(points, bottom, top):
    """One convex prism; its polygon never contains the central shaft hole."""
    points = np.asarray(points, float)
    polygon = points[ConvexHull(points).vertices]
    n = len(polygon)
    vertices = np.vstack((np.column_stack((polygon, np.full(n, bottom))),
                          np.column_stack((polygon, np.full(n, top)))))
    faces = []
    for i in range(1, n - 1):
        faces.extend(((0, i + 1, i), (n, n + i, n + i + 1)))
    for i in range(n):
        j = (i + 1) % n
        faces.extend(((i, j, n + j), (i, n + j, n + i)))
    mesh = trimesh.Trimesh(vertices=vertices, faces=np.asarray(faces), process=False)
    if mesh.volume < 0:
        mesh.invert()
    return mesh


def _polygon_area(points):
    return .5 * abs(float(np.sum(points[:, 0] * np.roll(points[:, 1], -1)
                                 - points[:, 1] * np.roll(points[:, 0], -1))))


def _simplify_path(points, tolerance=PROFILE_TOLERANCE):
    """Ramer-Douglas-Peucker on the actual tooth boundary, in metric units."""
    if len(points) < 3:
        return points
    edge = points[-1] - points[0]
    t = np.clip((points-points[0]) @ edge / max(float(edge @ edge), 1e-30), 0., 1.)
    distances = np.linalg.norm(points - (points[0] + t[:, None] * edge), axis=1)
    index = int(np.argmax(distances))
    if distances[index] <= tolerance:
        return points[[0, -1]]
    return np.vstack((_simplify_path(points[:index+1], tolerance)[:-1],
                      _simplify_path(points[index:], tolerance)))


def _convex_parts(polygon):
    """Ear-clip a simple tooth polygon, then merge only truly convex unions."""
    signed_area = np.sum(polygon[:,0]*np.roll(polygon[:,1],-1)-polygon[:,1]*np.roll(polygon[:,0],-1))
    if signed_area < 0:
        polygon = polygon[::-1]
    remaining, groups = list(range(len(polygon))), []
    while len(remaining) > 3:
        found = False
        for k in range(len(remaining)):
            ids = [remaining[k-1], remaining[k], remaining[(k+1) % len(remaining)]]
            a, b, c = polygon[ids]
            ab, bc = b-a, c-b
            if ab[0]*bc[1]-ab[1]*bc[0] <= 1e-14:
                continue
            others = np.array([polygon[i] for i in remaining if i not in ids])
            if len(others):
                ca = a-c
                s0 = ab[0]*(others-a)[:,1]-ab[1]*(others-a)[:,0]
                s1 = bc[0]*(others-b)[:,1]-bc[1]*(others-b)[:,0]
                s2 = ca[0]*(others-c)[:,1]-ca[1]*(others-c)[:,0]
                if np.any((s0 >= -1e-14) & (s1 >= -1e-14) & (s2 >= -1e-14)):
                    continue
            groups.append(ids)
            remaining.pop(k)
            found = True
            break
        if not found:
            raise RuntimeError("cannot triangulate source tooth boundary")
    groups.append(remaining)
    while True:
        merged = False
        for i, first in enumerate(groups):
            for j in range(i+1, len(groups)):
                second = groups[j]
                if len(set(first) & set(second)) < 2:
                    continue
                ids = sorted(set(first) | set(second))
                hull = ConvexHull(polygon[ids])
                if hull.volume <= _polygon_area(polygon[first]) + _polygon_area(polygon[second]) + 1e-12:
                    groups[i] = [ids[index] for index in hull.vertices]
                    groups.pop(j)
                    merged = True
                    break
            if merged:
                break
        if not merged:
            break
    parts = [polygon[group] for group in groups]
    if abs(sum(_polygon_area(part) for part in parts)-_polygon_area(polygon)) > 1e-10:
        raise RuntimeError("convex decomposition changed tooth area")
    return parts


def _material_added_distance(raw, simplified, center_angle):
    """Measured outward error on the simplified external boundary (not internals)."""
    samples = np.vstack([a + np.linspace(0., 1., 17)[:,None]*(b-a)
                         for a,b in zip(simplified[:-1],simplified[1:])])
    raw_angles = np.angle(np.exp(1j*(np.arctan2(raw[:,1],raw[:,0])-center_angle)))
    angles = np.angle(np.exp(1j*(np.arctan2(samples[:,1],samples[:,0])-center_angle)))
    expected = np.interp(angles,raw_angles,np.linalg.norm(raw,axis=1))
    samples = samples[np.linalg.norm(samples,axis=1) > expected + 1e-10]
    if not len(samples):
        return 0.
    edges = raw[1:]-raw[:-1]
    delta = samples[:,None,:]-raw[None,:-1,:]
    parameter = np.clip(np.sum(delta*edges[None,:,:],axis=2)
                        / np.maximum(np.sum(edges*edges,axis=1),1e-30)[None,:],0.,1.)
    distance = np.linalg.norm(delta-parameter[:,:,None]*edges[None,:,:],axis=2)
    return float(np.min(distance,axis=1).max())


def _annular_sectors(inner, outer, bottom, top, sectors=SECTORS):
    result = []
    for i in range(sectors):
        angles = np.array((i, i + 1)) * (2 * np.pi / sectors)
        directions = np.column_stack((np.cos(angles), np.sin(angles)))
        points = np.vstack((inner * directions, outer * directions))
        result.append(_prism(points, bottom, top))
    return result


def _cad_outline(path, center_x, teeth):
    """Intersect actual CAD triangles midway through the straight tooth faces."""
    mesh = trimesh.load_mesh(path, process=False)
    triangles, chunks = np.asarray(mesh.triangles), []
    for first, second in ((0, 1), (1, 2), (2, 0)):
        a, b = triangles[:, first], triangles[:, second]
        mask = (a[:, 2] - .010) * (b[:, 2] - .010) < 0
        a, b = a[mask], b[mask]
        t = (.010 - a[:, 2]) / (b[:, 2] - a[:, 2])
        chunks.append((a + (b - a) * t[:, None])[:, :2])
    points = np.unique(np.round(np.vstack(chunks) - (center_x, 0.), 10), axis=0)
    radii = np.linalg.norm(points, axis=1)
    nominal_root = .001 * teeth / 2 - .00125
    points = points[radii > (.005 + nominal_root) / 2]
    angle = np.arctan2(points[:, 1], points[:, 0])
    order = np.argsort(angle)
    points, angle = points[order], angle[order]
    radii = np.linalg.norm(points, axis=1)
    phase = float(np.angle(np.mean(np.exp(1j * teeth * angle[radii > radii.max() - 2e-6]))) / teeth)
    if np.diff(np.r_[angle, angle[0] + 2 * np.pi]).max() > .03:
        raise RuntimeError("CAD cross-section has an unexpected gap")
    return points * SCALE, phase, dict(
        source_cross_section_z_m=.010, tooth_count=teeth, root_radius=float(radii.min() * SCALE),
        tip_radius=float(radii.max() * SCALE), source_phase_radians=phase,
        outline_samples=len(points), source_group=f"GEABP1_0_{teeth}_10_B_10_b")


def _write_mesh_collision(folder, name, index, mesh, role):
    path = folder / "collision" / name / f"{index:03d}_{role}.obj"
    path.parent.mkdir(parents=True, exist_ok=True)
    mesh.export(path)
    return dict(kind="mesh", mesh=str(path.resolve()), role=role)


def _frustum(r_bottom, r_top, bottom, top, sections=64):
    angles = np.linspace(0., 2 * np.pi, sections, endpoint=False)
    ring = np.column_stack((np.cos(angles), np.sin(angles)))
    points = np.vstack((np.column_stack((r_bottom * ring, np.full(sections, bottom))),
                        np.column_stack((r_top * ring, np.full(sections, top)))))
    return trimesh.convex.convex_hull(points)


def _chamfer_sectors(inner_bottom, inner_top, outer, bottom, top, sectors=SECTORS):
    """Bore entry: annular sectors whose inner face widens toward the bottom."""
    result = []
    for i in range(sectors):
        angles = np.array((i, i + 1)) * (2 * np.pi / sectors)
        d = np.column_stack((np.cos(angles), np.sin(angles)))
        points = np.vstack([np.column_stack((r * d, np.full(2, z))) for r, z in
                            ((inner_bottom, bottom), (outer, bottom), (inner_top, top), (outer, top))])
        result.append(trimesh.convex.convex_hull(points))
    return result


def _gear_collisions(folder, name, source_file, spec):
    points, phase, report = _cad_outline(source_file, spec["cx"], spec["teeth"])
    root_radius = report["root_radius"]
    # Straight-sided CAD teeth below the gear origin; the upper hub adds the same height.
    meshes = [(mesh, "bore_hub_sector") for mesh in
              _annular_sectors(BORE_RADIUS, spec["hub_radius"], -TEETH_HEIGHT + BORE_CHAMFER, TEETH_HEIGHT)]
    meshes.extend((mesh, "bore_entry_chamfer") for mesh in
                  _chamfer_sectors(BORE_RADIUS + BORE_CHAMFER, BORE_RADIUS, spec["hub_radius"],
                                   -TEETH_HEIGHT, -TEETH_HEIGHT + BORE_CHAMFER))
    meshes.extend((mesh, "lower_ring_sector") for mesh in
                  _annular_sectors(spec["hub_radius"], root_radius, -TEETH_HEIGHT, 0.))
    meshes.extend((mesh, "hub_lip") for mesh in
                  _annular_sectors(spec["hub_radius"], spec["hub_radius"] + HUB_LIP_WIDTH,
                                   TEETH_HEIGHT - HUB_LIP_HEIGHT, TEETH_HEIGHT))
    angles = np.arctan2(points[:, 1], points[:, 0])
    tooth_pitch = 2 * np.pi / spec["teeth"]
    max_vertices, max_added_distance = 0, 0.
    tooth_piece_counts = []
    for tooth in range(spec["teeth"]):
        center = phase + tooth * tooth_pitch
        delta = np.angle(np.exp(1j * (angles - center)))
        selected = points[np.abs(delta) <= tooth_pitch / 2 + 1e-8]
        selected_delta = delta[np.abs(delta) <= tooth_pitch / 2 + 1e-8]
        selected = selected[np.argsort(selected_delta)]
        edge_angles = center + np.array((-.5, .5)) * tooth_pitch
        roots = root_radius * np.column_stack((np.cos(edge_angles), np.sin(edge_angles)))
        raw = np.vstack((roots[0],selected,roots[1]))
        raw = raw[np.r_[True,np.linalg.norm(np.diff(raw,axis=0),axis=1)>1e-8]]
        simplified = _simplify_path(raw)
        max_added_distance = max(max_added_distance,_material_added_distance(raw,simplified,center))
        pieces = _convex_parts(simplified)
        tooth_piece_counts.append(len(pieces))
        for polygon in pieces:
            inset = TOOTH_FACE_INSET.get(name, 0.)
            mesh = _prism(polygon, -TEETH_HEIGHT + inset, -inset)
            # Rotating the actual CAD preserves the original relative phases.
            mesh.vertices = _rot90(mesh.vertices)
            max_vertices = max(max_vertices, len(mesh.vertices))
            meshes.append((mesh, "cad_tooth_piece"))
    collision = [_write_mesh_collision(folder, name, i, mesh, role)
                 for i, (mesh, role) in enumerate(meshes)]
    report.update(convex_collision_count=len(collision), max_tooth_prism_vertices=max_vertices,
                  tooth_piece_counts=tooth_piece_counts,
                  profile_simplification_tolerance=PROFILE_TOLERANCE,
                  maximum_measured_material_added_distance=max_added_distance,
                  convex_partition_area_error_bound=1e-10,
                  bore_radius=BORE_RADIUS, bore_polygon_sides=SECTORS,
                  bore_min_clear_radius=BORE_RADIUS * math.cos(math.pi / SECTORS),
                  shaft_radius=SHAFT_RADIUS,
                  min_radial_insertion_clearance=BORE_RADIUS * math.cos(math.pi / SECTORS) - SHAFT_RADIUS,
                  source_chamfers_omitted_from_collision=True, authored_bore_entry_chamfer_m=BORE_CHAMFER)
    return collision, report


def _visual_obj(path, source=None, *, center=(0., 0., 0.), source_center=None,
                base=False, additions=()):
    lines, vertices = ["# See asset_sources.json; local additions are explicitly attributed.",
                       "mtllib materials.mtl"], 0
    source_vertices = []
    if source:
        for line in source.read_text(encoding="utf-8").splitlines():
            fields = line.split()
            if not fields or fields[0] == "mtllib":
                continue
            if fields[0] == "v":
                point = np.asarray([float(v) for v in fields[1:4]])
                source_vertices.append(point.copy())
                if source_center is not None:
                    point -= np.asarray(source_center)
                point = _rot90((point * SCALE)[None])[0] - np.asarray(center)
                lines.append("v " + _nums(point))
                vertices += 1
            elif fields[0] == "vn":
                normal = _rot90(np.array([[float(v) for v in fields[1:4]]]))[0]
                lines.append("vn " + _nums(normal))
            elif fields[0] == "f" and base:
                indices = [int(token.split("/")[0]) - 1 for token in fields[1:]]
                # The upstream shafts include flat details intended for its
                # insertion benchmark. Replace them visibly with the same
                # cylindrical journals used for this freely rotating task.
                if all(source_vertices[index][2] <= .005 + 1e-9 for index in indices):
                    lines.append(line)
            else:
                lines.append(line)
    for mesh, material in additions:
        lines.extend((f"g authored_{material}", f"usemtl {material}"))
        for point in mesh.vertices:
            lines.append("v " + _nums(point))
        for face in mesh.faces:
            lines.append("f " + " ".join(str(vertices + int(i) + 1) for i in face))
        vertices += len(mesh.vertices)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _inertial(collision, mass):
    meshes = [_primitive_mesh(spec) for spec in collision]
    volumes = np.array([abs(float(mesh.volume)) for mesh in meshes])
    total = float(volumes.sum())
    if total <= 0:
        raise RuntimeError("invalid collision volume")
    centers = np.array([mesh.center_mass for mesh in meshes])
    com = np.sum(centers * volumes[:, None], axis=0) / total
    inertia = np.zeros((3, 3))
    for mesh, volume, center in zip(meshes, volumes, centers):
        displacement = center - com
        inertia += mesh.moment_inertia + volume * (np.dot(displacement, displacement) * np.eye(3)
                                                    - np.outer(displacement, displacement))
    return com, inertia * (mass / total), total


def _urdf(path, name, visual, collision, mass):
    com, inertia, volume = _inertial(collision, mass)
    robot = ET.Element("robot", name=name)
    link = ET.SubElement(robot, "link", name=name)
    inertial = ET.SubElement(link, "inertial")
    ET.SubElement(inertial, "origin", xyz=_nums(com), rpy="0 0 0")
    ET.SubElement(inertial, "mass", value=str(mass))
    ET.SubElement(inertial, "inertia", ixx=str(inertia[0, 0]), iyy=str(inertia[1, 1]),
                  izz=str(inertia[2, 2]), ixy=str(inertia[0, 1]), ixz=str(inertia[0, 2]), iyz=str(inertia[1, 2]))
    vis = ET.SubElement(link, "visual")
    geom = ET.SubElement(vis, "geometry")
    ET.SubElement(geom, "mesh", filename=visual.name)
    for index, spec in enumerate(collision):
        node = ET.SubElement(link, "collision", name=f"{spec['role']}_{index:03d}")
        ET.SubElement(node, "origin", xyz=_nums(spec.get("pos", (0., 0., 0.))),
                      rpy=_nums(spec.get("rpy", (0., 0., 0.))))
        geom = ET.SubElement(node, "geometry")
        if spec["kind"] == "box":
            ET.SubElement(geom, "box", size=_nums(spec["size"]))
        elif spec["kind"] == "cylinder":
            ET.SubElement(geom, "cylinder", radius=str(spec["radius"]), length=str(spec["length"]))
        else:
            ET.SubElement(geom, "mesh", filename=Path(spec["mesh"]).relative_to(path.parent).as_posix())
    ET.indent(robot, space="  ")
    ET.ElementTree(robot).write(path, encoding="utf-8", xml_declaration=True)
    return dict(center_of_mass_local=com.tolist(), inertia_at_com=inertia.tolist(),
                collision_component_volume_sum=volume)


def _prepare_source(root):
    source = root / "source"
    if not (source / "SOURCE_MANIFEST.json").exists():
        if not SOURCE_FALLBACK.exists():
            raise FileNotFoundError("Factory source bundle is missing; see asset_sources.json URLs")
        shutil.copytree(SOURCE_FALLBACK, source, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("geometry_report.json", "geometry_summary.json"))
    return source


def _materials(root, mesh_dir):
    blocks = {}
    for path in mesh_dir.glob("*.mtl"):
        text = path.read_text(encoding="utf-8")
        for block in text.split("newmtl ")[1:]:
            blocks[block.splitlines()[0]] = "newmtl " + block.strip() + "\n"
    text = "\n".join(blocks.values())
    for name, color in {"authored_post": (.38, .42, .48), "authored_cover": (.15, .30, .43),
                        "authored_handle": (.76, .20, .12), "authored_shaft": (.62, .66, .70),
                        "authored_witness": (.025, .035, .045), "authored_hub_lip": (.70, .62, .30)}.items():
        text += f"\nnewmtl {name}\nKa 0 0 0\nKd {_nums(color)}\nKs .12 .12 .12\nNs 20\nd 1\n"
    (root / "materials.mtl").write_text(text, encoding="utf-8")


def build_assets(*, force=False, asset_root=None):
    root = Path(asset_root or ASSET_ROOT).resolve()
    root.mkdir(parents=True, exist_ok=True)
    catalog_path = root / "catalog.json"
    if catalog_path.exists() and not force:
        cached = json.loads(catalog_path.read_text(encoding="utf-8"))
        if cached.get("build_version") == BUILD_VERSION and cached.get("asset_root") == str(root):
            return cached
    source = _prepare_source(root)
    # Only stale generated collision OBJ files are removed. Resolve and verify
    # every target; never delete source assets or another task's directory.
    collision_root = (root / "collision").resolve()
    if collision_root.parent != root or collision_root.name != "collision":
        raise RuntimeError("unsafe generated collision directory")
    if collision_root.exists():
        for generated in collision_root.rglob("*.obj"):
            resolved = generated.resolve()
            if not resolved.is_relative_to(collision_root):
                raise RuntimeError("collision file resolves outside generated directory")
            resolved.unlink()
    mesh_dir = source / "assets/factory/mesh/factory_gears"
    _materials(root, mesh_dir)
    parts, reports = {}, {}

    def finish(name, collision, goal, mass, *, source_file=None, source_center=None,
               additions=(), is_base=False, extra=None):
        visual, urdf = root / f"{name}.obj", root / f"{name}.urdf"
        _visual_obj(visual, source_file, center=goal if is_base else (0., 0., 0.),
                    source_center=source_center, base=is_base, additions=additions)
        visual_mesh = trimesh.load_mesh(visual, process=False)
        size = np.asarray(visual_mesh.bounds[1]) - np.asarray(visual_mesh.bounds[0])
        inertial = _urdf(urdf, name, visual, collision, mass)
        parts[name] = dict(urdf=str(urdf), mesh=str(visual), mass=float(mass), size=size.tolist(),
                           goal_local=list(goal), goal_quat_wxyz=[1., 0., 0., 0.],
                           display_name=DISPLAY[name], collision_geometry=collision,
                           convexify=False, friction=.10 if name in GEARS else .65, **inertial)
        parts[name].update(extra or {})

    for name, spec in GEARS.items():
        source_file = mesh_dir / f"factory_gear_{spec['source']}_space_5e-4.obj"
        collision, report = _gear_collisions(root, name, source_file, spec)
        reports[name] = report
        phase = report["source_phase_radians"]
        pitch = 2 * np.pi / spec["teeth"]
        marker_angle = phase + round((np.pi / 4 - phase) / pitch) * pitch
        inner = spec["hub_radius"] + .001
        outer = report["tip_radius"] - .0018
        marker = trimesh.creation.box(extents=(outer-inner, .0018, .00008))
        marker.apply_translation(((outer+inner)/2, 0., .00006))
        marker.apply_transform(trimesh.transformations.rotation_matrix(marker_angle, (0,0,1)))
        # Mass comes from the explicit collision solids at a stated light-polymer
        # density, because the upstream visual CAD supplies no inertial data.
        volume = _inertial(collision, 1.)[2]
        mass = float(volume * POLYMER_DENSITY)
        seat = PLATE_TOP + TEETH_HEIGHT  # gear origin sits on the teeth/hub boundary
        lip = trimesh.creation.annulus(r_min=spec["hub_radius"], r_max=spec["hub_radius"] + HUB_LIP_WIDTH,
                                       height=HUB_LIP_HEIGHT, sections=64)
        lip.apply_translation((0., 0., TEETH_HEIGHT - HUB_LIP_HEIGHT / 2))
        finish(name, collision, (0., spec["cx"] * SCALE, seat), mass,
               source_file=source_file, source_center=(spec["cx"], 0., .015),
               additions=[(marker, "authored_witness"), (lip, "authored_hub_lip")], extra=dict(
                   teeth=spec["teeth"], pitch_radius=spec["teeth"] * .001 * SCALE / 2,
                   axis_local=[0., spec["cx"] * SCALE, seat],
                   shaft_axis=[0.,0.,1.], support=["base"],
                   insertion_clearance=report["min_radial_insertion_clearance"],
                   reference_tooth_phase=phase, witness_angle=marker_angle,
                   material_density_kg_m3=POLYMER_DENSITY))

    base_goal = np.array((0., 0., COVER_BOTTOM/2))
    plate = (.18*K, .36*K)
    post_xy, post_width = (.082*K, .172*K), .012*K
    base_collision = [_box((0.,0.,PLATE_TOP/2-base_goal[2]), (*plate,PLATE_TOP), "base_plate")]
    for name, spec in GEARS.items():
        top = HUB_TOP - JOURNAL_LEAD
        base_collision.append(_cylinder((0.,spec["cx"]*SCALE,(PLATE_TOP+top)/2-base_goal[2]),
                                        SHAFT_RADIUS,top-PLATE_TOP, f"shaft_{name}"))
        chamfer = _frustum(SHAFT_RADIUS, SHAFT_RADIUS - JOURNAL_TAPER, top - base_goal[2], HUB_TOP - base_goal[2])
        chamfer.apply_translation((0., spec["cx"] * SCALE, 0.))
        base_collision.append(_write_mesh_collision(root, "base", len(base_collision), chamfer,
                                                    f"shaft_chamfer_{name}"))
    pilot_bottom = COVER_BOTTOM - POST_PILOT
    posts = []
    for x in (-post_xy[0],post_xy[0]):
        for y in (-post_xy[1],post_xy[1]):
            posts.append(_box((x,y,(PLATE_TOP+pilot_bottom)/2-base_goal[2]),
                              (post_width,post_width,pilot_bottom-PLATE_TOP), "cover_support_post"))
            corners = np.array([(sx, sy) for sx in (-1, 1) for sy in (-1, 1)], float)
            points = np.vstack([np.column_stack((corners * post_width / 2, np.full(4, pilot_bottom - base_goal[2]))),
                                np.column_stack((corners * POST_TIP / 2, np.full(4, COVER_BOTTOM - base_goal[2])))])
            pilot = trimesh.convex.convex_hull(points + [x, y, 0.])
            posts.append(_write_mesh_collision(root, "base", len(base_collision) + len(posts), pilot,
                                               "cover_post_pilot"))
    base_collision.extend(posts)
    # Two lifting handles: a bar along x outside each plate end, carried by two
    # risers and arms clear of the gears, posts, cover and jig. The bar stands
    # high enough for fingers to hook underneath it.
    handle_x, bar_r, bar_z, arm_t = .057, .007, .047, .006
    for sign in (-1, 1):
        y_bar = sign * (plate[1]/2 + .040)
        for x in (-handle_x, handle_x):
            base_collision.append(_box((x, sign*(plate[1]/2-.005), (PLATE_TOP+bar_z+arm_t/2)/2-base_goal[2]),
                                       (arm_t, arm_t, bar_z+arm_t/2-PLATE_TOP), "handle_riser"))
            base_collision.append(_box((x, (sign*(plate[1]/2-.010)+y_bar)/2, bar_z-base_goal[2]),
                                       (arm_t, abs(y_bar-sign*(plate[1]/2-.010)), arm_t), "handle_arm"))
        base_collision.append(_cylinder((0., y_bar, bar_z-base_goal[2]), bar_r, 2*handle_x+arm_t,
                                        "lifting_handle", rpy=(0., math.pi/2, 0.)))
    # Moulded polymer base: mass from the explicit solids at the gear density.
    base_mass = float(_inertial(base_collision, 1.)[2] * POLYMER_DENSITY)
    finish("base", base_collision, base_goal.tolist(), base_mass,
           source_file=mesh_dir/"factory_gear_base_loose_space_5e-4_subdiv_4x.obj",
           additions=[(_primitive_mesh(p), "authored_post") for p in base_collision[1:]], is_base=True,
           extra=dict(support=["table", "fixture"],friction=.10))

    # Cover frame in its own frame: rails span 4K..12K above the origin, which is
    # placed so the rail bottoms rest on the post tops at COVER_BOTTOM.
    rail_bottom, rail_t = .004*K, .008*K
    rail_z = rail_bottom + rail_t/2
    cover_goal = (0.,0.,COVER_BOTTOM-rail_bottom)
    cover_collision = [_box((x,0.,rail_z), (.014*K,.36*K,rail_t), "perimeter_rail") for x in (-.083*K,.083*K)]
    cover_collision.extend(_box((0.,y,rail_z), (.152*K,.014*K,rail_t), "end_rail") for y in (-.173*K,.173*K))
    edge = .076*K
    for name,spec in GEARS.items():
        radius = {"small_gear":.0225,"medium_gear":.024,"large_gear":.026}[name]*K
        y = spec["cx"]*SCALE
        for side in (-1,1):
            cover_collision.append(_box((side*(radius+edge-.002*K)/2,y,rail_z),
                                         (edge-radius+.002*K,.012*K,rail_t),"bearing_bridge"))
        for mesh in _annular_sectors(.0155*K,radius,rail_bottom,rail_bottom+rail_t,sectors=24):
            mesh.apply_translation((0.,y,0.))
            cover_collision.append(_write_mesh_collision(root,"cover",len(cover_collision),mesh,"open_bearing_ring"))
    # Four visibly open-bottom locating cups engage the corner posts with
    # POST_CLEARANCE per side; their walls reach `depth` below the rail bottoms.
    wall, depth = .003*K, .016*K
    inner = post_width/2 + POST_CLEARANCE
    cup_z = rail_bottom - depth/2
    for x in (-post_xy[0],post_xy[0]):
        for y in (-post_xy[1],post_xy[1]):
            for side in (-1,1):
                for axis in (0, 1):
                    # Wall prism with its inner bottom edge chamfered (cup mouth lead-in).
                    length = 2 * (inner + wall) if axis == 0 else 2 * inner
                    profile = [(inner, cup_z + depth / 2), (inner + wall, cup_z + depth / 2),
                               (inner + wall, cup_z - depth / 2), (inner + CUP_CHAMFER, cup_z - depth / 2),
                               (inner, cup_z - depth / 2 + CUP_CHAMFER)]
                    points = [((side * n, t, z) if axis == 0 else (t, side * n, z))
                              for n, z in profile for t in (-length / 2, length / 2)]
                    mesh = trimesh.convex.convex_hull(np.array(points) + [x, y, 0.])
                    cover_collision.append(_write_mesh_collision(root, "cover", len(cover_collision), mesh,
                                                                 "post_socket_wall"))
    # Lifting handle over the centre of mass: a cross beam between the side rails
    # (between the large and medium hubs, 1 mm above their tops like the rings),
    # two risers and a 14 mm bar with room for hooked fingers underneath.
    handle_y, bar_z, bar_r, riser_x = COVER_HANDLE_Y, rail_z + .033, .007, .045
    cover_collision.append(_box((0., handle_y, rail_z), (2*.083*K, .010, rail_t), "handle_beam"))
    for x in (-riser_x, riser_x):
        cover_collision.append(_box((x, handle_y, (rail_z + bar_z)/2), (.008, .008, bar_z - rail_z), "handle_riser"))
    cover_collision.append(_cylinder((0., handle_y, bar_z), bar_r, 2*riser_x + .008, "lifting_handle",
                                     rpy=(0., math.pi/2, 0.)))
    cover_mass = float(_inertial(cover_collision, 1.)[2] * POLYMER_DENSITY)
    finish("cover", cover_collision, cover_goal, cover_mass,
           additions=[(_primitive_mesh(p),"authored_cover") for p in cover_collision],
           extra=dict(support=["base"], axial_hub_clearance=COVER_BOTTOM-HUB_TOP,
                      post_socket_side_clearance=POST_CLEARANCE, socket_bottom_table_local=COVER_BOTTOM-depth))

    # Square-section handle: it rests on a flat face and cannot roll away from a
    # pinch. The pushing tip is thinner than a tooth gap at the pitch circle.
    # The handle's top edges overhang by a 2.5 mm lip: a side pinch that creeps down
    # comes to rest under it.
    tool_collision = [_box((-.040,0.,0.),(.070,.024,.024),"handle"),
                      _box((-.040,0.,.010),(.070,.029,.004),"handle"),
                      _cylinder((.0285,0.,0.),.004,.067,"shaft",rpy=(0.,math.pi/2,0.)),
                      _box((.0685,0.,0.),(.013,.0025,.005),"pushing_tip")]
    finish("turning_tool",tool_collision,(-.15,.25,.012),.08,
           additions=[(_primitive_mesh(p),"authored_handle" if p["role"]=="handle" else "authored_shaft")
                      for p in tool_collision],extra=dict(support=[],assembly_part=False))

    # 8 mm tall: the large gear tips (77.5 mm radius) overhang the 75 mm plate edge
    # and must clear the locator walls when seated on the 12.5 mm plate.
    jig_t, jig_h = .010, .008
    hx, hy = plate[0]/2 + FIXTURE_CLEARANCE, plate[1]/2 + FIXTURE_CLEARANCE
    fixture = [_box((x,0.,jig_h/2),(jig_t,2*(hy+jig_t),jig_h),"base_locator") for x in (-hx-jig_t/2,hx+jig_t/2)]
    fixture.extend(_box((0.,y,jig_h/2),(2*hx,jig_t,jig_h),"base_locator") for y in (-hy-jig_t/2,hy+jig_t/2))
    fixture = [dict(size=p["size"],pos_local=p["pos"],color=[.29,.33,.38],name=f"jig_{i}")
               for i,p in enumerate(fixture)]
    # Each wall is a prism whose inner top edge carries a JIG_CHAMFER lead-in
    # (vertices relative to pos_local; the box size stays as its bounding box).
    for spec in fixture:
        (sx, sy, sz), (px, py, pz) = spec["size"], spec["pos_local"]
        axis = 0 if sx < sy else 1               # wall normal axis
        inward = -np.sign(px if axis == 0 else py)
        half_t, half_l = (sx if axis == 0 else sy) / 2, (sy if axis == 0 else sx) / 2
        profile = [(-inward * half_t, -sz / 2), (-inward * half_t, sz / 2),
                   (inward * half_t - inward * JIG_CHAMFER, sz / 2),
                   (inward * half_t, sz / 2 - JIG_CHAMFER_HEIGHT), (inward * half_t, -sz / 2)]
        points = []
        for n, z in profile:
            for l in (-half_l, half_l):
                points.append((n, l, z) if axis == 0 else (l, n, z))
        wall = trimesh.convex.convex_hull(np.array(points))
        path = root / "collision" / "fixture" / f"{spec['name']}.obj"
        path.parent.mkdir(parents=True, exist_ok=True)
        wall.export(path)
        spec["mesh"] = str(path.resolve())
    catalog = dict(schema_version=1,build_version=BUILD_VERSION,asset_root=str(root),
                   parts={name:parts[name] for name in NAMES},fixture=fixture,
                   gear_meta=dict(input="small_gear",teeth={name:spec["teeth"] for name,spec in GEARS.items()},
                       shaft_centers={name:[0.,spec["cx"]*SCALE,PLATE_TOP+TEETH_HEIGHT] for name,spec in GEARS.items()},
                       pitch_radii={name:spec["teeth"]*.001*SCALE/2 for name,spec in GEARS.items()},
                       gear_axis=[0.,0.,1.],module=.001*SCALE,scale=SCALE,
                       center_distances={"small_medium":(GEARS["small_gear"]["cx"]-GEARS["medium_gear"]["cx"])*SCALE,
                                         "medium_large":(GEARS["medium_gear"]["cx"]-GEARS["large_gear"]["cx"])*SCALE},
                       expected_ratios={"small_gear":1.,"medium_gear":-.5,"large_gear":1/3},
                       shaft_radius=SHAFT_RADIUS,shaft_bottom=PLATE_TOP,shaft_top=HUB_TOP,
                       cover_bottom=COVER_BOTTOM,cover_axial_clearance=COVER_AXIAL_CLEARANCE),
                   dynamics=dict(no_coupled_joints=True,no_dynamic_welds=True,
                                 gear_friction=.10,gear_density_kg_m3=POLYMER_DENSITY))
    provenance = dict(source_repository="https://github.com/isaac-sim/IsaacGymEnvs",
        source_commit=COMMIT,source_directory="assets/factory",source_manifest="source/SOURCE_MANIFEST.json",
        source_license="source/LICENSE.txt",factory_acknowledgments="source/assets/licenses/factory-acknowledgments.txt",
        rights_note="Custom base plate: repository BSD-3 terms. Gears and shafts: NIST courtesy attribution; preserve acknowledgments, not a blanket CC0 claim.",
        nist_source="https://www.nist.gov/el/intelligent-systems-division-73500/robotic-grasping-and-manipulation-assembly/assembly",
        nist_rights="https://www.nist.gov/open/copyright-fair-use-and-licensing-statements-srd-data-software-and-technical-series-publications",
        cad_source="https://cad.onshape.com/documents/a0587101f8bbd02384e2db0c/w/06e85c5fe55bdf224720e2bb/e/946907a4305ef6b82d7d287b",
        modifications=[f"Uniform {SCALE:g}x scale and rigid 90-degree rotation; gear visual triangles and original material colours retained.",
            "Each real CAD mid-plane tooth boundary is simplified to 50 micrometres, ear-clipped, then merged only into convex unions. Concave root fillets remain open; no whole-tooth hull fills them. Hub/root ring use 32 open-bore sectors. The source CAD's small axial chamfers are not reproduced.",
            f"Authored lead-ins make every fit self-guiding: a {BORE_CHAMFER*1000:.1f} mm x 45 degree bore-entry chamfer, journal tips tapered by {JOURNAL_TAPER*1000:.1f} mm in radius over {JOURNAL_LEAD*1000:.1f} mm, cover posts tapering to a {POST_TIP*1000:.1f} mm pilot over their top {POST_PILOT*1000:.1f} mm into cups with {CUP_CHAMFER*1000:.1f} mm mouth chamfers, and a {JIG_CHAMFER*1000:.1f} mm wide, {JIG_CHAMFER_HEIGHT*1000:.1f} mm tall chamfer on the {FIXTURE_CLEARANCE*1000:.1f} mm-clearance locator walls.",
            f"Each gear hub carries a {HUB_LIP_WIDTH*1000:.1f} mm x {HUB_LIP_HEIGHT*1000:.1f} mm collar at its top, like a flanged hub; it gives a pinch a ledge to rest on.",
            f"Original NIST shaft surface triangles are removed from the derived base visual. Three explicitly authored round journals of radius {SHAFT_RADIUS*1000:.2f} mm replace them in both visual and collision, providing a true rotational bearing and {SHAFT_CLEARANCE*1000:.2f} mm nominal radial insertion clearance.",
            "Original local authoring: round bearing journals, four cover support posts, open bearing-bridge cover with a central lifting handle, base locating jig, and detachable turning tool.",
            f"Four cover locating cups fit {post_width*1000:.1f} mm corner posts with {POST_CLEARANCE*1000:.1f} mm side clearance; cup bottoms are at table-local z={(COVER_BOTTOM-depth)*1000:.1f} mm.",
            "Base and cover masses come from their explicit solids at the gear polymer density; the turning tool has a square handle with a 2.5 mm top lip so it rests on a flat face and a creeping side pinch comes to rest under the lip.",
            "The base carries two authored lifting handles outside its plate ends, above the locating jig, so it can be carried with hooked fingers.",
            "Visual-only dark radial witness marks added on exposed tooth-disc top faces; no collision, text or hidden step labels.",
            "Simulation masses/inertias are authored from explicit solids; the upstream visual assets do not supply measured inertial data.",
            "Base and gear friction coefficients are authored simulation parameters of 0.10 representing lubricated bearing/end faces, not measured source-material properties; table and jig remain separate high-friction contacts."],
        source_files={str(p.relative_to(source)).replace('\\','/'):_sha(p) for p in source.rglob('*') if p.is_file()},
        generated_files={str(p.relative_to(root)).replace('\\','/'):_sha(p) for p in root.rglob('*') if p.is_file() and source not in p.parents
                         and p.name not in ('catalog.json','asset_sources.json','geometry_validation.json')})
    validation = dict(gears=reports,holes_preserved=True,whole_gear_convex_hull=False,
                      base_fixture_side_clearance=FIXTURE_CLEARANCE,cover_axial_hub_clearance=COVER_AXIAL_CLEARANCE,
                      cover_post_side_clearance=POST_CLEARANCE,cover_socket_bottom=COVER_BOTTOM-depth,
                      source_cad_retained=True,robot_expert_verified=False,mechanical_transmission_verified=False)
    (root/"geometry_validation.json").write_text(json.dumps(validation,indent=2)+"\n",encoding="utf-8")
    (root/"asset_sources.json").write_text(json.dumps(provenance,indent=2)+"\n",encoding="utf-8")
    catalog_path.write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return catalog


def asset(name):
    return build_assets()["parts"][name]


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force",action="store_true")
    args=parser.parse_args()
    catalog=build_assets(force=args.force)
    print(json.dumps({name:{key:spec[key] for key in ("size","mass","goal_local")}
                      for name,spec in catalog["parts"].items()},indent=2))
