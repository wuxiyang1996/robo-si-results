"""Keep physical gear assets and public reference images paired across runs."""
import hashlib
import json
import math
from pathlib import Path


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_instruction_config(config):
    """The bundled text explicitly prescribes these angle and dwell values."""
    from .task_spec import TaskConfig
    defaults = TaskConfig(recipe=config.recipe)
    for name in ("required_small_angle_rad", "stable_seconds", "final_hold_seconds"):
        if not math.isclose(getattr(config, name), getattr(defaults, name), rel_tol=0., abs_tol=1e-10):
            raise ValueError(f"{name} differs from the frozen public instructions")


def catalog_fingerprint(catalog):
    root = Path(catalog["asset_root"])
    def portable(value):
        if isinstance(value, dict):
            return {key: portable(item) for key, item in value.items()}
        if isinstance(value, list):
            return [portable(item) for item in value]
        if isinstance(value, str):
            try:
                return Path(value).relative_to(root).as_posix()
            except ValueError:
                pass
        return value
    data = {
        "parts": {name: {key: value for key, value in part.items()
            if key in ("mass", "size", "goal_local", "goal_quat_wxyz", "teeth", "role",
                       "friction", "support", "collision_boxes", "collision_shapes",
                       "collision_geometry", "convexify")}
            for name, part in catalog["parts"].items()},
        "fixture": catalog.get("fixture", []),
        "files": {str(path.relative_to(root)).replace("\\", "/"): sha256(path)
            for path in sorted(root.rglob("*")) if path.is_file() and
            path.suffix.lower() in (".obj", ".urdf", ".mtl", ".png", ".stl", ".ply", ".glb")},
    }
    return hashlib.sha256(json.dumps(portable(data), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def validate_reference_bundle(bundle, recipe, catalog):
    """Trusted development manifest validation, not a signed sandbox boundary."""
    bundle = Path(bundle)
    if not bundle.is_dir() and bundle.name != "bundle.json":
        raise ValueError("A rendered instruction manifest must be named bundle.json")
    directory = bundle if bundle.is_dir() else bundle.parent
    manifest = json.loads((directory.parent/"render_manifest.json").read_text(encoding="utf-8"))
    if manifest.get("catalog_fingerprint") != catalog_fingerprint(catalog):
        raise ValueError("Stale gear reference: regenerate with python -m humanoid.g1_gear_assembly.reference")
    expected = manifest["bundles"][recipe]
    instructions = json.loads((directory/"bundle.json").read_text(encoding="utf-8"))
    if len(expected["step_image_sha256"]) != len(instructions["steps"]):
        raise ValueError("Step image count differs from the instruction recipe")
    if sha256(directory/"bundle.json") != expected["bundle_sha256"]:
        raise ValueError("Instructions differ from the rendered bundle")
    if sha256(directory/"goal.png") != expected["goal_image_sha256"]:
        raise ValueError("Goal image differs from the rendered reference")
    for index, digest in enumerate(expected["step_image_sha256"], 1):
        if sha256(directory/f"steps/{index:02d}.png") != digest:
            raise ValueError(f"Step {index} differs from the rendered reference")
    return expected["bundle_sha256"]
