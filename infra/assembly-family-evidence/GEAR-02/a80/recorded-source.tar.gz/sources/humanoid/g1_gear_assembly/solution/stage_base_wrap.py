"""Base stage, journal-wrap variant: each hand wraps an end journal (small-gear shaft on
the left, large-gear shaft on the right), every finger curled past contact; the carry
integrates position, yaw and tilt so the hands counter the grasp compliance.
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from .controller import CONTROL_DT
from .skills import configure_ik, pose, raise_hands, rot_z, smooth

GRASP_ROTATION = np.array([[1., 0., 0.], [0., .9929893514390433, -.11820384058340883],
                           [0., .11820384058340883, .9929893514390433]])
GRASP_PALM_OFFSET = np.array([-.03011502191064197, .05532778318475037, .020680451850469194])
GRASP_HAND = dict(thumb_0=-.00031517951189123314, thumb_1=.21361814910104837, thumb_2=.9487025378294728,
                  middle_0=-1.198674149960847, middle_1=-.2157570997357299,
                  index_0=-1.0882557380227016, index_1=-.6980590009829263)
MIRROR = np.diag((1., -1., 1.))
SIDES = ("left", "right")


def hand_values(side, opening=0.):
    values = dict(GRASP_HAND)
    values["thumb_1"] -= opening
    values["thumb_2"] += opening
    for finger in ("middle", "index"):
        values[f"{finger}_0"] += opening
        values[f"{finger}_1"] -= opening
    if side == "right":
        values = {n: (v if n == "thumb_0" else -v) for n, v in values.items()}
    return values


def hand_target(c, opening=0., squeeze=0.):
    q = c.q.copy()
    for side in SIDES:
        sign = 1. if side == "left" else -1.
        for name, value in hand_values(side, opening).items():
            delta = 0. if name == "thumb_0" else squeeze * (sign if name.startswith("thumb") else -sign)
            i = c.index[f"{side}_hand_{name}_joint"]
            q[i] = np.clip(value + delta, c.lo[i] + 1e-5, c.hi[i] - 1e-5)
    return q


def grasp_tasks(c, height=0., inset=0., left_shaft="medium_gear"):
    """Palm targets around the end journals, from the catalog geometry.

    The wrap profile was fitted to a 14.65 mm journal whose top stood 37 mm above
    the base origin; the palm keeps the same depth below the journal top and the
    same gap to the journal surface.
    """
    p, _, yaw, _ = pose(c, "base")
    R = rot_z(yaw)
    parts, meta = c.env.catalog["parts"], c.env.catalog["gear_meta"]
    top = meta["shaft_top"] - parts["base"]["goal_local"][2]
    inset = inset + (.01465 - meta["shaft_radius"])
    # The small-gear journal sits beside a cover post at this scale; the left hand
    # wraps the medium-gear journal so its palm clears the posts.
    shaft_y = dict(left=meta["shaft_centers"][left_shaft][1], right=meta["shaft_centers"]["large_gear"][1])
    tasks = {}
    for side in SIDES:
        offset, rot = GRASP_PALM_OFFSET.copy(), GRASP_ROTATION.copy()
        if side == "right":
            offset, rot = MIRROR @ offset, MIRROR @ rot @ MIRROR
        offset = offset + np.array([0., shaft_y[side] - np.sign(offset[1]) * inset, .007 + (top - .037) + height])
        tasks[side] = ("palm", p + R @ offset, R @ rot)
    return tasks


def base_goal(c):
    return np.asarray(c.env.cfg.origin) + np.asarray(c.env.catalog["parts"]["base"]["goal_local"])


class Carry:
    """Hands keep their grasp-time placement in the base frame; position, yaw and
    tilt errors of the measured base are integrated into the commanded hand frame."""

    def __init__(self, c, tilt_gain=.04, corr=.08, inward=0., name="base"):
        self.c, self.tilt_gain, self.corr, self.name = c, tilt_gain, corr, name
        p, R, _, _ = pose(c, name)
        self.local = {side: (R.T @ (c.hand_pose(side)[0] - p), R.T @ c.hand_pose(side)[1]) for side in SIDES}
        # Optional inward bias: hooked hands pull the bars into the finger crooks.
        for side, (lp, lR) in self.local.items():
            lp = lp.copy()
            lp[1] -= np.sign(lp[1]) * inward
            self.local[side] = (lp, lR)
        self.corr_p, self.corr_r = np.zeros(3), np.zeros(3)

    def track(self, p_des, yaw_des, gain=.06, max_step=.0006):
        c = self.c
        p, R, yaw, state = pose(c, self.name)
        # A hook only loads once the hands rise; require a sustained loss.
        self.weak = getattr(self, "weak", 0) + 1 if state["robot_contact_force"] < .5 else 0
        if self.weak > 40:
            raise RuntimeError(f"{self.name} grasp lost")
        R_des = rot_z(yaw_des)
        self.corr_p = np.clip(self.corr_p + np.clip(gain * (p_des - p), -max_step, max_step), -self.corr, self.corr)
        error = Rotation.from_matrix(R_des @ R.T).as_rotvec()
        error[:2] *= self.tilt_gain / gain
        self.corr_r = np.clip(self.corr_r + np.clip(gain * error, -.0015, .0015), -.25, .25)
        R_cmd = Rotation.from_rotvec(self.corr_r).as_matrix() @ R_des
        tasks = {s: ("palm", p_des + self.corr_p + R_cmd @ lp, R_cmd @ lR) for s, (lp, lR) in self.local.items()}
        c.reach(tasks, rate=.8, feedback=.3, iters=12, rotation_feedback=.3)
        c.step()

    def rigid_move(self, p_goal, yaw_goal, seconds, steps=None):
        """Move the held part along a straight path with converged IK at each waypoint.

        Both hands keep their grasp-time placement exactly (no per-step drift);
        the commanded path starts from the current commanded frame.
        """
        c = self.c
        if not hasattr(self, "cmd_p"):
            p, _, yaw, _ = pose(c, self.name)
            self.cmd_p, self.cmd_yaw = p.copy(), yaw
        start_p, start_yaw = self.cmd_p.copy(), self.cmd_yaw
        p_goal = np.asarray(p_goal, dtype=float)
        steps = steps or max(2, int(np.ceil(np.linalg.norm(p_goal - start_p) / .01)))
        q_targets = []
        q = c.q.copy()
        for i in range(1, steps + 1):
            a = smooth(i / steps)
            pc, yc = start_p + a * (p_goal - start_p), start_yaw + a * (yaw_goal - start_yaw)
            R = rot_z(yc)
            tasks = {s: ("palm", pc + R @ lp, R @ lR) for s, (lp, lR) in self.local.items()}
            sol, _ = c.ik.solve(c.env.base_position, (1, 0, 0, 0), q, tasks, iters=120, damping=.02,
                                w_rot=.5, max_step=.06)
            q = q.copy()
            q[c.ik.upper] = sol[c.ik.upper]
            q_targets.append(q.copy())
        per = seconds / steps
        for target in q_targets:
            c.move_joints(target, per)
        self.cmd_p, self.cmd_yaw = p_goal.copy(), yaw_goal

    def move(self, p_goal, yaw_goal, seconds, settle=0., **kwargs):
        c = self.c
        p0, _, yaw0, _ = pose(c, self.name)
        p_goal = np.asarray(p_goal, dtype=float)
        count = max(1, math.ceil(seconds / CONTROL_DT))
        for i in range(count):
            a = smooth((i + 1) / count)
            self.track(p0 + a * (p_goal - p0), yaw0 + a * (yaw_goal - yaw0), **kwargs)
        for _ in range(math.ceil(settle / CONTROL_DT)):
            self.track(p_goal, yaw_goal, **kwargs)
        p, R, yaw, _ = pose(c, self.name)
        return dict(error_m=float(np.linalg.norm(p - p_goal)), yaw_error_rad=float(abs(yaw - yaw_goal)),
                    tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))))


def configure(c, roll=.30, yaw=2.6, elbow=.2):
    """IK ranges for the carry; a tighter waist keeps the arms doing the work."""
    configure_ik(c, waist_pitch=.45)
    c.ik.set_limit("waist_roll_joint", -roll, roll)
    c.ik.set_limit("waist_yaw_joint", -yaw, yaw)
    for side in SIDES:
        c.ik.set_limit(f"{side}_elbow_joint", elbow, 1.8)


def run_base(c, squeeze=.45, lift=.06, roll=.30, yaw=2.6, elbow=.2, corr=.08, inset=0.):
    configure(c, roll, yaw, elbow)
    raise_hands(c, seconds=2.)
    c.event("base_preshape")
    c.move_joints(hand_target(c, opening=.20), .7)
    c.event("base_hover")
    c.move_hands(grasp_tasks(c, .20, inset), seconds=2.5, feedback=.5, settle=.3)
    c.event("base_pregrasp")
    tasks = grasp_tasks(c, 0., inset)
    c.move_hands(tasks, seconds=2.5, feedback=.5, settle=.4)
    c.event("base_close")
    c.move_joints(hand_target(c), .4)
    c.move_joints(hand_target(c, squeeze=squeeze), 1.)
    c.hold(.5, tasks=tasks)
    c.event("base_closed", contact_force=c.object_state("base")["robot_contact_force"])
    carry = Carry(c, corr=corr)
    p0, _, _, _ = pose(c, "base")
    goal = base_goal(c)
    c.event("base_lift")
    carry.move(p0 + [0., 0., lift], 0., seconds=2.5, settle=1.)
    c.event("base_transport")
    carry.move(goal + [0., 0., lift], 0., seconds=10., settle=1.)
    hover = goal + [0., 0., .016]
    error = carry.move(hover, 0., seconds=1., settle=1.5, gain=.08)
    c.event("base_alignment", **error)
    for attempt in range(3):
        c.event("base_lower_into_jig", attempt=attempt)
        carry.move(goal - [0., 0., .003], 0., seconds=2., settle=.5)
        p, _, yaw, state = pose(c, "base")
        c.event("base_lowered", position=p.tolist(), yaw=yaw, support=state["support_forces"])
        if abs(p[2] - goal[2]) < .002:
            break
        carry.move(hover, 0., seconds=.8, settle=1.2, gain=.08)
    c.event("base_release")
    c.move_joints(hand_target(c, opening=.25), .8)
    c.hold(.3)
    away = {}
    for side in SIDES:
        hp, hR = c.hand_pose(side)
        away[side] = ("palm", hp + [0., .05 if side == "left" else -.05, .02], hR)
    c.move_hands(away, seconds=1., feedback=.4)
    c.move_hands({s: ("palm", t[1] + [0., 0., .12], t[2]) for s, t in away.items()}, seconds=1.5, feedback=.4,
                 settle=.3)
    p, _, yaw, _ = pose(c, "base")
    result = dict(position=p.tolist(), error=(p - goal).tolist(), yaw=yaw, stage=c.env.status["stage_name"],
                  conditions=c.env.status["conditions"].get("base"))
    c.event("base_result", **result)
    return result


class Tilt:
    """Command the base pose as a rotation about a fixed table pivot (one plate edge).

    The hands keep their grasp-time placement in the base frame; the commanded base
    pose is pitched by `angle` about the pivot line (along y through `pivot`) and
    translated by `shift`. Measured-pose errors are integrated into the command.
    """

    def __init__(self, c, corr=.05):
        self.c, self.corr = c, corr
        p, R, _, _ = pose(c, "base")
        self.p0 = p.copy()
        self.local = {side: (R.T @ (c.hand_pose(side)[0] - p), R.T @ c.hand_pose(side)[1]) for side in SIDES}
        self.corr_p, self.corr_r = np.zeros(3), np.zeros(3)

    def desired(self, pivot, angle, shift):
        Ry = Rotation.from_euler("y", -angle).as_matrix()  # positive angle lifts the far (+x) edge
        pivot = np.asarray(pivot, dtype=float)
        p = pivot + Ry @ (self.p0 - pivot) + np.asarray(shift, dtype=float)
        return p, Ry

    def track(self, pivot, angle, shift, gain=.05, max_step=.0005):
        c = self.c
        p_des, R_des = self.desired(pivot, angle, shift)
        p, R, _, state = pose(c, "base")
        if state["robot_contact_force"] < .5:
            raise RuntimeError("base grasp lost")
        self.corr_p = np.clip(self.corr_p + np.clip(gain * (p_des - p), -max_step, max_step), -self.corr, self.corr)
        error = Rotation.from_matrix(R_des @ R.T).as_rotvec()
        self.corr_r = np.clip(self.corr_r + np.clip(.6 * gain * error, -.001, .001), -.15, .15)
        R_cmd = Rotation.from_rotvec(self.corr_r).as_matrix() @ R_des
        tasks = {s: ("palm", p_des + self.corr_p + R_cmd @ lp, R_cmd @ lR) for s, (lp, lR) in self.local.items()}
        c.reach(tasks, rate=.8, feedback=.3, iters=12, rotation_feedback=.3)
        c.step()

    def move(self, pivot, angle0, angle1, shift0, shift1, seconds, settle=0.):
        count = max(1, math.ceil(seconds / CONTROL_DT))
        shift0, shift1 = np.asarray(shift0, dtype=float), np.asarray(shift1, dtype=float)
        for i in range(count):
            a = smooth((i + 1) / count)
            self.track(pivot, angle0 + a * (angle1 - angle0), shift0 + a * (shift1 - shift0))
        for _ in range(math.ceil(settle / CONTROL_DT)):
            self.track(pivot, angle1, shift1)


def tilt_slide_base(c, squeeze=.45, inset=.012, angle=.20):
    """Lift the far edge (near edge stays on the table), slide forward over the jig's near wall,
    set the far edge down inside the jig, then lift the near edge over the wall and lower."""
    configure(c)
    raise_hands(c, seconds=2.)
    c.move_joints(hand_target(c, opening=.20), .7)
    c.move_hands(grasp_tasks(c, .20, inset), seconds=2.5, feedback=.5, settle=.3)
    tasks = grasp_tasks(c, 0., inset)
    c.move_hands(tasks, seconds=2.5, feedback=.5, settle=.4)
    c.move_joints(hand_target(c), .4)
    c.move_joints(hand_target(c, squeeze=squeeze), 1.)
    c.hold(.5, tasks=tasks)
    p, R, _, _ = pose(c, "base")
    goal = base_goal(c)
    half = .09
    near = np.array((p[0] - half, p[1], p[2] - .038))  # near bottom edge line
    tilt = Tilt(c)
    c.event("base_tilt_up", angle=angle)
    tilt.move(near, 0., angle, 0., 0., seconds=2., settle=.5)
    travel = goal[0] - p[0]
    c.event("base_slide_far_edge_over_wall")
    tilt.move(near, angle, angle, [0., 0., 0.], [travel - .004, goal[1] - p[1], 0.], seconds=6., settle=.5)
    c.event("base_far_edge_down")
    tilt.move(near, angle, 0.012, [travel - .004, goal[1] - p[1], 0.], [travel - .004, goal[1] - p[1], 0.],
              seconds=1.5, settle=.4)
    pb, R, _, state = pose(c, "base")
    c.event("base_far_edge_result", position=pb.tolist(), support=state["support_forces"])
    return dict(position=pb.tolist(), support=state["support_forces"], goal=goal.tolist())
