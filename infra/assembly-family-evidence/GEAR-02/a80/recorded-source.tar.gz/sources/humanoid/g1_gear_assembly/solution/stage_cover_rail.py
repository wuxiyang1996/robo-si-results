"""Cover stage: one-hand pinch across the near perimeter rail, carry over the posts,
align the four locating cups, lower onto the post tops, release.

Privileged expert skill: measured cover and base poses close the loop. The cover
rests on the four posts by gravity; nothing fastens it.
"""
import math

import numpy as np

from .skills import (PADDLE, Pinch, configure_ik, goto, grasp_together, hook_release, pose, raise_hands, release_together, rot_z,
                     set_shape, shift_hands, smooth, wrap)
from .stage_base_wrap import Carry
from .stage_gears import Held

# Left-hand pinch across the 11.7 x 6.7 mm rail (search_bar_pinch.py,
# dev_runs/rail25_01): thumb on one side face, index and middle 57 mm apart
# along the rail on the other, all at mid-height.
RAIL_PROFILE = dict(
    rotation=np.array([[0.0, 0.0, 1.0], [0.9499485978485648, 0.3124062442486496, 0.0], [-0.3124062442486496, 0.9499485978485648, 0.0]]),
    offset=np.array([0.00017525557085100156, 0.009267069538574257, 0.08447929840584734]),
    hand={'thumb_0': 7.2e-11, 'thumb_1': -0.33321114512442646, 'thumb_2': 1.4172356558750103,
          'middle_0': -1.1086224093442394, 'middle_1': -1.1156502416470182,
          'index_0': -1.108622409381069, 'index_1': -1.1156502415577179})
# Near perimeter rail centre (cover frame, mid-height of the rail); rails along y.
RAIL_ANCHOR = (-.0633, 0., .00667)


def cover_seat(c):
    p, R, yaw, _ = pose(c, "base")
    parts = c.env.catalog["parts"]
    return p + R @ (np.asarray(parts["cover"]["goal_local"]) - np.asarray(parts["base"]["goal_local"])), yaw


def cup_error(c):
    """Cover position and yaw error from its seat (xy, z, yaw)."""
    seat, base_yaw = cover_seat(c)
    p, _, yaw, _ = pose(c, "cover")
    return seat - p, wrap(base_yaw - yaw)


# End-rail pinch searched against a table plane 5.3 mm above the real one
# (search_bar_pinch.py --gap 0.008 --contact-z 0.001, dev_runs/rail25_hi): Genesis
# convex-hulls the finger meshes, and the flatter rail25_01 pinch touched the table.
END_PROFILE = dict(
    rotation=np.array([[0.0, 0.0, 1.0000000000000002], [0.9804271019264227, 0.1968824466735338, 0.0], [-0.1968824466735338, 0.9804271019264227, 0.0]]),
    offset=np.array([-0.00015670448771024808, 0.004408574572925011, 0.08749920924797776]),
    hand={'thumb_0': 8.89617914247228e-11, 'thumb_1': -0.41512289298109334, 'thumb_2': 1.4300026182962702, 'middle_0': -1.279413528324113, 'middle_1': -0.8672176945682468, 'index_0': -1.2794135283345924, 'index_1': -0.8672176945473051})
# The right grip is turned half a turn: the mirrored grip put the right shoulder
# into the torso (Genesis self-collision, dev_runs/probe_block).
END_AZIMUTH = {"left": 0., "right": math.pi}
# End-rail centres (cover frame, rail mid-height), 2 cm toward the robot so both
# hands reach them over the posts; the fingers stay clear of the corner cups.
END_ANCHORS = {"left": (-.02, .144, .00667), "right": (-.02, -.144, .00667)}
STAGING = (.28, 0.)
PUSH_STAGING = (.28, .10)  # both end rails reachable: left hand y .244, right hand y -.044


def drag_cover(c, squeeze=.3):
    """Slide the cover on its cups across the table to the front centre (left-hand rail pinch)."""
    configure_ik(c)
    grip = Pinch(c, "cover", "left", RAIL_PROFILE, anchor=RAIL_ANCHOR, azimuth=-math.pi / 2, squeeze=squeeze)
    grip.grasp()
    held = Held(grip)
    p, _, yaw, _ = pose(c, "cover")
    c.event("cover_drag", start=p.tolist())
    held.move((STAGING[0], STAGING[1], p[2] + .001), 0., seconds=3.5, settle=.3)
    grip.release(rise=.08)
    p, _, yaw, _ = pose(c, "cover")
    c.event("cover_dragged", position=p.tolist(), yaw=yaw)


# Flat left hand, fingers down, finger pads facing -y: the pads press the inner
# face of the cover's -y end rail and slide the cover on its cups.
PUSH_ROTATION = np.array([[0., 0., 1.], [0., 1., 0.], [-1., 0., 0.]])
PUSH_PALM_HEIGHT = .132   # palm point above the table: distal pads at rail mid-height
PAD_OFFSET = .008         # finger pad face to palm point along the palm normal
END_RAIL_INNER = -.138    # inner face of the -y end rail, cover frame


def hand_path(c, side, p_to, R, seconds, step=.01):
    """Straight Cartesian hand path as converged-IK waypoints with joint interpolation."""
    c.ik._set(c.env.base_position, (1, 0, 0, 0), c.q)
    p_from = c.ik.hand_point(side, "palm").copy()
    p_to = np.asarray(p_to, dtype=float)
    steps = max(2, int(np.ceil(np.linalg.norm(p_to - p_from) / step)))
    q = c.q.copy()
    targets = []
    for i in range(1, steps + 1):
        a = smooth(i / steps)
        sol, _ = c.ik.solve(c.env.base_position, (1, 0, 0, 0), q, {side: ("palm", p_from + a * (p_to - p_from), R)},
                            iters=120, damping=.02, w_rot=.5, max_step=.06)
        q = q.copy()
        q[c.ik.upper] = sol[c.ik.upper]
        targets.append(q.copy())
    for target in targets:
        c.move_joints(target, seconds / steps)


def push_cover(c, target=None, gap=.010):
    """Slide the cover on its cups to the front staging point with the flat left hand."""
    configure_ik(c)
    set_shape(c, {"left": PADDLE["left"]})
    table = c.env.cfg.table_height
    p, _, yaw, _ = pose(c, "cover")
    goal = np.array(target if target is not None else PUSH_STAGING, dtype=float)
    R = rot_z(yaw) @ PUSH_ROTATION
    face = p + rot_z(yaw) @ np.array((0., END_RAIL_INNER, 0.))
    start = np.array((p[0], face[1] + PAD_OFFSET + gap, table + PUSH_PALM_HEIGHT))
    c.event("cover_push_approach", start=start.tolist())
    goto(c, {"left": ("palm", start + [0., 0., .07], R)}, seconds=2.2)
    hand_path(c, "left", start, R, seconds=1.2)
    c.event("cover_push")
    travel = goal[1] - p[1]
    hand_path(c, "left", start + [goal[0] - p[0], travel - gap, 0.], R, seconds=max(2., abs(travel) / .06))
    c.hold(.3)
    p2, _, yaw2, _ = pose(c, "cover")
    c.event("cover_pushed", position=p2.tolist(), yaw=yaw2)
    c.ik._set(c.env.base_position, (1, 0, 0, 0), c.q)
    here = c.ik.hand_point("left", "palm").copy()
    hand_path(c, "left", here + [0., .02, 0.], R, seconds=.6)
    hand_path(c, "left", here + [0., .02, .10], R, seconds=1.)
    return p2, yaw2


def pull_cover(c, squeeze=.45):
    """Drag the cover on its cups to the front staging point: the left hand pinches the
    middle of the near (-y) end rail and pulls, so the cover trails straight behind.
    (A flat-hand push from inside the frame rode over the 6.7 mm rail.)"""
    configure_ik(c)
    grip = Pinch(c, "cover", "left", END_PROFILE, anchor=(0., -.144, .00667), azimuth=math.pi, squeeze=squeeze)
    grip.grasp()
    held = Held(grip)
    p, _, _, _ = pose(c, "cover")
    c.event("cover_pull", start=p.tolist())
    held.move((PUSH_STAGING[0], PUSH_STAGING[1], p[2]), 0., seconds=4., settle=.4)
    grip.release(rise=.08)
    p2, _, yaw2, _ = pose(c, "cover")
    c.event("cover_pulled", position=p2.tolist(), yaw=yaw2)
    return p2, yaw2


def shuttle_cover(c, squeeze=.45, lift=.02):
    """Two-hand move from the supply spot to the front staging point, set down on the
    table. At the supply spot the left hand reaches its end rail only at the edge of
    its workspace and grips weakly, which is enough for this short low move but not
    for the carry over the posts; the carry re-grips at the staging point."""
    grips = [Pinch(c, "cover", side, END_PROFILE, anchor=END_ANCHORS[side], azimuth=END_AZIMUTH[side],
                   squeeze=squeeze) for side in ("left", "right")]
    grasp_together(c, grips, label="cover_shuttle", converged_descent=True)
    c.hold(.3)
    carry = Carry(c, tilt_gain=.03, corr=.06, name="cover")
    p0, _, yaw0, _ = pose(c, "cover")
    c.event("cover_shuttle_lift")
    carry.rigid_move(p0 + [0., 0., lift], yaw0, seconds=1.)
    carry.rigid_move(np.array((PUSH_STAGING[0], PUSH_STAGING[1], p0[2] + lift)), 0., seconds=3.)
    carry.rigid_move(np.array((PUSH_STAGING[0], PUSH_STAGING[1], p0[2] + .002)), 0., seconds=1.)
    release_together(c, grips)
    raise_hands(c)
    p, _, yaw, _ = pose(c, "cover")
    c.event("cover_staged", position=p.tolist(), yaw=yaw)


def run_cover(c, ready=False, squeeze=.45, lift=.035, hover=.016, tol=.00025, yaw_tol=.001, drag=False):
    configure_ik(c)
    if ready:
        raise_hands(c)
    if drag:
        pull_cover(c)
    else:
        shuttle_cover(c, squeeze=squeeze)
    grips = [Pinch(c, "cover", side, END_PROFILE, anchor=END_ANCHORS[side], azimuth=END_AZIMUTH[side],
                   squeeze=squeeze) for side in ("left", "right")]
    grasp_together(c, grips, label="cover_end_rails", converged_descent=True)
    c.hold(.3)
    carry = Carry(c, tilt_gain=.03, corr=.06, name="cover")
    p0, _, yaw0, _ = pose(c, "cover")
    seat, base_yaw = cover_seat(c)
    c.event("cover_lift")
    # Straight up to the carry height first: on a slanted path the far cups hit the posts.
    carry_z = seat[2] + .03
    carry.rigid_move(np.array((p0[0], p0[1], carry_z)), yaw0, seconds=2.)
    c.hold(.3)
    p1, _, _, _ = pose(c, "cover")
    c.event("cover_carry_over_posts", seat=seat.tolist())
    carry.rigid_move(seat + [0., 0., .03] + (carry.cmd_p - p1), base_yaw, seconds=3.5)
    c.hold(.4)
    for attempt in range(3):
        for _ in range(6):
            err, yaw_err = cup_error(c)
            seat, _ = cover_seat(c)
            p, _, _, _ = pose(c, "cover")
            error = seat + [0., 0., hover] - p
            if np.linalg.norm(error[:2]) < tol and abs(error[2]) < .002 and abs(yaw_err) < yaw_tol:
                break
            shift_hands(c, ("left", "right"), error, seconds=.8, yaw=yaw_err, pivot=p)
            c.hold(.4)
        err, yaw_err = cup_error(c)
        c.event("cover_aligned", attempt=attempt, error=err.tolist(), yaw_error=yaw_err)
        p, _, _, _ = pose(c, "cover")
        shift_hands(c, ("left", "right"), seat - [0., 0., .003] - p, seconds=2.)
        c.hold(.5)
        err, yaw_err = cup_error(c)
        c.event("cover_lowered", attempt=attempt, error=err.tolist(), yaw_error=yaw_err)
        if abs(err[2]) < .003:
            break
        p, _, _, _ = pose(c, "cover")
        shift_hands(c, ("left", "right"), seat + [0., 0., hover] - p, seconds=.8)
        c.hold(.3)
    release_together(c, grips)
    c.hold(.6)
    err, yaw_err = cup_error(c)
    result = dict(error=err.tolist(), yaw_error=yaw_err, completed=list(c.env.status["completed"]),
                  conditions=c.env.status.get("conditions", {}).get("cover"))
    c.event("cover_result", **result)
    return result


# Variant with the contacts 2.5 mm below the rail centre (search_bar_pinch.py
# --contact-z -0.0025, dev_runs/rail25_cz-0.0025): fingertips wrap the lower edge.
RAIL_CRADLE = dict(
    rotation=np.array([[0.0, 0.0, 1.0000000000000002], [0.9522080893106531, 0.3054500853680612, 0.0], [-0.3054500853680612, 0.9522080893106531, 0.0]]),
    offset=np.array([0.0001752555707347051, 0.011219626878559291, 0.08056950107314882]),
    hand={'thumb_0': -5.1622312376844373e-11, 'thumb_1': -0.3970774669692019, 'thumb_2': 1.4727658988751973, 'middle_0': -1.1416427870848136, 'middle_1': -1.1207591352597237, 'index_0': -1.1416427870558346, 'index_1': -1.1207591353327144})


def push_only(c):
    configure_ik(c)
    raise_hands(c)
    p, yaw = pull_cover(c)
    return dict(position=p.tolist(), yaw=yaw)


def test_end_rails(c, squeeze=.45, cradle=True, lift=.05, hold=3.):
    configure_ik(c)
    profile = RAIL_CRADLE if cradle else RAIL_PROFILE
    grips = [Pinch(c, "cover", side, profile, anchor=END_ANCHORS[side], azimuth=0., squeeze=squeeze)
             for side in ("left", "right")]
    grasp_together(c, grips, label="cover_end_rails", converged_descent=True)
    carry = Carry(c, tilt_gain=.03, corr=.06, name="cover")
    p0, _, yaw0, _ = pose(c, "cover")
    carry.rigid_move(p0 + [0., 0., lift], yaw0, seconds=1.5)
    c.hold(hold)
    p, R, yaw, st = pose(c, "cover")
    return dict(lift=float(p[2] - p0[2]), tilt=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))),
                force=st["robot_contact_force"])


def probe_right_block(c, squeeze=.45):
    """Dev: descend both end-rail grips, then list every robot contact and the arm's joint margins."""
    configure_ik(c)
    grips = [Pinch(c, "cover", side, RAIL_PROFILE, anchor=END_ANCHORS[side], azimuth=0., squeeze=squeeze)
             for side in ("left", "right")]
    import json as _json
    env = c.env
    names = {l.idx: l.name for l in env.robot.links}
    c.move_joints(grips[0].curled(-.35), .3)
    tasks = {}
    for g in grips:
        tasks.update(g.target(.10))
    goto(c, tasks, seconds=2.5)
    tasks = {}
    for g in grips:
        tasks.update(g.target())
    goto(c, tasks, seconds=1.8)
    c.hold(.3)
    out = []
    for other_name, other in [("self", env.robot), ("table", env.table)] + [(k, v) for k, v in env.objects.items()]:
        raw = env.robot.get_contacts(with_entity=other)
        a, b = raw["link_a"].cpu().numpy(), raw["link_b"].cpu().numpy()
        for i in range(len(a)):
            out.append((other_name, names.get(int(a[i]), int(a[i])), names.get(int(b[i]), int(b[i]))))
    q = c.actual_q()
    margins = {n: (round(float(q[i] - c.lo[i]), 3), round(float(c.hi[i] - q[i]), 3)) for n, i in c.index.items()
               if n.startswith("right") and not "hand" in n or n.startswith("waist")}
    err = {s: (c.hand_pose(s)[0] - t[1]).tolist() for s, t in tasks.items()}
    print("PROBE", _json.dumps(dict(contacts=out[:40], margins=margins, err=err)), flush=True)
    return dict(n=len(out))


def handle_anchor(c):
    """Cover lifting-handle bar centre in the cover frame (catalog collision geometry)."""
    bar = [g for g in c.env.catalog["parts"]["cover"]["collision_geometry"] if g["role"] == "lifting_handle"][0]
    return tuple(bar["pos"])


def run_cover_handle(c, ready=False, squeeze=.5, hover=.012, tol=.001, yaw_tol=.01):
    """One hand hooks the cover's lifting handle (the base-handle hook grasp), carries the
    cover hanging level from its centre of mass over the posts, and lowers it onto the
    post pilots, which guide the last few millimetres."""
    from .stage_base_hook import HOOK_PROFILE
    configure_ik(c)
    if ready:
        raise_hands(c)
    grip = Pinch(c, "cover", "left", HOOK_PROFILE, anchor=handle_anchor(c), azimuth=0., squeeze=squeeze,
                 opening=.35, thumb_opening=0.)
    grip.grasp()
    # Closing the hook rolls the bar; the hooked cover is held rigidly enough to be
    # levelled by turning the hand (unlike a pinch on a smooth hub).
    held = Held(grip, level=True)
    p0, _, yaw0, _ = pose(c, "cover")
    seat, base_yaw = cover_seat(c)
    c.event("cover_lift")
    held.move((p0[0], p0[1], seat[2] + .05), yaw0, seconds=1.5, settle=.6)
    c.event("cover_carry_over_posts", seat=seat.tolist())
    held.move(seat + [0., 0., .05], base_yaw, seconds=3.5, settle=.5)
    for attempt in range(3):
        for _ in range(4):
            err, yaw_err = cup_error(c)
            seat, base_yaw = cover_seat(c)
            p, _, _, _ = pose(c, "cover")
            if np.linalg.norm(err[:2]) < tol and abs(yaw_err) < yaw_tol and abs(err[2] + hover) < .003:
                break
            held.move((p[0] + err[0], p[1] + err[1], seat[2] + hover), base_yaw, seconds=.8, settle=.3)
        err, yaw_err = cup_error(c)
        c.event("cover_aligned", attempt=attempt, error=err.tolist(), yaw_error=yaw_err)
        p, _, _, _ = pose(c, "cover")
        held.move((p[0], p[1], seat[2] - .003), base_yaw, seconds=1.5, settle=.4)
        err, yaw_err = cup_error(c)
        c.event("cover_lowered", attempt=attempt, error=err.tolist(), yaw_error=yaw_err)
        if abs(err[2]) < .003:
            break
        p, _, _, _ = pose(c, "cover")
        held.move((p[0], p[1], seat[2] + hover), base_yaw, seconds=.8, settle=.2)
    hook_release(c, [grip], rise=.08)
    c.hold(.6)
    err, yaw_err = cup_error(c)
    result = dict(error=err.tolist(), yaw_error=yaw_err, completed=list(c.env.status["completed"]),
                  conditions=c.env.status.get("conditions", {}).get("cover"))
    c.event("cover_result", **result)
    return result
