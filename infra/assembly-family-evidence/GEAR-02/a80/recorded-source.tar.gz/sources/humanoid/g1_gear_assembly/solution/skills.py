"""Shared privileged skills: two-hand palm squeeze carry with measured-pose feedback.

The hands form flat paddles (straight fingers, thumb folded over the palm) and
squeeze the part from opposite sides. Hand targets live in a "hand frame" with
yaw psi about the vertical; the part follows by friction only. Integrators on
the measured part position and yaw remove arm sag and grasp slip.
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from .controller import CONTROL_DT

SIDES = ("left", "right")
# Thumb folded over the palm (least protrusion beyond the palm face); fingers straight.
PADDLE = {"left": dict(thumb_0=0., thumb_1=1.04, thumb_2=1.74, middle_0=0., middle_1=0., index_0=0., index_1=0.),
          "right": dict(thumb_0=0., thumb_1=-1.04, thumb_2=-1.74, middle_0=0., middle_1=0., index_0=0., index_1=0.)}
PALM_FACE = .021  # palm face to palm point, along the palm normal


def smooth(a):
    a = min(1., max(0., a))
    return a ** 3 * (10. - 15. * a + 6. * a * a)


def rot_z(yaw):
    return Rotation.from_euler("z", yaw).as_matrix()


def wrap(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


def pose(c, name):
    state = c.object_state(name)
    q = np.asarray(state["quat"], dtype=float)
    R = Rotation.from_quat(q[[1, 2, 3, 0]]).as_matrix()
    return np.asarray(state["position"], dtype=float), R, math.atan2(R[1, 0], R[0, 0]), state


def configure_ik(c, waist_pitch=.50):
    """IK ranges: leaning forward reaches the far, low journal positions."""
    c.ik.set_limit("waist_pitch_joint", -.25, waist_pitch)
    c.ik.set_limit("waist_roll_joint", -.30, .30)
    for side in SIDES:
        c.ik.set_limit(f"{side}_elbow_joint", .2, 1.8)


def side_forces(c, name):
    """Robot contact force magnitude on a part, split into left and right hand links."""
    env = c.env
    if not hasattr(env, "_link_sides"):
        env._link_sides = {link.idx: ("left" if link.name.startswith("left") else
                                      "right" if link.name.startswith("right") else None)
                           for link in env.robot.links}
    raw = env.objects[name].get_contacts(with_entity=env.robot)
    a, b = raw["link_a"].cpu().numpy(), raw["link_b"].cpu().numpy()
    fa, fb = raw["force_a"].cpu().numpy(), raw["force_b"].cpu().numpy()
    out = {"left": 0., "right": 0.}
    for i in range(len(a)):
        for link, force in ((a[i], fa[i]), (b[i], fb[i])):
            side = env._link_sides.get(int(link))
            if side:
                out[side] += float(np.linalg.norm(force))
    return out


def goto(c, tasks, seconds=2.5, iters=250):
    """Joint-space move to a converged IK solution for {side: (kind, pos, R)}.

    The per-step Cartesian IK only takes small steps from the current posture
    and can stall when an arm must cross the body; a full solve first, then a
    smooth joint interpolation, reaches the same targets reliably.
    """
    solution, errors = c.ik.solve(c.env.base_position, (1, 0, 0, 0), c.q, tasks, iters=iters,
                                  damping=.02, w_rot=.5, max_step=.08)
    target = c.q.copy()
    target[c.ik.upper] = solution[c.ik.upper]
    c.event("goto", errors={k: float(v) for k, v in errors.items()})
    c.move_joints(target, seconds)
    return errors


def shift_hands(c, sides, delta, seconds=1.5, yaw=0., pivot=None, rot=None):
    """Translate (and optionally rotate about `pivot`: yaw, or a full matrix `rot`) the
    current hand poses with converged IK."""
    delta = np.asarray(delta, dtype=float)
    R = rot_z(yaw) if rot is None else np.asarray(rot, dtype=float)
    tasks = {}
    # Shift from the commanded hand poses: under load the actual hands lag their
    # commands by a few millimetres, which a shift from the measured pose never removes.
    c.ik._set(c.env.base_position, (1, 0, 0, 0), c.q)
    commanded = {side: (c.ik.hand_point(side, "palm").copy(), c.ik.d.xmat[c.ik.wrist[side]].reshape(3, 3).copy())
                 for side in sides}
    for side in sides:
        p, Rh = commanded[side]
        if pivot is not None:
            p = np.asarray(pivot) + R @ (p - np.asarray(pivot))
            Rh = R @ Rh
        tasks[side] = ("palm", p + delta, Rh)
    return goto(c, tasks, seconds=seconds, iters=150)


def raise_hands(c, seconds=1.5):
    """Lift both hands sideways then forward so nothing sweeps the tabletop."""
    c.event("raise_hands")
    q = c.q.copy()
    q[c.index["left_shoulder_roll_joint"]] = max(q[c.index["left_shoulder_roll_joint"]], 1.0)
    q[c.index["right_shoulder_roll_joint"]] = min(q[c.index["right_shoulder_roll_joint"]], -1.0)
    c.move_joints(q, seconds)
    for side in SIDES:
        q[c.index[f"{side}_shoulder_pitch_joint"]] = -.8
        q[c.index[f"{side}_elbow_joint"]] = 1.3
    c.move_joints(q, seconds)


def set_shape(c, shapes, seconds=.6):
    q = c.q.copy()
    for side, shape in shapes.items():
        for joint, value in shape.items():
            i = c.index[f"{side}_hand_{joint}_joint"]
            q[i] = np.clip(value, c.lo[i] + 1e-5, c.hi[i] - 1e-5)
    c.move_joints(q, seconds)


class Bimanual:
    """Palms at +y (left) and -y (right) of the part in the hand frame, fingers along +x.

    contact[side]: palm-point position at zero gap relative to the part origin
    in the hand frame; the gap is added along +y for the left and -y for the right.
    """

    def __init__(self, c, name, contact, psi=0., force=40.):
        self.c, self.name = c, name
        self.force = force
        self.weak_steps = 0
        self.contact = {side: np.asarray(v, dtype=float) for side, v in contact.items()}
        self.normal = {"left": np.array((0., 1., 0.)), "right": np.array((0., -1., 0.))}
        self.psi = psi
        self.offset = None
        self.corr_p, self.corr_psi = np.zeros(3), 0.

    def tasks(self, origin, psi, gap):
        R = rot_z(psi)
        gaps = gap if isinstance(gap, dict) else {side: gap for side in self.contact}
        return {side: ("palm", np.asarray(origin) + R @ (local + gaps[side] * self.normal[side]), R)
                for side, local in self.contact.items()}

    def approach(self, gap=.035, lift=.08, seconds=2.5):
        c = self.c
        p, _, _, _ = pose(c, self.name)
        c.event(f"{self.name}_paddles_above")
        goto(c, self.tasks(p + [0., 0., lift], self.psi, gap), seconds=seconds)
        c.move_hands(self.tasks(p + [0., 0., lift], self.psi, gap), seconds=.5, feedback=.5, settle=.3)
        c.event(f"{self.name}_paddles_down")
        p, _, _, _ = pose(c, self.name)
        c.move_hands(self.tasks(p, self.psi, gap), seconds=1.8, feedback=.5, settle=.3)

    def regulate(self, force=None):
        """Adjust each palm's commanded penetration toward half the target squeeze force."""
        forces = side_forces(self.c, self.name)
        if not isinstance(self.gap, dict):
            self.gap = {side: self.gap for side in self.contact}
        for side in self.contact:
            step = np.clip(6e-5 * (forces[side] - self.force / 2), -.001, .0006)
            self.gap[side] = float(np.clip(self.gap[side] + step, -.12, .01))

    def squeeze(self, gap=-.02, seconds=1., regulate_seconds=2.):
        c = self.c
        c.event(f"{self.name}_squeeze", gap=gap, force=self.force)
        p, _, yaw, _ = pose(c, self.name)
        start = self.gap if hasattr(self, "gap") else .035
        count = max(1, math.ceil(seconds / CONTROL_DT))
        for i in range(count):
            g = start + smooth((i + 1) / count) * (gap - start)
            c.reach(self.tasks(p, self.psi, g), rate=.8, feedback=.0, iters=12)
            c.step()
        self.gap = {side: gap for side in self.contact}
        for _ in range(math.ceil(regulate_seconds / CONTROL_DT)):
            self.regulate()
            c.reach(self.tasks(p, self.psi, self.gap), rate=.8, feedback=.0, iters=12)
            c.step()
        _, _, yaw, state = pose(c, self.name)
        c.event(f"{self.name}_squeezed", gap=dict(self.gap), contact_force=state["robot_contact_force"],
                sides=side_forces(c, self.name))
        self.offset = yaw - self.psi

    def track(self, p_des, yaw_des, integrate=True, gain=.05, max_step=.0006, yaw_gain=.05):
        c = self.c
        p, _, yaw, state = pose(c, self.name)
        force = state["robot_contact_force"]
        self.weak_steps = self.weak_steps + 1 if force < .5 else 0
        if self.weak_steps > 10:
            raise RuntimeError(f"{self.name}: squeeze grasp lost")
        self.regulate()
        if integrate:
            self.corr_p = np.clip(self.corr_p + np.clip(gain * (p_des - p), -max_step, max_step), -.06, .06)
            self.corr_psi = float(np.clip(self.corr_psi + np.clip(yaw_gain * wrap(yaw_des - yaw), -.0015, .0015),
                                          -.1, .1))
        psi = yaw_des - self.offset + self.corr_psi
        c.reach(self.tasks(p_des + self.corr_p, psi, self.gap), rate=.8, feedback=.0, iters=12)
        c.step()
        return p, yaw

    def move(self, p_goal, yaw_goal, seconds, settle=0., **kwargs):
        p0, _, yaw0, _ = pose(self.c, self.name)
        p_goal = np.asarray(p_goal, dtype=float)
        dyaw = wrap(yaw_goal - yaw0)
        count = max(1, math.ceil(seconds / CONTROL_DT))
        for i in range(count):
            a = smooth((i + 1) / count)
            self.track(p0 + a * (p_goal - p0), yaw0 + a * dyaw, **kwargs)
        for _ in range(math.ceil(settle / CONTROL_DT)):
            self.track(p_goal, yaw0 + dyaw, **kwargs)
        p, R, yaw, _ = pose(self.c, self.name)
        return dict(position_error_m=float(np.linalg.norm(p - p_goal)),
                    xy_error_m=float(np.linalg.norm((p - p_goal)[:2])),
                    yaw_error_rad=float(abs(wrap(yaw - yaw0 - dyaw))),
                    tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))))

    def release(self, gap=.04, seconds=.8, rise=.10):
        c = self.c
        c.event(f"{self.name}_release")
        p, _, yaw, _ = pose(c, self.name)
        psi = yaw - self.offset + self.corr_psi
        origin = p + self.corr_p
        count = max(1, math.ceil(seconds / CONTROL_DT))
        start = self.gap if isinstance(self.gap, dict) else {side: self.gap for side in self.contact}
        for i in range(count):
            a = smooth((i + 1) / count)
            g = {side: start[side] + a * (gap - start[side]) for side in self.contact}
            c.reach(self.tasks(origin, psi, g), rate=.8, feedback=.3, iters=12)
            c.step()
        c.event(f"{self.name}_withdraw")
        c.move_hands(self.tasks(origin + [0., 0., rise], psi, gap), seconds=1.5, feedback=.4, settle=.2)


FLEX = ("thumb_1", "thumb_2", "middle_0", "middle_1", "index_0", "index_1")


class Pinch:
    """One-hand top pinch from a left-hand profile (palm offset, wrist rotation, joints).

    The hand descends with the fingers opened by `opening`, closes to the
    contact shape and then curls every flexion joint further by `squeeze`; the
    joint PD against contact supplies the grip. `anchor` locates the feature in
    the part's yaw frame; `azimuth` turns the whole grasp about the vertical.
    """

    def __init__(self, c, name, side, profile, anchor=(0., 0., 0.), azimuth=0., opening=.35, squeeze=.3,
                 thumb_opening=None, finger_squeeze=None):
        self.c, self.name, self.side = c, name, side
        self.thumb_opening = opening if thumb_opening is None else thumb_opening
        # Fingers squeeze less than the thumb when two fingers would otherwise push one
        # thumb back to its joint stop.
        self.finger_ratio = 1. if finger_squeeze is None else finger_squeeze / max(squeeze, 1e-9)
        mirror = np.diag((1., -1., 1.))
        R, offset = np.asarray(profile["rotation"]), np.asarray(profile["offset"])
        if side == "right":
            R, offset = mirror @ R @ mirror, mirror @ offset
        self.rotation, self.offset = rot_z(azimuth) @ R, rot_z(azimuth) @ offset
        self.anchor = np.asarray(anchor, dtype=float)
        self.sign = 1. if side == "left" else -1.
        self.shape = {j: (v if side == "left" or j == "thumb_0" else -v) for j, v in profile["hand"].items()}
        self.opening, self.squeeze_amount = opening, squeeze

    def joint(self, j):
        return self.c.index[f"{self.side}_hand_{j}_joint"]

    def curled(self, amount):
        """Contact shape with every flexion joint curled by `amount` (negative opens;
        the thumb opens by `thumb_opening` instead, so it can stay clear of nearby parts)."""
        q = self.c.q.copy()
        for j, v in self.shape.items():
            a = amount
            if j.startswith("thumb") and amount < 0:
                a = amount * self.thumb_opening / max(self.opening, 1e-9)
            elif not j.startswith("thumb") and amount > 0:
                a = amount * self.finger_ratio
            delta = 0. if j == "thumb_0" else a * (self.sign if j.startswith("thumb") else -self.sign)
            i = self.joint(j)
            q[i] = np.clip(v + delta, self.c.lo[i] + 1e-5, self.c.hi[i] - 1e-5)
        return q

    def target(self, height=0.):
        p, _, yaw, _ = pose(self.c, self.name)
        p = p + rot_z(yaw) @ self.anchor
        return {self.side: ("palm", p + self.offset + [0., 0., height], self.rotation)}

    def grasp(self, hover=.10):
        c = self.c
        c.event(f"{self.name}_pinch_preshape", side=self.side)
        c.move_joints(self.curled(-self.opening), .6)
        c.event(f"{self.name}_pinch_approach")
        goto(c, self.target(hover), seconds=2.2)
        c.move_hands(self.target(hover), seconds=.4, feedback=.6, settle=.3, rotation_feedback=.3)
        c.event(f"{self.name}_pinch_descend")
        tasks = self.target()
        c.move_hands(tasks, seconds=1.6, feedback=.7, settle=.4, rotation_feedback=.3)
        c.event(f"{self.name}_pinch_close")
        for amount, seconds in ((0., .5), (self.squeeze_amount, .6)):
            start, goal = c.q.copy(), self.curled(amount)
            count = max(1, math.ceil(seconds / CONTROL_DT))
            for i in range(count):
                a = smooth((i + 1) / count)
                hand = [self.joint(j) for j in self.shape]
                c.q[hand] = start[hand] + a * (goal[hand] - start[hand])
                c.reach(tasks, feedback=.7, iters=12, rotation_feedback=.3)
                c.step()
        state = c.object_state(self.name)
        c.event(f"{self.name}_pinch_closed", contact_force=state["robot_contact_force"])
        return tasks

    def release(self, seconds=.6, rise=.08):
        c = self.c
        c.event(f"{self.name}_pinch_release")
        palm, rot = c.hand_pose(self.side)
        start, goal = c.q.copy(), self.curled(-self.opening)
        hand = [self.joint(j) for j in self.shape]
        count = max(1, math.ceil(seconds / CONTROL_DT))
        for i in range(count):
            a = smooth((i + 1) / count)
            c.q[hand] = start[hand] + a * (goal[hand] - start[hand])
            c.reach({self.side: ("palm", palm, rot)}, feedback=.6, rotation_feedback=.3)
            c.step()
        c.move_hands({self.side: ("palm", palm + [0., 0., rise], rot)}, seconds=1.2, feedback=.5, settle=.2)


def grasp_together(c, grips, hover=.10, label="pinch_together", converged_descent=False):
    """Preshape, approach, descend and close several one-hand pinches at once.

    Moving the hands together keeps one closed hand from dragging the part
    while the other is still approaching (the waist is shared).
    """
    def merged(amounts):
        q = c.q.copy()
        for grip, amount in zip(grips, amounts):
            hand = [grip.joint(j) for j in grip.shape]
            q[hand] = grip.curled(amount)[hand]
        return q

    c.event(f"{label}_preshape")
    c.move_joints(merged([-g.opening for g in grips]), .6)
    c.event(f"{label}_approach")
    tasks = {}
    for grip in grips:
        tasks.update(grip.target(hover))
    goto(c, tasks, seconds=2.5)
    c.move_hands(tasks, seconds=.4, feedback=.6, settle=.3, rotation_feedback=.3)
    c.event(f"{label}_descend")
    tasks = {}
    for grip in grips:
        tasks.update(grip.target())
    if converged_descent:
        # Per-step IK can stall a reaching arm short of a low target; solve it fully first.
        goto(c, tasks, seconds=1.8)
        c.move_hands(tasks, seconds=.3, feedback=.7, settle=.3, rotation_feedback=.3)
    else:
        c.move_hands(tasks, seconds=1.8, feedback=.7, settle=.4, rotation_feedback=.3)
    c.event(f"{label}_descended", palm_errors={side: (c.hand_pose(side)[0] - task[1]).tolist()
                                               for side, task in tasks.items()})
    c.event(f"{label}_close")
    for amounts, seconds in (([0.] * len(grips), .5), ([g.squeeze_amount for g in grips], .6)):
        start, goal = c.q.copy(), merged(amounts)
        joints = [g.joint(j) for g in grips for j in g.shape]
        count = max(1, math.ceil(seconds / CONTROL_DT))
        for i in range(count):
            a = smooth((i + 1) / count)
            c.q[joints] = start[joints] + a * (goal[joints] - start[joints])
            c.reach(tasks, feedback=.7, iters=12, rotation_feedback=.3)
            c.step()
    c.event(f"{label}_closed", sides=side_forces(c, grips[0].name))
    return tasks


def release_together(c, grips, seconds=.6, rise=.10):
    c.event("release_together")
    poses = {g.side: c.hand_pose(g.side) for g in grips}
    start = c.q.copy()
    goal = c.q.copy()
    for g in grips:
        hand = [g.joint(j) for j in g.shape]
        goal[hand] = g.curled(-g.opening)[hand]
    count = max(1, math.ceil(seconds / CONTROL_DT))
    tasks = {side: ("palm", p, R) for side, (p, R) in poses.items()}
    for i in range(count):
        a = smooth((i + 1) / count)
        for g in grips:
            hand = [g.joint(j) for j in g.shape]
            c.q[hand] = start[hand] + a * (goal[hand] - start[hand])
        c.reach(tasks, feedback=.6, rotation_feedback=.3)
        c.step()
    c.move_hands({side: ("palm", p + [0., 0., rise], R) for side, (p, R) in poses.items()},
                 seconds=1.2, feedback=.5, settle=.2)


def hook_release(c, grips, out=.04, drop=.008, rise=.10, seconds=.6):
    """Open a cradle on a bar (fingers under it from outside, thumb from inside) and
    leave without lifting the part: open fingers and thumb, drop below the bar, slide
    outward along the finger direction so the thumb passes under the bar, then rise."""
    c.event("hook_release")
    poses = {g.side: c.hand_pose(g.side) for g in grips}
    start, goal = c.q.copy(), c.q.copy()
    for g in grips:
        hand = [g.joint(j) for j in g.shape]
        thumb_opening, g.thumb_opening = g.thumb_opening, g.opening
        goal[hand] = g.curled(-g.opening)[hand]
        g.thumb_opening = thumb_opening
    tasks = {side: ("palm", p, R) for side, (p, R) in poses.items()}
    count = max(1, math.ceil(seconds / CONTROL_DT))
    for i in range(count):
        a = smooth((i + 1) / count)
        for g in grips:
            hand = [g.joint(j) for j in g.shape]
            c.q[hand] = start[hand] + a * (goal[hand] - start[hand])
        c.reach(tasks, feedback=.6, rotation_feedback=.3)
        c.step()
    lowered = {side: ("palm", p - [0., 0., drop], R) for side, (p, R) in poses.items()}
    c.move_hands(lowered, seconds=.5, feedback=.5, settle=.1)
    shifted = {}
    for g in grips:
        p, R = poses[g.side]
        finger = R[:, 0].copy()  # wrist x axis: along the fingers
        finger[2] = 0.
        finger /= max(np.linalg.norm(finger), 1e-9)
        shifted[g.side] = ("palm", p - [0., 0., drop] + out * finger, R)
    c.move_hands(shifted, seconds=.8, feedback=.5, settle=.2)
    c.move_hands({side: ("palm", task[1] + [0., 0., rise], task[2]) for side, task in shifted.items()},
                 seconds=1.2, feedback=.5, settle=.2)
