"""Read-only scoring for assembly and tool-driven real gear transmission.

The trusted input contains only actual measured body states and contact forces:
``objects[name]`` supplies position, wxyz quaternion, linear/angular velocity,
robot_contact_force, support_forces (upward normal component by other body),
and contact_forces (normal-force magnitude by other body). There is no input
phase, grasp flag, commanded angle, attachment state, or externally set score.

Yaw is unwrapped from successive measurements after the cover has been seated.
Transmission credit requires a held tool touching the small gear, no direct
robot contact with any gear, recent measured contact at both tooth interfaces, signed
angular ratios from the source tooth counts, and sufficient moving contact
history. Static placement alone can never complete the drive test.
"""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
from math import acos, atan2, cos, degrees, isfinite, pi, sin, sqrt


TABLE_HEIGHT = .74
GEAR_NAMES = ("large_gear", "medium_gear", "small_gear")
ASSEMBLY_NAMES = ("base",) + GEAR_NAMES + ("cover",)
OBJECT_NAMES = ASSEMBLY_NAMES + ("turning_tool",)
object_names = OBJECT_NAMES
STEPS = ASSEMBLY_NAMES + ("drive_test", "release")
RECIPES = {"anticlockwise": STEPS, "clockwise": STEPS}
MESH_PAIRS = (("small_gear", "medium_gear"), ("medium_gear", "large_gear"))
PHYSICAL_DEPENDENCIES = {
    "base": (), "large_gear": ("base",),
    "medium_gear": ("base", "large_gear"),
    "small_gear": ("base", "medium_gear"),
    "cover": GEAR_NAMES, "drive_test": ("cover",), "release": ("drive_test",),
}
_CONTACT_NAMES = frozenset(OBJECT_NAMES + ("table", "fixture", "supply_rack", "ground", "robot", "other"))


def _finite(value):
    if isinstance(value, bool):
        raise ValueError("Boolean is not a physical measurement")
    result = float(value)
    if not isfinite(result):
        raise ValueError("Non-finite physical measurement")
    return result


def _vector(value, count):
    if len(value) != count:
        raise ValueError(f"Expected {count} coordinates")
    return tuple(_finite(item) for item in value)


def _norm(value):
    return sqrt(sum(item * item for item in value))


def _quaternion(value):
    q = _vector(value, 4)
    norm = _norm(q)
    if norm < 1e-12:
        raise ValueError("Zero quaternion")
    return tuple(item / norm for item in q)


def _axis(q):
    w, x, y, z = q
    return (2 * (x*z + w*y), 2 * (y*z - w*x), 1 - 2 * (x*x + y*y))


def _yaw(q):
    w, x, y, z = q
    return atan2(2 * (w*z + x*y), 1 - 2 * (y*y + z*z))


def _wrapped_delta(value):
    return atan2(sin(value), cos(value))


def _relative_yaws(objects):
    base_yaw = _yaw(objects["base"]["quat"])
    return {name: _wrapped_delta(_yaw(objects[name]["quat"]) - base_yaw) for name in GEAR_NAMES}


@dataclass(frozen=True)
class TaskConfig:
    seed: int = 0
    recipe: str = "anticlockwise"
    table_height: float = TABLE_HEIGHT
    table_center: tuple = (.52, 0.)
    table_size: tuple = (.68, 1.3, .05)
    origin: tuple = (.44, 0., TABLE_HEIGHT)
    control_dt: float = .02
    max_episode_seconds: float = 360.
    object_names: tuple = OBJECT_NAMES
    position_tolerance: float = .004
    angle_tolerance_degrees: float = 12.
    stable_seconds: float = .5
    final_hold_seconds: float = 2.
    support_loss_grace_seconds: float = .3
    wrong_order_grace_seconds: float = .25
    linear_speed_max: float = .025
    angular_speed_max: float = .15
    robot_contact_force_max: float = .05
    support_force_min: float = .01
    tool_contact_force_min: float = .01
    mesh_contact_force_min: float = .002
    mesh_contact_memory_seconds: float = .12
    mesh_contact_seconds_min: float = .02
    mesh_contact_impulse_min: float = .0002
    mesh_contact_fraction_min: float = .05
    required_small_angle_rad: float = pi / 2
    ratio_relative_tolerance: float = .20
    ratio_absolute_tolerance_rad: float = .05
    max_drive_angular_speed: float = 12.
    motion_epsilon_rad: float = .00002
    drop_distance: float = .12

    def __post_init__(self):
        if isinstance(self.seed, bool) or not isinstance(self.seed, int) or self.seed < 0:
            raise ValueError("seed must be a nonnegative integer")
        if self.recipe not in RECIPES:
            raise ValueError("recipe must be anticlockwise or clockwise")
        if tuple(self.object_names) != OBJECT_NAMES:
            raise ValueError("object_names must identify the five assembly parts and turning tool")
        for name, value in vars(self).items():
            if name in ("seed", "recipe", "object_names", "table_center", "table_size", "origin"):
                continue
            if _finite(value) <= 0:
                raise ValueError(f"{name} must be positive")
        _vector(self.table_center, 2)
        if min(_vector(self.table_size, 3)) <= 0:
            raise ValueError("table_size must be positive")
        origin = _vector(self.origin, 3)
        if abs(origin[2] - self.table_height) > 1e-9:
            raise ValueError("origin must lie on the tabletop")
        if self.angle_tolerance_degrees >= 90 or self.ratio_relative_tolerance >= 1 or self.mesh_contact_fraction_min > 1:
            raise ValueError("Invalid angle, ratio, or contact-fraction tolerance")

    @property
    def sequence(self):
        return RECIPES[self.recipe]

    @property
    def drive_sign(self):
        return 1 if self.recipe == "anticlockwise" else -1


class Evaluator:
    def __init__(self, config, catalog):
        self.cfg = config
        self.sequence = self.order = tuple(config.sequence)
        self.goals = {
            name: (tuple(config.origin[i] + _vector(catalog["parts"][name]["goal_local"], 3)[i] for i in range(3)),
                   _quaternion(catalog["parts"][name].get("goal_quat_wxyz", (1., 0., 0., 0.))))
            for name in ASSEMBLY_NAMES
        }
        self.teeth = {}
        for name in GEAR_NAMES:
            teeth = catalog["parts"][name].get("teeth", catalog.get("gear_meta", {}).get("teeth", {}).get(name))
            if isinstance(teeth, bool) or not isinstance(teeth, int) or teeth < 3:
                raise ValueError(f"Catalog must provide an actual integer tooth count for {name}")
            self.teeth[name] = teeth
        self.reset()

    def reset(self):
        self.elapsed = 0.
        self.stage = 0
        self.completed = []
        self.current_dwell = self.final_dwell = 0.
        self.conditions, self.loss_dwell, self.wrong_order_dwell = {}, {}, {}
        self.drive_angles = {name: 0. for name in GEAR_NAMES}
        self.credited_angles = {name: 0. for name in GEAR_NAMES}
        self.previous_yaw = None
        self.mesh_contact_age = {pair: float("inf") for pair in MESH_PAIRS}
        self.mesh_contact_seconds = {pair: 0. for pair in MESH_PAIRS}
        self.mesh_contact_impulse = {pair: 0. for pair in MESH_PAIRS}
        self.drive_motion_seconds = self.tool_contact_seconds = 0.
        self.success = self.failed = False
        self.reason = "in_progress"
        self.failure_detail = None
        self._terminal = None
        return self.status()

    def status(self):
        if self._terminal is not None:
            return deepcopy(self._terminal)
        return {
            "stage": self.stage, "stage_name": self.order[self.stage] if self.stage < len(self.order) else "complete",
            "completed": list(self.completed), "assignments": {name: name for name in self.completed if name in ASSEMBLY_NAMES},
            "score": int(self.success), "progress": 1. if self.success else self.stage / len(self.order),
            "success": self.success, "failed": self.failed, "terminated": self.success or self.failed,
            "terminal": self.success or self.failed, "reason": self.reason,
            "failure_reason": self.reason if self.failed else None, "failure_detail": deepcopy(self.failure_detail),
            "elapsed_seconds": self.elapsed, "current_stable_seconds": self.current_dwell,
            "final_hold_seconds": self.final_dwell, "conditions": deepcopy(self.conditions),
            "drive_angles_rad": dict(self.drive_angles), "credited_angles_rad": dict(self.credited_angles),
            "mesh_contact_seconds": {"--".join(pair): value for pair, value in self.mesh_contact_seconds.items()},
            "mesh_contact_impulse_ns": {"--".join(pair): value for pair, value in self.mesh_contact_impulse.items()},
            "drive_motion_seconds": self.drive_motion_seconds, "tool_contact_seconds": self.tool_contact_seconds,
        }

    def _finish(self, reason, *, success=False, detail=None):
        self.reason, self.failure_detail = reason, detail
        self.success, self.failed = success, not success
        self._terminal = self.status()
        return deepcopy(self._terminal)

    @staticmethod
    def _read_object(raw):
        result = {
            "position": _vector(raw["position"], 3), "quat": _quaternion(raw["quat"]),
            "linear_velocity": _vector(raw["linear_velocity"], 3), "angular_velocity": _vector(raw["angular_velocity"], 3),
            "robot_contact_force": _finite(raw["robot_contact_force"]),
        }
        for field in ("support_forces", "contact_forces"):
            values = raw[field]
            if not isinstance(values, Mapping) or set(values) - _CONTACT_NAMES:
                raise ValueError("Unknown contact identity")
            result[field] = {name: _finite(force) for name, force in values.items()}
            if any(force < 0 for force in result[field].values()):
                raise ValueError("Contact magnitudes must be nonnegative")
        if result["robot_contact_force"] < 0:
            raise ValueError("Robot contact magnitude must be nonnegative")
        return result

    def _near(self, name, obj):
        position, quat = self.goals[name]
        if any(abs(obj["position"][i] - position[i]) > self.cfg.position_tolerance for i in range(3)):
            return False
        if name in GEAR_NAMES:
            dot = sum(a*b for a, b in zip(_axis(obj["quat"]), _axis(quat)))
            error = degrees(acos(min(1., max(-1., dot))))
        else:
            dot = abs(sum(a*b for a, b in zip(obj["quat"], quat)))
            error = degrees(2 * acos(min(1., dot)))
        return error <= self.cfg.angle_tolerance_degrees

    def _slow(self, obj, *, permit_gear_yaw=False):
        angular = obj["angular_velocity"][:2] if permit_gear_yaw else obj["angular_velocity"]
        return _norm(obj["linear_velocity"]) <= self.cfg.linear_speed_max and _norm(angular) <= self.cfg.angular_speed_max

    def _released(self, obj):
        return obj["robot_contact_force"] <= self.cfg.robot_contact_force_max

    def _condition(self, name, objects):
        obj = objects[name]
        force = obj["support_forces"]
        support = (max(force.get("table", 0.), force.get("fixture", 0.)) if name == "base" else force.get("base", 0.))
        pose = self._near(name, obj)
        supported = support > self.cfg.support_force_min
        slow, released = self._slow(obj, permit_gear_yaw=name in GEAR_NAMES), self._released(obj)
        return {"pose": pose, "supported": supported, "slow": slow, "released": released,
                "structural_valid": pose and supported,
                "stable_released": pose and supported and slow and released}

    @staticmethod
    def _contact(objects, first, second):
        return max(objects[first]["contact_forces"].get(second, 0.), objects[second]["contact_forces"].get(first, 0.))

    def _drive(self, objects, dt):
        yaw = _relative_yaws(objects)
        if self.previous_yaw is None:
            self.previous_yaw = yaw
            return False
        delta = {name: _wrapped_delta(yaw[name] - self.previous_yaw[name]) for name in GEAR_NAMES}
        self.previous_yaw = yaw
        if any(abs(value) > self.cfg.max_drive_angular_speed * dt + .002 for value in delta.values()):
            self._finish("invalid_gear_motion", detail={"reason": "yaw jump exceeds measured-step limit"})
            return False
        for name, value in delta.items():
            self.drive_angles[name] += value
        moving = max(abs(value) for value in delta.values()) > self.cfg.motion_epsilon_rad
        intact = all(self.conditions[name]["structural_valid"] for name in ASSEMBLY_NAMES)
        held_tool = objects["turning_tool"]["robot_contact_force"] > self.cfg.tool_contact_force_min
        tool_contact = self._contact(objects, "turning_tool", "small_gear") > self.cfg.tool_contact_force_min
        unassisted = all(self._released(objects[name]) for name in GEAR_NAMES)
        input_active = intact and held_tool and tool_contact and unassisted
        forces = {pair: self._contact(objects, *pair) for pair in MESH_PAIRS}
        for pair, force in forces.items():
            self.mesh_contact_age[pair] += dt
            if force > self.cfg.mesh_contact_force_min:
                self.mesh_contact_age[pair] = 0.
            if input_active and moving and force > self.cfg.mesh_contact_force_min:
                self.mesh_contact_seconds[pair] += dt
                self.mesh_contact_impulse[pair] += force * dt
        qualified = input_active and all(age <= self.cfg.mesh_contact_memory_seconds for age in self.mesh_contact_age.values())
        if qualified and moving:
            self.drive_motion_seconds += dt
            self.tool_contact_seconds += dt
            for name, value in delta.items():
                self.credited_angles[name] += value
        signed_small = self.cfg.drive_sign * self.credited_angles["small_gear"]
        if signed_small < self.cfg.required_small_angle_rad:
            return False
        expected = {
            "small_gear": self.credited_angles["small_gear"],
            "medium_gear": -self.credited_angles["small_gear"] * self.teeth["small_gear"] / self.teeth["medium_gear"],
            "large_gear": self.credited_angles["small_gear"] * self.teeth["small_gear"] / self.teeth["large_gear"],
        }
        ratios = all(
            self.credited_angles[name] * expected[name] > 0.
            and abs(self.credited_angles[name] - expected[name]) <= self.cfg.ratio_absolute_tolerance_rad + self.cfg.ratio_relative_tolerance * abs(expected[name])
            for name in GEAR_NAMES
        )
        contact_history = all(
            self.mesh_contact_seconds[pair] >= self.cfg.mesh_contact_seconds_min
            and self.mesh_contact_seconds[pair] >= self.cfg.mesh_contact_fraction_min * self.drive_motion_seconds
            and self.mesh_contact_impulse[pair] >= self.cfg.mesh_contact_impulse_min
            for pair in MESH_PAIRS
        )
        self.conditions["drive_test"] = {"tool_input": input_active, "ratios": ratios,
            "contact_history": contact_history, "required_angle": signed_small >= self.cfg.required_small_angle_rad}
        return qualified and ratios and contact_history

    def update(self, state, dt):
        if self._terminal is not None:
            return deepcopy(self._terminal)
        try:
            dt = _finite(dt)
            if dt <= 0. or dt > self.cfg.control_dt * 1.01:
                return self._finish("invalid_sample_interval")
            objects = {name: self._read_object(state["objects"][name]) for name in OBJECT_NAMES}
        except (KeyError, TypeError, ValueError, OverflowError):
            return self._finish("invalid_state")
        self.elapsed += dt
        if self.elapsed >= self.cfg.max_episode_seconds:
            return self._finish("timeout")
        for name, obj in objects.items():
            if obj["position"][2] < self.cfg.table_height - self.cfg.drop_distance:
                return self._finish("object_dropped", detail={"object": name})
        self.conditions = {name: self._condition(name, objects) for name in ASSEMBLY_NAMES}
        for name in self.completed:
            if name not in ASSEMBLY_NAMES:
                continue
            self.loss_dwell[name] = 0. if self.conditions[name]["structural_valid"] else self.loss_dwell.get(name, 0.) + dt
            if self.loss_dwell[name] >= self.cfg.support_loss_grace_seconds:
                return self._finish("structure_lost", detail={"object": name})
        if self.stage < len(ASSEMBLY_NAMES):
            for future in ASSEMBLY_NAMES[self.stage + 1:]:
                condition = self.conditions[future]["stable_released"]
                self.wrong_order_dwell[future] = self.wrong_order_dwell.get(future, 0.) + dt if condition else 0.
                if self.wrong_order_dwell[future] >= self.cfg.wrong_order_grace_seconds:
                    return self._finish("wrong_order", detail={"object": future, "expected": self.order[self.stage]})
            name = self.order[self.stage]
            valid = self.conditions[name]["stable_released"] and all(
                self.conditions[previous]["structural_valid"] for previous in self.completed)
            self.current_dwell = self.current_dwell + dt if valid else 0.
            if self.current_dwell + 1e-9 >= self.cfg.stable_seconds:
                self.completed.append(name)
                self.stage += 1
                self.current_dwell = 0.
                if self.stage == len(ASSEMBLY_NAMES):
                    self.previous_yaw = _relative_yaws(objects)
        elif self.stage == len(ASSEMBLY_NAMES):
            if self._drive(objects, dt):
                self.completed.append("drive_test")
                self.stage += 1
            if self._terminal is not None:
                return deepcopy(self._terminal)
        else:
            valid = all(self.conditions[name]["structural_valid"] for name in ASSEMBLY_NAMES)
            valid = valid and all(self._released(obj) and self._slow(obj) for obj in objects.values())
            tool_on_table = objects["turning_tool"]["support_forces"].get("table", 0.) > self.cfg.support_force_min
            tool_clear = all(self._contact(objects, "turning_tool", name) <= self.cfg.tool_contact_force_min for name in GEAR_NAMES)
            self.conditions["release"] = {"tool_on_table": tool_on_table, "tool_clear_of_gears": tool_clear,
                                           "all_slow_and_released": valid}
            valid = valid and tool_on_table and tool_clear
            self.final_dwell = self.final_dwell + dt if valid else 0.
            if self.final_dwell + 1e-9 >= self.cfg.final_hold_seconds:
                self.completed.append("release")
                self.stage += 1
                return self._finish("assembled_driven_and_released", success=True)
        return self.status()
