"""Full privileged expert: base, three gears, cover, tool drive, tool parked, hands off.

Run it through run_expert.py so every action is recorded and audited from the
default reset, e.g.
  python -m humanoid.g1_gear_assembly.solution.run_expert --policy expert:run --output runs/gear_expert --replay
"""
from .stage_base_hook import run_base
from .stage_cover_rail import run_cover_handle
from .stage_drive import run_drive
from .stage_gears import run_large_held, run_medium_held, run_small_held


def await_stage(c, name, timeout=8.):
    """Hold still until the evaluator credits `name` (released and stable)."""
    c.event("await_stage", stage=name)
    steps = 0
    while name not in c.env.status["completed"] and steps * .02 < timeout:
        c.hold(.1)
        steps += 5
    if name not in c.env.status["completed"]:
        raise RuntimeError(f"stage {name} not credited: {c.env.status.get('conditions', {}).get(name)}")


def run(c):
    # Every stage starts by raising both hands: a one-hand reach turns the shared
    # waist, which would otherwise carry the idle hand into the placed parts.
    run_base(c)
    await_stage(c, "base")
    run_large_held(c, ready=True)
    await_stage(c, "large_gear")
    run_medium_held(c, ready=True)
    await_stage(c, "medium_gear")
    run_small_held(c, ready=True)
    await_stage(c, "small_gear")
    run_cover_handle(c, ready=True)
    await_stage(c, "cover")
    run_drive(c, ready=True)
    c.hold(2.5)
    return dict(success=c.env.status["success"], reason=c.env.status["reason"],
                completed=list(c.env.status["completed"]))
