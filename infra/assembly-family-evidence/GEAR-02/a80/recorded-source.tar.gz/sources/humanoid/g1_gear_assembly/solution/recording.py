"""Audited default-reset joint-action recordings for privileged gear experts.

This is a development API audit, not a hostile-code sandbox. The recorder
intercepts every environment control interval; an independent replay uses
only saved joint targets in a fresh environment.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import json
import hashlib
from pathlib import Path
import shutil

import numpy as np
from PIL import Image

from ..genesis_env import CONTROL_DT, SIM_DT, supply_layout
from ..provenance import catalog_fingerprint, sha256
from ..task_spec import TaskConfig

PACKAGE = Path(__file__).resolve().parents[1]


def plain(value):
    if hasattr(value, "detach"):
        return value.detach().cpu().numpy().tolist()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {key: plain(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [plain(item) for item in value]
    return value


def write_json(path, value):
    Path(path).write_text(json.dumps(plain(value), ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


class EpisodeAudit:
    ENTITY_METHODS = ("set_pos", "set_quat", "set_qpos", "set_dofs_position",
        "set_dofs_velocity", "set_vverts", "set_dofs_force_range", "set_dofs_armature",
        "apply_links_external_wrench", "apply_links_external_force", "apply_links_external_torque")

    def __init__(self, env):
        self.env, self.active, self.originals, self.violations = env, False, [], []
        self.guarded_methods = []
        self.fresh_default_reset = False

    def guard(self, owner, name, label):
        if not hasattr(owner, name):
            return
        original = getattr(owner, name)
        existed = name in getattr(owner, "__dict__", {})
        def forbidden(*args, **kwargs):
            item = dict(method=f"{label}.{name}", physics_steps=self.env.physics_steps)
            self.violations.append(item)
            raise RuntimeError(f"Forbidden state/force modification during expert recording: {item['method']}")
        setattr(owner, name, forbidden)
        self.originals.append((owner, name, original, existed))
        self.guarded_methods.append(f"{label}.{name}")

    def __enter__(self):
        cfg = self.env.cfg
        if asdict(cfg) != asdict(TaskConfig(seed=cfg.seed, recipe=cfg.recipe)):
            raise ValueError("Expert recording requires the standard task configuration")
        self.env.reset()
        if self.env.physics_steps != 0:
            raise ValueError("Expert recording must begin from the default reset")
        poses, _ = supply_layout(self.env.catalog, cfg.seed, cfg.table_height)
        state = self.env.trusted_state()
        for name, pose in poses.items():
            actual = state["objects"][name]
            if not np.allclose(actual["position"], pose["pos"], rtol=0., atol=1e-6):
                raise ValueError(f"Unexpected initial object pose: {name}")
            if abs(np.dot(actual["quat"], pose["quat"])) < 1.-1e-8:
                raise ValueError(f"Unexpected initial object orientation: {name}")
            if any(np.linalg.norm(actual[field]) > 1e-6 for field in ("linear_velocity", "angular_velocity")):
                raise ValueError(f"Object must start at rest: {name}")
        if not np.allclose(self.env._array(self.env.robot.get_dofs_position(self.env.dofs)),
                           self.env._array(self.env.default_q), rtol=0., atol=1e-6):
            raise ValueError("Unexpected initial robot posture")
        if np.linalg.norm(self.env._array(self.env.robot.get_dofs_velocity(self.env.dofs))) > 1e-6:
            raise ValueError("Robot must start at rest")
        self.fresh_default_reset = True
        try:
            for index, entity in enumerate(self.env.scene.entities):
                for name in self.ENTITY_METHODS:
                    self.guard(entity, name, f"entity_{index}")
            for name in ("reset", "set_state", "add_entity"):
                self.guard(self.env.scene, name, "scene")
            self.guard(self.env, "reset", "env")
            for name in ("add_weld_constraint", "delete_weld_constraint", "set_state"):
                self.guard(self.env.scene.rigid_solver, name, "rigid_solver")
            self.active = True
            return self
        except BaseException:
            self.restore()
            raise

    def restore(self):
        for owner, name, original, existed in reversed(self.originals):
            if existed:
                setattr(owner, name, original)
            else:
                delattr(owner, name)
        self.originals.clear()
        self.active = False

    def __exit__(self, *args):
        self.restore()

    def report(self):
        return dict(fresh_default_reset=self.fresh_default_reset,
                    forbidden_state_or_force_attempts=deepcopy(self.violations),
                    guarded_methods=list(self.guarded_methods),
                    scope="development API guards plus independent action replay; not an isolated sandbox")


class Recorder:
    def __init__(self, env, audit, output, *, backend="cpu", policy=None, rgb_stride=5, source_snapshot=None):
        if not audit.active or env.physics_steps:
            raise ValueError("Recorder must immediately follow an audited reset")
        self.env, self.audit, self.output = env, audit, Path(output)
        if self.output.exists() and any(self.output.iterdir()):
            raise FileExistsError("Expert output must be empty")
        self.output.mkdir(parents=True, exist_ok=True)
        self.backend, self.policy, self.rgb_stride = backend, policy, rgb_stride
        if rgb_stride < 1:
            raise ValueError("RGB stride must be positive")
        self.controller = None
        self.rows, self.frame_indices, self.frame_times = [], [], []
        self.original_advance = None
        self.original_scene_step = None
        self.step_active = False
        self.closed = False
        self.last_tick = 0
        source_snapshot = source_snapshot or dict(
            implementation={p.name:p.read_bytes() for p in PACKAGE.glob("*.py")},
            controllers={p.name:p.read_bytes() for p in Path(__file__).parent.glob("*.py")})
        self.implementation_hashes = {name:hashlib.sha256(data).hexdigest() for name,data in source_snapshot["implementation"].items()}
        current = {p.name:sha256(p) for p in PACKAGE.glob("*.py")}
        if current != self.implementation_hashes:
            raise RuntimeError("Environment implementation changed during scene construction")
        self.controller_hashes = {name:hashlib.sha256(data).hexdigest() for name,data in source_snapshot["controllers"].items()}
        self.loaded_code_hashes = source_snapshot.get("loaded_code",{})
        source_output = self.output/"controller_sources"
        source_output.mkdir()
        for name,data in source_snapshot["controllers"].items():
            (source_output/name).write_bytes(data)
        reference = PACKAGE/"references"/env.cfg.recipe
        shutil.copytree(reference, self.output/"instruction")
        shutil.copy2(reference.parent/"render_manifest.json", self.output/"render_manifest.json")
        self.trace = (self.output/"trusted_trace.jsonl").open("w", encoding="utf-8")
        if env.cam is not None:
            (self.output/"rgb").mkdir()
            Image.fromarray(env.render()).save(self.output/"initial.png")
            Image.fromarray(env.sensor_rgb()).save(self.output/"initial_sensor.png")

    def __enter__(self):
        self.original_advance = self.env.advance_targets
        if hasattr(self.env.scene, "step"):
            self.original_scene_step = self.env.scene.step
            self.scene_step_existed = "step" in getattr(self.env.scene, "__dict__", {})
            def scene_step(*args, **kwargs):
                if not self.step_active:
                    self.audit.violations.append(dict(method="scene.step outside recorded action",physics_steps=self.env.physics_steps))
                    raise RuntimeError("Direct scene stepping bypasses the recorded joint action")
                return self.original_scene_step(*args, **kwargs)
            self.env.scene.step = scene_step
        def advance(target):
            if self.env.physics_steps != self.last_tick:
                raise RuntimeError("An unrecorded control interval occurred")
            recorded = np.asarray(plain(target), dtype=np.float32).copy()
            start_tick = self.env.physics_steps
            index = len(self.rows)
            if self.env.cam is not None and index % self.rgb_stride == 0:
                Image.fromarray(self.env.sensor_rgb()).save(self.output/"rgb"/f"{index:06d}.png")
                self.frame_indices.append(index)
                self.frame_times.append(start_tick*SIM_DT)
            phase = getattr(self.controller, "phase", "unknown")
            nominal = getattr(self.controller, "q", recorded)
            self.step_active = True
            try:
                self.original_advance(target)
            finally:
                self.step_active = False
            ticks = self.env.physics_steps-start_tick
            if ticks <= 0 or ticks > round(CONTROL_DT/SIM_DT):
                raise RuntimeError("Each recorded action must advance exactly one control interval")
            if ticks != round(CONTROL_DT/SIM_DT) and not self.env.status["terminated"]:
                raise RuntimeError("Only a terminal control interval may be shortened")
            state = self.env.trusted_state()
            self.rows.append(dict(target=recorded, nominal=np.asarray(nominal).copy(),
                time=state["time"], q=self.env._array(self.env.robot.get_dofs_position(self.env.dofs)).copy(),
                qd=self.env._array(self.env.robot.get_dofs_velocity(self.env.dofs)).copy(),
                reward=float(self.env.status["success"])-float(self.env.status["failed"]), phase=phase))
            self.trace.write(json.dumps(plain(dict(state=state, status=self.env.status, phase=phase)), ensure_ascii=False)+"\n")
            self.trace.flush()
            self.last_tick = self.env.physics_steps
        self.env.advance_targets = advance
        return self

    def finish(self, error=None):
        if self.closed:
            return self.report
        self.closed = True
        if self.original_advance is not None:
            self.env.advance_targets = self.original_advance
        if self.original_scene_step is not None:
            if self.scene_step_existed:
                self.env.scene.step = self.original_scene_step
            else:
                delattr(self.env.scene, "step")
        self.trace.close()
        rows = self.rows
        np.savez_compressed(self.output/"trajectory.npz",
            targets=np.asarray([r["target"] for r in rows]).reshape((-1,43)),
            nominal_q=np.asarray([r["nominal"] for r in rows]).reshape((-1,43)),
            time=[r["time"] for r in rows], joint_position=np.asarray([r["q"] for r in rows]).reshape((-1,43)),
            joint_velocity=np.asarray([r["qd"] for r in rows]).reshape((-1,43)),
            reward=[r["reward"] for r in rows], phase=[r["phase"] for r in rows],
            rgb_action_index=np.asarray(self.frame_indices,dtype=int), rgb_time=self.frame_times)
        report = self.env.diagnostics()
        report.update(schema_version=1, seed=self.env.cfg.seed, recipe=self.env.cfg.recipe,
            backend=self.backend, policy=self.policy, purpose="privileged_expert_candidate",
            state_feedback="privileged object/contact state and joint state",
            full_task_success=bool(self.env.status["success"]), robot_expert_verified=False,
            recording_complete=error is None and bool(rows) and self.env.physics_steps==self.last_tick,
            error=str(error) if error is not None else None,
            audit=self.audit.report(), forbidden_state_write_audit_performed=True,
            catalog_fingerprint=catalog_fingerprint(self.env.catalog), instruction_sha256=self.env.instruction_digest,
            implementation_sha256=self.implementation_hashes, controller_source_sha256=self.controller_hashes,
            loaded_python_code_sha256=self.loaded_code_hashes,
            control_steps=len(rows), rgb_stride=self.rgb_stride if self.env.cam else None,
            complete_policy_rgb_recorded=bool(self.env.cam and self.rgb_stride==1),
            action_semantics="43 absolute G1 joint angles, radians, hardware-capped PD",
            state_timing="RGB precedes action; state and time follow action",
            fixed_pelvis=True, adapter_has_object_pose_action=False)
        if self.audit.violations:
            report["recording_complete"] = report["full_task_success"] = False
        write_json(self.output/"report.json", report)
        if self.env.cam is not None:
            Image.fromarray(self.env.render()).save(self.output/"final.png")
            Image.fromarray(self.env.sensor_rgb()).save(self.output/"final_sensor.png")
        self.report = report
        return report

    def __exit__(self, exc_type, exc_value, traceback):
        self.finish(exc_value)
