"""G1 assembly from rendered CAD references with contact-driven gear testing."""
