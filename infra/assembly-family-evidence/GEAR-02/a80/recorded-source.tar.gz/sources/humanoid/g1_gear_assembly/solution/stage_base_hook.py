"""Base stage with the lifting handles: each hand hooks a handle bar, the base is carried
over the jig wall, aligned on its measured pose, lowered into the jig and released.

Privileged expert skill: the measured base pose closes the loop; joint targets
are the only actions. The fingers curl under the bars, so the base hangs from
the hands instead of relying on squeeze friction.
"""
import math

import numpy as np

from .skills import Pinch, configure_ik, grasp_together, hook_release, pose, raise_hands, shift_hands, side_forces
from .stage_base_wrap import Carry, base_goal

# Left-hand cradle on the 14 mm handle bar (search_bar_pinch.py --contact-z -0.0055,
# dev_runs/hook_bar_02): thumb and fingertips meet below the bar centre line.
HOOK_PROFILE = dict(
    rotation=np.array([[0.0, 0.0, 1.0], [0.935393868068, 0.3536075672, 0.0], [-0.3536075672, 0.935393868068, 0.0]]),
    offset=np.array([-0.000193120101, -0.003397851472, 0.088366935649]),
    hand={'thumb_0': 1.28e-10, 'thumb_1': 0.119876082167, 'thumb_2': 0.876934986368, 'middle_0': -0.972998409284, 'middle_1': -0.897985453515, 'index_0': -0.972998409237, 'index_1': -0.897985453582})
SIDES = ("left", "right")


def handle_anchor(c, side):
    """Handle-bar centre in the base frame (catalog collision geometry)."""
    bars = [g for g in c.env.catalog["parts"]["base"]["collision_geometry"] if g["role"] == "lifting_handle"]
    bar = max(bars, key=lambda g: g["pos"][1]) if side == "left" else min(bars, key=lambda g: g["pos"][1])
    return tuple(bar["pos"])


def configure(c):
    # Leaning forward is what lets both hands reach the handles over the jig.
    configure_ik(c, waist_pitch=.50)
    c.ik.set_limit("waist_roll_joint", -.30, .30)


def run_base(c, lift=.035, squeeze=.5, opening=.35):
    configure(c)
    raise_hands(c, seconds=1.5)
    # The thumb sits inboard of the bar; opening it would swing it onto the journal tops.
    grips = {side: Pinch(c, "base", side, HOOK_PROFILE, anchor=handle_anchor(c, side), squeeze=squeeze,
                         opening=opening, thumb_opening=0.) for side in SIDES}
    grasp_together(c, list(grips.values()), label="base_hooks")
    c.hold(.3)
    carry = Carry(c, tilt_gain=.03, corr=.10)
    p0, _, yaw0, _ = pose(c, "base")
    goal = base_goal(c)
    c.event("base_lift", start=p0.tolist())
    carry.rigid_move(p0 + [0., 0., lift], yaw0, seconds=2.5)
    c.hold(.5)
    p1, _, _, state = pose(c, "base")
    c.event("base_lifted", position=p1.tolist(), sides=side_forces(c, "base"))
    c.event("base_transport")
    carry.rigid_move(goal + [0., 0., lift] + (carry.cmd_p - p1), 0., seconds=6.)
    c.hold(.5)
    # Hand over to the feedback carry without a jump: start its integrator at the sag offset.
    p2, _, _, _ = pose(c, "base")
    carry.corr_p = carry.cmd_p - p2
    # Final placement by relative hand moves from the measured base pose: the
    # cradled bars may sit a little differently in the hands than at grasp time. The
    # base pitches a few degrees in the hooks; the jig chamfer seats it on release.
    def tilt_deg(R):
        return float(np.degrees(np.arccos(np.clip(R[2, 2], -1., 1.))))

    def align(height, rounds, seconds=.8):
        for _ in range(rounds):
            p, R, yaw, _ = pose(c, "base")
            error = goal + [0., 0., height] - p
            if np.linalg.norm(error[:2]) < .0005 and abs(error[2]) < .002 and abs(yaw) < .002:
                break
            shift_hands(c, SIDES, error, seconds=seconds, yaw=-yaw, pivot=p)
            c.hold(.4)

    align(.015, 8)
    p, R, yaw, _ = pose(c, "base")
    c.event("base_alignment", error=(p - goal - [0., 0., .015]).tolist(), yaw=yaw, tilt_deg=tilt_deg(R))
    for attempt in range(3):
        c.event("base_lower_into_jig", attempt=attempt)
        p, R, _, _ = pose(c, "base")
        shift_hands(c, SIDES, goal - [0., 0., .004] - p, seconds=2.)
        c.hold(.5)
        p, R, yaw, state = pose(c, "base")
        c.event("base_lowered", position=p.tolist(), yaw=yaw, tilt_deg=tilt_deg(R), support=state["support_forces"])
        # Seated, or aligned and already below the jig rim: the jig walls guide the
        # last few millimetres once the hooks open.
        aligned = np.linalg.norm((p - goal)[:2]) < .0006 and abs(yaw) < .0015
        if abs(p[2] - goal[2]) < .002 or (aligned and p[2] - goal[2] < .007 and not state["support_forces"]):
            break
        p, R, _, _ = pose(c, "base")
        shift_hands(c, SIDES, goal + [0., 0., .015] - p, seconds=.8)
        c.hold(.3)
        align(.015, 4)
    hook_release(c, list(grips.values()))
    c.hold(.6)
    p, _, yaw, _ = pose(c, "base")
    result = dict(position=p.tolist(), error=(p - goal).tolist(), yaw=yaw, stage=c.env.status["stage_name"],
                  completed=list(c.env.status["completed"]), conditions=c.env.status["conditions"].get("base"))
    c.event("base_result", **result)
    return result
