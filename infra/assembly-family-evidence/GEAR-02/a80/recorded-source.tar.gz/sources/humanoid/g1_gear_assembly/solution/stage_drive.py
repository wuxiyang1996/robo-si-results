"""Drive test: pick the turning tool, push the small gear through tooth strokes, park the tool.

Privileged expert skill: measured tool, gear and base poses close the loop.
Only the tool touches the small gear; the hand never touches a gear. The tool
is held level by a three-point pinch on its square handle and enters from the
robot side at tooth height, under the cover rail.
"""
import math

import numpy as np

from .skills import Pinch, configure_ik, pose, raise_hands
from .stage_gears import Held

# Left-hand top pinch across the 24 mm square handle with its 2.5 mm top lip
# (search_bar_pinch.py --width 0.024 --height 0.024 --gap 0 --contact-z -0.002
# --lip 0.0025 0.004, dev_runs/toollip_cz-0.002): thumb on one face, index and
# middle 57 mm apart on the other, all 10 mm below the lip; mirrored for the right hand.
TOOL_PROFILE = dict(
    rotation=np.array([[0.0, 0.0, 1.0000000000000004], [0.9632525574134942, 0.268597301990105, 0.0], [-0.268597301990105, 0.9632525574134942, 0.0]]),
    offset=np.array([-0.00015670448730531995, 0.0021479215525066347, 0.08545484846229684]),
    hand={'thumb_0': 3.396347500936371e-11, 'thumb_1': -0.32985837748541497, 'thumb_2': 1.3252637006840935, 'middle_0': -1.0080961258307655, 'middle_1': -1.0610951770332573, 'index_0': -1.008096125885941, 'index_1': -1.0610951769217913})
# Pinch over the tool's centre of mass (catalog: x = -35.2 mm): with no gravity moment
# the pinch cannot creep into a nose-down pitch.
HANDLE_ANCHOR = (-.0352, 0., 0.)
TIP_END = .075
TOOTH_PITCH = 2 * math.pi / 20
GAP_PHASE = TOOTH_PITCH / 2  # small-gear teeth are centred at 0 + k*18 deg in its frame


def pick_tool(c, side="left", lift=.06, squeeze=.3):
    configure_ik(c)
    grip = Pinch(c, "turning_tool", side, TOOL_PROFILE, anchor=HANDLE_ANCHOR, squeeze=squeeze)
    grip.grasp()
    held = Held(grip)
    p, _, yaw, _ = pose(c, "turning_tool")
    c.event("tool_lift")
    held.move(p + [0., 0., lift], yaw, seconds=2., settle=.6)
    # Once lifted, level the tool by turning the wrist: tilted, its weight slides it
    # along the pinch. (Levelling during the lift-off rolled the handle out of the pinch.)
    held.level = True
    p2, R, _, state = pose(c, "turning_tool")
    result = dict(lift_m=float(p2[2] - p[2]), contact_force=state["robot_contact_force"],
                  tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))))
    c.event("tool_lift_result", **result)
    return grip, held, result


def small_center(c):
    p, _, yaw, _ = pose(c, "small_gear")
    return p, yaw


def gap_angle(c, start, sign=1):
    """World angle (about the small axis) of the first tooth gap at or past `start`
    in the drive direction (sign +1 anticlockwise, -1 clockwise)."""
    _, yaw = small_center(c)
    if sign > 0:
        k = math.ceil((start - yaw - GAP_PHASE) / TOOTH_PITCH)
    else:
        k = math.floor((start - yaw - GAP_PHASE) / TOOTH_PITCH)
    return yaw + GAP_PHASE + k * TOOTH_PITCH


def tool_pose(center, theta, r_end, z):
    """Tool origin and yaw with the tip end at radius r_end, angle theta, pointing inward."""
    direction = np.array((math.cos(theta), math.sin(theta), 0.))
    tip = np.asarray(center, dtype=float) + r_end * direction
    return np.array((tip[0], tip[1], z)) + TIP_END * direction, theta + math.pi


def drive(c, held, strokes=5, start=None, stop=None):
    """Radial insertion into a tooth gap from the +y side, sweep about the small axis in
    the recipe direction, retract, repeat. The tool passes under the cover's end rail
    and the base handle bar; the medium gear is on the other side."""
    sign = c.env.cfg.drive_sign
    if start is None:
        start, stop = (math.radians(88.), math.radians(126.)) if sign > 0 else (math.radians(126.), math.radians(88.))
    center, yaw0 = small_center(c)
    h = (c.env.catalog["gear_meta"]["shaft_top"] - c.env.catalog["gear_meta"]["shaft_bottom"]) / 2
    z = center[2] - h / 2  # tooth mid-height
    root = c.env.catalog["parts"]["small_gear"].get("root_radius", .0219)
    r_in, r_out, r_far = .023, .036, .095
    theta = gap_angle(c, start, sign)
    c.event("drive_enter", gap_deg=math.degrees(theta))
    # Carry above the cover (its top is ~45 mm above tooth height), stop with the tip
    # outside the cover's near rail, then lower straight down beside the gear.
    held.move(*tool_pose(center, theta, r_far, z + .08), seconds=3.5, settle=.4)
    held.move(*tool_pose(center, theta, r_far, z), seconds=2., settle=.3)
    for stroke in range(strokes):
        theta = gap_angle(c, start, sign)
        c.event("drive_stroke", stroke=stroke, gap_deg=math.degrees(theta))
        held.move(*tool_pose(center, theta, r_out, z), seconds=1., settle=.2)
        theta = gap_angle(c, start, sign)
        held.move(*tool_pose(center, theta, r_in, z), seconds=.8, settle=.2, gain=.08)
        count = round(2.5 / .02)
        for i in range(count):
            th = theta + (i + 1) / count * (stop - theta)
            held.track(*tool_pose(center, th, r_in, z), gain=.06)
        held.move(*tool_pose(center, stop, r_in, z), seconds=.3, settle=.2)
        status = c.env.status
        c.event("drive_stroke_result", stroke=stroke, small_turn_deg=math.degrees(small_center(c)[1] - yaw0),
                credited=status.get("credited_angles_rad"), completed=list(status["completed"]),
                conditions=status.get("conditions", {}).get("drive_test"))
        held.move(*tool_pose(center, stop, r_out, z), seconds=.6, settle=.1)
        if "drive_test" in status["completed"]:
            break
        held.move(*tool_pose(center, start, r_out, z), seconds=1.2, settle=.1)
    held.move(*tool_pose(center, math.radians(90.), r_far, z), seconds=1.5, settle=.2)
    held.move(*tool_pose(center, math.radians(90.), r_far, z + .08), seconds=1.2, settle=.2)
    return dict(completed=list(c.env.status["completed"]), credited=c.env.status.get("credited_angles_rad"),
                root_radius=root)


def park_tool(c, grip, held, spot=(.30, .40)):
    """Set the tool on the table on its flat handle face and open the pinch."""
    table = c.env.cfg.table_height
    p, _, _, _ = pose(c, "turning_tool")
    c.event("tool_park", spot=list(spot))
    held.move([p[0], p[1], p[2] + .04], 0., seconds=1., settle=.2)
    held.move([spot[0], spot[1], table + .04], 0., seconds=3., settle=.3)
    held.move([spot[0], spot[1], table + .0125], 0., seconds=1.2, settle=.4)
    grip.release(rise=.10)


def run_drive(c, ready=False):
    if ready:
        raise_hands(c)
    grip, held, _ = pick_tool(c)
    result = drive(c, held)
    park_tool(c, grip, held)
    c.hold(2.5)
    status = c.env.status
    result.update(stage=status["stage_name"], success=status["success"], reason=status["reason"])
    c.event("drive_result", **result)
    return result


def test_pick_tool(c):
    raise_hands(c)
    _, held, result = pick_tool(c)
    p, _, _, _ = pose(c, "turning_tool")
    held.move(p + [.05, .15, .02], 0., seconds=2., settle=1.)
    p, R, _, state = pose(c, "turning_tool")
    result.update(after_carry=dict(position=p.tolist(), tilt_deg=float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))),
                                   contact_force=state["robot_contact_force"]))
    return result


def test_tool_hold(c, hold=30.):
    """Dev: pick the tool and hold it still; log its drift in the hand (pinch creep check)."""
    import json as _json
    raise_hands(c)
    grip, held, result = pick_tool(c)
    p0, _, yaw0, _ = pose(c, "turning_tool")
    hp0, _ = c.hand_pose(grip.side)
    rel0 = p0 - hp0
    for i in range(int(hold / 2.)):
        held.move(p0, yaw0, seconds=.1, settle=1.9)
        p, R, yaw, st = pose(c, "turning_tool")
        hp, _ = c.hand_pose(grip.side)
        print("TOOL", _json.dumps(dict(t=2 * (i + 1), drift_mm=np.round((p - hp - rel0) * 1000, 2).tolist(),
                                       tilt=round(float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1)))), 2),
                                       f=round(st["robot_contact_force"], 1))), flush=True)
        if st["robot_contact_force"] < .05:
            break
    return result
