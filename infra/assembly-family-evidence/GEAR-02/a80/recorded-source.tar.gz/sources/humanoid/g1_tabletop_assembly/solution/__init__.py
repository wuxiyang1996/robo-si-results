"""Privileged joint-controlled reference expert and reproducible recordings."""
