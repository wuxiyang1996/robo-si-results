"""Physical right-Dex3 cap grasp with a hook added only after leaving the table.

``parts_runs/cap_helper5`` validates actual stage 2 -> 3 insertion and release
after an explicitly diagnostic brace/sleeve setup, using the default robot.
This is segment evidence, not a complete assembly expert. All control goes
through robot joint targets; no scene placements occur in this module.
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from humanoid.g1_tabletop.genesis_env import CONTROL_DT


HOLE_CLEAR_FOR_POST = True
_MIRROR = np.diag([1., -1., 1.])
GRASP_ROTATION = _MIRROR @ (
    Rotation.from_euler("x", -20., degrees=True).as_matrix()
    @ Rotation.from_euler("z", 90., degrees=True).as_matrix()
    @ Rotation.from_euler("x", 90., degrees=True).as_matrix()) @ _MIRROR
PALM_OFFSET = np.array([0., .00331379660691378, .0912135232650593])
OPEN_HAND = {
    "thumb_0": .08799515946084369,
    "thumb_1": .16377767962911965,
    "thumb_2": -.5127780017426237,
    "middle_0": .7538957717248191,
    "middle_1": .4677844383963046,
    "index_0": .7538957717049959,
    "index_1": .46778443867553937,
}
DESIRED_SUMS = {
    "thumb": OPEN_HAND["thumb_1"] + OPEN_HAND["thumb_2"],
    "middle": OPEN_HAND["middle_0"] + OPEN_HAND["middle_1"],
    "index": OPEN_HAND["index_0"] + OPEN_HAND["index_1"],
}


def configure_ik(c):
    c.ik.set_limit("waist_pitch_joint", -.25, .30)
    c.ik.set_limit("waist_roll_joint", -.25, .25)
    c.ik.set_limit("right_elbow_joint", .2, 1.8)


class FingerOrientationServo:
    """Maintain actual distal angles and deepen the curl off the table."""

    def __init__(self, c, *, hook=.2, air_hook=.45):
        self.controller = c
        self.enabled = True
        self.closed = False
        self.hook = hook
        self.air_hook = air_hook
        self.release_active = False
        self.initial_height = float(c.object_state("cap")["pos"][2])

        def feedback(current):
            if not self.enabled:
                return
            if self.closed and not self.release_active:
                if current.object_state("cap")["pos"][2] > self.initial_height + .02251:
                    self.hook += float(np.clip(self.air_hook - self.hook, -.01, .01))
            actual = current.actual_q()
            for finger, first_number, second_number in (
                    ("thumb", 1, 2), ("middle", 0, 1), ("index", 0, 1)):
                first = current.index[f"right_hand_{finger}_{first_number}_joint"]
                second = current.index[f"right_hand_{finger}_{second_number}_joint"]
                desired = DESIRED_SUMS[finger]
                if self.closed:
                    desired += -self.hook if finger == "thumb" else self.hook
                error = desired - actual[first] - actual[second]
                current.q[second] = np.clip(
                    desired - actual[first] + .5 * error,
                    current.lo[second] + 1e-5, current.hi[second] - 1e-5)

        self.callback = feedback
        c.joint_feedback["right_grasp"] = feedback

    def remove(self):
        self.enabled = False
        if self.controller.joint_feedback.get("right_grasp") is self.callback:
            self.controller.joint_feedback.pop("right_grasp")


def install_finger_servo(c):
    old = getattr(c, "_cap_finger_servo", None)
    if old is not None and c.joint_feedback.get("right_grasp") is old.callback:
        old.enabled = True
        return old
    servo = FingerOrientationServo(c)
    c._cap_finger_servo = servo
    return servo


def grasp_pose(c):
    state = c.object_state("cap")
    quat = np.asarray(state["quat"])
    rotation = Rotation.from_quat(quat[[1, 2, 3, 0]]).as_matrix()
    yaw = math.atan2(rotation[1, 0], rotation[0, 0])
    rotation = Rotation.from_euler("z", yaw).as_matrix()
    return np.asarray(state["pos"]) + rotation @ PALM_OFFSET, rotation @ GRASP_ROTATION


def _tasks(palm, rotation, other_pose=None):
    tasks = {"right": ("palm", np.asarray(palm), rotation)}
    if other_pose is not None:
        tasks["left"] = ("palm", other_pose[0], None)
    return tasks


def _open_targets(c):
    target = c.q.copy()
    for finger, value in OPEN_HAND.items():
        target[c.index[f"right_hand_{finger}_joint"]] = value
    return target


def approach(c, *, hover=.10, seconds=4., preserve_other_hand=False, other_pose=None):
    """Approach a measured cap from elevated, collision-free arm poses."""
    configure_ik(c)
    old = getattr(c, "_cap_finger_servo", None)
    if old is not None:
        old.remove()
    install_finger_servo(c)
    c.event("cap_preshape", hole_clear_for_post=True)
    c.move_joints(_open_targets(c), seconds=.7)
    palm, rotation = grasp_pose(c)
    if other_pose is None and preserve_other_hand:
        other_pose = c.hand_pose("left")
    c.event("cap_approach_high")
    c.move_hands(_tasks(palm + [0, 0, hover], rotation, other_pose),
                 seconds=seconds, feedback=.5, settle=1.)
    return palm, rotation, other_pose


def grasp(c, *, approach_first=True, squeeze=.18, lift_height=.20,
          hold_seconds=0., preserve_other_hand=False, other_pose=None, approach_seconds=4.):
    """Grasp the outer 80 mm width and retain the empty central hole.

    The hook is shallow while the cap rests on the table. After lifting 22.5 mm,
    it deepens gradually to retain contact with the thin side walls.
    Returns measured evidence; it never advances the task evaluator.
    """
    configure_ik(c)
    if approach_first:
        palm, rotation, other_pose = approach(
            c, preserve_other_hand=preserve_other_hand, other_pose=other_pose, seconds=approach_seconds)
    else:
        palm, rotation = grasp_pose(c)
        if other_pose is None and preserve_other_hand:
            other_pose = c.hand_pose("left")
    servo = install_finger_servo(c)
    initial_height = float(c.object_state("cap")["pos"][2])
    if not hasattr(c, "held_hand_rotations"):
        c.held_hand_rotations = {}
    c.held_hand_rotations["right"] = rotation.copy()
    tasks = _tasks(palm, rotation, other_pose)
    c.event("cap_descend")
    c.move_hands(tasks, seconds=3., feedback=.5, settle=.5)
    c.event("cap_squeeze")
    servo.closed = True
    start = c.q.copy()
    closed = start.copy()
    closed[c.index["right_hand_thumb_1_joint"]] -= squeeze
    for finger in ("middle", "index"):
        closed[c.index[f"right_hand_{finger}_0_joint"]] += squeeze
    active = [c.index[f"right_hand_{finger}_joint"] for finger in OPEN_HAND]
    for i in range(100):
        fraction = min(1., (i + 1) / 50)
        fraction = fraction * fraction * (3 - 2 * fraction)
        c.q[active] = (start + fraction * (closed - start))[active]
        c.reach(tasks, feedback=.8)
        c.step()
    c.event("cap_lift", commanded_lift_m=lift_height)
    c.move_hands(_tasks(palm + [0, 0, lift_height], rotation, other_pose),
                 seconds=max(3., lift_height / .05), feedback=.5, settle=hold_seconds)
    state = c.object_state("cap")
    result = {
        "hole_clear_for_post": True,
        "lift_m": float(state["pos"][2] - initial_height),
        "robot_contact": bool(state["robot_contact"]),
        "support_contact": bool(state["support_contact"]),
        "linear_speed_m_s": float(np.linalg.norm(state["linear_velocity"])),
        "palm_position": c.hand_pose("right")[0].tolist(),
        "cap_position": state["pos"],
        "hook_angle_rad": servo.hook,
    }
    result["grasp_verified"] = bool(
        result["lift_m"] > .05 and result["robot_contact"]
        and not result["support_contact"] and result["linear_speed_m_s"] < .01)
    c.event("cap_grasp_result", **result)
    return result


def release(c, side="right", seconds=.7, keep_center=True):
    """Open the grasp, compensating the measured cap's sideways release drift."""
    if side != "right":
        raise ValueError("this cap grasp is defined for the right Dex3")
    palm, rotation = c.hand_pose("right")
    tasks = _tasks(palm, rotation)
    desired_center = np.asarray(c.object_state("cap")["pos"], dtype=float)
    correction = np.zeros(3)
    servo = getattr(c, "_cap_finger_servo", None)
    if servo is not None:
        servo.release_active = True
    initial_hook = 0. if servo is None else servo.hook
    start, target = c.q.copy(), _open_targets(c)
    active = [c.index[f"right_hand_{finger}_joint"]
              for finger in ("thumb_0", "thumb_1", "middle_0", "index_0")]
    c.event("cap_release")
    count = max(1, math.ceil(seconds / CONTROL_DT))
    for i in range(count):
        fraction = (i + 1) / count
        if servo is not None:
            servo.hook = initial_hook * (1 - fraction)
        c.q[active] = start[active] + fraction * (target[active] - start[active])
        if keep_center:
            state = c.object_state("cap")
            if state["robot_contact"]:
                error = desired_center[:2] - np.asarray(state["pos"])[:2]
                correction[:2] = np.clip(
                    correction[:2] + np.clip(.35 * error, -.002, .002), -.025, .025)
            tasks = _tasks(palm + correction, rotation)
        c.reach(tasks, feedback=.5, iters=12)
        c.step()
    c.hold(.25, tasks=tasks)
    if servo is not None:
        servo.remove()
    if hasattr(c, "held_hand_rotations"):
        c.held_hand_rotations.pop("right", None)


def insert(c, *, release_clearance=.018, release_seconds=.7):
    """Transfer a physically held cap above the post and release with xy feedback.

    Releasing before pressing on the post lets gravity level the slightly
    tilted ring. Correcting sideways finger-release drift is necessary: without
    it this same path shifted the cap about 10 mm and flipped it onto its side.
    """
    from .parts import transfer_held_part

    cfg = c.env.cfg
    state = c.object_state("cap")
    if not state["robot_contact"] or state["support_contact"]:
        raise RuntimeError("cap insertion requires a physically held, unsupported cap")
    c.event("cap_transfer_above")
    release_height = cfg.post_top + cfg.cap_height / 2 + .018
    error = transfer_held_part(
        c, "cap", "right", [*cfg.base_center, release_height], seconds=3.)
    if error > .006:
        raise RuntimeError(f"cap: release alignment error {error:.4f}")
    if release_clearance < .018:
        # Align above the post before lowering vertically. A diagonal approach
        # at the engagement height catches the side of the locating post.
        c.event("cap_engage_post")
        error = transfer_held_part(c, "cap", "right",
                                   [*cfg.base_center, cfg.post_top+cfg.cap_height/2+release_clearance],
                                   seconds=.4, settle_steps=20)
        if error > .006:
            raise RuntimeError(f"cap: vertical engagement error {error:.4f}")
    release(c, seconds=release_seconds)
    c.event("cap_retract_after_release")
    palm, rotation = c.hand_pose("right")
    c.move_hand("right", palm + [0., 0., .10], rotation, seconds=1.5)
    c.event("cap_verify_seated")
    c.hold(2.5)
    result = dict(status=dict(c.env.status), cap=c.object_state("cap"))
    if not c.env.status.get("success") or c.env.status.get("stage") != 3:
        raise RuntimeError(f"cap: evaluator did not confirm assembly: {c.env.status}")
    c.event("cap_assembly_result", **result)
    return result


def recenter_after_sleeve(c, seconds=3.5):
    """Return elevated empty arms to a centered positive-elbow posture.

    Sleeve insertion can leave waist yaw near -1.4 rad and the unused right hand
    behind the torso. A direct Cartesian cap approach then cannot converge.
    This joint interpolation starts from the current targets, preserving finger
    angles. It is not a pose assignment or a replay from the default robot.
    """
    target = c.q.copy()
    for name, index in c.index.items():
        if (name.startswith("waist") or "shoulder" in name
                or "elbow" in name or "wrist" in name):
            target[index] = 0.
    for side, sign in (("left", 1.), ("right", -1.)):
        target[c.index[f"{side}_shoulder_pitch_joint"]] = -.8
        target[c.index[f"{side}_shoulder_roll_joint"]] = sign * 1.15
        target[c.index[f"{side}_elbow_joint"]] = 1.3
    c.event("cap_recenter_after_sleeve")
    c.move_joints(target, seconds=seconds)
    c.hold(.2)
    c.event("cap_recenter_complete",
            palms={side: c.hand_pose(side)[0].tolist() for side in ("left", "right")})


def run_cap(c, *, release_clearance=.018, release_seconds=.7, approach_seconds=4.):
    """Run the validated cap segment from clear, elevated positive-elbow arms.

    The left palm moves to (.25, .35, 1.05) during right-hand approach. The caller
    must first release the sleeve and lift the left fingers clear of the post.
    The right palm must already be above the table on the positive-elbow branch.
    No reset/default-posture joint path is replayed here.
    """
    if c.env.status.get("stage") != 2:
        raise RuntimeError("cap segment requires the evaluator's insert_cap stage")
    if (abs(c.actual_q()[c.index["waist_yaw_joint"]]) > .5
            or c.hand_pose("right")[0][0] < .15):
        recenter_after_sleeve(c)
    result = grasp(
        c, lift_height=.20, hold_seconds=0.,
        other_pose=(np.array([.25, .35, 1.05]), None), approach_seconds=approach_seconds)
    if not result["grasp_verified"]:
        raise RuntimeError(f"cap: physical grasp was not verified: {result}")
    return insert(c, release_clearance=release_clearance, release_seconds=release_seconds)
