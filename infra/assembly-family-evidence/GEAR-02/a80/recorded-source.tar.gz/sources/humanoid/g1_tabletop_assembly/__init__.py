"""G1 tabletop assembly with a required fixture support tool."""

from .task_spec import Evaluator, TaskConfig, scene_objects

__all__ = ["Evaluator", "TaskConfig", "scene_objects"]
