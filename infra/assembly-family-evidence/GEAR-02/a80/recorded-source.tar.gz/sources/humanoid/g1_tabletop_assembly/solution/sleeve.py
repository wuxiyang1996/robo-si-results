"""Single-left-Dex3 sleeve grasp using joint targets and measured finger angles.

The grasp spans the sleeve's outer 100 mm width, keeping its hole empty.
``grasp_search_runs/feedback6`` supplies isolated physical grasp evidence;
``runner_runs/sleeve_natural_01`` also validates a default-robot approach.
Transition from another task stage and complete insertion still need validation.
No robot/object pose setters or evaluator writes are used here.
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from humanoid.g1_tabletop.genesis_env import CONTROL_DT


HOLE_CLEAR_FOR_POST = True
GRASP_ROTATION = (Rotation.from_euler("x", -20, degrees=True).as_matrix()
                  @ Rotation.from_euler("z", 90, degrees=True).as_matrix()
                  @ Rotation.from_euler("x", 90, degrees=True).as_matrix())
PALM_OFFSET = np.asarray([0., -.0036713886858313, .0761413472898285])
OPEN_HAND = {
    "thumb_0": .027070739590121372,
    "thumb_1": -.4245844658359032,
    "thumb_2": .7736344278235096,
    "middle_0": -.477889686340502,
    "middle_1": -.7438245062444832,
    "index_0": -.4778896863405025,
    "index_1": -.7438245062444827,
}
DESIRED_SUMS = {
    "thumb": OPEN_HAND["thumb_1"] + OPEN_HAND["thumb_2"],
    "middle": OPEN_HAND["middle_0"] + OPEN_HAND["middle_1"],
    "index": OPEN_HAND["index_0"] + OPEN_HAND["index_1"],
}


def configure_ik(c):
    """Keep room for gravity compensation and contact feedback at joint limits."""
    c.ik.set_limit("waist_pitch_joint", -.25, .30)
    c.ik.set_limit("waist_roll_joint", -.25, .25)
    c.ik.set_limit("left_elbow_joint", .2, 1.8)


def maintain_distal(c, gain=.5):
    """Set distal references from measured proximal angles; no simulation writes.

    Equal and opposite *reference* changes do not preserve actual finger
    orientation under contact loads. This feedback keeps distal collision
    surfaces approximately vertical so normal grip force does not press down.
    """
    actual = c.actual_q()
    for finger, first_number, second_number in (
            ("thumb", 1, 2), ("middle", 0, 1), ("index", 0, 1)):
        first = c.index[f"left_hand_{finger}_{first_number}_joint"]
        second = c.index[f"left_hand_{finger}_{second_number}_joint"]
        desired = DESIRED_SUMS[finger]
        error = desired - actual[first] - actual[second]
        c.q[second] = np.clip(desired - actual[first] + gain * error,
                             c.lo[second], c.hi[second])


class FingerOrientationServo:
    """Install through Controller's joint-feedback hook before torque targets."""

    def __init__(self, controller):
        self.controller = controller
        self.enabled = True

        def feedback(current):
            if self.enabled:
                maintain_distal(current)

        self.callback = feedback
        controller.joint_feedback["left_grasp"] = feedback

    def remove(self):
        self.enabled = False
        if self.controller.joint_feedback.get("left_grasp") is self.callback:
            self.controller.joint_feedback.pop("left_grasp")


def install_finger_servo(c):
    old = getattr(c, "_sleeve_finger_servo", None)
    if old is not None and c.joint_feedback.get("left_grasp") is old.callback:
        old.enabled = True
        return old
    servo = FingerOrientationServo(c)
    c._sleeve_finger_servo = servo
    return servo


def grasp_pose(c):
    """Palm pose relative to the currently measured sleeve, including its yaw."""
    state = c.object_state("sleeve")
    quaternion = np.asarray(state["quat"])
    rotation = Rotation.from_quat(quaternion[[1, 2, 3, 0]]).as_matrix()
    # Parts start upright; use measured yaw so small roll noise does not move
    # finger normals away from the vertical direction used by the servo.
    yaw = math.atan2(rotation[1, 0], rotation[0, 0])
    rotation = Rotation.from_euler("z", yaw).as_matrix()
    return np.asarray(state["pos"]) + rotation @ PALM_OFFSET, rotation @ GRASP_ROTATION


def _tasks(c, palm, rotation, other_pose=None):
    tasks = {"left": ("palm", np.asarray(palm), rotation)}
    if other_pose is not None:
        tasks["right"] = ("palm", other_pose[0], None)
    return tasks


def _open_targets(c):
    target = c.q.copy()
    for finger, value in OPEN_HAND.items():
        target[c.index[f"left_hand_{finger}_joint"]] = value
    return target


def approach(c, *, hover=.08, seconds=3., preserve_other_hand=False):
    """Approach from clear elevated space, optionally retaining right position.

    This deliberately does not reset or replay a default-posture joint path.
    The caller must withdraw the fixture-support hand before beginning it.
    """
    configure_ik(c)
    old = getattr(c, "_sleeve_finger_servo", None)
    if old is not None:
        old.enabled = False
    c.event("sleeve_preshape", hole_clear_for_post=True)
    c.move_joints(_open_targets(c), seconds=.5)
    palm, rotation = grasp_pose(c)
    other = c.hand_pose("right") if preserve_other_hand else None
    c.event("sleeve_approach_high")
    c.move_hands(_tasks(c, palm + [0, 0, .18], rotation, other),
                 seconds=seconds, feedback=.5, settle=.3)
    c.event("sleeve_hover")
    c.move_hands(_tasks(c, palm + [0, 0, hover], rotation, other),
                 seconds=2., feedback=.5, settle=.3)
    install_finger_servo(c)
    return palm, rotation


def grasp(c, *, approach_first=True, squeeze=.3, lift_height=.08,
          hold_seconds=2., hover=.08, preserve_other_hand=False, settle_timeout=0.):
    """Close on the outer walls, lift, and report measured grasp evidence.

    Success here means an unsupported, still-held sleeve; it does not mean the
    assembly task is complete. The finger servo remains installed for transport.
    """
    configure_ik(c)
    if approach_first:
        approach(c, hover=hover, preserve_other_hand=preserve_other_hand)
    install_finger_servo(c)
    palm, rotation = grasp_pose(c)
    if not hasattr(c, "held_hand_rotations"):
        c.held_hand_rotations = {}
    c.held_hand_rotations["left"] = rotation.copy()
    other = c.hand_pose("right") if preserve_other_hand else None
    tasks = _tasks(c, palm, rotation, other)
    initial = np.asarray(c.object_state("sleeve")["pos"])
    c.event("sleeve_lower_to_outer_walls")
    c.move_hands(tasks, seconds=2., feedback=.5, settle=.3)
    closed = c.q.copy()
    closed[c.index["left_hand_thumb_1_joint"]] += squeeze
    for finger in ("middle", "index"):
        closed[c.index[f"left_hand_{finger}_0_joint"]] -= squeeze
    c.event("sleeve_close_outer_walls")
    c.move_joints(closed, seconds=1.)
    c.hold(.5)
    c.event("sleeve_lift", commanded_lift_m=lift_height)
    c.move_hands(_tasks(c, palm + [0, 0, lift_height], rotation, other),
                 seconds=2., feedback=.5, settle=hold_seconds)
    state = c.object_state("sleeve")
    for _ in range(math.ceil(settle_timeout/CONTROL_DT)):
        if (not state["robot_contact"] or state["support_contact"]
                or np.linalg.norm(state["linear_velocity"]) < .01):
            break
        c.step()
        state = c.object_state("sleeve")
    result = {
        "hole_clear_for_post": True,
        "lift_m": float(state["pos"][2] - initial[2]),
        "robot_contact": bool(state["robot_contact"]),
        "support_contact": bool(state["support_contact"]),
        "linear_speed_m_s": float(np.linalg.norm(state["linear_velocity"])),
        "palm_position": c.hand_pose("left")[0].tolist(),
        "sleeve_position": state["pos"],
    }
    result["grasp_verified"] = bool(result["lift_m"] > .05 and result["robot_contact"]
                                    and not result["support_contact"]
                                    and result["linear_speed_m_s"] < .01)
    c.event("sleeve_grasp_result", **result)
    return result


def release(c, side="left", seconds=1.):
    """Open the three-finger grasp while retaining the current palm pose."""
    if side != "left":
        raise ValueError("this sleeve grasp is defined for the left Dex3 hand")
    palm, rotation = c.hand_pose("left")
    tasks = _tasks(c, palm, rotation)
    start = c.q.copy()
    target = _open_targets(c)
    active = [c.index[f"left_hand_{finger}_joint"]
              for finger in ("thumb_0", "thumb_1", "middle_0", "index_0")]
    c.event("sleeve_release")
    count = max(1, math.ceil(seconds / CONTROL_DT))
    for i in range(count):
        fraction = (i + 1) / count
        c.q[active] = start[active] + fraction * (target[active] - start[active])
        c.reach(tasks, feedback=.5, iters=12)
        c.step()
    c.hold(.25, tasks=tasks)
    servo = getattr(c, "_sleeve_finger_servo", None)
    if servo is not None:
        servo.remove()
    if hasattr(c, "held_hand_rotations"):
        c.held_hand_rotations.pop("left", None)
