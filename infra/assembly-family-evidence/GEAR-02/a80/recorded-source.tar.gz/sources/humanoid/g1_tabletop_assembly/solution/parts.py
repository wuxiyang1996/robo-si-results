"""Contact-only part manipulation helpers.

The forward-slide prefix has physical diagnostic evidence. Grasp and insertion
remain under development; this module does not label a proposed motion a success.
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from humanoid.g1_tabletop.genesis_env import CONTROL_DT, JOINT_NAMES


def _pose(c, side):
    return c.hand_pose(side)


def _move(c, goals, seconds, rate=.7):
    """Slow interpolation on the tested positive-elbow IK branch."""
    goals = dict(goals)
    for side in ("left", "right"):
        if side not in goals:
            goals[side] = _pose(c, side)
    start = {side: _pose(c, side) for side in goals}
    count = max(1, round(seconds / CONTROL_DT))
    for i in range(count):
        a = min(1., (i+1) / max(1, round(seconds*.8/CONTROL_DT)))
        a = a*a*(3-2*a)
        tasks = {}
        for side, (pos, rot) in goals.items():
            p0, r0 = start[side]
            rotation = None
            if rot is not None:
                rotation = Rotation.from_rotvec(
                    a*Rotation.from_matrix(rot @ r0.T).as_rotvec()).as_matrix() @ r0
            tasks[side] = ("palm", p0+a*(np.asarray(pos)-p0), rotation)
        solution, _ = c.ik.solve(
            c.env.base_position, (1, 0, 0, 0), c.q, tasks,
            iters=8, damping=.03, w_rot=.3, max_step=.1)
        up = c.ik.upper
        c.q[up] += np.clip(solution[up]-c.q[up], -rate*CONTROL_DT, rate*CONTROL_DT)
        c.step()


def _joints(c, target, seconds):
    start = c.q.copy()
    count = max(1, round(seconds/CONTROL_DT))
    for i in range(count):
        a = (i+1)/count
        a = a*a*(3-2*a)
        c.q = start+a*(target-start)
        c.step()


def natural_ready_from_default(c):
    """Raise from the default low-arm posture without sweeping through the table.

    This transition is validated from the default posture only. A later skill
    must first move its hands into clear space before reusing a joint trajectory.
    """
    c.event("parts_raise_outwards")
    target = c.q.copy()
    target[JOINT_NAMES.index("left_shoulder_roll_joint")] = 1.15
    target[JOINT_NAMES.index("right_shoulder_roll_joint")] = -1.15
    _joints(c, target, 3.)
    c.event("parts_raise_forward")
    target = c.q.copy()
    for side in ("left", "right"):
        target[JOINT_NAMES.index(f"{side}_shoulder_pitch_joint")] = -.8
        target[JOINT_NAMES.index(f"{side}_elbow_joint")] = 1.3
    _joints(c, target, 3.)
    for side in ("left", "right"):
        c.ik.set_limit(f"{side}_elbow_joint", .2, 2.58)


def push_sleeve_forward(c, target_x=.29):
    """Move sleeve toward the robot with two real fingertips on its far wall.

    Preconditions: hands are in clear elevated space on the positive-elbow
    branch. The measured sleeve pose is used; no object state is assigned.
    Evidence: parts_runs/bimanual7, sleeve x .43 -> .28095, support retained.
    """
    p = np.asarray(c.env.state()["sleeve"]["pos"])
    depth = c.env.cfg.sleeve_outer_size[0]
    rotation = (Rotation.from_euler("z", -90, degrees=True).as_matrix()
                @ Rotation.from_euler("y", 90, degrees=True).as_matrix())
    c.hand_preset("left", "squeeze", seconds=0.)

    def goals(center, gap=.015):
        contact = center+np.array([depth/2, 0., .03])
        return {"left": (contact-rotation @ np.array([.065, -.055-gap, 0.]), rotation),
                "right": (np.array([.25, -.3, 1.05]), None)}

    c.event("sleeve_push_approach")
    _move(c, goals(p+[0., 0., .20]), 5.)
    c.event("sleeve_push_lower")
    _move(c, goals(p), 4.)
    c.event("sleeve_push_slide")
    _move(c, goals(np.array([target_x, p[1], p[2]]), gap=-.015), 5.)
    c.event("sleeve_push_retract")
    palm, _ = _pose(c, "left")
    _move(c, {"left": (palm+[0., 0., .28], rotation)}, 4.)
    measured = c.env.state()["sleeve"]
    result = dict(start=p.tolist(), end=measured["pos"],
                  moved_forward=measured["pos"][0] < p[0]-.08,
                  brace_supported=c.env.status.get("conditions", {}).get("brace_supported", False))
    c.event("sleeve_forward_result", **result)
    return result


def transfer_held_part(c, name, side, goal, seconds=4., position_step=.008,
                       preserve_other_hand=False, allow_post_release=False, settle_steps=50):
    """Closed-loop object pose transfer for an already verified physical grasp.

    Follow the part's translation while retaining the measured wrist rotation.
    A friction grasp can rotate within the fingers; treating it as a rigid
    attachment for rotation correction caused it to slip in the lift probe.
    """
    start = np.asarray(c.env.state()[name]["pos"])
    start_palm, hand_rotation = _pose(c, side)
    hand_rotation = getattr(c, "held_hand_rotations", {}).get(side, hand_rotation)
    goal = np.asarray(goal, dtype=float)
    count = max(1, math.ceil(seconds/CONTROL_DT))
    other = "right" if side == "left" else "left"
    other_pose = _pose(c, other)
    correction = np.zeros(3)
    for i in range(count + settle_steps):
        a = (i+1)/count
        a = min(1., a)
        a = a*a*(3-2*a)
        desired = start+a*(goal-start)
        state = c.env.state()[name]
        position = np.asarray(state["pos"])
        if not state["robot_contact"] and np.linalg.norm(position-goal) > .01:
            if allow_post_release and _over_post(c, name, position):
                c.event(f"{name}_released_over_post", position=position.tolist())
                break
            raise RuntimeError(f"{name}: grasp lost during transfer")
        error = desired-position
        if i >= count:
            correction = np.clip(
                correction+np.clip(.08*error, -position_step, position_step), -.035, .035)
        target = start_palm+(desired-start)+correction
        tasks = {side: ("palm", target, hand_rotation)}
        if preserve_other_hand:
            tasks[other] = ("palm", other_pose[0], None)
        c.reach(tasks, rate=.8, feedback=.5, iters=12)
        c.step()
        if position[2] < c.env.cfg.table_height-.02:
            raise RuntimeError(f"{name} lost during physical transfer")
    measured = np.asarray(c.env.state()[name]["pos"])
    return float(np.linalg.norm(measured-goal))


def _over_post(c, name, position):
    height = getattr(c.env.cfg, f"{name}_height")
    goal_z = getattr(c.env.cfg, f"{name}_goal")[2]
    return (np.linalg.norm(np.asarray(position[:2])-c.env.cfg.base_center) < .008
            and goal_z-.005 < position[2] < c.env.cfg.post_top+height/2+.01)


def insert_held_part(c, name, side, release, *, hole_clear_for_post=True):
    """Candidate insertion of a physically held ring, with measured checks.

    ``release(c, side)`` must open its grasp while keeping the hand outside the
    post. This routine is a controller candidate until its entire physical
    insertion has passed; it never advances the evaluator itself.
    """
    if name not in ("sleeve", "cap"):
        raise ValueError("expected sleeve or cap")
    cfg = c.env.cfg
    state = c.env.state()[name]
    height = getattr(cfg, f"{name}_height")
    if state["robot_contact_force_n"] <= .1:
        raise RuntimeError(f"{name}: no measured grasp contact")
    if state["pos"][2] < cfg.table_height+height/2+.02:
        raise RuntimeError(f"{name}: grasp has not lifted the part")
    c.ik.set_limit(f"{side}_elbow_joint", .2, 1.95)
    c.ik.set_limit(f"{side}_wrist_pitch_joint", -1.50, 1.50)
    c.ik.set_limit(f"{side}_wrist_yaw_joint", -1.45, 1.45)
    c.event(f"{name}_clear_post")
    p = np.asarray(state["pos"])
    clearance = cfg.post_top+height/2+.012
    lift_seconds = 1. if abs(p[2]-clearance) < .04 else 4.
    error = transfer_held_part(c, name, side, [p[0], p[1], clearance], lift_seconds)
    if error > .025:
        raise RuntimeError(f"{name}: failed clearance lift, position error {error:.4f}")
    c.event(f"{name}_align_above_post")
    above = np.array([*cfg.base_center, clearance])
    error = transfer_held_part(c, name, side, above, 3.)
    if error > .006:
        raise RuntimeError(f"{name}: insertion alignment error {error:.4f}")
    c.event(f"{name}_engage_post")
    # A short initial engagement guides the subsequent gravity seating.
    # Deeper forced descent tilted the sleeve within its friction grasp.
    release_height = (cfg.post_top+height/2-.008 if hole_clear_for_post
                      else cfg.post_top+height/2+.006)
    release_point = np.array([*cfg.base_center, release_height])
    error = transfer_held_part(c, name, side, release_point, 4., position_step=.004,
                               allow_post_release=True)
    if error > .007 and not _over_post(c, name, c.env.state()[name]["pos"]):
        raise RuntimeError(f"{name}: post engagement error {error:.4f}")
    c.event(f"{name}_release")
    release(c, side)
    palm, rotation = _pose(c, side)
    _move(c, {side: (palm+[0., 0., .12], rotation)}, 2.)
    c.event(f"{name}_verify_seated")
    c.hold(.8 if name == "sleeve" else 2.2)
    expected = 2 if name == "sleeve" else 3
    result = dict(status=dict(c.env.status), objects=c.env.state())
    if c.env.status.get("stage", 0) < expected:
        raise RuntimeError(f"{name}: evaluator did not confirm seated/released")
    return result
