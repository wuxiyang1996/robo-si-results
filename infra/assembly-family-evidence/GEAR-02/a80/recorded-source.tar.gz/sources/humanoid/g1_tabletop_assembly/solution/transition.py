"""Joint-controlled transitions between the tool and part manipulation postures."""
import math

import numpy as np
from scipy.spatial.transform import Rotation


def positive_elbow_ready(c, time_scale=.5):
    """Lift and retract before changing elbow branch (5.76 s by default).

    ``time_scale=1`` preserves the original 11.5 s motion. The IK reference
    rate scales with the duration so shorter moves can follow the same route.
    """
    if not math.isfinite(time_scale) or time_scale <= 0:
        raise ValueError("time_scale must be finite and positive")
    rate = .7 / time_scale
    c.event("parts_transition_lift")
    tasks = {}
    for side in ("left", "right"):
        position, rotation = c.hand_pose(side)
        position[2] = max(position[2], 1.12)
        tasks[side] = ("palm", position, rotation)
    c.move_hands(tasks, seconds=3.*time_scale, rate=rate)
    c.event("parts_transition_retract")
    c.move_hands({
        side: ("palm", (.15, sign*.35, 1.16), None)
        for side, sign in (("left", 1.), ("right", -1.))
    }, seconds=4.*time_scale, rate=rate)
    c.event("parts_transition_positive_elbows")
    target = c.env.default_q.cpu().numpy().astype(float)
    for side, sign in (("left", 1.), ("right", -1.)):
        target[c.index[f"{side}_shoulder_roll_joint"]] = sign*1.15
        target[c.index[f"{side}_shoulder_pitch_joint"]] = -.8
        target[c.index[f"{side}_elbow_joint"]] = 1.3
    c.move_joints(target, seconds=4.*time_scale)
    c.hold(.5*time_scale)
    for side in ("left", "right"):
        c.ik.set_limit(f"{side}_elbow_joint", .2,
                       c.hi[c.index[f"{side}_elbow_joint"]])
    c.event("parts_transition_complete",
            palms={side: c.hand_pose(side)[0].tolist() for side in ("left", "right")})


def probe_transition(c):
    """Exercise a representative elevated tool posture from a default reset."""
    from .tool import safe_ready
    safe_ready(c)
    c.event("transition_probe_tool_posture")
    c.move_hands({
        "left": ("palm", (.586, .232, 1.05),
                 Rotation.from_euler("x", np.pi/2).as_matrix()),
        "right": ("palm", (.30, -.035, 1.04),
                  Rotation.from_euler("x", -np.pi/2).as_matrix()),
    }, seconds=5., rate=.7)
    positive_elbow_ready(c)
