"""Staged assembly controller; transitions are confirmed by physical scoring."""
from . import cap, sleeve
from .parts import insert_held_part
from .transition import positive_elbow_ready


def parts_after_support(c):
    """Continue a real, released tool placement with sleeve and cap assembly."""
    status = c.env.status
    if status["stage"] != 1 or not status["conditions"]["brace_supported"]:
        raise RuntimeError("part assembly requires a physically supported, released fixture")
    positive_elbow_ready(c)
    grasp = sleeve.grasp(c, lift_height=.25, hold_seconds=1.)
    if not grasp["grasp_verified"]:
        raise RuntimeError(f"sleeve: physical grasp was not verified: {grasp}")
    insert_held_part(c, "sleeve", "left", sleeve.release)
    result = cap.run_cap(c)
    if not c.env.status["success"]:
        raise RuntimeError("assembly evaluator did not confirm released success")
    return result
