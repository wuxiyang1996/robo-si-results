"""Physical brace placement candidates.

This module only commands the task's joint-target action interface.  The
development runner records candidate failures as well as successful stages.
"""
from __future__ import annotations

import numpy as np
from scipy.spatial.transform import Rotation

from humanoid.g1_box_stair_transport.robot import JOINT_NAMES, JOINT_LIMITS
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from .controller import Controller


def hand_preset(q, side, mode="press"):
    q = np.asarray(q).copy()
    sign = -1.0 if side == "left" else 1.0
    flex, distal, t1, t2 = {
        "press": (0., 0., -1.047, 1.),
        "squeeze": (.6, 0., -1.047, 1.),
        "open": (0., 0., 0., 0.),
    }[mode]
    for finger in ("index", "middle"):
        q[JOINT_NAMES.index(f"{side}_hand_{finger}_0_joint")] = sign * flex
        q[JOINT_NAMES.index(f"{side}_hand_{finger}_1_joint")] = sign * distal
    q[JOINT_NAMES.index(f"{side}_hand_thumb_0_joint")] = 0.
    q[JOINT_NAMES.index(f"{side}_hand_thumb_1_joint")] = sign * t1
    q[JOINT_NAMES.index(f"{side}_hand_thumb_2_joint")] = -sign * t2
    return np.clip(q, np.asarray(JOINT_LIMITS)[:, 0], np.asarray(JOINT_LIMITS)[:, 1])


class ToolProbeController(Controller):
    """Standalone development controller, interchangeable with the final driver."""

    def __init__(self, env, output=None, frame_every=0):
        self.rows, self.targets = [], []
        self.output = output
        self.frame_every = frame_every
        self.count = 0
        self.phase = "initial"
        self.hands = {"left": "press", "right": "press"}
        super().__init__(env, on_step=self.record_step)

    def palms(self, measured=True):
        q = self.actual_q() if measured else self.q
        self.ik._set(self.env.base_position, (1., 0., 0., 0.), q)
        return {side: self.ik.hand_point(side, "palm").copy() for side in ("left", "right")}

    def record_step(self, target, obs, reward, info, phase):
        self.targets.append(target)
        self.count += 1
        row = dict(time=obs["time"], phase=self.phase, status=info,
                   objects=obs["objects"], joint_position=obs["joint_position"],
                   palms={k: v.tolist() for k, v in self.palms().items()})
        if self.phase == "long_thumb_push_feedback":
            row["brace_robot_contacts"] = self.contacts("brace")
        self.rows.append(row)
        if self.output and self.frame_every and self.count % self.frame_every == 0:
            from PIL import Image
            Image.fromarray(self.env.render()).save(self.output / f"frame_{self.count:05d}.png")

    def move(self, tasks, seconds=3., phase="reach", rate=1., interpolate=True):
        self.phase = phase
        self.move_hands(tasks, seconds=seconds, rate=rate)
        return True

    def hold(self, seconds=.5, tasks=None):
        super().hold(seconds, tasks=tasks)
        return True


def safe_ready(controller):
    controller.event("lift_hands_before_table")
    tasks = {
        side: ("palm", (.03, .26 if side == "left" else -.26, 1.06), np.eye(3))
        for side in ("left", "right")
    }
    controller.move_hands(tasks, seconds=4., rate=.8, settle=.4)
    controller.hand_preset("left", "press", seconds=.4)
    controller.hand_preset("right", "press", seconds=.4)


def _move(controller, tasks, seconds, phase):
    controller.event(phase)
    controller.move_hands(tasks, seconds=seconds, rate=1.)
    return True


def preposition_brace(controller, *, mode="diagonal"):
    """Physical sliding attempts that keep the tool outside the fixture."""
    controller.hand_preset("left", "squeeze", seconds=.3)
    if mode in ("top", "top_force"):
        rot = Rotation.from_euler("x", np.pi / 2).as_matrix()
        z = .848 if mode == "top" else .818
        waypoints = (
            ((.365, .40, 1.04), 4., "brace_top_approach"),
            ((.365, .40, z), 4., "brace_top_contact"),
            ((.525, .22, z), 6., "brace_top_slide"),
            ((.525, .22, 1.04), 3., "brace_top_release"),
        )
    elif mode == "corner":
        rot = Rotation.from_euler("z", np.pi / 4).as_matrix()
        waypoints = (
            ((.31, .49, 1.04), 4., "brace_corner_approach"),
            ((.31, .49, .780), 4., "brace_corner_lower"),
            ((.47, .31, .780), 7., "brace_corner_push"),
            ((.47, .31, 1.04), 3., "brace_corner_release"),
        )
    else:
        rot = Rotation.from_euler("z", np.pi / 4).as_matrix()
        waypoints = (
            ((.29, .428, 1.04), 4., "brace_diag_approach"),
            ((.29, .428, .780), 4., "brace_diag_lower"),
            ((.48, .29, .780), 7., "brace_diag_push"),
            ((.48, .29, 1.04), 3., "brace_diag_release"),
        )
    for pos, seconds, phase in waypoints:
        _move(controller, {"left": ("palm", pos, rot)}, seconds, phase)
    controller.hold(.5)
    return True


def pinch_preposition_brace(controller, variant=1):
    """Try a real thumb/finger pinch across the tool's narrow dimension."""
    rot = Rotation.from_euler("x", np.pi / 2).as_matrix()
    q = controller.q.copy()
    for finger in ("index", "middle"):
        q[controller.index[f"left_hand_{finger}_0_joint"]] = 0. if variant == 1 else -1.15
        q[controller.index[f"left_hand_{finger}_1_joint"]] = 0.
    q[controller.index["left_hand_thumb_0_joint"]] = 0.
    q[controller.index["left_hand_thumb_1_joint"]] = -.70
    q[controller.index["left_hand_thumb_2_joint"]] = 0.
    controller.move_joints(q, seconds=.5)
    _move(controller, {"left": ("palm", (.431, .40, 1.05), rot)}, 4., "pinch_hover")
    low = .870 if variant == 1 else (.845 if variant == 4 else .855)
    _move(controller, {"left": ("palm", (.431, .40, low), rot)}, 4., "pinch_lower")
    q = controller.q.copy()
    for finger in ("index", "middle"):
        q[controller.index[f"left_hand_{finger}_0_joint"]] = -1.57 if variant in (1, 4) else -1.4
        q[controller.index[f"left_hand_{finger}_1_joint"]] = 0. if variant == 1 else (-.7 if variant == 4 else -.5)
    q[controller.index["left_hand_thumb_1_joint"]] = .1 if variant == 4 else -.10
    q[controller.index["left_hand_thumb_2_joint"]] = 0. if variant == 1 else (.7 if variant == 4 else .5)
    controller.event("pinch_close")
    controller.move_joints(q, seconds=2.)
    lift = .93 if variant < 3 else (.96 if variant == 4 else .99)
    goalx, goaly = (.591, .22) if variant < 3 else (.586, .232)
    if variant == 5:
        goalx = .550
    _move(controller, {"left": ("palm", (.431, .40, lift), rot)}, 4., "pinch_lift")
    _move(controller, {"left": ("palm", (goalx, goaly, lift), rot)}, 6., "pinch_transfer")
    _move(controller, {"left": ("palm", (goalx, goaly, .870), rot)}, 4., "pinch_lower_goal")
    q = controller.q.copy()
    for finger in ("index", "middle"):
        q[controller.index[f"left_hand_{finger}_0_joint"]] = 0.
    q[controller.index["left_hand_thumb_1_joint"]] = -.70
    controller.event("pinch_open")
    controller.move_joints(q, seconds=2.)
    _move(controller, {"left": ("palm", (goalx, goaly, 1.05), rot)}, 3., "pinch_clear")
    controller.hold(.5)


def press_fixture(controller, *, height=.865, x=.30, y=-.035, keep_left=False):
    """Right palm down on the near side supplies the hinge lifting moment."""
    rot = Rotation.from_euler("x", -np.pi / 2).as_matrix()
    # Flat finger contact is about 4 cm below the palm center.
    for pos, seconds, phase in (
        ((x, y, 1.04), 4., "fixture_approach"),
        ((x, y, .96), 2., "fixture_hover"),
        ((x, y, height), 4., "fixture_press"),
    ):
        tasks = {"right": ("palm", pos, rot)}
        if keep_left:
            tasks["left"] = ("palm", (.525, .365, 1.04), np.eye(3))
        if not _move(controller, tasks, seconds, phase):
            return False
    return True


def insert_brace(controller):
    """Keep the fixture lifted while the left fingers slide the brace inside."""
    # Restore the collision-free arm branch that was independently validated
    # for pressing. These are joint targets, never simulator state writes.
    _move(controller, {
        "left": ("palm", (.06, .27, 1.03), None),
        "right": ("palm", (.06, -.27, 1.03), None),
    }, 3., "press_retract_before_rebranch")
    ready = np.asarray([
        -.10, 0., 0., .30, -.20, 0., -.10, 0., 0., .30, -.20, 0.,
        0., 0., -.4987725, .5844294, .4259725, .3010576, -.3043091,
        -.0473653, -.7010527, .1189222, 0., 1.0393806, 1.0428044,
        -.0007776, -.0001165, -.0016268, -.0003442,
        .5843495, -.4259823, -.3010773, -.3043895, .0473741,
        -.701085, -.1189297, 0., -1.0440409, -1.0599315,
        .0007767, .0001155, .0016003, .0003467,
    ])
    controller.event("press_restore_safe_branch")
    controller.move_joints(np.clip(ready, controller.lo, controller.hi), seconds=3.)
    controller.hand_preset("left", "squeeze", seconds=.5)
    press_fixture(controller, keep_left=False)
    fixture_quat = controller.object_state("fixture")["quat"]
    fixture_pitch = 2 * np.arcsin(np.clip(fixture_quat[2], -1., 1.))
    if fixture_pitch > -.005:
        raise RuntimeError(f"fixture press did not open brace clearance: pitch={fixture_pitch:.4f}")
    # Leave room for the real PD controller's gravity offset. Using the
    # kinematic upper limit directly clips its position command and raises
    # the loaded hand by several centimetres.
    controller.ik.set_limit("waist_pitch_joint", -.4, .32)
    right = ("palm", (.30, -.035, .865), Rotation.from_euler("x", -np.pi / 2).as_matrix())
    push_yaw = .17
    push_rot = Rotation.from_euler("z", push_yaw).as_matrix()
    brace = controller.object_state("brace")["pos"]
    # The narrow brace is pushed by the two fingertips. The thumb lies
    # behind its x face; including it in a broad-box contact centroid would
    # put the fingers outside the brace and twist the block.
    contact_offset = push_rot @ np.array([.102, -.055, 0.])
    px, py = float(brace[0])-contact_offset[0], float(brace[1])+.098-contact_offset[1]
    for pos, seconds, phase in (
        ((px, py, 1.03), 3., "brace_y_hover"),
        ((px, py, .783), 4., "brace_y_lower"),
    ):
        _move(controller, {"left": ("palm", pos, push_rot), "right": right}, seconds, phase)
    controller.event("brace_y_push_feedback")
    start_contact_y = float(brace[1])+.098
    filtered_yaw = 0.
    for i in range(300):
        current = controller.object_state("brace")
        yaw = 2*np.arcsin(np.clip(current["quat"][3], -1., 1.))
        filtered_yaw = .8*filtered_yaw + .2*yaw
        desired_push_yaw = np.clip(.17+4*(.59-current["pos"][0]), -.25, .5)
        push_yaw = .8*push_yaw+.2*desired_push_yaw
        push_rot = Rotation.from_euler("z", push_yaw).as_matrix()
        contact_offset = push_rot @ np.array([.102, -.055, 0.])
        desired_x = current["pos"][0]-contact_offset[0]+.15*filtered_yaw
        px += np.clip(desired_x-px, -.0015, .0015)
        a = (i+1)/300
        a = a*a*(3-2*a)
        contact_y = start_contact_y+a*(.160-start_contact_y)
        pos = (px, contact_y-contact_offset[1], .783)
        controller.reach({"left": ("palm", pos, push_rot), "right": right},
                         rate=1., feedback=.25)
        controller.step()
    for pos, seconds, phase in (
        ((px, .23, .783), 2., "brace_y_retreat"),
        ((px, .26, 1.04), 3., "brace_y_clear"),
    ):
        _move(controller, {"left": ("palm", pos, push_rot), "right": right}, seconds, phase)
    _move(controller, {
        "right": ("palm", (.30, -.035, 1.04), right[2]),
        "left": ("palm", (px, .26, 1.04), push_rot),
    }, 3., "fixture_release")
    controller.hold(1.)
    if controller.env.status.get("stage", 0) < 1:
        finish_brace_with_thumb(controller)
    return controller.env.status.get("stage", 0) >= 1


def finish_brace_with_thumb(controller):
    """The straight thumb fits the remaining gap under the platform edge."""
    brace = controller.object_state("brace")
    yaw = 2 * np.arcsin(np.clip(brace["quat"][3], -1., 1.))
    if abs(yaw) > .12 or abs(brace["pos"][0] - .59) > .022:
        raise RuntimeError(f"coarse brace slide is misaligned: {brace['pos']}, yaw={yaw:.3f}")
    controller.ik.set_limit("waist_pitch_joint", -.3, .35)
    controller.ik.set_limit("waist_yaw_joint", -1.5, .8)
    # Both hands leave the work surface before the thin pusher is shaped.
    _move(controller, {
        "left": ("palm", (.06, .27, 1.03), None),
        "right": ("palm", (.06, -.27, 1.03), None),
    }, 3., "thumb_finish_clear")
    controller.hand_preset("left", "open", seconds=.5)
    down = Rotation.from_euler("x", 60., degrees=True).as_matrix()
    rotation = down
    bx, by, _ = controller.object_state("brace")["pos"]
    for point, seconds, phase in (
        ((bx, by+.12, .95), 3., "thumb_finish_hover"),
        ((bx, by+.12, .772), 3., "thumb_finish_lower"),
    ):
        _move(controller, {"left": ("thumb", point, rotation)}, seconds, phase)
    controller.ik.set_limit("waist_pitch_joint", .10, .35)
    rotation = Rotation.from_euler("z", -.19).as_matrix() @ down
    _move(controller, {"left": ("thumb", (bx+.006, .096, .772), rotation)},
          4., "thumb_finish_push")
    for point, seconds, phase in (
        ((bx, .20, .772), 2., "thumb_finish_retreat"),
        ((bx, .23, 1.04), 2., "thumb_finish_release"),
    ):
        _move(controller, {"left": ("thumb", point, rotation)}, seconds, phase)
    controller.hold(1.)


def run_tool(controller):
    """Stage-zero candidate; only the standard Controller action API is used."""
    safe_ready(controller)
    pinch_preposition_brace(controller, variant=5)
    if not insert_brace(controller):
        raise RuntimeError(f"brace placement candidate did not pass stage zero: {controller.env.status}")
    return True


def insert_brace_with_long_thumb(controller):
    """A high wrist and extended thumb keep the pusher clear of the parts."""
    controller.ik.set_limit("waist_pitch_joint", -.4, .35)
    controller.ik.set_limit("right_shoulder_roll_joint", -1.55, 0.)
    controller.hand_preset("left", "open", seconds=.5)
    q = controller.q.copy()
    q[controller.index["left_hand_thumb_1_joint"]] = .8
    controller.move_joints(q, seconds=.5)
    bx, by, _ = controller.object_state("brace")["pos"]
    rotation = Rotation.from_euler("x", 90., degrees=True).as_matrix()
    right_rotation = Rotation.from_euler("x", -90., degrees=True).as_matrix()
    right = ("palm", (.30, -.035, .865), right_rotation)
    for point, seconds, phase in (
        ((bx+.025, by+.11, .95), 3., "long_thumb_hover"),
        ((bx+.025, by+.11, .755), 4., "long_thumb_lower"),
    ):
        _move(controller, {"left": ("thumb", point, rotation), "right": right},
              seconds, phase)
    start, _ = controller.hand_pose("left", "thumb")
    controller.event("long_thumb_push_feedback")
    contact_offset = .025
    heading = 0.
    for i in range(350):
        brace = controller.object_state("brace")
        yaw = 2*np.arcsin(np.clip(brace["quat"][3], -1., 1.))
        a = (i+1)/350
        a = a**3*(10-15*a+6*a*a)
        rotation = (Rotation.from_euler("z", heading).as_matrix()
                    @ Rotation.from_euler(
                        "x", 90.-15.*np.clip((a-.4)/.6, 0., 1.), degrees=True).as_matrix())
        contacts = [row for row in controller.contacts("brace")
                    if row["link"].startswith("left_") and row["force"][1] > .1]
        if contacts:
            weights = np.array([row["force"][1] for row in contacts])
            center_x = np.average([row["position"][0] for row in contacts], weights=weights)
            thumb, _ = controller.hand_pose("left", "thumb")
            measured_offset = np.clip(thumb[0]-center_x, -.01, .06)
            contact_offset = .9*contact_offset+.1*measured_offset
        goal = np.array((.59+contact_offset+.10*yaw, .096, .755))
        point = start+a*(goal-start)
        point[0] = goal[0]
        controller.reach({"left": ("thumb", point, rotation), "right": right},
                         rate=1., feedback=.25)
        controller.step()
    _move(controller, {
        "left": ("thumb", (bx+.025, .22, .94), rotation), "right": right},
        3., "long_thumb_clear")
    _move(controller, {
        "left": ("thumb", (bx, .22, 1.04), rotation),
        "right": ("palm", (.30, -.035, 1.04), right_rotation),
    }, 3., "long_thumb_release_fixture")
    controller.hold(1.)
    return controller.env.status.get("stage", 0) >= 1


def push_brace(controller, *, press_height=.83):
    """Two-direction sliding candidate, with a separate hand lifting the plate."""
    rot_pushx = Rotation.from_euler("z", np.pi / 2).as_matrix()
    rot_down = Rotation.from_euler("x", -np.pi / 2).as_matrix()
    for pos, seconds, phase in (
        ((.31, .335, 1.05), 4., "brace_approach_x"),
        ((.31, .335, .783), 4., "brace_lower_x"),
        ((.51, .335, .783), 6., "brace_push_x"),
        ((.51, .335, 1.03), 3., "brace_clear_x"),
    ):
        if not controller.move({"left": ("palm", pos, rot_pushx)}, seconds, phase):
            return False
    if not press_fixture(controller, height=press_height):
        return False
    fixed = ("palm", (.30, -.035, press_height), rot_down)
    for pos, seconds, phase in (
        ((.525, .565, 1.03), 4., "brace_approach_y"),
        ((.525, .565, .783), 4., "brace_lower_y"),
        ((.525, .135, .783), 10., "brace_push_y"),
        ((.525, .23, .90), 3., "brace_release"),
    ):
        tasks = {"left": ("palm", pos, np.eye(3)), "right": fixed}
        if not controller.move(tasks, seconds, phase):
            return False
    if not controller.move({"right": ("palm", (.30, -.035, 1.02), rot_down)},
                           3., "fixture_release"):
        return False
    return controller.hold(1.)
