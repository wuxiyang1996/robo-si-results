"""Setup-only scene alterations, recorded independently from unchanged goal CAD.

All additions are real rigid bodies created BEFORE scene.build. No action can
create bodies, teleport parts, change friction or attach constraints.
"""
from contextlib import contextmanager
import numpy as np

def extras(task,table=.74):
    if task=='GEAR-03':
        return [dict(name='thin_tool',size=(.19,.012,.012),pos=(.30,.51,table+.006),mass=.10,color=(.18,.55,.75)),
                dict(name='wide_tool',size=(.21,.052,.025),pos=(.62,-.51,table+.0125),mass=.22,color=(.70,.28,.18))]
    if task=='REF-02':
        return [dict(name='temporary_fixture',size=(.07,.055,.025),pos=(.30,.30,table+.0125),mass=.45,color=(.20,.65,.30))]
    if task=='REF-03':
        return [dict(name='access_wall',size=(.035,.35,.30),pos=(.73,0,table+.15),mass=4.,fixed=True,color=(.31,.37,.44)),
                dict(name='temporary_fixture',size=(.07,.055,.025),pos=(.30,.30,table+.0125),mass=.45,color=(.20,.65,.30))]
    return []

@contextmanager
def augment(mod,task,catalog,cfg):
    import genesis as gs
    original_build=gs.Scene.build;original_layout=mod.supply_layout;created={};descriptors=extras(task,cfg.table_height)
    def build(scene,*a,**kw):
        for spec in descriptors:
            created[spec['name']]=scene.add_entity(gs.morphs.Box(size=spec['size'],pos=spec['pos'],fixed=spec.get('fixed',False)),
                    material=gs.materials.Rigid(rho=spec['mass']/np.prod(spec['size']),friction=.7),
                    surface=gs.surfaces.Default(color=spec['color']))
        return original_build(scene,*a,**kw)
    def layout(data,seed,table):
        poses,racks=original_layout(data,seed,table)
        if task=='GEAR-02':
            for name in ('base','large_gear','medium_gear','small_gear'):
                part=data['parts'][name];p=np.asarray(cfg.origin)+part['goal_local']
                if name=='medium_gear':p=p+[0,0,.035]
                poses[name]={'pos':tuple(p),'quat':(0.,1.,0.,0.) if name=='medium_gear' else tuple(part.get('goal_quat_wxyz',(1,0,0,0)))}
        return poses,racks
    gs.Scene.build=build;mod.supply_layout=layout
    try:yield created,descriptors
    finally:gs.Scene.build=original_build;mod.supply_layout=original_layout

def register(env,created):
    env.objects.update(created)
    env.link_owners.update({link.idx:name for name,ent in created.items() for link in ent.links})
