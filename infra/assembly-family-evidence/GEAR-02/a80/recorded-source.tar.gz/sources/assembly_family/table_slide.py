"""Use table support for handoff, then carry around the fixed fixture."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import smooth

def shim(c,fit,goal=(.275,-.27),side='right',goal_yaw=np.pi/2,support='table',front_first=False,name='shim',entry_turn=np.pi/2,intermediate_xy=None):
    if name=='shim':
        c.ik.set_limit('waist_pitch_joint',-.40,.44)
        c.ik.set_limit('waist_roll_joint',-.44,.44)
    start_state=c.object_state(name)
    start_yaw=Rotation.from_quat(np.asarray(start_state['quat'])[[1,2,3,0]]).as_euler('xyz')[2]
    sign=-1. if side=='right' else 1.
    mirror=np.diag([1.,-1.,1.]) if side=='right' else np.eye(3)
    turn=Rotation.from_euler('z',start_yaw+entry_turn).as_matrix()
    rot=turn@mirror@np.asarray(fit['rotation'])@mirror
    offset=turn@mirror@np.asarray(fit['palm_offset']);offset[2]-=.004 if side=='left' else .002
    shape={j:v if j=='thumb_0' else sign*v for j,v in fit['hand_joints'].items()}
    pairs=[('thumb',1,2),('index',0,1),('middle',0,1)]
    sums={f:shape[f'{f}_{a}']+shape[f'{f}_{b}'] for f,a,b in pairs}
    def target(amount):
        q=c.q.copy()
        for j,v in shape.items():q[c.index[side+'_hand_'+j+'_joint']]=v
        for f,a,b in pairs:
            ia=c.index[f'{side}_hand_{f}_{a}_joint'];ib=c.index[f'{side}_hand_{f}_{b}_joint']
            shift=sign*amount*(1. if f=='thumb' else -.7);q[ia]+=shift;q[ib]-=shift
        return np.clip(q,c.lo+.04,c.hi-.04)
    p=np.asarray(c.object_state(name)['pos']);palm=p+offset
    c.event(name+'_table_pinch_preshape');c.move_joints(target(-.12),seconds=1.)
    if side=='left':
        from .reach_screen import approach_from_contact
        c.ik.set_limit('waist_yaw_joint',-1.5,.8)
        c.ik.set_limit('left_elbow_joint',.2,1.8)
        approach_from_contact(c,side,palm,rot)
    else:c.move_hands({side:('palm',palm+[0,0,.12],rot)},seconds=2.5)
    c.move_hands({side:('palm',palm,rot)},seconds=2.,feedback=.5)
    def feedback(current):
        measured=current.actual_q()
        for f,a,b in pairs:
            ia=c.index[f'{side}_hand_{f}_{a}_joint'];ib=c.index[f'{side}_hand_{f}_{b}_joint']
            error=sums[f]-measured[ia]-measured[ib]
            current.q[ib]=np.clip(sums[f]-measured[ia]+.3*error,current.lo[ib]+.04,current.hi[ib]-.04)
    key=name+'_table_slide_fingers';c.joint_feedback[key]=feedback
    try:
        c.event(name+'_table_pinch_close');c.move_joints(target(.40),seconds=1.5)
        state=c.object_state(name);p=np.asarray(state['pos']);hp,hR=c.hand_pose(side);local=hp-p;correction=np.zeros(3)
        start_yaw=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_euler('xyz')[2]
        destination=np.r_[goal,p[2]] if len(goal)==2 else np.asarray(goal)
        route=[(destination,goal_yaw,6.)]
        if intermediate_xy is not None:
            route=[(np.r_[intermediate_xy,p[2]],goal_yaw,6.),(destination,goal_yaw,8.)]
        if front_first:
            route=[(np.array([destination[0],p[1],p[2]]),start_yaw,4.),
                   (destination,goal_yaw,4.)]
        if side=='left':
            if name=='shim':goal_yaw=np.pi
            c.event(name+'_lift_before_planned_carry')
            lift=.09 if name=='brace' else .04
            c.move_hands({side:('palm',hp+[0,0,lift],hR)},seconds=2.5 if name=='brace' else 1.5,feedback=.5)
            state=c.object_state(name);actual=np.asarray(state['pos'])
            if not state['hand_contact'] or actual[2]<p[2]+.025:raise RuntimeError(name+': planned carry requires a measured lift')
            # Curl the distal pads only after table clearance, so the rim
            # rests below the pads instead of peeling out during yaw motion.
            for f in sums:sums[f]+=sign*(.03 if f=='thumb' else -.06)
            c.event(name+'_airborne_grip_reinforcement');c.move_joints(target(.40),seconds=.8)
            state=c.object_state(name);actual=np.asarray(state['pos'])
            R=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix();hp,hR=c.hand_pose(side)
            goal_R=Rotation.from_euler('z',goal_yaw).as_matrix();target_p=destination+[0,0,.04]+goal_R@R.T@(hp-actual);target_R=goal_R@R.T@hR
            candidates=[]
            for sy in (1.5,0.,-1.5):
                seed=c.actual_q();seed[c.index['waist_yaw_joint']]=0.;seed[c.index[side+'_shoulder_yaw_joint']]=sy;seed[c.index[side+'_elbow_joint']]=1.2
                solved,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,{side:('palm',target_p,target_R)},iters=600,damping=.02,w_rot=.5,max_step=.08)
                angle=np.linalg.norm(Rotation.from_matrix(target_R@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec())
                if errors[side]<.004 and angle<.04:
                    command=c.q.copy();command[c.ik.upper]=solved[c.ik.upper];candidates.append(command);break
            if not candidates:raise RuntimeError(name+': no reachable destination for supported handoff carry')
            from .approach_path import move
            try:move(c,candidates[0],side,carried=name)
            except RuntimeError:
                landed=c.object_state(name)
                R_landed=Rotation.from_quat(np.asarray(landed['quat'])[[1,2,3,0]]).as_matrix()
                valid=(name=='brace' and not landed['robot_contact']
                       and np.linalg.norm(np.asarray(landed['pos'])-destination)<.015
                       and R_landed[2,2]>.95 and landed['support_forces'].get('table',0)>.05)
                if not valid:raise
                c.event('brace_measured_staging_setdown',position=landed['pos'])
                c.move_joints(target(-.16),seconds=1.2)
                hp,hR=c.hand_pose(side)
                c.move_hands({side:('palm',hp+[0,0,.12],hR)},seconds=1.5);c.hold(.6)
                landed=c.object_state(name)
                if landed['robot_contact'] or np.linalg.norm(np.asarray(landed['pos'])-destination)>.015 or landed['support_forces'].get('table',0)<.05 or np.linalg.norm(landed['linear_velocity'])>.03:
                    raise RuntimeError('brace: early staging setdown did not remain released and stable')
                return
            state=c.object_state(name);p=np.asarray(state['pos']);hp,hR=c.hand_pose(side);local=hp-p;correction[:]=0.
            start_yaw=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_euler('xyz')[2]
            goal_yaw=start_yaw+np.arctan2(np.sin(goal_yaw-start_yaw),np.cos(goal_yaw-start_yaw))
            route=[(destination,goal_yaw,3.)]
        previous=p.copy();previous_yaw=start_yaw
        for endpoint,end_yaw,seconds in route:
            c.event(name+('_supported_pinch_slide' if side=='right' else '_front_clearance_carry'),goal=endpoint.tolist(),side=side,goal_yaw=end_yaw)
            count=round(seconds/.02)
            for i in range(count):
                state=c.object_state(name);actual=np.asarray(state['pos'])
                if not state['hand_contact'] or actual[0]<( .205 if side=='right' else .12):raise RuntimeError(name+': pinch lost safe contact')
                amount=smooth((i+1)/count)
                desired=previous+amount*(endpoint-previous)
                correction=np.clip(correction+np.clip(.08*(desired-actual),-.0005,.0005),-.025,.025)
                if side=='right':correction[2]=0.
                yaw=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_euler('xyz')[2]
                desired_yaw=previous_yaw+amount*(end_yaw-previous_yaw)
                turn=Rotation.from_euler('z',desired_yaw-start_yaw+np.clip(desired_yaw-yaw,-.15,.15)).as_matrix()
                desired_R=turn@hR
                if intermediate_xy is not None:
                    measured_R=c.hand_pose(side)[1]
                    error_R=Rotation.from_matrix(desired_R@measured_R.T).as_rotvec()
                    desired_R=Rotation.from_rotvec(.35*error_R).as_matrix()@desired_R
                c.reach({side:('palm',desired+turn@local+correction,desired_R)},feedback=.5);c.step()
            previous=endpoint;previous_yaw=end_yaw
        c.event(name+'_table_pinch_release');c.move_joints(target(-.16),seconds=1.2)
    finally:c.joint_feedback.pop(key,None)
    hp,hR=c.hand_pose(side)
    c.move_hands({side:('palm',hp+[0,0,.12],hR)},seconds=1.5);c.hold(.3)
    state=c.object_state(name)
    if intermediate_xy is not None:
        # A cross-body pinch may stop short of its nominal xy. A released,
        # level pose on the receiving side is sufficient for the next hand
        # to finish the edge alignment from its own measured workspace.
        position=np.asarray(state['pos']);rotation=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
        if not (.205<position[0]<.38 and .18<position[1]<.42 and rotation[2,2]>.95
                and state['support_forces'].get('table',0)>.05 and not state['robot_contact']):
            raise RuntimeError(name+': cross-table handoff did not establish released receiving-side support')
        c.event(name+'_left_side_released_handoff',position=position.tolist(),nominal_goal=np.asarray(goal).tolist())
        return
    if np.linalg.norm(np.asarray(state['pos'])[:2]-np.asarray(goal)[:2])>.015 or state['support_forces'].get(support,0)<.05 or state['robot_contact']:
        raise RuntimeError(name+': table slide did not finish at a released supported pose')
