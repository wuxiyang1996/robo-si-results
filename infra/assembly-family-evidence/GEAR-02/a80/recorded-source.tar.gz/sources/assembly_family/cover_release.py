"""Leave a seated cover handle before raising the formerly hooked hand."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import pose,smooth


def release(c,grips,**_):
    if len(grips)!=1 or grips[0].side!='left':
        raise RuntimeError('cover: this geometry-checked release requires the left handle grasp')
    starts={g.side:c.hand_pose(g.side)for g in grips}
    start=c.q.copy();goals={}
    for g in grips:
        previous=g.thumb_opening;g.thumb_opening=max(.55,g.opening)
        goals[g.side]=g.curled(-max(.55,g.opening));g.thumb_opening=previous
    c.event('cover_open_hooks_before_withdrawal')
    for i in range(60):
        a=smooth((i+1)/60)
        for g in grips:
            joints=[g.joint(j)for j in g.shape]
            c.q[joints]=start[joints]+a*(goals[g.side][joints]-start[joints])
        c.reach({side:('palm',p,R)for side,(p,R)in starts.items()},feedback=.5,rotation_feedback=.3);c.step()
    # A small upward/backward move opens the thumb's escape corridor. The
    # former downward/forward move drove its distal link into the handle.
    # These relative waypoints were screened against every original cover
    # collision mesh; the executing Genesis trace still decides feasibility.
    starts={g.side:c.hand_pose(g.side)for g in grips};cover_R=pose(c,'cover')[1]
    thumb_start={g.side:c.actual_q()[[g.joint('thumb_'+str(i))for i in range(3)]] for g in grips}
    waypoints=[([.0041115363,-.0095774415,.0119736428],None,1.5),([0.,-.08,.08],[-.8,-.5,.2],3.)]
    previous_shift=np.zeros(3)
    for shift,thumb,seconds in waypoints:
        shift=np.asarray(shift);count=round(seconds/.02);current_thumb={g.side:c.actual_q()[[g.joint('thumb_'+str(i))for i in range(3)]]for g in grips}
        targets={g.side:(thumb_start[g.side]+[-.0365485273,-.1077390238,.0418370302] if thumb is None else np.asarray(thumb))for g in grips}
        c.event('cover_geometry_checked_unhook',relative_translation=shift.tolist(),thumb_targets={s:q.tolist()for s,q in targets.items()})
        for i in range(count):
            a=smooth((i+1)/count);delta=previous_shift+a*(shift-previous_shift)
            for g in grips:
                joints=[g.joint('thumb_'+str(j))for j in range(3)]
                c.q[joints]=current_thumb[g.side]+a*(targets[g.side]-current_thumb[g.side])
            c.reach({side:('palm',p+cover_R@delta,R)for side,(p,R)in starts.items()},feedback=.5,rotation_feedback=.3,iters=20);c.step()
        previous_shift=shift
    c.hold(.5);state=pose(c,'cover')[3]
    c.event('cover_unhook_measured_release',robot_contact_force=state['robot_contact_force'],supports=state['support_forces'])
    if state['robot_contact_force']>.05:
        raise RuntimeError('cover: hooks still contact the cover; refusing to lift it off the posts')
    targets={}
    for side in starts:
        hp,hR=c.hand_pose(side);targets[side]=('palm',hp+[0,0,.10],hR)
    c.move_hands(targets,seconds=1.5,feedback=.5,rotation_feedback=.3)


def place(c,ready=True):
    from humanoid.g1_gear_assembly.solution import stage_cover_rail
    original=stage_cover_rail.hook_release;stage_cover_rail.hook_release=release
    try:return stage_cover_rail.run_cover_handle(c,ready=ready)
    finally:stage_cover_rail.hook_release=original
