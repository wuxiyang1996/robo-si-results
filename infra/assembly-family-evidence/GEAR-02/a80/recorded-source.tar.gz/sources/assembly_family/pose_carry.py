"""Measured pose servo for a held part, including inverted orientations."""
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from humanoid.g1_gear_assembly.solution.skills import pose,smooth


def move(c,grip,goal,rotation,seconds,phase,stop_when=None,integrate=True,hand_feedback=False,preserve_reference=False):
    name,side=grip.name,grip.side
    p0,R0,_,_=pose(c,name);hp,hR=c.hand_pose(side)
    local_p=R0.T@(hp-p0);local_R=R0.T@hR
    bias_p=np.zeros(3);bias_R=np.eye(3)
    if preserve_reference:
        # Keep the outgoing grasp servo's nominal offset at the skill boundary.
        # Dropping its settled compensation can withdraw the hand immediately,
        # before this new part-pose integrator has time to rebuild the load.
        c.ik._set(c.env.base_position,(1,0,0,0),c.q)
        bias_p=c.ik.hand_point(side,'palm').copy()-hp
        bias_R=c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).copy()@hR.T
        c.event(phase+'_preserve_grasp_reference',position_bias=bias_p.tolist(),rotation_bias=Rotation.from_matrix(bias_R).as_rotvec().tolist())
    orientation=Slerp([0.,1.],Rotation.from_matrix(np.stack([R0,rotation])))
    cp=np.zeros(3);cr=np.zeros(3);hand_cp=np.zeros(3);hand_cr=np.zeros(3);weak=0;n=max(1,round(seconds/.02))
    c.event(phase,goal_position=np.asarray(goal).tolist(),goal_rotation=np.asarray(rotation).tolist())
    for i in range(n+30):
        a=smooth(min(1.,(i+1)/n));desired=p0+a*(np.asarray(goal)-p0);Rd=orientation(a).as_matrix()
        actual,R,_,state=pose(c,name)
        if stop_when is not None and stop_when(actual,R,state):
            c.event(phase+'_handoff_ready',position=actual.tolist())
            return
        weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>10:raise RuntimeError(name+': grasp lost during '+phase)
        if integrate:
            cp=np.clip(cp+np.clip(.045*(desired-actual),-.0003,.0003),-.035,.035)
            error=Rotation.from_matrix(Rd@R.T).as_rotvec()
            cr=np.clip(cr+np.clip(.025*error,-.001,.001),-.22,.22)
        Rc=Rotation.from_rotvec(cr).as_matrix()@Rd
        point=desired+cp+Rc@local_p+bias_p;orientation_target=bias_R@Rc@local_R
        if hand_feedback:
            actual_hand,actual_hand_R=c.hand_pose(side)
            hand_cp=np.clip(hand_cp+np.clip(.04*(point-actual_hand),-.0003,.0003),-.025,.025)
            hand_error=Rotation.from_matrix(orientation_target@actual_hand_R.T).as_rotvec()
            hand_cr=np.clip(hand_cr+np.clip(.04*hand_error,-.001,.001),-.10,.10)
            point=point+hand_cp;orientation_target=Rotation.from_rotvec(hand_cr).as_matrix()@orientation_target
        c.reach({side:('palm',point,orientation_target)},feedback=0. if preserve_reference else .4,
                rotation_feedback=0. if preserve_reference else .3,iters=12)
        c.step()
