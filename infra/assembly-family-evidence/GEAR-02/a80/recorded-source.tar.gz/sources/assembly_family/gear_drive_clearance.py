"""Exact authored gear geometry queries in an independent kinematic model."""
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK,XML
from .contact_audit import is_hand


class GearClearance:
    def __init__(self,c):
        self.c=c;root=ET.parse(XML).getroot();root.find('compiler').set('meshdir',str(XML.parent/'assets'))
        world=root.find('worldbody');asset=root.find('asset');self.geoms=[]
        def nums(x):return ' '.join(map(str,x))
        for name,part in c.env.catalog['parts'].items():
            for i,g in enumerate(part['collision_geometry']):
                key='gearquery_'+name+'_'+str(i);attrs=dict(name=key,type=g['kind'],contype='0',conaffinity='0')
                if g['kind']=='mesh':
                    ET.SubElement(asset,'mesh',name=key,file=g['mesh']);attrs['mesh']=key
                elif g['kind']=='box':attrs['size']=nums(np.asarray(g['size'])/2)
                elif g['kind']=='cylinder':attrs['size']=nums([g['radius'],g['length']/2])
                else:raise ValueError(g['kind'])
                ET.SubElement(world,'geom',**attrs)
                self.geoms.append((key,name,np.asarray(g.get('pos',[0,0,0])),Rotation.from_euler('xyz',g.get('rpy',[0,0,0])).as_matrix()))
        self.fixed=[]
        for i,g in enumerate(c.env.catalog['fixture']):
            key='gearquery_fixture_'+str(i)
            ET.SubElement(world,'geom',name=key,type='box',size=nums(np.asarray(g['size'])/2),contype='0',conaffinity='0')
            self.fixed.append((key,'fixture',np.asarray(c.env.cfg.origin)+g['pos_local']))
        cfg=c.env.cfg
        ET.SubElement(world,'geom',name='gearquery_table',type='box',size=nums(np.asarray(cfg.table_size)/2),contype='0',conaffinity='0')
        self.fixed.append(('gearquery_table','table',np.array([*cfg.table_center,cfg.table_height-cfg.table_size[2]/2])))
        self.ik=UpperBodyIK();self.ik.m=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'));self.ik.d=mujoco.MjData(self.ik.m)
        m=self.ik.m;self.ids={key:m.geom(key).id for key,_,_,_ in self.geoms}
        self.tool=[self.ids[k]for k,n,_,_ in self.geoms if n=='turning_tool']
        self.scene=[(self.ids[k],n)for k,n,_,_ in self.geoms if n!='turning_tool']+[(m.geom(k).id,n)for k,n,_ in self.fixed]
        self.robot=[];self.blocked=None
        for g in range(m.ngeom):
            link=m.body(m.geom_bodyid[g]).name
            if not m.geom_contype[g] or not link.startswith(('left_','right_')) or not any(x in link for x in ('shoulder','elbow','wrist','hand')):continue
            mesh=m.mesh(m.geom_dataid[g]).name if m.geom_type[g]==mujoco.mjtGeom.mjGEOM_MESH else ''
            self.robot.append((g,.003 if is_hand(link,mesh)else .012))

    def clear(self,solution,point,rotation):
        c=self.c;m,d=self.ik.m,self.ik.d;q=c.actual_q().copy();q[c.ik.upper]=solution[c.ik.upper]
        self.ik._set(c.env.base_position,(1,0,0,0),q);mujoco.mj_collision(m,d)
        for contact in d.contact[:d.ncon]:
            if contact.dist<-.001 and min(m.geom_bodyid[contact.geom])>0:
                self.blocked=dict(reason='robot_self_collision',distance_m=float(contact.dist));return False
        states={name:c.object_state(name)for name in c.env.catalog['parts']}
        for key,name,pos,R in self.geoms:
            state=states[name]
            op,oR=(point,rotation)if name=='turning_tool'else(np.asarray(state['position']),Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix())
            gid=self.ids[key];d.geom_xpos[gid]=op+oR@pos;d.geom_xmat[gid]=(oR@R).reshape(9)
        for key,_,position in self.fixed:
            gid=m.geom(key).id;d.geom_xpos[gid]=position;d.geom_xmat[gid]=np.eye(3).reshape(9)
        ids=np.asarray([g for g,_ in self.scene]);positions=d.geom_xpos[ids];radii=m.geom_rbound[ids]
        for g,margin in self.robot+[(g,.001)for g in self.tool]:
            nearby=np.flatnonzero(np.linalg.norm(positions-d.geom_xpos[g],axis=1)<radii+m.geom_rbound[g]+margin)
            for i in nearby:
                other,name=self.scene[i]
                if g in self.tool and name=='small_gear':continue
                distance=float(mujoco.mj_geomDistance(m,d,g,other,margin,None))
                if distance<margin:
                    self.blocked=dict(link=m.body(m.geom_bodyid[g]).name,geometry=m.geom(g).name,object=name,distance_m=distance);return False
        self.blocked=None;return True
