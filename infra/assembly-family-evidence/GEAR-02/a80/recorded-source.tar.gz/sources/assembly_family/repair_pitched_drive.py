"""Drive a tooth gap with a mildly inclined tool and measured grasp geometry."""
import math
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from humanoid.g1_gear_assembly.solution.skills import pose,smooth
from humanoid.g1_gear_assembly.solution.stage_drive import small_center,gap_angle
from .gear_drive_clearance import GearClearance


def drive(c,held,strokes=10):
    sign=c.env.cfg.drive_sign;low,high=map(math.radians,(175.,205.));start,stop=(low,high)if sign>0 else(high,low)
    pitch=math.radians(10.);center,_=small_center(c);height=center[2]-.0125+.004
    c.ik.set_limit('waist_pitch_joint',-.46,.48);c.ik.set_limit('waist_roll_joint',-.48,.48);c.ik.set_limit('left_elbow_joint',-.8,1.8)
    screen=GearClearance(c);lp,lR=held.local;cp=held.corr_p.copy();cr=held.corr_r.copy();weak=0
    def target(theta,radius,dz=0.):
        R=Rotation.from_euler('z',theta+np.pi).as_matrix()@Rotation.from_euler('y',pitch).as_matrix()
        center,_=small_center(c);tip=np.array([center[0]+radius*np.cos(theta),center[1]+radius*np.sin(theta),height+dz])
        return tip-R@np.array([.075,0,0]),R
    def track(point,R,contact=False):
        nonlocal cp,cr,weak
        actual,actual_R,_,state=pose(c,'turning_tool');weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>25:raise RuntimeError('tool: pitched drive lost its physical grasp')
        cp=np.clip(cp+np.clip(.05*(point-actual),-.0005,.0005),-.05,.05)
        if not contact:
            rv=Rotation.from_matrix(R@actual_R.T).as_rotvec();cr=np.clip(cr+np.clip(.03*rv,-.002,.002),-.3,.3)
        commanded=Rotation.from_rotvec(cr).as_matrix()@R
        c.reach({'left':('palm',point+cp+commanded@lp,commanded@lR)},feedback=.4,rotation_feedback=.3,iters=20);c.step()
    def move(point,R,seconds,contact=False):
        p0,R0,_,_=pose(c,'turning_tool');interpolation=Slerp([0.,1.],Rotation.from_matrix([R0,R]));solution=c.actual_q().copy()
        count=max(20,int(np.ceil(np.linalg.norm(point-p0)/.004)))
        for f in np.linspace(0,1,count+1):
            pc=p0+f*(point-p0);Rc=interpolation(f).as_matrix()
            solution,errors=c.ik.solve(c.env.base_position,(1,0,0,0),solution,{'left':('palm',pc+Rc@lp,Rc@lR)},iters=150,damping=.02,w_rot=.5,max_step=.06)
            angle_error=np.linalg.norm(Rotation.from_matrix((Rc@lR)@c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3).T).as_rotvec())
            if max(errors.values())>.003 or angle_error>.04 or not screen.clear(solution,pc,Rc):
                c.event('pitched_tool_path_rejected',fraction=float(f),errors=errors,blocked=screen.blocked)
                raise RuntimeError('tool: pitched waypoint lacks continuous scene clearance')
        c.event('pitched_tool_screened_move',position=point.tolist(),rotation=R.tolist(),samples=count+1,contact_motion=contact)
        for i in range(round(seconds/.02)):
            f=smooth((i+1)/round(seconds/.02));track(p0+f*(point-p0),interpolation(f).as_matrix(),contact=contact)
        stable=0
        for _ in range(250):
            p,Ractual,_,state=pose(c,'turning_tool');ep=np.linalg.norm(p-point);er=np.linalg.norm(Rotation.from_matrix(R@Ractual.T).as_rotvec())
            stable=stable+1 if ep<.0015 and er<.025 and np.linalg.norm(state['linear_velocity'])<.008 else 0
            if stable>=10:return
            track(point,R,contact=contact)
        raise RuntimeError('tool: pitched waypoint did not physically converge')
    c.event('repair_pitched_gap_drive',pitch_degrees=10.,sector_degrees=[175.,205.],tip_height_m=float(height),maximum_strokes=strokes)
    for stroke in range(strokes):
        theta=gap_angle(c,start,sign)
        if sign*(stop-theta)<math.radians(8.):raise RuntimeError('tool: insufficient tooth-gap travel inside the screened sector')
        move(*target(theta,.095,.08),seconds=3.5)
        move(*target(theta,.095),seconds=2.)
        move(*target(theta,.036),seconds=2.)
        move(*target(theta,.023),seconds=1.5,contact=True)
        # Validate the full held-tool sweep before touching the next tooth.
        solution=c.actual_q().copy()
        for angle in np.linspace(theta,stop,41):
            pc,Rc=target(angle,.023)
            solution,errors=c.ik.solve(c.env.base_position,(1,0,0,0),solution,{'left':('palm',pc+Rc@lp,Rc@lR)},iters=150,damping=.02,w_rot=.5,max_step=.06)
            angle_error=np.linalg.norm(Rotation.from_matrix((Rc@lR)@c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3).T).as_rotvec())
            if max(errors.values())>.003 or angle_error>.04 or not screen.clear(solution,pc,Rc):raise RuntimeError('tool: pitched sweep lacks measured scene clearance '+str(screen.blocked))
        c.event('pitched_tool_loaded_sweep',stroke=stroke,start_rad=theta,stop_rad=stop)
        for i in range(200):track(*target(theta+smooth((i+1)/200)*(stop-theta),.023),contact=True)
        c.event('pitched_tool_stroke_result',stroke=stroke,credited=c.env.status.get('credited_angles_rad'),completed=list(c.env.status['completed']))
        move(*target(stop,.036),seconds=1.5,contact=True)
        move(*target(stop,.095),seconds=2.)
        move(*target(stop,.095,.08),seconds=2.)
        if 'drive_test'in c.env.status['completed']:break
    # Hand control returns with the current measured tool transform for parking.
    from humanoid.g1_gear_assembly.solution.stage_gears import Held
    refreshed=Held(held.grip,level=True);held.local=refreshed.local;held.corr_p[:]=0.;held.corr_r[:]=0.
    return dict(completed=list(c.env.status['completed']),credited=c.env.status.get('credited_angles_rad'))


def drive_regrasp(c,held,strokes=10):
    """Physically set down and reacquire the tool after each pair of strokes."""
    from humanoid.g1_gear_assembly.solution.stage_drive import park_tool
    from .tool_pick import pick_parallel
    for cycle in range(math.ceil(strokes/2)):
        count=min(2,strokes-2*cycle)
        c.event('pitched_drive_physical_regrasp_cycle',cycle=cycle,maximum_strokes=count)
        result=drive(c,held,strokes=count)
        if 'drive_test' in c.env.status['completed']:return result
        if 2*(cycle+1)>=strokes:break
        lo,hi=c.ik.lo.copy(),c.ik.hi.copy()
        c.ik.set_limit('waist_pitch_joint',-.25,.49)
        try:park_tool(c,held.grip,held)
        finally:c.ik.lo[:],c.ik.hi[:]=lo,hi
        c.hold(.6)
        p,R,_,state=pose(c,'turning_tool')
        if state['robot_contact_force']>.05 or state['support_forces'].get('table',0)<.05:
            raise RuntimeError('tool: regrasp requires a genuinely released table-supported tool')
        c.event('pitched_tool_released_before_regrasp',position=p.tolist(),credited=c.env.status.get('credited_angles_rad'))
        _,fresh,_=pick_parallel(c,anchor=(-.04,0.,0.))
        held.grip=fresh.grip;held.local=fresh.local;held.level=fresh.level
        held.corr_p=fresh.corr_p.copy();held.corr_r=fresh.corr_r.copy();held.weak=0
    return result
