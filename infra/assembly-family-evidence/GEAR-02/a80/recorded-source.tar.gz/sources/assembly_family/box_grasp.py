"""CAD-matched planar pinch through normal joint targets, with measured feedback."""
import numpy as np
from scipy.spatial.transform import Rotation


def pick_place(c, name, goal, fit, side=None):
    from humanoid.g1_tabletop_assembly.solution.tool import safe_ready
    safe_ready(c)
    state=c.object_state(name);start_pos=np.asarray(state['pos'])
    side=side or ('left' if start_pos[1]>0 else 'right')
    sign=1. if side=='left' else -1.
    mirror=np.diag([1.,-1.,1.])
    rotation=np.asarray(fit['rotation']);offset=np.asarray(fit['palm_offset'])
    shape=dict(fit['hand_joints'])
    if side=='right':
        rotation=mirror@rotation@mirror;offset=mirror@offset
        shape={j:v if j=='thumb_0' else -v for j,v in shape.items()}
    # The searched bar's long axis is x; this support's long axis is y.
    turn=Rotation.from_euler('z',np.pi/2).as_matrix()
    rotation=turn@rotation;offset=turn@offset
    # Put the thumb's contact below the top edge; a top-edge contact slipped
    # after only 3 mm of lift in a04 despite opposing fingertip forces.
    offset[2]-=.007
    pairs=[('thumb',1,2),('index',0,1),('middle',0,1)]
    sums={f:shape[f'{f}_{a}']+shape[f'{f}_{b}'] for f,a,b in pairs}
    def target(amount):
        q=c.q.copy()
        for j,v in shape.items():q[c.index[f'{side}_hand_{j}_joint']]=v
        for f,a,b in pairs:
            ia=c.index[f'{side}_hand_{f}_{a}_joint'];ib=c.index[f'{side}_hand_{f}_{b}_joint']
            shift=sign*amount*(1. if f=='thumb' else -.7)
            q[ia]+=shift;q[ib]-=shift
        return np.clip(q,c.lo+.02,c.hi-.02)
    c.event(name+'_geometry_preshape');c.move_joints(target(-.12),seconds=1.2)
    palm=start_pos+offset
    for dz in (.13,0.):
        c.event(name+'_geometry_approach');c.move_hands({side:('palm',palm+[0,0,dz],rotation)},seconds=3.,feedback=.4)
    def servo(current):
        measured=current.actual_q()
        for f,a,b in pairs:
            ia=c.index[f'{side}_hand_{f}_{a}_joint'];ib=c.index[f'{side}_hand_{f}_{b}_joint']
            error=sums[f]-measured[ia]-measured[ib]
            current.q[ib]=np.clip(sums[f]-measured[ia]+.3*error,current.lo[ib]+.02,current.hi[ib]-.02)
    key=side+'_support_orientation';c.joint_feedback[key]=servo
    iklo,ikhi=c.ik.lo.copy(),c.ik.hi.copy()
    try:
        c.event(name+'_geometry_close');c.move_joints(target(.40),seconds=2.)
        measured_hand,R=c.hand_pose(side)
        c.event(name+'_geometry_lift');c.move_hands({side:('palm',measured_hand+[0,0,.10],R)},seconds=3.,feedback=.5)
        current=c.object_state(name)
        if not current['hand_contact'] or current['pos'][2]<start_pos[2]+.035:
            raise RuntimeError(name+': geometry-matched pinch failed physical lift')
        c.ik.set_limit('waist_pitch_joint',-.40,.44)
        c.ik.set_limit('waist_roll_joint',-.44,.44)
        # A straight lateral carry intersects the tilted fixture's front edge.
        # Use the clear strip at x=.24 before crossing the table centreline.
        for waypoint in ([.24,current['pos'][1],current['pos'][2]],
                         [.24,goal[1],current['pos'][2]]):
            hand,R=c.hand_pose(side);part=np.asarray(c.object_state(name)['pos'])
            delta=np.asarray(waypoint)-part
            if np.linalg.norm(delta)<.008:continue
            c.event(name+'_front_corridor');c.move_hands({side:('palm',hand+delta,R)},seconds=max(2.,np.linalg.norm(delta)/.12),feedback=.5)
        for height in (.10,.025,.001):
            for _ in range(3):
                current=c.object_state(name)
                if not current['hand_contact']:raise RuntimeError(name+': pinch lost in transfer')
                hand,R=c.hand_pose(side);delta=np.asarray(goal)+[0,0,height]-current['pos']
                if np.linalg.norm(delta)<.003:break
                c.event(name+'_geometry_transfer');c.move_hands({side:('palm',hand+delta,R)},seconds=2.,feedback=.5)
        c.event(name+'_geometry_release');c.move_joints(target(-.16),seconds=1.3)
    finally:
        c.joint_feedback.pop(key,None)
        c.ik.lo[:]=iklo;c.ik.hi[:]=ikhi
    hand,R=c.hand_pose(side);c.move_hands({side:('palm',hand+[0,0,.12],R)},seconds=1.5);c.hold(.6)
    current=c.object_state(name)
    if current['robot_contact'] or np.linalg.norm(np.asarray(current['pos'])-goal)>.012:
        raise RuntimeError(name+': released support missed placement target')
