"""Relocate the released temporary support with measured table contact."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import pose,smooth
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,Held,release


def slide(c,fit,goal,side=None,release_seconds=2.):
    name='temporary_fixture';p,_,yaw,_=pose(c,name)
    side=side or ('left' if p[1]>0 else 'right')
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])-[0,0,.006],
                 hand=fit['hand_joints'],squeeze=.55,hook=0.)
    grip=HubGrip(c,name,side,yaw,profile=profile);grip.grasp()
    held=Held(grip,level=True)
    c.event('reuse_fixture_table_slide',goal=np.asarray(goal).tolist())
    held.move(goal,yaw,seconds=4.,settle=.3)
    if side=='right':
        # Release the complete finger shape together. Distal-sum feedback
        # during proximal opening can press the thumb into the table and
        # drive its proximal joint beyond the hardware stop.
        c.event('temporary_fixture_measured_full_hand_release')
        grip.closed=False;c.joint_feedback.pop(grip.key,None)
        start=c.actual_q().copy();joints=[grip.joint(j)for j in grip.open]
        target=start.copy()
        for j,value in grip.open.items():target[grip.joint(j)]=value
        target=np.clip(target,c.lo+.03,c.hi-.03)
        palm,rotation=c.hand_pose(side);count=max(100,round(release_seconds/.02))
        for i in range(count):
            a=smooth((i+1)/count);c.q[joints]=start[joints]+a*(target[joints]-start[joints])
            c.reach({side:('palm',palm+[0,0,.003*a],rotation)},feedback=.4,rotation_feedback=.3);c.step()
        palm,rotation=c.hand_pose(side)
        c.move_hands({side:('palm',palm+[0,0,.10],rotation)},seconds=1.5,feedback=.5,settle=.2)
    else:release(c,grip,seconds=release_seconds)
    c.hold(.8)
    p,_,_,state=pose(c,name)
    if np.linalg.norm(p-goal)>.015 or state['robot_contact_force']>.05 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('fixture: repeated relocation lacks stable released table support')
    c.event('reuse_fixture_released',position=p.tolist())
