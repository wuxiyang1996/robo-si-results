"""Geometric release envelope for feet already guided by the real slot walls."""
import itertools
import numpy as np


def envelope(env,name,slot,position,rotation):
    origin=np.asarray(env.cfg.origin);p=np.asarray(position);R=np.asarray(rotation)
    posts=sorted([b for b in env.catalog['parts'][name]['collision_boxes']if b['role']=='upright'],key=lambda b:b['pos'][0])
    iy=0 if env.catalog['parts'][slot]['goal_local'][1]>0 else 1
    fixture={b['name']:b for b in env.catalog['fixture']};details=[]
    corners=np.array(list(itertools.product((-1.,1.),repeat=3)))
    for ix,post in enumerate(posts):
        limits=[];walls=[]
        for axis in (0,1):
            lower=fixture[f'jig_slot_{ix}_{iy}_{axis}_-1'];upper=fixture[f'jig_slot_{ix}_{iy}_{axis}_1'];walls.extend((lower,upper))
            limits.append([origin[axis]+lower['pos_local'][axis]+lower['size'][axis]/2,
                           origin[axis]+upper['pos_local'][axis]-upper['size'][axis]/2])
        floor=max(origin[2]+w['pos_local'][2]-w['size'][2]/2 for w in walls)
        rim=min(origin[2]+w['pos_local'][2]+w['size'][2]/2 for w in walls)
        vertices=(np.asarray(post['pos'])+corners*np.asarray(post['size'])/2)@R.T+p
        depth=float(rim-vertices[:,2].min())
        if depth<.003 or vertices[:,2].min()<floor-.001:return False,dict(reason='feet_not_inside_guiding_wall_height',foot=ix,engagement_m=depth)
        clipped=[v for v in vertices if floor<=v[2]<=rim]
        for i in range(8):
            for bit in (1,2,4):
                j=i^bit
                if j<i:continue
                a,b=vertices[i],vertices[j]
                for z in (floor,rim):
                    if abs(b[2]-a[2])<1e-12:continue
                    t=(z-a[2])/(b[2]-a[2])
                    if 0<=t<=1:clipped.append(a+t*(b-a))
        if not clipped:return False,dict(reason='no_foot_wall_height_overlap',foot=ix)
        xy=np.asarray(clipped)[:,:2];bounds=np.asarray(limits)
        margins=np.r_[xy.min(0)-bounds[:,0],bounds[:,1]-xy.max(0)]
        # A tenth of a millimetre admits an already touching soft-contact face;
        # it does not alter the simulator or any final task predicate.
        if margins.min()<-.0001:return False,dict(reason='foot_outside_slot_opening',foot=ix,margins_m=margins.tolist())
        details.append(dict(foot=ix,engagement_m=depth,margins_m=margins.tolist()))
    return len(details)==2,dict(feet=details)
