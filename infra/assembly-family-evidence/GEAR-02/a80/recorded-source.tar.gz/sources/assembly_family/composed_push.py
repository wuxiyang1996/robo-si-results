"""Translate a released two-piece stand by pushing its lower body on the table."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import smooth
from .push_approach import prepare


def check(c):
    brace=c.object_state('brace');shim=c.object_state('shim')
    R=Rotation.from_quat(np.asarray(shim['quat'])[[1,2,3,0]]).as_matrix()
    if brace['robot_contact'] or shim['robot_contact'] or brace['support_forces'].get('table',0)<.05 or shim['support_forces'].get('brace',0)<.05 or R[2,2]<.95:
        raise RuntimeError('composed stand: released measured support path was lost')


def move(c):
    check(c)
    c.hand_preset('left','open',seconds=1.)
    q=c.q.copy()
    for j in ('index_0','index_1','middle_0','middle_1'):q[c.index['left_hand_'+j+'_joint']]=-.05
    c.event('compose_push_prepare_vertical_index');c.move_joints(q,seconds=1.)
    c.ik._set(c.env.base_position,(1,0,0,0),c.q)
    index_tip=c.ik.point(c.ik.m.body('left_hand_index_1_link').id,[.04,0,0])
    palm=c.ik.hand_point('left','palm');wrist_R=c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3)
    local_palm=wrist_R.T@(palm-index_tip)
    target=np.array([c.env.cfg.brace_goal_xy[0]-.013,
                     c.env.cfg.fixture_size[1]/2+c.env.cfg.brace_size[1]/2+.042])
    # The sleeve occupies the straight north route at x=.43. Move the stand
    # sideways first so that the composed support clears that real obstacle.
    for axis,angle,label,destination in [(0,0.,'west_clear',.55),(1,np.pi/2,'north',target[1]),(0,0.,'west',target[0])]:
        before=np.asarray(c.object_state('brace')['pos'])
        rotation=Rotation.from_euler('z',angle).as_matrix()@Rotation.from_euler('y',np.pi/2).as_matrix()
        # The vertical index side can align an overhanging shim with the
        # stand and then push both layers horizontally. The wrist stays high.
        point=np.array([before[0],before[1]+c.env.cfg.brace_size[1]/2+.055,c.env.cfg.table_height+.005]) if axis==1 else np.array([before[0]-c.env.cfg.brace_size[0]/2-.055,before[1],c.env.cfg.table_height+.005])
        point=point+rotation@local_palm
        c.event('compose_push_'+label+'_approach')
        prepare(c,point,rotation,axis=axis,kind='palm')
        palm,_=c.hand_pose('left');direction=1. if axis==0 else -1.
        c.event('compose_push_'+label+'_establish_both_layer_contact')
        for i in range(160):
            if c.object_state('brace')['hand_contact']:break
            desired=palm.copy();desired[axis]+=direction*.0005*(i+1)
            c.reach({'left':('palm',desired,rotation)},rate=.8,feedback=.4,iters=16);c.step()
        if not c.object_state('brace')['hand_contact']:
            raise RuntimeError('composed stand: index did not establish actual lower-layer contact')
        before=np.asarray(c.object_state('brace')['pos'])
        origin,_=c.hand_pose('left','palm');correction=0.
        delta=destination-before[axis]
        c.event('compose_push_'+label,axis=axis,target=float(destination))
        for i in range(250):
            actual=np.asarray(c.object_state('brace')['pos'])
            desired=before[axis]+smooth((i+1)/250)*delta
            correction=float(np.clip(correction+np.clip(.05*(desired-actual[axis]),-.0005,.0005),-.045,.045))
            command=origin.copy();command[axis]+=desired-before[axis]+correction
            other=1-axis;command[other]+=.6*np.clip(before[other]-actual[other],-.025,.025)
            c.reach({'left':('palm',command,rotation)},rate=.8,feedback=.4,iters=16);c.step()
        palm,_=c.hand_pose('left','palm')
        c.event('compose_push_'+label+'_withdraw')
        outward=np.zeros(3);outward[axis]=-.05 if axis==0 else .05
        c.move_hands({'left':('palm',palm+outward+[0,0,.08],rotation)},seconds=2.)
        c.hold(.6);check(c)
        after=np.asarray(c.object_state('brace')['pos'])
        if abs(after[axis]-destination)>.02:
            raise RuntimeError('composed stand: table push did not reach '+label+' target')
        c.event('compose_push_'+label+'_verified',position=after.tolist())
    c.event('composed_stand_staging_verified',position=c.object_state('brace')['pos'])
