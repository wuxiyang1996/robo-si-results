"""Joint-space approach planning against measured fixture and table geometry.

MuJoCo is used only for kinematic collision queries. Executing the returned
waypoints still uses the normal Genesis joint controller and physics audit.
"""
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK,XML
from humanoid.g1_support_retrieval.task_spec import JOINT_NAMES


def plan(c,goal,side='left',carried=None,protected=()):
    root=ET.parse(XML).getroot()
    root.find('compiler').set('meshdir',str(XML.parent/'assets'))
    world=root.find('worldbody');fixture=c.object_state('fixture')
    def numbers(v):return ' '.join(str(float(x)) for x in v)
    ET.SubElement(world,'geom',name='approach_fixture',type='box',pos=numbers(fixture['pos']),
                  quat=numbers(fixture['quat']),size=numbers(np.asarray(c.env.cfg.fixture_size)/2))
    fixture_R=Rotation.from_quat(np.asarray(fixture['quat'])[[1,2,3,0]]).as_matrix()
    post_local=np.r_[c.env.cfg.post_offset,(c.env.cfg.fixture_size[2]+c.env.cfg.post_height)/2]
    ET.SubElement(world,'geom',name='approach_post',type='box',
                  pos=numbers(np.asarray(fixture['pos'])+fixture_R@post_local),
                  quat=numbers(fixture['quat']),size=numbers(np.r_[c.env.cfg.post_size,c.env.cfg.post_height]/2))
    table=c.env.cfg.table_size
    ET.SubElement(world,'geom',name='approach_table',type='box',
                  pos=numbers([*c.env.cfg.table_center,c.env.cfg.table_height-table[2]/2]),size=numbers(np.asarray(table)/2))
    environment_obstacles=['approach_rear_support']
    ET.SubElement(world,'geom',name='approach_rear_support',type='box',pos='-.14 0 .36',size='.04 .05 .36')
    for x in (-1,1):
        for y in (-1,1):
            key=f'approach_table_leg_{x}_{y}';environment_obstacles.append(key)
            position=[c.env.cfg.table_center[0]+x*(table[0]/2-.045),
                      c.env.cfg.table_center[1]+y*(table[1]/2-.045),
                      (c.env.cfg.table_height-table[2])/2]
            ET.SubElement(world,'geom',name=key,type='box',pos=numbers(position),
                          size=numbers([.0225,.0225,(c.env.cfg.table_height-table[2])/2]))
    part_obstacles=[]
    protected_parts=set(protected)
    if carried:protected_parts.update(('brace','sleeve','cap'))
    if protected_parts:
        for name in sorted(protected_parts):
            if name==carried:continue
            state=c.object_state(name);spec=c.env.specs[name]
            size=spec['size'] if 'size' in spec else (*spec['outer_size'],spec['height'])
            key='approach_part_'+name;part_obstacles.append(key)
            ET.SubElement(world,'geom',name=key,type='box',pos=numbers(state['pos']),
                          quat=numbers(state['quat']),size=numbers(np.asarray(size)/2))
    if carried:
        # A rigid grasp is only a collision-planning assumption. No attachment
        # is created in the executing simulator; measured contact still gates it.
        reference=UpperBodyIK();reference._set(c.env.base_position,(1,0,0,0),c.actual_q())
        wrist=reference.wrist[side];wR=reference.d.xmat[wrist].reshape(3,3);wp=reference.d.xpos[wrist]
        state=c.object_state(carried);oR=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
        local_p=wR.T@(np.asarray(state['pos'])-wp);local_R=wR.T@oR
        wrist_body=root.find(".//body[@name='"+side+"_wrist_yaw_link']")
        ET.SubElement(wrist_body,'geom',name='approach_payload',type='box',pos=numbers(local_p),
                      quat=numbers(Rotation.from_matrix(local_R).as_quat()[[3,0,1,2]]),size=numbers(np.asarray(c.env.specs[carried]['size'])/2))
    ik=UpperBodyIK();ik.m=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'));ik.d=mujoco.MjData(ik.m)
    obstacles=[ik.m.geom(n).id for n in ('approach_fixture','approach_post','approach_table',*environment_obstacles,*part_obstacles)]
    payload_id=ik.m.geom('approach_payload').id if carried else None
    payload_robot_obstacles=[g for g in range(ik.m.ngeom) if ik.m.geom_contype[g]
        and g not in obstacles and g!=payload_id and ik.m.geom_bodyid[g]>0
        and not ik.m.body(ik.m.geom_bodyid[g]).name.startswith((side+'_hand',side+'_wrist'))] if carried else []
    moving=[g for g in range(ik.m.ngeom) if ik.m.geom_contype[g] and
            ik.m.body(ik.m.geom_bodyid[g]).name.startswith(('left_','right_')) and
            any(s in ik.m.body(ik.m.geom_bodyid[g]).name for s in ('shoulder','elbow','wrist','hand'))]
    active=[i for i in c.ik.upper if JOINT_NAMES[i].startswith(('waist',side+'_'))]
    slots=[list(c.ik.upper).index(i) for i in active]
    lo,hi=c.ik.lo[slots],c.ik.hi[slots]
    base=c.actual_q().copy();start=base[active].copy();finish=np.asarray(goal)[active].copy()
    queries=0;blocked={}
    def clear(point):
        nonlocal queries
        queries+=1;q=base.copy();q[active]=point
        ik._set(c.env.base_position,(1,0,0,0),q)
        # An unconstrained arm shortcut can invert a thin pinched plate.
        # Keep its support normal near vertical throughout the carried path.
        if payload_id is not None and ik.d.geom_xmat[payload_id].reshape(3,3)[2,2]<np.cos(np.deg2rad(20)):
            return False
        if payload_id is not None and ik.d.geom_xpos[payload_id,2]<c.env.cfg.table_height+.04:
            return False
        mujoco.mj_collision(ik.m,ik.d)
        if any(contact.dist<-.001 and min(ik.m.geom_bodyid[contact.geom])>0
               and payload_id not in contact.geom for contact in ik.d.contact[:ik.d.ncon]):return False
        if payload_id is not None and any(mujoco.mj_geomDistance(ik.m,ik.d,payload_id,g,.012,None)<.012 for g in payload_robot_obstacles):
            return False
        for g in moving:
            for obstacle in obstacles:
                distance=mujoco.mj_geomDistance(ik.m,ik.d,g,obstacle,.012,None)
                if distance<.012:
                    blocked.clear();blocked.update(robot_geometry=ik.m.geom(g).name,robot_link=ik.m.body(ik.m.geom_bodyid[g]).name,obstacle=ik.m.geom(obstacle).name,distance_m=float(distance))
                    return False
        return True
    def edge(a,b):
        steps=max(1,int(np.ceil(np.max(np.abs(b-a))/.04)))
        return all(clear(a+(b-a)*i/steps) for i in range(1,steps+1))
    if not clear(start):raise RuntimeError('Approach start lacks 12 mm static obstacle clearance: '+str(blocked))
    if not clear(finish):raise RuntimeError('Approach finish lacks 12 mm static obstacle clearance: '+str(blocked))
    if edge(start,finish):path=[start,finish]
    else:
        rng=np.random.default_rng(0);trees=[([start],[-1]),([finish],[-1])];path=None
        def extend(tree,target):
            points,parents=tree;index=int(np.argmin([np.linalg.norm(p-target) for p in points]));p=points[index]
            distance=np.linalg.norm(target-p)
            candidate=p+(target-p)*min(1.,.35/max(distance,1e-12))
            if not edge(p,candidate):return None,False
            points.append(candidate);parents.append(index)
            return len(points)-1,distance<=.35
        def branch(tree,index):
            result=[]
            while index!=-1:result.append(tree[0][index]);index=tree[1][index]
            return result[::-1]
        for iteration in range(1800):
            which=iteration%2;other=1-which
            sample=trees[other][0][-1] if rng.random()<.25 else rng.uniform(lo,hi)
            if carried and rng.random()>.25:
                # Project samples into poses that keep the thin plate level;
                # random 10-DOF samples almost never satisfy that constraint.
                if rng.random()<.5:
                    vertex=trees[which][0][rng.integers(len(trees[which][0]))]
                    sample=np.clip(vertex+rng.normal(0,.45,len(active)),lo,hi)
                seed=base.copy();seed[active]=sample
                ik._set(c.env.base_position,(1,0,0,0),seed)
                object_R=ik.d.geom_xmat[payload_id].reshape(3,3)
                yaw=np.arctan2(object_R[1,0],object_R[0,0])
                wrist_R=Rotation.from_euler('z',yaw).as_matrix()@local_R.T
                position=ik.hand_point(side,'palm').copy()
                projected,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,
                    {side:('palm',position,wrist_R)},iters=70,damping=.02,w_rot=.5,max_step=.08)
                if errors[side]>.01:continue
                sample=projected[active]
            a,_=extend(trees[which],sample)
            if a is None:continue
            target=trees[which][0][a]
            for _ in range(40):
                b,reached=extend(trees[other],target)
                if b is None:break
                if reached:
                    first=branch(trees[which],a);second=branch(trees[other],b)
                    path=first+second[-2::-1]
                    if which==1:path=path[::-1]
                    break
            if path is not None:break
        if path is None:raise RuntimeError('No collision-free approach found within bounded joint-space search')
        # Shortcuts are checked at the same spatial resolution as tree edges.
        simplified=[path[0]];i=0
        while i<len(path)-1:
            j=len(path)-1
            while j>i+1 and not edge(path[i],path[j]):j-=1
            simplified.append(path[j]);i=j
        path=simplified
    result=[]
    for point in path:
        q=c.q.copy();q[active]=point;result.append(q)
    c.event('collision_checked_approach',clearance_m=.012,queries=queries,carried_object=carried,
            active_joints=[JOINT_NAMES[i] for i in active],waypoints=[p.tolist() for p in path])
    return result


def move(c,goal,side='left',carried=None,protected=()):
    waypoints=plan(c,goal,side,carried,protected=protected)
    weak=[0]
    def guard(current):
        held=current.object_state(carried)['hand_contact'];weak[0]=0 if held else weak[0]+1
        if weak[0]>5:raise RuntimeError(carried+': contact lost on planned carry')
    if carried:c.joint_feedback['planned_carry_guard']=guard
    original={name:np.asarray(c.object_state(name)['pos']) for name in protected}
    def preserve_loose_parts(current):
        for name,position in original.items():
            actual=np.asarray(current.object_state(name)['pos'])
            if np.linalg.norm(actual-position)>.03:
                raise RuntimeError(name+': unloaded approach disturbed the protected table staging')
    if protected:c.joint_feedback['planned_loose_part_guard']=preserve_loose_parts
    try:
        for previous,target in zip(waypoints,waypoints[1:]):
            speed=getattr(c,'planned_carry_joint_rate',.25) if carried else getattr(c,'planned_unloaded_joint_rate',.7)
            seconds=max(1.2 if carried else .8,float(np.max(np.abs(target-previous)))/speed)
            c.move_joints(target,seconds=seconds)
    finally:
        c.joint_feedback.pop('planned_carry_guard',None)
        c.joint_feedback.pop('planned_loose_part_guard',None)
