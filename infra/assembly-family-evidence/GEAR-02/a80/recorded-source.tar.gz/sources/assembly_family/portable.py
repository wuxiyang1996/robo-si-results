"""Load unchanged authored assets with platform-local paths; never edit originals."""
import copy
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def catalog(family):
    folder=ROOT/'humanoid'/('g1_gear_assembly/assets' if family=='GEAR' else 'g1_reference_assembly/assets/shelf')
    data=json.loads((folder/'catalog.json').read_text())
    old=data['asset_root'].replace('\\','/')
    def fix(v):
        if isinstance(v,dict):return {k:fix(x) for k,x in v.items()}
        if isinstance(v,list):return [fix(x) for x in v]
        if isinstance(v,str):
            norm=v.replace('\\','/')
            if norm==old or norm.startswith(old+'/'):return str(folder)+norm[len(old):]
        return v
    data=fix(data)
    for name,part in data['parts'].items():
        part['urdf']=str(folder/(name+'.urdf'))
        if not Path(part['urdf']).is_file():raise FileNotFoundError(part['urdf'])
    return data

def make_env(task, output, backend='gpu', camera=True):
    family=task.split('-')[0]
    if family=='ASM':
        from humanoid.g1_tabletop_assembly.genesis_env import G1TabletopAssemblyGenesis
        from humanoid.g1_tabletop_assembly.task_spec import TaskConfig
        if task in ('ASM-03','ASM-04'):
            from .assembly_extension import ExtensionConfig,ExtensionEvaluator
            cfg=ExtensionConfig(extension=task)
            env=G1TabletopAssemblyGenesis(cfg=cfg,backend=backend,camera=camera)
            env.evaluator=ExtensionEvaluator(cfg);env.status=env.evaluator.reset()
            return env
        cfg=TaskConfig(difficulty=3 if task=='ASM-02' else 1)
        return G1TabletopAssemblyGenesis(cfg=cfg,backend=backend,camera=camera)
    if family=='GEAR':
        from humanoid.g1_gear_assembly import genesis_env as mod
        from humanoid.g1_gear_assembly.task_spec import TaskConfig
        cls=mod.G1GearAssembly
    else:
        from humanoid.g1_reference_assembly import genesis_env as mod
        from humanoid.g1_reference_assembly.task_spec import TaskConfig
        cls=mod.G1ReferenceAssembly
    data=catalog(family)
    # Only path localization. The existing image/geometry fingerprint validator
    # remains enabled and rejects any mismatch rather than silently accepting it.
    mod.build_assets=lambda:copy.deepcopy(data)
    (output/'catalog.json').write_text(json.dumps(data,indent=2)+'\n')
    cfg=TaskConfig()
    regenerated=ROOT/'assembly_family/references'/family/cfg.recipe
    kwargs=dict(backend=backend,camera=camera,instruction_dir=regenerated if regenerated.exists() else None)
    if task in ('GEAR-02','GEAR-03','REF-02','REF-03'):
        from .scene_extensions import augment,register
        with augment(mod,task,data,cfg) as (created,descriptors):env=cls(cfg,**kwargs)
        register(env,created)
        (output/'scene_extension.json').write_text(json.dumps({'task':task,'objects':descriptors,'initialization':'partial assembly with inverted middle gear, case v2' if task=='GEAR-02' else 'default supplies plus physical extras'},indent=2)+'\n')
        if family=='GEAR':
            from .gear_extension import RepairEvaluator,ToolEvaluator
            env.evaluator=(RepairEvaluator if task=='GEAR-02' else ToolEvaluator)(cfg,data)
            env.status=env.evaluator.reset()
        else:
            from .reference_extension import FixtureEvaluator,ConstrainedEvaluator
            env.evaluator=(FixtureEvaluator if task=='REF-02' else ConstrainedEvaluator)(cfg,data)
            env.status=env.evaluator.reset()
        return env
    return cls(cfg,**kwargs)
