"""Classify actual collision geometry, including palms sharing a wrist link."""
from pathlib import Path

VERSION = 'collision_geometry_v2'

def is_hand(link, mesh_path):
    if link.startswith(('left_hand_', 'right_hand_')):
        return True
    for side in ('left', 'right'):
        if link == side + '_wrist_yaw_link':
            return Path(mesh_path).stem == side + '_hand_palm_link'
    return False

def forbidden(record, owner):
    return owner not in ('ground', 'fixed_environment') and not is_hand(record['link'], record['mesh_path'])

def geometry_catalog(robot):
    return {str(g.idx): {'link': g.link.name, 'mesh_path': str(g.metadata.get('mesh_path', '')),
                         'name': str(g.metadata.get('name', ''))} for g in robot.geoms}

def violations(peaks, catalog):
    result = []
    for key, value in peaks.items():
        geom, owner = key.split('|', 1)
        record = catalog[geom]
        if value > 2. and forbidden(record, owner):
            result.append({'pair': record['link'] + '|' + owner, 'robot_geom': int(geom),
                           'mesh_path': record['mesh_path'], 'peak_force_n': value})
    return result
