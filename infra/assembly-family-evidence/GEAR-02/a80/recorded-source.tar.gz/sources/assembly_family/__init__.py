"""Isolated implementation and evidence for the ten registered assembly tasks."""
from .source_loading import install as _install_source_recording
_install_source_recording()
