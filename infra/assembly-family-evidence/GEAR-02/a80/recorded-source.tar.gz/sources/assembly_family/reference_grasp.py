"""Side entry for thin shelf boards; commands only, no state initialization."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,goto,smooth
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip
from .reach_screen import goto as screened_goto


def board_grasp(c,name,side,fit,world_anchor=None,entry_yaw=None,squeeze=.20,follow_tilt=False,opening=0.,front_clearance=.13):
    c.ik.set_limit('waist_yaw_joint',-.5,.5)
    p,R,yaw,_=pose(c,name)
    hand=dict(fit['hand_joints'])
    for finger,a,b,direction in [('thumb',1,2,-1.),('index',0,1,1.),('middle',0,1,1.)]:
        hand[f'{finger}_{a}']+=direction*opening
        hand[f'{finger}_{b}']-=direction*opening
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset']),hand=hand,squeeze=squeeze+opening,hook=0.)
    # The rack has a transverse beam at the robot-facing edge. Enter through
    # its open inner side, with both finger pads between the support beams.
    if entry_yaw is None:entry_yaw=-np.pi/2 if side=='right' else np.pi/2
    # Mesh distance checks on the complete board permit a deeper entry.
    # Keep the pads 47 mm inside the edge. Recorded board rotation moved
    # one pad off the edge at the former 27 mm insertion depth.
    anchor=Rotation.from_euler('z',-yaw).apply([-.09,.04 if side=='right' else -.04,0] if world_anchor is None else world_anchor)
    grip=HubGrip(c,name,side,0.,profile=profile,anchor=anchor)
    angle=np.pi/2 if side=='left' else -np.pi/2
    turn=Rotation.from_euler('z',entry_yaw+angle).as_matrix()@Rotation.from_euler('x',-angle).as_matrix()
    grip.rotation=turn@grip.rotation;grip.offset=turn@grip.offset
    if follow_tilt:
        tilt=R@Rotation.from_euler('z',-yaw).as_matrix()
        grip.rotation=tilt@grip.rotation;grip.offset=tilt@grip.offset
    grip.front=Rotation.from_euler('z',entry_yaw).apply([-front_clearance,0,0])
    c.event(name+'_horizontal_preshape');grip.preshape(seconds=1.)
    tasks=grip.target();_,palm,rot=tasks[side]
    hover=palm+grip.front;hover[2]=max(1.04,palm[2]+.12)
    c.event(name+'_horizontal_front_approach');screened_goto(c,{side:('palm',hover,rot)},seconds=3.,iters=600)
    c.move_hands({side:('palm',palm+grip.front,rot)},seconds=2.,feedback=.5)
    c.event(name+'_horizontal_edge_entry');c.move_hands(tasks,seconds=2.,feedback=.5)
    c.event(name+'_horizontal_close');grip.closed=True;start=c.q.copy()
    active=[grip.joint(j)for j in ('thumb_1','middle_0','index_0')]
    delta=np.array([grip.sign,-grip.sign,-grip.sign])*grip.squeeze
    for i in range(60):
        c.q[active]=start[active]+smooth((i+1)/60)*delta
        c.reach(tasks,feedback=.5,rotation_feedback=.3,iters=12);c.step()
    c.hold(.2)
    if pose(c,name)[3]['robot_contact_force']<.05:
        raise RuntimeError(name+': side-entry closure established no sustained contact')
    return grip


def board_release(c,grip):
    c.event(grip.name+'_horizontal_release');palm,rot=c.hand_pose(grip.side)
    grip.closed=False;start=c.q.copy()
    for i in range(50):
        a=smooth((i+1)/50)
        for j in ('thumb_0','thumb_1','middle_0','index_0'):
            k=grip.joint(j);c.q[k]=start[k]+a*(grip.open[j]-start[k])
        c.reach({grip.side:('palm',palm,rot)},feedback=.5,rotation_feedback=.3);c.step()
    c.event(grip.name+'_horizontal_withdraw')
    c.move_hands({grip.side:('palm',palm+grip.front,rot)},seconds=1.5,feedback=.5)
    c.joint_feedback.pop(grip.key,None)
    c.move_hands({grip.side:('palm',palm+grip.front+[0,0,.12],rot)},seconds=1.5)
