"""Table-supported near-edge staging, then two side pinches of one real rail."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,configure_ik,side_forces,smooth
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,release
from humanoid.g1_gear_assembly.solution.stage_base_wrap import Carry
from .reach_screen import goto
from .paired_grasp import acquire_hub
from .paired_grasp import acquire
from humanoid.g1_gear_assembly.solution.skills import Pinch
from humanoid.g1_gear_assembly.solution.stage_base_hook import HOOK_PROFILE


def move(c,grip,goal,rotation,seconds,phase):
    """Translate and yaw a supported rail while leaving its roll passive."""
    p0,_,yaw0,_=pose(c,grip.name);hp0,hR0=c.hand_pose(grip.side)
    yaw_goal=float(np.arctan2(rotation[1,0],rotation[0,0]));dyaw=float(np.arctan2(np.sin(yaw_goal-yaw0),np.cos(yaw_goal-yaw0)))
    cp=np.zeros(2);hand_cp=np.zeros(3);hand_cr=np.zeros(3);weak=0
    n=max(1,round(seconds/.02));c.event(phase,goal_position=np.asarray(goal).tolist(),wrist_roll='held_in_world_while_payload_roll_is_passive')
    for i in range(n+25):
        a=smooth(min(1.,(i+1)/n));p,_,_,state=pose(c,grip.name)
        weak=weak+1 if state['robot_contact_force']<.5 else 0
        if weak>10:raise RuntimeError(grip.name+': grasp lost during '+phase)
        desired=p0+a*(np.asarray(goal)-p0)
        cp=np.clip(cp+np.clip(.03*(desired[:2]-p[:2]),-.00025,.00025),-.025,.025)
        delta=Rotation.from_euler('z',a*dyaw).as_matrix()
        point=desired+delta@(hp0-p0);point[:2]+=cp;point[2]=hp0[2]
        want=delta@hR0;actual,actual_R=c.hand_pose(grip.side)
        hand_cp=np.clip(hand_cp+np.clip(.04*(point-actual),-.0003,.0003),-.025,.025)
        error=Rotation.from_matrix(want@actual_R.T).as_rotvec()
        hand_cr=np.clip(hand_cr+np.clip(.04*error,-.001,.001),-.10,.10)
        c.reach({grip.side:('palm',point+hand_cp,Rotation.from_rotvec(hand_cr).as_matrix()@want)},feedback=.5,rotation_feedback=.3,iters=20);c.step()
        if i%25==0:
            c.event(phase+'_contact_tracking',fraction=min(1.,(i+1)/n),position=p.tolist(),force_n=state['robot_contact_force'],supports=state['support_forces'],palm_error_m=float(np.linalg.norm(point-actual)),rotation_error_rad=float(np.linalg.norm(error)))


def stage(c,m,name,supply_lift=False):
    configure_ik(c,waist_pitch=.48);c.ik.set_limit('waist_roll_joint',-.38,.38)
    p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0.,.1485,0.]
    grip=Pinch(c,name,'left',HOOK_PROFILE,azimuth=yaw-np.pi,anchor=anchor,opening=0.,squeeze=.55)
    c.event('carrier_near_tie_grasp_before_table_pivot')
    goto(c,grip.target(.12),seconds=3.,iters=600,self_clear=True)
    acquire(c,grip,protect_other=False,close=False)
    amount=[0.];indices=[grip.joint(j)for j in grip.shape];stable=0
    c.event('carrier_overhang_force_controlled_closure',target_total_force_n=60.)
    def regulate(current):
        force=side_forces(current,name)['left']
        if force>110:raise RuntimeError('carrier: force-controlled pinch exceeded its planned 110 N envelope')
        amount[0]=float(np.clip(amount[0]+np.clip(.00015*(60.-force),-.002,.002),0.,.55))
        goal=grip.curled(amount[0]);current.q[indices]=goal[indices]
    key='carrier_measured_pinch_force';c.joint_feedback[key]=regulate
    for _ in range(350):
        c.reach(grip.target(),feedback=.5,rotation_feedback=.3,iters=20);c.step()
        force=side_forces(c,name)['left'];stable=stable+1 if 45.<force<80. else 0
        if stable>=10:break
    if stable<10:raise RuntimeError('carrier: adaptive closure did not establish a settled real grip')
    c.event('carrier_adaptive_pinch_force_settled',closure=amount[0],force_n=force)
    p,R,yaw,state=pose(c,name)
    if state['robot_contact_force']<.5:raise RuntimeError('carrier: near-end table grasp has no real contact')
    # This tie overhangs the table, so the distal pads can hook beneath it
    # before carrying any weight. The far tie did not have this clearance.
    hp,hR=c.hand_pose('left');c.event('carrier_curled_pinch_on_free_overhanging_near_tie')
    raw=c.env.objects[name].get_contacts(with_entity=c.env.robot)
    own={link.idx for link in c.env.objects[name].links};robot={link.idx:link.name for link in c.env.robot.links};measured=[]
    for i in range(len(raw['link_a'])):
        a,b=int(raw['link_a'][i]),int(raw['link_b'][i])
        if a in own and b in robot:measured.append(dict(robot_link=robot[b],force_on_object=raw['force_a'][i].cpu().numpy().tolist()))
        elif b in own and a in robot:measured.append(dict(robot_link=robot[a],force_on_object=raw['force_b'][i].cpu().numpy().tolist()))
    c.event('carrier_hook_measured_contact_vectors',contacts=measured)
    p,R,yaw,state=pose(c,name)
    half=np.asarray(c.env.catalog['parts'][name]['size'])/2
    table_z=float(c.env.cfg.table_height+half[2])
    # Lift the near tie while gravity keeps the rear on the table. Holding
    # the wrist orientation avoids forcing a torsional roll of the thin bar.
    hp,hR=c.hand_pose('left');c.event('carrier_lift_near_edge_with_fixed_wrist')
    c.move_hands({'left':('palm',hp+[0,0,.020],hR)},seconds=3.,feedback=.5,rotation_feedback=.3)
    p,R,_,state=pose(c,name);front=p+R@[0.,half[1],-half[2]]
    c.event('carrier_near_edge_clearance_measurement',height_m=float(front[2]-c.env.cfg.table_height),supports=state['support_forces'])
    if front[2]<c.env.cfg.table_height+.003 or state['robot_contact_force']<.5 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('carrier: near end did not clear the table lip with measured rear support and grip')
    if supply_lift:return supply_pair(c,m,name,grip)
    tilt=R.copy()
    move(c,grip,[.285,p[1],p[2]],tilt,3.,'carrier_near_grasp_clear_table_edge')
    p=pose(c,name)[0];move(c,grip,[p[0],.20,p[2]],tilt,4.,'carrier_near_grasp_clear_supply_rack')
    p,R,yaw,_=pose(c,name);tilt0=Rotation.from_euler('z',-yaw).as_matrix()@R
    move(c,grip,p,tilt0,5.,'carrier_turn_on_table_from_near_end')
    p=pose(c,name)[0];move(c,grip,[p[0],0.,p[2]],tilt0,4.,'carrier_near_grasp_slide_to_midline')
    p=pose(c,name)[0];move(c,grip,[.34,0.,p[2]],tilt0,3.,'carrier_near_grasp_stage_for_side_pair')
    c.event('carrier_release_raised_near_tie_over_real_table')
    c.joint_feedback.pop(key,None);grip.release(seconds=1.,rise=.10);c.hold(.5)
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p-[.34,0.,table_z])>.015 or R[2,2]<.98 or state['support_forces'].get('table',0)<.05 or state['robot_contact_force']>.05:
        raise RuntimeError('carrier: side-pair staging lacks released measured table support')
    c.event('carrier_side_pair_table_staging_success',position=p.tolist())
    c.event('carrier_table_staging_probe_success',position=p.tolist())


def run(c,m,name):
    stage(c,m,name)
    # Each palm stays in front of the rail, with its wrist above the table.
    # This is the thin-board side profile, applied at two separate rail points.
    from .reference_grasp import board_grasp
    from .held_ik import solve as held_solve
    for side,lo,hi in [('left',.03,1.5),('right',-1.5,-.03)]:
        c.ik.set_limit(side+'_shoulder_roll_joint',lo,hi)
        c.ik.set_limit(side+'_elbow_joint',.2,2.05)
    fit=m.contract['grasp_profiles']['frame']
    left=board_grasp(c,name,'left',fit,world_anchor=[-.08349098346,.08,0.],entry_yaw=0.,squeeze=.35,front_clearance=.03)
    hp,hR=c.hand_pose('left');original=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        return held_solve(c.ik,root_pos,root_quat,q,dict(tasks,left=('palm',hp,hR)),'left',*args,**kwargs)
    c.ik.solve=keep
    try:right=board_grasp(c,name,'right',fit,world_anchor=[-.08349098346,-.08,0.],entry_yaw=0.,squeeze=.35,front_clearance=.03)
    finally:c.ik.solve=original
    forces=side_forces(c,name)
    c.event('carrier_side_pair_contact_measurement',forces=forces)
    if min(forces.values())<.5:raise RuntimeError('carrier: side-pair requires measured contacts on both hands')
    carry=Carry(c,name=name,tilt_gain=.04,corr=.06);p=pose(c,name)[0]
    carry.move(p+[0,0,.06],0.,seconds=4.,settle=.6)
    actual,R,_,state=pose(c,name)
    if actual[2]<p[2]+.045 or R[2,2]<.98 or min(side_forces(c,name).values())<.5:
        raise RuntimeError('carrier: two side pinches did not sustain a measured flat lift')
    c.event('carrier_side_pair_flat_lift_success',position=actual.tolist())
    return left,right,carry


def supply_pair(c,m,name,left):
    """Keep the overhang free while bringing the far tie into two-arm reach."""
    from .held_ik import solve as held_solve
    p,R,yaw,_=pose(c,name)
    move(c,left,[p[0],.30,p[2]],R,5.,'carrier_near_tie_slide_laterally_before_inboard_motion')
    p,R,yaw,state=pose(c,name)
    if abs(p[1]-.30)>.015 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: lateral supply staging missed its goal or lost real hand contact')
    for side,lo,hi in [('left',.03,1.5),('right',-1.5,-.03)]:
        c.ik.set_limit(side+'_shoulder_roll_joint',lo,hi)
    fit=m.contract['grasp_profiles']['frame']
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset']),hand=fit['hand_joints'],squeeze=.25,hook=0.)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0.,-.1485,0.]
    right=HubGrip(c,name,'right',yaw,profile=profile,anchor=anchor)
    hp,hR=c.hand_pose('left');original=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        combined=dict(tasks,left=('palm',hp,hR))
        if kwargs.get('iters',0)>30:return original(root_pos,root_quat,q,combined,*args,**kwargs)
        return held_solve(c.ik,root_pos,root_quat,q,combined,'left',*args,**kwargs)
    c.ik.solve=keep
    try:acquire_hub(c,right,protect_other=True,hover=.08)
    finally:c.ik.solve=original
    forces=side_forces(c,name);c.event('carrier_supply_pair_contact_check',forces=forces)
    if min(forces.values())<.5:raise RuntimeError('carrier: far-tie acquisition lacks real two-hand contact')
    carry=Carry(c,name=name,tilt_gain=.04,corr=.06);start=pose(c,name)[0]
    carry.move(start+[0,0,.08],yaw,seconds=4.,settle=.6)
    p,R,_,state=pose(c,name)
    forces=side_forces(c,name)
    if p[2]<start[2]+.06 or R[2,2]<.98 or min(forces.values())<.5:
        raise RuntimeError('carrier: supply end-tie pair did not sustain a real balanced lift')
    c.event('carrier_supply_bimanual_lift_probe_success',position=p.tolist(),forces=forces)
    return left,right,carry
