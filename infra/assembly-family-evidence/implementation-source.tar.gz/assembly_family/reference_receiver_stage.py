"""Stage both unloaded hands before the near-post frame grasp carries load."""
import itertools
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,Pinch
from humanoid.g1_gear_assembly.solution.stage_base_hook import HOOK_PROFILE
from .grasp_clearance import ReceivingArm
from .held_ik import solve as held_solve


def prepare(c,right):
    p,R,_,_=pose(c,right.name)
    pivot=p+R@[.0841,-.00329093125,0.]
    angle=max(.30,float(np.arctan2(R[2,0],R[2,1])+.32))
    turn=Rotation.from_rotvec(-R[:,2]*angle).as_matrix()
    future_p=pivot+turn@(p-pivot);future_R=turn@R
    yaw=float(np.arctan2(future_R[1,0],future_R[0,0]))
    rz=Rotation.from_euler('z',yaw).as_matrix()
    tilt=future_R@(rz@Rotation.from_euler('x',np.pi/2).as_matrix()).T
    azimuth=Rotation.from_euler('z',yaw+np.pi).as_matrix()
    left_point=future_p+future_R@[.06,-.00329093125,.0773333333]+tilt@azimuth@HOOK_PROFILE['offset']+[0,0,.06]
    left_rotation=tilt@azimuth@HOOK_PROFILE['rotation']
    left=Pinch(c,right.name,'left',HOOK_PROFILE,opening=.2,squeeze=.55)
    target=c.q.copy()
    for grip in (left,right):
        opened=grip.curled(-grip.opening)
        joints=[grip.joint(j)for j in grip.shape]
        target[joints]=opened[joints]
    c.move_joints(target,seconds=1.)
    goals=dict(right.target(.10),left=('palm',left_point,left_rotation))
    c.ik.set_limit('waist_roll_joint',-.48,.48)
    c.ik.set_limit('waist_pitch_joint',-.46,.48)
    c.ik.set_limit('right_elbow_joint',-.8,1.8)
    screens=[ReceivingArm(c,right.name,side,protect_scene=True)for side in ('left','right')]
    base=c.actual_q().copy();active=c.ik.upper
    def clear(point):
        q=base.copy();q[active]=point
        return all(s.clear(q,hand_clearance=.010,self_clear=True,scene_clearance=.035,hand_scene_clearance=.035)for s in screens)
    def edge(a,b):
        count=max(1,int(np.ceil(np.max(abs(a-b))/.04)))
        return all(clear(a+(b-a)*i/count)for i in range(1,count+1))
    candidates=[]
    for yaw,ls,rs in itertools.product((0.,-.8,.8),(-1.5,0.,1.5),(-1.5,0.,1.5)):
        seed=c.q.copy()
        for joint,value in [('waist_yaw_joint',yaw),('left_shoulder_yaw_joint',ls),('right_shoulder_yaw_joint',rs)]:seed[c.index[joint]]=value
        q,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,goals,iters=400,damping=.02,w_rot=.5,max_step=.06)
        angles=[np.linalg.norm(Rotation.from_matrix(goal[2]@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec())for side,goal in goals.items()]
        if max(errors.values())<.004 and max(angles)<.04 and clear(q[active]):candidates.append(q[active].copy())
    if not candidates:raise RuntimeError('frame: unloaded receiving and donor hover poses are not jointly clear')
    start=base[active];candidates.sort(key=lambda q:np.linalg.norm(q-start));path=None
    for finish in candidates:
        if edge(start,finish):path=[start,finish];break
    if path is None:
        rng=np.random.default_rng(11);points=[start];parents=[-1]
        for iteration in range(3500):
            finish=candidates[iteration%len(candidates)]
            sample=finish if rng.random()<.35 else rng.uniform(c.ik.lo,c.ik.hi)
            parent=int(np.argmin([np.linalg.norm(q-sample)for q in points]));a=points[parent]
            b=a+(sample-a)*min(1.,.30/max(np.linalg.norm(sample-a),1e-9))
            if not edge(a,b):continue
            points.append(b);parents.append(parent)
            if edge(b,finish):
                path=[finish];index=len(points)-1
                while index!=-1:path.append(points[index]);index=parents[index]
                path=path[::-1];break
    if path is None:raise RuntimeError('frame: no clear unloaded receiver staging path')
    shortened=[path[0]];index=0
    while index<len(path)-1:
        last=len(path)-1
        while last>index+1 and not edge(path[index],path[last]):last-=1
        shortened.append(path[last]);index=last
    path=shortened
    c.event('right_frame_stage_receiver_before_loading',left_hover=left_point.tolist(),waypoints=[x.tolist()for x in path])
    actual_screens=[ReceivingArm(c,right.name,side,clearance=.005,protect_scene=True)for side in ('left','right')]
    def guard(current):
        for screen in actual_screens:
            if not screen.clear(current.actual_q(),scene_clearance=.005):raise RuntimeError('frame: unloaded staging lost actual clearance '+str(screen.blocked))
    c.joint_feedback['unloaded_receiver_stage']=guard
    try:
        for waypoint in path[1:]:
            target=c.q.copy();target[active]=waypoint
            c.move_joints(target,seconds=max(1.5,1.9*float(np.max(abs(target[active]-c.q[active])))/.35))
        c.move_hands(goals,seconds=1.,feedback=.5,rotation_feedback=.3)
    finally:c.joint_feedback.pop('unloaded_receiver_stage',None)
    kp,kR=c.hand_pose('left');original=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        combined=dict(tasks,left=('palm',kp,kR))
        if kwargs.get('iters',0)>30:return original(root_pos,root_quat,q,combined,*args,**kwargs)
        return held_solve(c.ik,root_pos,root_quat,q,combined,'right' if 'right' in tasks else 'left',*args,**kwargs)
    c.ik.solve=keep
    return original
