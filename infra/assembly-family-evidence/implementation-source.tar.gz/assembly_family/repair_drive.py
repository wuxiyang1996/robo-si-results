"""Give the real turning tip clearance above the base and time to settle."""
import numpy as np
from humanoid.g1_gear_assembly.solution import stage_drive


def drive(c,held,**kwargs):
    original_pose,original_move=stage_drive.tool_pose,held.move
    def raised(center,theta,r_end,z):
        p,yaw=original_pose(center,theta,r_end,z)
        return p+np.array([0.,0.,.004]),yaw
    def settled(*args,**kw):
        kw['settle']=max(1.,kw.get('settle',0.))
        return original_move(*args,**kw)
    c.event('repair_drive_raise_tip_and_settle',height_offset_m=.004,minimum_settle_seconds=1.)
    stage_drive.tool_pose=raised;held.move=settled
    try:return stage_drive.drive(c,held,**kwargs)
    finally:stage_drive.tool_pose=original_pose;held.move=original_move
