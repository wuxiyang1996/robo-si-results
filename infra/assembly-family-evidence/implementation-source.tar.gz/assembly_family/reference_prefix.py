"""Re-execute the physically witnessed first-fixture prefix with live measurements."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import pose
from . import fixture_reuse,reference_place
from .pose_carry import move


def fixture_first(c,m,fast=False):
    from .policies import ref_fixture_use_probe,ref_01
    ref_fixture_use_probe(c,m)
    name='left_frame';m.high_id='deploy_fixture';fixture=pose(c,'temporary_fixture')[0]
    fixture_reuse.slide(c,m.contract['grasp_profiles']['fixture'],fixture+[0,-.12,0],release_seconds=1.)
    grip=ref_01(c,m,slots=[name],park_idle=True,acquire_only=True,converged_acquire=False)
    move(c,grip,[.30,.20,1.02],np.eye(3),6.,'fixture_supported_frame_reorient')
    reference_place.frame(c,grip,name,time_scale=.5 if fast else 1.)
    if name not in c.env.status['completed'] or name not in c.env.status.get('fixture_uses',{}):
        raise RuntimeError('fixture: original first-use prefix did not preserve the original released installation')
    c.event('fixture_use_left_frame_integrated_success',uses=c.env.status['fixture_uses'])
