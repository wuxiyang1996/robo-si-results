"""A clear final under-edge pose can still have a blocked vertical approach."""
from copy import deepcopy
from types import SimpleNamespace
import unittest
import xml.etree.ElementTree as ET
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import XML,PALM
from .carrier_under_edge_profile import PROFILE
from .rail_opening import widen


class RailOpeningTests(unittest.TestCase):
    def test_opening_clears_the_upper_corner_before_under_edge_closure(self):
        root=ET.parse(XML).getroot()
        root.find('compiler').set('meshdir',str(XML.parent/'assets'))
        hand=deepcopy(root.find(".//body[@name='left_wrist_yaw_link']"))
        hand.set('pos','0 0 0');hand.set('childclass','g1')
        hand.remove(hand.find('joint'));ET.SubElement(hand,'freejoint',name='query_hand')
        world=root.find('worldbody')
        for node in list(world):world.remove(node)
        world.append(hand)
        ET.SubElement(world,'geom',name='rail',type='box',size='.16025 .00444063059 .004129108335')
        for tag in ('actuator','keyframe','sensor','contact','equality'):
            node=root.find(tag)
            if node is not None:root.remove(node)
        model=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'))
        data=mujoco.MjData(model);rail=model.geom('rail').id
        geoms=[g for g in np.flatnonzero(model.geom_contype)if g!=rail]
        rotation=np.asarray(PROFILE['rotation'])
        origin=np.asarray(PROFILE['palm_offset'])-rotation@PALM['left']
        def distance(shape,height):
            data.qpos[:3]=origin+[0.,0.,height]
            data.qpos[3:7]=Rotation.from_matrix(rotation).as_quat()[[3,0,1,2]]
            for joint,value in shape.items():
                data.qpos[model.jnt_qposadr[model.joint('left_hand_'+joint+'_joint').id]]=value
            mujoco.mj_forward(model,data)
            return min(mujoco.mj_geomDistance(model,data,g,rail,.1,None)for g in geoms)
        narrow=PROFILE['hand_joints'].copy()
        self.assertGreater(distance(narrow,0.),.001)
        self.assertLess(distance(narrow,.020),-.002)
        grip=SimpleNamespace(open=narrow.copy(),sign=1.,squeeze=.30)
        widen(grip,.18)
        self.assertGreater(min(distance(grip.open,float(h))for h in np.linspace(0.,.03,31)),.004)


if __name__=='__main__':unittest.main()
