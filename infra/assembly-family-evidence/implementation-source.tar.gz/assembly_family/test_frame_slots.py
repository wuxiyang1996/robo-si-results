"""Reject unsupported high releases and feet crossing a real slot wall."""
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
import numpy as np
from scipy.spatial.transform import Rotation
from .frame_slots import envelope


class SlotReleaseTests(unittest.TestCase):
    def setUp(self):
        path=Path(__file__).resolve().parents[1]/'humanoid/g1_reference_assembly/assets/shelf/catalog.json'
        self.env=SimpleNamespace(catalog=json.loads(path.read_text()),cfg=SimpleNamespace(origin=[.48,0,.74]))
        self.goal=np.asarray(self.env.cfg.origin)+self.env.catalog['parts']['left_frame']['goal_local']
    def test_feet_guided_below_rim_can_release_before_floor_contact(self):
        valid,_=envelope(self.env,'left_frame','left_frame',self.goal+[0,0,.015],np.eye(3))
        self.assertTrue(valid)
    def test_high_feet_and_wall_crossings_are_rejected(self):
        self.assertFalse(envelope(self.env,'left_frame','left_frame',self.goal+[0,0,.026],np.eye(3))[0])
        self.assertFalse(envelope(self.env,'left_frame','left_frame',self.goal+[.003,0,.015],np.eye(3))[0])
    def test_loaded_lean_uses_actual_feet_instead_of_part_center(self):
        R=Rotation.from_euler('x',.04).as_matrix();p=self.goal+[0,-.125*np.sin(.04),.015]
        self.assertTrue(envelope(self.env,'left_frame','left_frame',p,R)[0])


if __name__=='__main__':unittest.main()
