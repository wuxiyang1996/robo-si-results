"""Repair uses original support grace without crediting unsupported motion."""
import math
import unittest
from copy import deepcopy
from .gear_extension import RepairEvaluator
from .portable import catalog
from humanoid.g1_gear_assembly.task_spec import TaskConfig,GEAR_NAMES


class RepairSupportTests(unittest.TestCase):
    def ready(self,rule=RepairEvaluator.SUPPORT_LOSS_RULE):
        cfg=TaskConfig();data=catalog('GEAR');state={'objects':{}}
        for n,p in data['parts'].items():
            state['objects'][n]=dict(position=[cfg.origin[i]+p['goal_local'][i] for i in range(3)],
                quat=p.get('goal_quat_wxyz',[1,0,0,0]),linear_velocity=[0,0,0],angular_velocity=[0,0,0],
                robot_contact_force=0.,support_forces={'table' if n in ('base','turning_tool') else 'base':1.},contact_forces={})
        ev=RepairEvaluator(cfg,data,support_loss_rule=rule)
        fault=deepcopy(state);fault['objects']['medium_gear']['position'][0]+=.012
        ev.update(fault,.0025)
        extracted=deepcopy(fault);extracted['objects']['medium_gear']['position'][2]+=.06
        extracted['objects']['medium_gear']['robot_contact_force']=1.
        ev.update(extracted,.0025)
        for _ in range(1500):
            if ev.stage==5:break
            ev.update(state,.0025)
        self.assertEqual(ev.stage,5)
        state['objects']['turning_tool']['robot_contact_force']=1.
        state['objects']['turning_tool']['contact_forces']={'small_gear':.2}
        state['objects']['small_gear']['contact_forces']={'medium_gear':.2}
        state['objects']['medium_gear']['contact_forces']={'large_gear':.2}
        return ev,state

    def yaw(self,state,small):
        for n,ratio in [('small_gear',1.),('medium_gear',-.5),('large_gear',1/3)]:
            angle=small*ratio;state['objects'][n]['quat']=[math.cos(angle/2),0,0,math.sin(angle/2)]

    def prime(self,ev,state):
        for i in range(1,11):self.yaw(state,.01*i);ev.update(state,.0025)
        self.assertGreater(ev.credited_angles['small_gear'],.09)

    def test_gap_preserves_credit_but_never_credits_gap_motion(self):
        ev,state=self.ready();self.prime(ev,state);before=ev.credited_angles.copy()
        state['objects']['small_gear']['support_forces']={}
        for i in range(11,21):self.yaw(state,.01*i);ev.update(state,.0025)
        self.assertEqual(ev.stage,5);self.assertEqual(ev.credited_angles,before)
        state['objects']['small_gear']['support_forces']={'base':1.}
        self.yaw(state,.21);ev.update(state,.0025)
        self.assertAlmostEqual(ev.credited_angles['small_gear']-before['small_gear'],.01)
        self.assertEqual(ev.loss_dwell['small_gear'],0.)

    def test_persistent_loss_revokes_all_drive_evidence_at_original_boundary(self):
        ev,state=self.ready();self.prime(ev,state)
        state['objects']['small_gear']['support_forces']={}
        for _ in range(119):ev.update(state,.0025)
        self.assertEqual(ev.stage,5)
        ev.update(state,.0025)
        self.assertEqual(ev.stage,0);self.assertEqual(ev.completed,[])
        self.assertTrue(all(v==0. for v in ev.credited_angles.values()))
        self.assertTrue(all(v==0. for v in ev.mesh_contact_seconds.values()))
        self.assertTrue(all(v==0. for v in ev.mesh_contact_impulse.values()))
        self.assertEqual(ev.drive_motion_seconds,0.)
        self.assertIn('medium_gear',ev.extracted)

    def test_recovered_and_separate_component_gaps_do_not_accumulate(self):
        ev,state=self.ready();self.prime(ev,state)
        for _ in range(3):
            for n in ('small_gear','medium_gear'):
                state['objects'][n]['support_forces']={}
                for _ in range(100):ev.update(state,.0025)
                state['objects'][n]['support_forces']={'base':1.};ev.update(state,.0025)
        self.assertEqual(ev.stage,5)

    def test_legacy_recordings_keep_immediate_reset(self):
        ev,state=self.ready('immediate_v0');self.prime(ev,state)
        state['objects']['small_gear']['support_forces']={};ev.update(state,.0025)
        self.assertEqual(ev.stage,0);self.assertEqual(ev.credited_angles['small_gear'],0.)

    def test_grace_does_not_waive_tool_contact_or_gear_ratio(self):
        ev,state=self.ready();state['objects']['turning_tool']['contact_forces']={}
        for i in range(1,201):self.yaw(state,.01*i);ev.update(state,.0025)
        self.assertEqual(ev.credited_angles['small_gear'],0.);self.assertEqual(ev.stage,5)
        state['objects']['turning_tool']['contact_forces']={'small_gear':.2}
        for i in range(201,401):
            angle=.01*i;state['objects']['small_gear']['quat']=[math.cos(angle/2),0,0,math.sin(angle/2)]
            ev.update(state,.0025)
        self.assertGreater(ev.credited_angles['small_gear'],1.57);self.assertEqual(ev.stage,5)
        self.assertFalse(ev.conditions['drive_test']['ratios'])

    def test_valid_contact_ratios_and_release_are_still_required(self):
        ev,state=self.ready()
        for i in range(1,170):
            self.yaw(state,.01*i);ev.update(state,.0025)
            if ev.stage==6:break
        self.assertEqual(ev.stage,6);self.assertFalse(ev.success)
        state['objects']['turning_tool']['robot_contact_force']=0.
        state['objects']['turning_tool']['contact_forces']={}
        for _ in range(801):ev.update(state,.0025)
        self.assertTrue(ev.success)

    def test_persistent_loss_after_drive_revokes_release_progress(self):
        ev,state=self.ready()
        for i in range(1,170):
            self.yaw(state,.01*i);ev.update(state,.0025)
            if ev.stage==6:break
        state['objects']['cover']['support_forces']={}
        for _ in range(120):ev.update(state,.0025)
        self.assertEqual(ev.stage,0);self.assertFalse(ev.success)


if __name__=='__main__':unittest.main()
