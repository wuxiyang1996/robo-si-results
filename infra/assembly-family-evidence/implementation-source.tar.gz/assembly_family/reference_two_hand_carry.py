"""Plan and execute a carried rail while retaining both physical grasps.

All scene poses below belong to independent kinematic queries. Execution uses
ordinary bounded joint targets; neither hand is attached to the payload.
"""
from types import SimpleNamespace
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation, Slerp
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from humanoid.g1_support_retrieval.task_spec import JOINT_NAMES
from humanoid.g1_gear_assembly.solution.skills import pose, side_forces
from .grasp_clearance import ReceivingArm


def move(c,left,right):
    name=right.name;base=c.actual_q().copy();p,R,_,_=pose(c,name)
    free_left=getattr(c,'carrier_donor_position_only',False)
    fk=UpperBodyIK();local={};bias={}
    fk._set(c.env.base_position,(1,0,0,0),c.q)
    for side in ('left','right'):
        hp,hR=c.hand_pose(side)
        local[side]=(R.T@(hp-p),R.T@hR)
        bias[side]=(fk.hand_point(side,'palm').copy()-hp,
                    fk.d.xmat[fk.wrist[side]].reshape(3,3).copy()@hR.T)
    states={n:dict(c.object_state(n)) for n in c.env.objects}
    env=SimpleNamespace(base_position=c.env.base_position,catalog=c.env.catalog,cfg=c.env.cfg,objects=c.env.objects)
    query=SimpleNamespace(ik=c.ik,env=env,actual_q=lambda:base,object_state=lambda n:states[n])
    screens=[ReceivingArm(query,name,s,protect_scene=True) for s in ('left','right')]
    queries=0;blocked=None

    def clear(q):
        nonlocal queries,blocked
        queries+=1;blocked=None
        fk._set(c.env.base_position,(1,0,0,0),q)
        rr=fk.d.xmat[fk.wrist['right']].reshape(3,3).copy()
        pr=rr@local['right'][1].T
        pp=fk.hand_point('right','palm')-pr@local['right'][0]
        le=np.linalg.norm(fk.hand_point('left','palm')-(pp+pr@local['left'][0]))
        lr=np.linalg.norm(Rotation.from_matrix((pr@local['left'][1])@fk.d.xmat[fk.wrist['left']].reshape(3,3).T).as_rotvec())
        if le>.003 or (not free_left and lr>.04):
            blocked=dict(reason='relative_grasp',position_m=float(le),rotation_rad=float(lr));return False
        states[name].update(position=pp.tolist(),quat=Rotation.from_matrix(pr).as_quat()[[3,0,1,2]].tolist())
        for screen in screens:
            if not screen.clear(q,self_clear=True):blocked=screen.blocked;return False
        screen=screens[0];model,d=screen.ik.m,screen.ik.d
        for pg in screen.part:
            extent=float(np.abs(d.geom_xmat[pg].reshape(3,3)[2])@model.geom_size[pg])
            if d.geom_xpos[pg,2]-extent<c.env.cfg.table_height+.015:
                blocked=dict(reason='payload_table');return False
            for sg,owner,_,_ in screen.scene:
                if np.linalg.norm(d.geom_xpos[pg]-d.geom_xpos[sg])>model.geom_rbound[pg]+model.geom_rbound[sg]+.012:continue
                if mujoco.mj_geomDistance(model,d,pg,sg,.012,None)<.012:
                    blocked=dict(reason='payload_scene',object=owner);return False
        return True

    def edge(a,b):
        count=max(10,int(np.ceil(np.max(abs(b[c.ik.upper]-a[c.ik.upper]))/.025)))
        return all(clear(a+(b-a)*f/count)for f in range(1,count+1))

    def solve(previous,goals):
        seeds=[previous.copy()]
        for joint in ('right_shoulder_roll_joint','right_shoulder_yaw_joint','right_elbow_joint','waist_roll_joint','waist_yaw_joint','left_shoulder_yaw_joint'):
            for change in (-.35,.35):
                seed=previous.copy();seed[c.index[joint]]+=change;seeds.append(seed)
        for seed in seeds:
            q,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,goals,iters=150,damping=.02,w_rot=.5,max_step=.05)
            angles=[np.linalg.norm(Rotation.from_matrix(goals[s][2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())for s in goals if goals[s][2] is not None]
            if max(errors.values())>.003 or max(angles)>.035:continue
            if np.max(abs(q[c.ik.upper]-previous[c.ik.upper]))>.45:continue
            if clear(q) and edge(previous,q):return q
        return None

    if not clear(base):raise RuntimeError(name+': bimanual start lacks clearance: '+str(blocked))
    path=None;goal=np.array([.4,0.,1.04])
    for mid in ([.32,-.08,.98],[.35,-.1,1.0],[.36,-.12,1.0],[.36,-.15,1.0],[.35,-.1,.95]):
        previous=base.copy();candidate=[base.copy()];start_p,start_R=p.copy(),R.copy()
        valid=True
        for end_p,end_R in ((np.array(mid),R),(np.array(mid),np.eye(3)),(goal,np.eye(3))):
            orient=Slerp([0.,1.],Rotation.from_matrix(np.stack([start_R,end_R])))
            for f in np.linspace(0,1,51):
                point=start_p+f*(end_p-start_p);rot=orient(f).as_matrix()
                goals={s:('palm',point+rot@v[0],None if free_left and s=='left' else rot@v[1])for s,v in local.items()}
                result=solve(previous,goals)
                if result is None:valid=False;break
                candidate.append(result.copy());previous=result
            if not valid:break
            start_p,start_R=end_p,end_R
        c.event('carrier_two_hand_route_screen',intermediate=mid,clear=valid,queries=queries,blocked=blocked)
        if valid:path=candidate;break
    if path is None:raise RuntimeError(name+': no continuously clear bimanual route')
    c.event('carrier_two_hand_carry_plan',goal=goal.tolist(),donor_rotation_constraint='free_hook_rotation' if free_left else 'rigid',waypoints=[q.tolist()for q in path],queries=queries,
            actual_grasp_transforms={s:dict(position=v[0].tolist(),rotation=v[1].tolist())for s,v in local.items()},
            motor_reference_bias={s:dict(position=v[0].tolist(),rotation=v[1].tolist())for s,v in bias.items()})
    actual_screens=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True) for s in ('left','right')]
    weak=0;cp={s:np.zeros(3)for s in local};cr={s:np.zeros(3)for s in local}
    maximum_left_force=0.
    class DonorReleaseReady(Exception):pass
    def advance(seed):
        nonlocal weak,maximum_left_force
        fk._set(c.env.base_position,(1,0,0,0),seed);goals={}
        for side in local:
            desired=fk.hand_point(side,'palm').copy();desired_R=fk.d.xmat[fk.wrist[side]].reshape(3,3).copy()
            actual,actual_R=c.hand_pose(side);error=desired-actual
            rv=Rotation.from_matrix(desired_R@actual_R.T).as_rotvec()
            cp[side]=np.clip(cp[side]+np.clip(.035*error,-.0002,.0002),-.025,.025)
            cr[side]=np.clip(cr[side]+np.clip(.02*rv,-.0005,.0005),-.12,.12)
            goals[side]=('palm',desired+bias[side][0]+cp[side]+np.clip(.4*error,-.008,.008),
                         bias[side][1]@Rotation.from_rotvec(cr[side]+.3*rv).as_matrix()@desired_R)
        solved,_=c.ik.solve(c.env.base_position,(1,0,0,0),seed,goals,iters=24,damping=.015,w_rot=.5,max_step=.05)
        c.q[c.ik.upper]+=np.clip(solved[c.ik.upper]-c.q[c.ik.upper],-.008,.008);c.step()
        forces=side_forces(c,name);maximum_left_force=max(maximum_left_force,forces['left'])
        weak=weak+1 if sum(forces.values())<.05 else 0
        if weak>10:raise RuntimeError(name+': both physical grasps lost during two-hand carry')
        for screen in actual_screens:
            if not screen.clear(c.actual_q(),scene_clearance=.010):
                raise RuntimeError(name+': two-hand actual clearance lost: '+str(screen.blocked))
        if getattr(c,'carrier_release_donor_on_tilt',False):
            _,observed_R,_,_=pose(c,name)
            if observed_R[2,2]>.50 and forces['right']>.5:
                c.event('carrier_release_hook_before_palm_enters_flat_rail',normal_z=float(observed_R[2,2]),forces=forces)
                raise DonorReleaseReady()
    c.event('carrier_two_hand_carry_start',forces=side_forces(c,name))
    try:
        for a,b in zip(path,path[1:]):
            count=max(3,int(np.ceil(np.max(abs(b[c.ik.upper]-a[c.ik.upper]))/(.20*.02))))
            for i in range(count):advance(a+(b-a)*(i+1)/count)
        for _ in range(50):advance(path[-1])
    except DonorReleaseReady:
        from .held_ik import solve as hold_loaded
        hp,hR=c.hand_pose('right');fk._set(c.env.base_position,(1,0,0,0),c.q)
        nominal_p=fk.hand_point('right','palm').copy()
        nominal_R=fk.d.xmat[fk.wrist['right']].reshape(3,3).copy()
        original=c.ik.solve
        def hold_receiver(root_pos,root_quat,q,tasks,*args,**kwargs):
            ap,ar=c.hand_pose('right')
            rv=Rotation.from_matrix(hR@ar.T).as_rotvec()
            goal=('palm',nominal_p+np.clip(.5*(hp-ap),-.008,.008),Rotation.from_rotvec(.3*rv).as_matrix()@nominal_R)
            return hold_loaded(c.ik,root_pos,root_quat,q,dict(tasks,right=goal),'right',*args,**kwargs)
        c.ik.solve=hold_receiver
        try:left.release(seconds=1.5,rise=.10)
        finally:c.ik.solve=original
        if side_forces(c,name)['right']<.5:raise RuntimeError(name+': staged donor release lost the real receiver grasp')
        from .reference_carry_path import move as carry
        carry(c,right,goal,np.eye(3))
        actual,actual_R,_,_=pose(c,name)
        if np.linalg.norm(actual-goal)>.02 or actual_R[2,2]<.95 or side_forces(c,name)['right']<.5:
            raise RuntimeError(name+': staged single-receiver carry did not reach a measured horizontal hold')
        c.event('carrier_staged_donor_release_flat_hold',position=actual.tolist(),forces=side_forces(c,name))
        return
    actual,actual_R,_,state=pose(c,name)
    c.event('carrier_two_hand_carry_end',position=actual.tolist(),rotation=actual_R.tolist(),forces=side_forces(c,name),maximum_left_force_n=maximum_left_force)
    if np.linalg.norm(actual-goal)>.02 or actual_R[2,2]<.95 or min(side_forces(c,name).values())<.05 or maximum_left_force<.5:
        raise RuntimeError(name+': two-hand carry failed measured horizontal hold')
