"""Move the existing finger pads beneath a rail only after a measured lift."""
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
from humanoid.g1_gear_assembly.solution.skills import pose,smooth,side_forces
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip
from humanoid.g1_gear_assembly.solution.stage_base_wrap import Carry
from .carrier_under_edge_profile import PROFILE
from .grasp_clearance import ReceivingArm
from .rail_contact_depth import measure


def transition(c,name,grips):
    p,R,yaw,state=pose(c,name)
    if p[2]<c.env.cfg.table_height+.019 or state['support_forces'].get('table',0)>.05:
        raise RuntimeError(name+': under-rail transition requires measured space above the table')
    profile=dict(rotation=np.asarray(PROFILE['rotation']),offset=np.asarray(PROFILE['palm_offset']),hand=PROFILE['hand_joints'],squeeze=.15,hook=0.)
    fresh={};start_q=c.q.copy();goal_q=start_q.copy();hands={s:c.hand_pose(s)for s in grips}
    old_sums={s:g.sums.copy()for s,g in grips.items()};targets={}
    for side,y in [('left',.1485),('right',-.1485)]:
        anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,y,0.])
        g=HubGrip(c,name,side,yaw+np.pi,profile=profile,anchor=anchor);fresh[side]=g;targets[side]=g.target()[side]
        for j,v in g.open.items():goal_q[g.joint(j)]=v
        for j,sign in [('thumb_1',g.sign),('index_0',-g.sign),('middle_0',-g.sign)]:goal_q[g.joint(j)]+=sign*.15
    c.ik._set(c.env.base_position,(1,0,0,0),start_q)
    bias={s:(c.ik.hand_point(s,'palm').copy()-hp,c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).copy()@hR.T)for s,(hp,hR)in hands.items()}
    rotation={s:Slerp([0,1],Rotation.from_matrix([hands[s][1],targets[s][2]]))for s in grips}
    cp={s:np.zeros(3)for s in grips};cr={s:np.zeros(3)for s in grips}
    guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
    c.event('carrier_transition_to_under_rail_contacts',profile=PROFILE,seconds=1.2,settle_seconds=.4)
    weak=0
    for i in range(80):
        f=smooth(min(1.,(i+1)/60));goals={}
        for side,g in grips.items():
            g.hook=0.;g.sums={finger:(1-f)*old_sums[side][finger]+f*fresh[side].sums[finger]for finger in g.sums}
            for j in ('thumb_0','thumb_1','index_0','middle_0'):
                idx=g.joint(j);c.q[idx]=(1-f)*start_q[idx]+f*goal_q[idx]
            point=hands[side][0]+f*(targets[side][1]-hands[side][0]);rot=rotation[side](f).as_matrix()
            hp,hR=c.hand_pose(side);error=point-hp;rv=Rotation.from_matrix(rot@hR.T).as_rotvec()
            cp[side]=np.clip(cp[side]+np.clip(.04*error,-.0002,.0002),-.02,.02)
            cr[side]=np.clip(cr[side]+np.clip(.025*rv,-.0005,.0005),-.08,.08)
            goals[side]=('palm',point+bias[side][0]+cp[side]+.3*error,bias[side][1]@Rotation.from_rotvec(cr[side]+.3*rv).as_matrix()@rot)
        for screen in guards:
            if not screen.clear(c.actual_q(),scene_clearance=.005,hand_scene_clearance=0.):raise RuntimeError(name+': under-rail transition lacks measured clearance '+str(screen.blocked))
        c.reach(goals,iters=24,rate=.4);c.step()
        weak=weak+1 if c.object_state(name)['robot_contact_force']<.5 else 0
        if weak>10:raise RuntimeError(name+': contact lost during under-rail transition')
        if i%10==0:c.event('carrier_under_rail_transition_measurement',fraction=f,contacts=measure(c,name),position=pose(c,name)[0].tolist())
    contacts=measure(c,name);p,R,_,state=pose(c,name)
    if R[2,2]<.95 or p[2]<c.env.cfg.table_height+.015 or any(s not in contacts or not any(v['local_z_m']<-.002 and v['force_n']>.1 for v in contacts[s]['points'])for s in grips):
        raise RuntimeError(name+': measured contacts do not establish both under-rail supports')
    for side,g in grips.items():g.open=fresh[side].open;g.rotation=fresh[side].rotation;g.offset=fresh[side].offset;g.anchor=fresh[side].anchor
    carry=Carry(c,name=name,tilt_gain=.04,corr=.06)
    c.ik._set(c.env.base_position,(1,0,0,0),c.q)
    carry.local={s:(R.T@(c.ik.hand_point(s,'palm').copy()-p),R.T@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).copy())for s in grips}
    c.event('carrier_under_rail_supports_measured',contacts=contacts,position=p.tolist(),forces=side_forces(c,name))
    return carry


def sequential(c,name,grips):
    """Keep one loaded hand while opening, lowering and closing the other."""
    profile=dict(rotation=np.asarray(PROFILE['rotation']),offset=np.asarray(PROFILE['palm_offset']),hand=PROFILE['hand_joints'],squeeze=.20,hook=0.)
    for side,y in [('left',.1485),('right',-.1485)]:
        donor='right' if side=='left' else 'left'
        p,R,yaw,state=pose(c,name)
        if p[2]<c.env.cfg.table_height+.025 or R[2,2]<.95:raise RuntimeError(name+': alternating undergrasp lacks level table clearance')
        anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,y,0.])
        new=HubGrip(c,name,side,yaw+np.pi,profile=profile,anchor=anchor)
        initial_q=c.q.copy();old=grips[side];old_sums=old.sums.copy()
        opened=initial_q.copy()
        for j,v in new.open.items():opened[new.joint(j)]=v
        closed=opened.copy()
        for j,sign in [('thumb_1',new.sign),('index_0',-new.sign),('middle_0',-new.sign)]:closed[new.joint(j)]+=sign*.20
        hp,hR=c.hand_pose(side);dp,dR=c.hand_pose(donor)
        c.ik._set(c.env.base_position,(1,0,0,0),c.q)
        donor_bias=(c.ik.hand_point(donor,'palm').copy()-dp,c.ik.d.xmat[c.ik.wrist[donor]].reshape(3,3).copy()@dR.T)
        receiver_bias=(c.ik.hand_point(side,'palm').copy()-hp,c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).copy()@hR.T)
        donor_local=(R.T@(dp-p),R.T@dR);point=new.target()[side][1];rotation=new.rotation
        cp=np.zeros(3);cr=np.zeros(3);part_cp=np.zeros(3);part_cr=np.zeros(3)
        guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
        c.event('carrier_alternating_under_rail_regrasp',receiver=side,donor=donor,contact_position=point.tolist(),profile=PROFILE)
        start_point,start_R=hp.copy(),hR.copy();closed_stop=False;weak_donor=0
        for phase,seconds,end_point,end_R,start_hand,end_hand in [
            ('open_above',.3,point+[0,0,.020],rotation,initial_q,opened),
            ('descend_below_edge',.4,point,rotation,opened,opened),
            ('close_under_edge',.4,point,rotation,opened,closed),
            ('settle_under_edge',.2,point,rotation,closed,closed)]:
            turns=Slerp([0,1],Rotation.from_matrix([start_R,end_R]));count=round(seconds/.02)
            for i in range(count):
                f=smooth((i+1)/count)
                if phase=='open_above':old.sums={finger:(1-f)*old_sums[finger]+f*new.sums[finger]for finger in old.sums};old.hook=0.
                if not (phase in ('close_under_edge','settle_under_edge') and closed_stop):
                    for j in ('thumb_0','thumb_1','index_0','middle_0'):
                        idx=new.joint(j);c.q[idx]=start_hand[idx]+f*(end_hand[idx]-start_hand[idx])
                desired=start_point+f*(np.asarray(end_point)-start_point);want=turns(f).as_matrix()
                actual,actual_R=c.hand_pose(side);ep=desired-actual;er=Rotation.from_matrix(want@actual_R.T).as_rotvec()
                cp=np.clip(cp+np.clip(.04*ep,-.0002,.0002),-.020,.020);cr=np.clip(cr+np.clip(.025*er,-.0005,.0005),-.08,.08)
                observed,observed_R,_,state=pose(c,name)
                part_cp=np.clip(part_cp+np.clip(.04*(p-observed),-.0002,.0002),-.020,.020)
                rv=Rotation.from_matrix(R@observed_R.T).as_rotvec();part_cr=np.clip(part_cr+np.clip(.025*rv,-.001,.001),-.15,.15)
                desired_R=Rotation.from_rotvec(part_cr).as_matrix()@R
                tasks={side:('palm',desired+receiver_bias[0]+cp+.3*ep,receiver_bias[1]@Rotation.from_rotvec(cr+.3*er).as_matrix()@want),
                       donor:('palm',p+part_cp+desired_R@donor_local[0]+donor_bias[0],donor_bias[1]@desired_R@donor_local[1])}
                for screen in guards:
                    if not screen.clear(c.actual_q(),scene_clearance=.005,hand_scene_clearance=0.):raise RuntimeError(name+': alternating regrasp clearance lost '+str(screen.blocked))
                c.reach(tasks,iters=28,rate=.4);c.step()
                forces=side_forces(c,name)
                weak_donor=weak_donor+1 if forces[donor]<.5 else 0
                if weak_donor>10:raise RuntimeError(name+': supporting hand lost contact during alternating regrasp')
                if phase=='close_under_edge' and forces[side]>20.:closed_stop=True
            start_point,start_R=np.asarray(end_point),end_R
            c.event('carrier_alternating_regrasp_measurement',receiver=side,subphase=phase,contacts=measure(c,name),position=pose(c,name)[0].tolist())
        contacts=measure(c,name)
        if side not in contacts or not any(v['local_z_m']<-.002 and v['force_n']>.1 for v in contacts[side]['points']):
            raise RuntimeError(name+': receiver did not establish a measured under-rail contact')
        old.open=new.open;old.sums=new.sums;old.rotation=new.rotation;old.offset=new.offset;old.anchor=new.anchor
    p,R,_,_=pose(c,name);carry=Carry(c,name=name,tilt_gain=.04,corr=.06)
    c.ik._set(c.env.base_position,(1,0,0,0),c.q)
    carry.local={s:(R.T@(c.ik.hand_point(s,'palm').copy()-p),R.T@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).copy())for s in grips}
    c.event('carrier_both_under_rail_supports_measured',contacts=measure(c,name),position=p.tolist())
    return carry
