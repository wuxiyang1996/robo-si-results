"""Move a released-support frame out from under an installed frame before lifting."""
from copy import deepcopy
from types import SimpleNamespace
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,smooth
from .grasp_clearance import ReceivingArm


def move(c,grip,dx=-.12,dy=0.):
    name,side=grip.name,grip.side;p,R,_,state=pose(c,name);hp,hR=c.hand_pose(side)
    displacement=np.array([dx,dy,0.])
    if sum(state['support_forces'].values())<.05:raise RuntimeError(name+': slide requires real external support')
    measured=deepcopy(c.env.trusted_state()['objects']);q=c.actual_q().copy()
    query=SimpleNamespace(ik=c.ik,actual_q=lambda:q,object_state=lambda n:measured[n],
                          env=SimpleNamespace(base_position=c.env.base_position,catalog=c.env.catalog,cfg=c.env.cfg,objects=c.env.objects))
    screens=[ReceivingArm(query,name,s,protect_scene=True)for s in ('left','right')]
    solution=q.copy()
    for f in np.linspace(0,1,31):
        delta=displacement*f;measured[name]['position']=(p+delta).tolist()
        solution,errors=c.ik.solve(c.env.base_position,(1,0,0,0),solution,{side:('palm',hp+delta,hR)},iters=150,damping=.015,w_rot=.5,max_step=.05)
        if max(errors.values())>.003 or not all(s.clear(solution,scene_clearance=.025,self_clear=True,hand_scene_clearance=0.)for s in screens):
            raise RuntimeError(name+': supported slide has no clear arm path '+str(dict(fraction=float(f),blocked=[s.blocked for s in screens])))
    c.event('second_fixture_slide_frame_before_lifting',displacement_m=displacement.tolist(),wrist='fixed_world_rotation',support='real_table_and_fixture_contacts')
    c.ik._set(c.env.base_position,(1,0,0,0),c.q)
    bias=c.ik.hand_point(side,'palm').copy()-hp;bias_R=c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).copy()@hR.T
    cp=np.zeros(3);cr=np.zeros(3);weak=0
    guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
    for i in range(250):
        if not all(s.clear(c.actual_q(),scene_clearance=.005,hand_scene_clearance=0.)for s in guards):
            raise RuntimeError(name+': actual arm clearance lost during supported slide')
        desired=hp+displacement*smooth(min(1.,(i+1)/200))
        actual,actual_R=c.hand_pose(side);error=desired-actual;rv=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
        cp=np.clip(cp+np.clip(.04*error,-.0002,.0002),-.025,.025);cr=np.clip(cr+np.clip(.025*rv,-.001,.001),-.10,.10)
        c.reach({side:('palm',desired+bias+cp+np.clip(.5*error,-.008,.008),bias_R@Rotation.from_rotvec(cr+.3*rv).as_matrix()@hR)},rate=.4,iters=24);c.step()
        state=c.object_state(name);weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>10:raise RuntimeError(name+': rail contact lost during supported slide')
    after,_,_,state=pose(c,name)
    c.event('second_fixture_supported_slide_measurement',position=after.tolist(),supports=state['support_forces'])
    if np.linalg.norm(after[:2]-(p+displacement)[:2])>.02 or sum(state['support_forces'].values())<.05:
        raise RuntimeError(name+': supported slide missed its measured position')
    grip.release(seconds=1.5,rise=.12);c.hold(.6)
