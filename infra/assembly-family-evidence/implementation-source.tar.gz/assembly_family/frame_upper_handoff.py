"""Exchange a measured lower-rail load for an upper-rail hanging grasp."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,Pinch,smooth,side_forces
from humanoid.g1_gear_assembly.solution.stage_base_hook import HOOK_PROFILE
from .paired_grasp import acquire
from .held_ik import solve as held_solve
from .grasp_clearance import ReceivingArm


def transfer(c,donor):
    name=donor.name;p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([0.,-.00329093125,.0773333333])
    receiver=Pinch(c,name,'left',HOOK_PROFILE,anchor=anchor,azimuth=yaw+np.pi,opening=.25,squeeze=.55)
    flat=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
    tilt=R@Rotation.from_euler('x',np.pi).as_matrix()@flat.T
    receiver.offset=tilt@receiver.offset;receiver.rotation=tilt@receiver.rotation
    local_p=R.T@(Rotation.from_euler('z',yaw).as_matrix()@anchor+receiver.offset)
    local_R=R.T@receiver.rotation
    def target(height=0.):
        p,R,_,_=pose(c,name)
        return {'left':('palm',p+R@local_p+[0.,0.,height],R@local_R)}
    receiver.target=target
    receiver.preserve_donor_reference=True;receiver.donor_pose_only=True
    receiver.measured_close_force_n=40.;receiver.overhead_receiver_route=True
    receiver.scene_clearance_m=.025
    solve=c.ik.solve;keep_side='right';hp,hR=c.hand_pose(keep_side)
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        combined={keep_side:('palm',hp,hR),**tasks}
        if kwargs.get('iters',0)>30:return solve(root_pos,root_quat,q,combined,*args,**kwargs)
        return held_solve(c.ik,root_pos,root_quat,q,combined,keep_side,*args,**kwargs)
    guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
    def guard(current):
        for screen in guards:
            if not screen.clear(current.actual_q(),scene_clearance=.005,hand_scene_clearance=0.):
                raise RuntimeError(name+': upper-rail handoff lost measured clearance '+str(screen.blocked))
    c.joint_feedback['upper_rail_handoff_clearance']=guard
    c.event('second_fixture_handoff_to_upper_rail',rail_local_z_m=.0773333333,face_flip_rad=float(np.pi),receiver_force_n=40.)
    try:
        c.ik.solve=keep
        acquire(c,receiver,receiver_clearance=True,hover=.06,elbow_branches=True,protect_scene=True)
        c.ik.solve=solve
        # Raise both real contacts together before the lower hand opens.
        # This gives the inverted frame room to swing below the upper rail.
        measured={s:c.hand_pose(s)for s in ('left','right')}
        c.ik._set(c.env.base_position,(1,0,0,0),c.q)
        biases={s:(c.ik.hand_point(s,'palm').copy()-measured[s][0],c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).copy()@measured[s][1].T)for s in measured}
        correction={s:np.zeros(3)for s in measured}
        c.event('second_fixture_bilateral_handoff_clearance_lift',rise_m=.15)
        for i in range(200):
            tasks={}
            for s,(point,rot)in measured.items():
                desired=point+[0.,0.,.15*smooth(min(1.,(i+1)/175))]
                actual,_=c.hand_pose(s);error=desired-actual
                correction[s]=np.clip(correction[s]+np.clip(.04*error,-.0002,.0002),-.025,.025)
                tasks[s]=('palm',desired+biases[s][0]+correction[s],biases[s][1]@rot)
            c.reach(tasks,iters=24,rate=.4);c.step()
            if min(side_forces(c,name).values())<.05:raise RuntimeError(name+': bilateral lift lost a real hand contact')
        p,R,_,_=pose(c,name)
        if (p+R@np.array([0.,-.00329093125,.0773333333]))[2]<1.04:
            raise RuntimeError(name+': upper rail lacks gravity-swing clearance')
        keep_side='left';hp,hR=c.hand_pose('left');c.ik.solve=keep
        donor.release(seconds=1.3,rise=.10)
        from .policies import park_unused_arm_high
        park_unused_arm_high(c,'right')
    finally:
        c.ik.solve=solve;c.joint_feedback.pop('upper_rail_handoff_clearance',None)
    if side_forces(c,name)['left']<.5:raise RuntimeError(name+': upper-rail receiver did not retain the frame')
    return receiver
