"""Use the original tooth-gap drive inside the clear robot-facing sector."""
import math
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose
from humanoid.g1_gear_assembly.solution.stage_drive import small_center,tool_pose,gap_angle


def drive(c,held,strokes=10,converged=False):
    if converged:
        c.ik.set_limit('waist_pitch_joint',-.46,.48)
        c.ik.set_limit('waist_roll_joint',-.48,.48)
        c.ik.set_limit('left_elbow_joint',-.8,1.8)
        c.event('repair_tool_use_authored_close_workspace',planning_only=True,hardware_limits_unchanged=True)
    sign=c.env.cfg.drive_sign
    low,high=map(math.radians,(180.,210.))
    start,stop=(low,high) if sign>0 else (high,low)
    center,_=small_center(c)
    z=center[2]-(c.env.catalog['gear_meta']['shaft_top']-c.env.catalog['gear_meta']['shaft_bottom'])/4
    if converged:z+=.004
    inside,outside,far=.023,.036,.095
    original_move=held.move
    def settled_move(point,yaw,**kwargs):
        if not converged:return original_move(point,yaw,**kwargs)
        kwargs['seconds']=max(2.,kwargs.get('seconds',2.))
        original_move(point,yaw,**kwargs)
        stable=0
        for _ in range(250):
            p,R,actual_yaw,state=pose(c,'turning_tool')
            position=float(np.linalg.norm(p-point));angle=float(np.linalg.norm(Rotation.from_matrix(Rotation.from_euler('z',yaw).as_matrix()@R.T).as_rotvec()))
            stable=stable+1 if position<.0015 and angle<.025 and np.linalg.norm(state['linear_velocity'])<.008 else 0
            if stable>=10:break
            held.track(point,yaw,gain=.03)
        else:raise RuntimeError('tool: entry waypoint did not settle before advancing; '+str(dict(position_error=position,rotation_error=angle)))
        c.event('repair_sector_measured_waypoint_settled',position_error_m=position,rotation_error_rad=angle)
    move=settled_move
    c.event('repair_sector_gap_drive',sector_degrees=[180,210],tooth_height_m=float(z),maximum_strokes=strokes)
    theta=gap_angle(c,start,sign)
    move(*tool_pose(center,theta,far,z+.08),seconds=3.5,settle=.4)
    move(*tool_pose(center,theta,far,z),seconds=2.,settle=.4)
    for stroke in range(strokes):
        theta=gap_angle(c,start,sign)
        if sign*(stop-theta)<math.radians(8.):
            raise RuntimeError('repair: no usable tooth gap inside the clear sector')
        center,_=small_center(c)
        c.event('repair_sector_gap_stroke',stroke=stroke,start_degrees=math.degrees(theta),stop_degrees=math.degrees(stop))
        move(*tool_pose(center,theta,outside,z),seconds=1.2,settle=.3)
        move(*tool_pose(center,theta,inside,z),seconds=1.,settle=.3,gain=.08)
        for i in range(250 if converged else 125):
            angle=theta+(i+1)/(250 if converged else 125)*(stop-theta)
            held.track(*tool_pose(small_center(c)[0],angle,inside,z),gain=.06)
        move(*tool_pose(small_center(c)[0],stop,inside,z),seconds=.3,settle=.3)
        c.event('repair_sector_gap_result',stroke=stroke,credited=c.env.status.get('credited_angles_rad'),completed=list(c.env.status['completed']))
        move(*tool_pose(small_center(c)[0],stop,outside,z),seconds=.8,settle=.2)
        if 'drive_test' in c.env.status['completed']:break
        move(*tool_pose(small_center(c)[0],start,outside,z),seconds=1.5,settle=.2)
    center,_=small_center(c)
    move(*tool_pose(center,stop,far,z),seconds=1.5,settle=.3)
    move(*tool_pose(center,stop,far,z+.08),seconds=1.5,settle=.3)
    return dict(completed=list(c.env.status['completed']),credited=c.env.status.get('credited_angles_rad'))
