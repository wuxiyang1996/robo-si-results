"""Choose the upward rail face after a frame settles on a real support."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose, Pinch, smooth, side_forces
from humanoid.g1_gear_assembly.solution.stage_base_hook import HOOK_PROFILE
from .grasp_clearance import ReceivingArm
from .table_pair import joint_route


def acquire(c,name,rail_local_z=-.0915,force_target=20.):
    p,R,yaw,state=pose(c,name)
    if state['robot_contact_force']>.05:raise RuntimeError(name+': regrasp requires a released frame')
    # The two broad faces are equivalent grasp surfaces. The local frame's
    # sign is not: using the pre-release face after a fall points the palm
    # below the tabletop. Select the upward face from measured orientation.
    face=R@Rotation.from_euler('x',np.pi if R[2,1]<0 else 0.).as_matrix()
    flat=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
    tilt=face@flat.T
    c.ik.set_limit('waist_pitch_joint',-.46,.48);c.ik.set_limit('waist_roll_joint',-.48,.48)
    for side in ('left','right'):c.ik.set_limit(side+'_elbow_joint',-.8,1.8)
    planned=None
    candidates=getattr(c,'fixture_regrasp_candidates',[('left',np.pi,0.),('right',np.pi,0.),('left',0.,.04)])
    for side,turn,x in candidates:
        anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([x,-.00329093125,rail_local_z])
        g=Pinch(c,name,side,HOOK_PROFILE,anchor=anchor,azimuth=yaw+turn,opening=.25,squeeze=.55)
        g.offset=tilt@g.offset;g.rotation=tilt@g.rotation
        c.move_joints(g.curled(-g.opening),seconds=.6)
        screens=[ReceivingArm(c,name,s,protect_scene=True)for s in ('left','right')]
        for wy,sy,el in ((0.,0.,.5),(-1.,1.5,1.2),(1.,-1.5,1.2),(-1.,-1.5,-.6),(1.,1.5,-.6)):
            seed=c.actual_q().copy()
            for j,v in [('waist_yaw_joint',wy),(side+'_shoulder_yaw_joint',sy),(side+'_elbow_joint',el)]:seed[c.index[j]]=v
            sol,e=c.ik.solve(c.env.base_position,(1,0,0,0),seed,g.target(.08),iters=300,damping=.02,w_rot=.5,max_step=.08)
            if max(e.values())>.003 or not all(s.clear(sol,self_clear=True,scene_clearance=.025,hand_scene_clearance=.01)for s in screens):continue
            hover=sol.copy();path=[]
            for f in np.linspace(0,1,21):
                goals=g.target(.08*(1-f))
                sol,e=c.ik.solve(c.env.base_position,(1,0,0,0),sol,goals,iters=120,damping=.015,w_rot=.5,max_step=.05)
                angle=np.linalg.norm(Rotation.from_matrix(goals[side][2]@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec())
                if max(e.values())>.003 or angle>.04 or not all(s.clear(sol,self_clear=True,scene_clearance=.025,hand_scene_clearance=.003 if f<.8 else 0.)for s in screens):break
                path.append(sol.copy())
            if len(path)==21:
                route=joint_route(c,name,hover,screens);planned=(g,route,path);break
        if planned is not None:break
    if planned is None:raise RuntimeError(name+': no clear upward-face rail regrasp')
    g,route,path=planned;side=g.side
    c.event('released_frame_upward_face_regrasp',side=side,measured_rotation=R.tolist(),upward_face_rotation=face.tolist(),rail_local_z_m=rail_local_z)
    guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
    def guard(current):
        for screen in guards:
            tolerance=getattr(c,'fixture_hand_support_tolerance',0.)
            options={'hand_scene_margins':{'temporary_fixture':-tolerance}} if tolerance else {}
            if not screen.clear(current.actual_q(),scene_clearance=.005,hand_scene_clearance=0.,**options):
                raise RuntimeError(name+': measured regrasp arm clearance lost '+str(screen.blocked))
    c.joint_feedback['released_frame_regrasp']=guard
    try:
        for waypoint in route[1:]:
            goal=c.q.copy();goal[c.ik.upper]=waypoint
            c.move_joints(goal,seconds=max(2.,1.9*float(np.max(abs(goal[c.ik.upper]-c.q[c.ik.upper])))/.35))
        for waypoint in path[1:]:
            goal=c.q.copy();goal[c.ik.upper]=waypoint[c.ik.upper]
            c.move_joints(goal,seconds=max(.15,1.9*float(np.max(abs(goal[c.ik.upper]-c.q[c.ik.upper])))/.35))
        _,point,rot=g.target()[side];cp=np.zeros(3);cr=np.zeros(3)
        def track():
            nonlocal cp,cr
            hp,hR=c.hand_pose(side);error=point-hp;rv=Rotation.from_matrix(rot@hR.T).as_rotvec()
            cp=np.clip(cp+np.clip(.04*error,-.0002,.0002),-.035,.035)
            cr=np.clip(cr+np.clip(.025*rv,-.001,.001),-.12,.12)
            c.reach({side:('palm',point+cp+np.clip(.5*error,-.008,.008),Rotation.from_rotvec(cr+.3*rv).as_matrix()@rot)},rate=.4,iters=24)
            c.step();return np.linalg.norm(error),np.linalg.norm(rv)
        for _ in range(250):
            ep,er=track()
            if ep<.0015 and er<.02:break
        if ep>.004 or er>.04:raise RuntimeError(name+': upward-face palm did not converge')
        indices=[g.joint(j)for j in g.shape]
        for amount in (0.,g.squeeze_amount):
            start=c.q.copy();goal=g.curled(amount);count=30 if amount==0 else 100;loaded=0
            for i in range(count):
                c.q[indices]=start[indices]+smooth((i+1)/count)*(goal[indices]-start[indices]);track()
                loaded=loaded+1 if side_forces(c,name)[side]>=force_target else 0
                if amount>0 and loaded>=3:break
        for _ in range(20):track()
        forces=side_forces(c,name);c.event('released_frame_regrasp_contact',forces=forces)
        if forces[side]<.5:raise RuntimeError(name+': upward-face regrasp has no sustained hand contact')
    finally:c.joint_feedback.pop('released_frame_regrasp',None)
    return g
