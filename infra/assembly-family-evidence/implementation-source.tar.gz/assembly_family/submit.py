"""Submit one monitored attempt and register the scheduler's returned job ID."""
import argparse
import fcntl
import json
from pathlib import Path
import re
import subprocess
from .contracts import ROOT,plan


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--task',required=True);p.add_argument('--attempt',required=True)
    p.add_argument('--policy',required=True);p.add_argument('--node',required=True)
    p.add_argument('--backend',choices=('cpu','gpu'),default='cpu')
    p.add_argument('--time');a=p.parse_args()
    plan(a.task)
    if not re.fullmatch(r'a\d+',a.attempt):p.error('attempt must be a numeric a-prefixed ID')
    output=Path('assembly_family/runs')/a.task/a.attempt
    if (ROOT/output).exists():p.error('attempt output already exists')
    queue=ROOT/'assembly_family/queue.json'
    with (queue.with_suffix('.lock')).open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX);rows=json.loads(queue.read_text())
        if any(r['task']==a.task and r['attempt']==a.attempt for r in rows):p.error('attempt already registered')
        log=f'assembly_family/{a.task.lower().replace("-","")}-{a.attempt}.log'
        script='assembly_family/run_cpu.sbatch'if a.backend=='cpu'else'assembly_family/run.sbatch'
        duration=a.time or ('03:00:00' if a.backend=='cpu' and a.task.startswith('GEAR-') else '00:30:00')
        command=['sbatch','--nodelist='+a.node,'--time='+duration,'--job-name='+a.task.lower().replace('-','')+'-'+a.attempt,
                 '--output='+log,script,'--task',a.task,'--output',str(output),'--policy',a.policy,
                 '--joint-margin','.03','--joint-limit-damping','--stop-on-physics-violation']
        result=subprocess.run(command,cwd=ROOT,check=True,capture_output=True,text=True)
        match=re.fullmatch(r'Submitted batch job (\d+)\s*',result.stdout)
        if not match:raise RuntimeError('Unexpected scheduler response: '+result.stdout)
        row=dict(task=a.task,attempt=a.attempt,job_id=int(match[1]),backend=a.backend,policy=a.policy,node=a.node)
        rows.append(row);temporary=queue.with_suffix('.json.writing');temporary.write_text(json.dumps(rows,indent=2)+'\n');temporary.replace(queue)
        print(json.dumps(row))


if __name__=='__main__':main()
