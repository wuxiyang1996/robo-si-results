"""Use the real table to bear a thin carrier's weight during flattening."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose, smooth
from .reference_carry_path import move as carried_move
from .pose_carry import move as pose_move


def stage(c,grip):
    name=grip.name
    centre=np.asarray(getattr(c,'carrier_table_stage_xy',(.26,0.)),dtype=float)
    hover=np.r_[centre+[.08349098346,0.],.86]
    vertical=Rotation.from_euler('y',np.pi/2).as_matrix()
    # The far long rail becomes the table hinge. Its x coordinate must
    # include the half-width so the final carrier centre is x=.26 m.
    carried_move(c,grip,hover,vertical)
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p-hover)>.02:
        raise RuntimeError('carrier: screened table-pivot approach missed the measured workspace')
    boxes=c.env.catalog['parts'][name]['collision_boxes']
    extent=max(float(-(R@np.asarray(b['pos']))[2]+np.abs(R[2])@(np.asarray(b['size'])/2))for b in boxes)
    landing=p.copy();landing[2]=c.env.cfg.table_height+extent+.0005
    pose_move(c,grip,landing,R,3.,'carrier_lower_far_rail_to_real_table',preserve_reference=True,
              stop_when=lambda p,r,s:s['support_forces'].get('table',0)>.05)
    c.hold(.3);p,R,_,state=pose(c,name)
    if state['support_forces'].get('table',0)<.05:
        raise RuntimeError('carrier: no measured table support before pivot')
    pivot=p+R@np.array([.08349098346,0.,0.])
    near=p+R@np.array([-.08349098346,.08,0.])
    hp,hR=c.hand_pose(grip.side)
    c.ik._set(c.env.base_position,(1,0,0,0),c.q)
    bias=c.ik.hand_point(grip.side,'palm').copy()-hp
    bias_R=c.ik.d.xmat[c.ik.wrist[grip.side]].reshape(3,3).copy()@hR.T
    angle=float(np.arctan2(R[0,2],R[2,2]));axis=R[:,1].copy()
    cp=np.zeros(3);cr=np.zeros(3);weak=0
    c.event('carrier_table_supported_flatten',pivot=pivot.tolist(),angle_rad=-angle,
            wrist_rotation='held_world_pose',expected_centre_m=[*centre,c.env.cfg.table_height+.00413])
    for i in range(300):
        turn=Rotation.from_rotvec(-axis*angle*smooth(min(1.,(i+1)/250))).as_matrix()
        desired=hp+pivot+turn@(near-pivot)-near
        actual,actual_R=c.hand_pose(grip.side);error=desired-actual
        rv=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
        cp=np.clip(cp+np.clip(.035*error,-.0002,.0002),-.025,.025)
        cr=np.clip(cr+np.clip(.02*rv,-.0005,.0005),-.10,.10)
        c.reach({grip.side:('palm',desired+bias+cp+np.clip(.4*error,-.008,.008),
                            bias_R@Rotation.from_rotvec(cr+.3*rv).as_matrix()@hR)},rate=.4,iters=20)
        c.step();point,rot,_,state=pose(c,name)
        weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>10:raise RuntimeError('carrier: hook lost contact during supported flattening')
        if i%25==0:c.event('carrier_table_pivot_measurement',position=point.tolist(),normal_z=float(rot[2,2]),
                           force_n=state['robot_contact_force'],supports=state['support_forces'])
        if rot[2,2]>.96 and state['support_forces'].get('table',0)>.1 and np.linalg.norm(point[:2]-centre)<.025:
            # Continuing the hook below this supported shallow tilt trapped
            # its middle finger against the table in a176. Open at the actual
            # wrist pose and let gravity finish seating the released carrier.
            c.event('carrier_release_supported_shallow_tilt_before_finger_table_load',
                    normal_z=float(rot[2,2]),position=point.tolist(),supports=state['support_forces'])
            break
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 or np.linalg.norm(p[:2]-centre)>.025 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('carrier: table pivot did not establish a measured flat supported pose')
    grip.release(seconds=1.5,rise=.12);c.hold(.6)
    p,R,_,state=pose(c,name)
    if R[2,2]<.97 or p[2]>c.env.cfg.table_height+.015 or np.linalg.norm(p[:2]-centre)>.025 or state['support_forces'].get('table',0)<.05 or state['robot_contact_force']>.05:
        raise RuntimeError('carrier: flat table staging did not survive release')
    c.event('carrier_flat_table_pivot_probe_success',position=p.tolist(),supports=state['support_forces'])
    return grip
