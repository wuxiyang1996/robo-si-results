"""Enter beside an inverted rim before loading the thumb against it."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import goto,smooth,pose


def acquire(c,grip):
    c.event('repair_rim_preshape');grip.preshape()
    yaw=pose(c,grip.name)[2]
    away=Rotation.from_euler('z',yaw).as_matrix()@np.array([-.0049172,-.0009062,0.])
    _,nominal_hover,rotation=grip.target(.12)[grip.side]
    hover={grip.side:('palm',nominal_hover+away,rotation)}
    c.event('repair_rim_hover');goto(c,hover,seconds=2.5)
    c.move_hands(hover,seconds=.4,feedback=.6,settle=.3,rotation_feedback=.3)
    # The former vertical descent loaded only the thumb and forced its
    # proximal joint open before closure. Descend 5 mm on the thumb side,
    # then return while the opposed fingers close around the actual rim.
    nominal=grip.target();_,palm,rotation=nominal[grip.side]
    c.event('repair_rim_thumb_clear_descent',away=away.tolist())
    start_p,_=c.hand_pose(grip.side);thumb_joint=grip.joint('thumb_1')
    for i in range(110):
        state=pose(c,grip.name)[3]
        if c.actual_q()[thumb_joint]>c.hi[thumb_joint]-.05 and state['robot_contact_force']>1.:
            c.event('repair_rim_close_before_thumb_stop',contact_force=state['robot_contact_force'])
            actual,_=c.hand_pose(grip.side);palm[2]=actual[2]
            break
        a=smooth(min(1.,(i+1)/90));desired=start_p+a*(palm+away-start_p)
        c.reach({grip.side:('palm',desired,rotation)},feedback=.6,rotation_feedback=.3,iters=16);c.step()
    grip.closed=True;start=c.q.copy()
    active=[grip.joint(j)for j in ('thumb_1','middle_0','index_0')]
    delta=np.array([grip.sign,-grip.sign,-grip.sign])*grip.squeeze
    c.event('repair_rim_close_with_centering')
    for i in range(80):
        a=smooth(min(1.,(i+1)/60))
        c.q[active]=start[active]+a*delta
        centre=smooth(np.clip(((i+1)/80-.25)/.75,0.,1.))
        c.reach({grip.side:('palm',palm+(1.-centre)*away,rotation)},feedback=.6,rotation_feedback=.3,iters=16);c.step()
    c.event('repair_rim_grasp_contact_check',contact_force=pose(c,grip.name)[3]['robot_contact_force'])
    if pose(c,grip.name)[3]['robot_contact_force']<.5:
        raise RuntimeError('repair: rim closure established no measured contact')
