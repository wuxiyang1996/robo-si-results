"""Exercise settling against the actual trusted-state field contract."""
import unittest
from types import SimpleNamespace
from .reference_frame_settle import wait


class Controller:
    def __init__(self,force):
        self.steps=0;self.force=force;self.events=[]

    def object_state(self,name):
        return dict(position=[.24,-.27,.79],quat=[1.,0.,0.,0.],
                    linear_velocity=[0.,0.,0.],angular_velocity=[0.,0.,0.],
                    robot_contact_force=self.force(self.steps),support_forces={'table':1.1})

    def step(self):self.steps+=1

    def event(self,phase,**data):self.events.append((phase,data))


class FrameSettleTests(unittest.TestCase):
    def test_returned_contact_can_settle_and_records_trusted_measurements(self):
        c=Controller(lambda step:0. if step==1 else 1.2)
        wait(c,SimpleNamespace(name='right_frame'))
        phase,data=c.events[-1]
        self.assertEqual(phase,'frame_post_hook_measured_settled')
        self.assertEqual(data['robot_contact_force_n'],1.2)
        self.assertEqual(data['supports'],{'table':1.1})

    def test_stationary_part_without_hand_contact_is_not_a_grasp(self):
        c=Controller(lambda step:0.)
        with self.assertRaisesRegex(RuntimeError,'contact lost'):
            wait(c,SimpleNamespace(name='right_frame'))
        self.assertFalse(any(p=='frame_post_hook_measured_settled' for p,_ in c.events))


if __name__=='__main__':unittest.main()
