"""Asset inventory only. No geometry parse is treated as a physical witness."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
from .contracts import ROOT,DESIGN,VELOCITY_SOURCE

def main():
    stretch=Path('/fs/gamma-projects/vlm-robot/robo-si-local-tests/h1-implementation-20261027/asset-cache/stretch_urdf/stretch_urdf/SE3/stretch_description_SE3_eoa_wrist_dw3_tool_sg3.urdf')
    sources={'G':VELOCITY_SOURCE,'F':VELOCITY_SOURCE.with_name('g1_29dof_rev_1_0_with_inspire_hand_DFQ.urdf'),'S':stretch}
    rows={}
    for body,p in sources.items():
        joints=ET.parse(p).getroot().findall('joint') if p.exists() else []
        rows[body]={'asset':str(p),'exists':p.exists(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None,
            'nonfixed_joints':sum(j.get('type')!='fixed' for j in joints),'mimic_followers':sum(j.find('mimic') is not None for j in joints),
            'assembly_controller_adapter':'not implemented','physical_witness':False}
    data={'scope':'static asset inventory only; not a grasp, reachability or physics test','bodies':rows,
          'planned_configurations':[x for t in json.loads(DESIGN.read_text())['tasks'] for x in t['configurations']]}
    for p in (ROOT/'assembly_family/body-readiness.json',ROOT/'infra/assembly-family-evidence/body-readiness.json'):
        p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:dict(asset_exists=v['exists'],physical_witness=False) for k,v in rows.items()}))
if __name__=='__main__':main()
