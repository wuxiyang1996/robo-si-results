"""Prevent stale bytecode and post-import source edits from corrupting evidence."""
import importlib.machinery
import importlib.util
import os
from pathlib import Path
import py_compile
import tempfile
import traceback
import unittest
import subprocess
import sys
from .source_loading import RecordedSourceLoader,loaded_bytes,observe_imports


class SourceLoadingTests(unittest.TestCase):
    def test_fresh_process_import_without_prior_util_import(self):
        result=subprocess.run([sys.executable,'-S','-c','import assembly_family.portable'],cwd=Path(__file__).resolve().parents[1],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def load(self,path,loader_type):
        loader=loader_type('source_recording_probe',str(path))
        spec=importlib.util.spec_from_loader(loader.name,loader)
        module=importlib.util.module_from_spec(spec);loader.exec_module(module)
        return module

    def test_ignores_timestamp_valid_stale_bytecode(self):
        with tempfile.TemporaryDirectory()as directory:
            path=Path(directory)/'probe.py';path.write_text("VALUE='old'\n");stamp=path.stat().st_mtime
            py_compile.compile(str(path),doraise=True)
            path.write_text("VALUE='new'\n");os.utime(path,(stamp,stamp))
            self.assertEqual(self.load(path,importlib.machinery.SourceFileLoader).VALUE,'old')
            self.assertEqual(self.load(path,RecordedSourceLoader).VALUE,'new')
            self.assertEqual(loaded_bytes(path),b"VALUE='new'\n")

    def test_retains_imported_bytes_after_source_changes(self):
        with tempfile.TemporaryDirectory()as directory:
            path=Path(directory)/'probe.py';path.write_text("VALUE='loaded'\n")
            module=self.load(path,RecordedSourceLoader)
            path.write_text("VALUE='edited later'\n")
            self.assertEqual(module.VALUE,'loaded')
            self.assertEqual(loaded_bytes(path),b"VALUE='loaded'\n")

    def test_later_import_is_persisted_before_execution(self):
        with tempfile.TemporaryDirectory()as directory:
            path=Path(directory)/'late.py';path.write_text("VALUE='late import'\n")
            captured=[];remove=observe_imports(lambda filename,raw:captured.append((filename,raw)))
            try:module=self.load(path,RecordedSourceLoader)
            finally:remove()
            path.write_text("VALUE='later edit'\n")
            self.assertEqual(module.VALUE,'late import')
            self.assertEqual(captured,[(path.resolve(),b"VALUE='late import'\n")])

    def test_traceback_retains_the_executed_source_line(self):
        with tempfile.TemporaryDirectory()as directory:
            path=Path(directory)/'probe.py'
            path.write_text("def fail():\n    raise RuntimeError('loaded_line_for_evidence')\n")
            module=self.load(path,RecordedSourceLoader)
            path.write_text("def fail():\n    raise RuntimeError('edited_line_after_import')\n")
            try:module.fail()
            except RuntimeError:
                rendered=traceback.format_exc()
            self.assertIn("raise RuntimeError('loaded_line_for_evidence')",rendered)
            self.assertNotIn('edited_line_after_import',rendered)


if __name__=='__main__':unittest.main()
