"""Place an interchangeable shelf board using measured grip and carrier support."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,configure_ik
from .reference_grasp import board_grasp,board_release
from .pose_carry import move


def board(c,m,slot):
    from .policies import park_unused_arm_high
    used=set(c.env.status.get('assignments',{}).values())
    candidates=[n for n in c.env.catalog['parts'] if n.endswith('shelf') and n not in used]
    if not candidates:raise RuntimeError('shelf: no unassigned supply board remains')
    name=max(candidates,key=lambda n:pose(c,n)[0][2]);m.high_id=slot
    c.event('select_exposed_supply_board',selected=name,slot=slot)
    hp,hR=c.hand_pose('left')
    if hp[2]<1.15:
        c.event('clear_released_carrier_hand_before_board')
        c.move_hands({'left':('palm',hp+[0,0,.18],hR)},seconds=2.5,feedback=.5,rotation_feedback=.3)
        hp,hR=c.hand_pose('left')
        c.move_hands({'left':('palm',hp+[-.12,0,0],hR)},seconds=2.,feedback=.5,rotation_feedback=.3)
        park_unused_arm_high(c,'left')
    configure_ik(c,waist_pitch=.48)
    c.ik.set_limit('right_shoulder_roll_joint',-1.5,-.03)
    grip=board_grasp(c,name,'right',m.contract['grasp_profiles']['frame'])
    before,R,_,_=pose(c,name)
    supply_rotation=R.copy()
    move(c,grip,before+[0,0,.015],R,1.5,'board_clear_rack_rail')
    move(c,grip,before+[-.28,0,.015],R,3.,'board_extract_supply')
    move(c,grip,before+[-.28,0,.115],R,3.,'board_lift_clear_of_supply')
    goal_R=Rotation.from_euler('z',np.pi).as_matrix()
    goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    move(c,grip,[.40,-.20,1.06],goal_R,4.,'board_rotate_to_front_grasp')
    move(c,grip,[.28,0.,1.06],goal_R,3.,'board_front_clearance')
    move(c,grip,[.28,0.,goal[2]+.025],goal_R,3.,'board_descend_in_front')
    move(c,grip,goal+[0,0,.025],goal_R,4.,'board_enter_shelf_gap')
    carrier_slot=c.env.catalog['parts'][slot]['support'][0]
    carrier=c.env.status.get('assignments',{}).get(carrier_slot)
    if carrier is None:raise RuntimeError('board: its original carrier dependency is unassigned')
    move(c,grip,goal,goal_R,3.,'board_set_down_on_carrier',
         stop_when=lambda p,R,s:s['support_forces'].get(carrier,0)>.05 and np.linalg.norm(p-goal)<.008)
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p-goal)>.008 or state['support_forces'].get(carrier,0)<.05:
        raise RuntimeError('board: original carrier has not physically received the board')
    grip.front=goal_R@supply_rotation.T@grip.front
    board_release(c,grip);c.hold(1.)
    if slot not in c.env.status['completed']:
        raise RuntimeError('board: released placement did not pass the original shelf predicate')
    c.event('board_shelf_placement_probe_success',slot=slot,object=name)
