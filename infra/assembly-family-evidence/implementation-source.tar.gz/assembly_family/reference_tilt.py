"""Seat the low carrier by releasing a supported tilt, keeping wrists above the table."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,smooth
from .pose_carry import move


def lower_carrier(c,grip,slot='lower_crossbar'):
    goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    angle=np.deg2rad(40.);rotation=Rotation.from_euler('y',angle).as_matrix()
    # Receive the +x rail on the existing U-wall tops. The rotated square
    # rail is wider than the slot until gravity brings it nearly level.
    # At 40 degrees the raised front rail clears the middle front receiver;
    # 30 degrees also put the loaded wrist beyond its reachable workspace.
    half=.08349098346
    half_width=.008881261175912859/2;half_height=.008258216666666665/2
    wall_top=.012
    rotated_bottom=half_width*np.sin(angle)+half_height*np.cos(angle)
    seat_rise=wall_top+rotated_bottom-half_height
    target=goal+[half*(1.-np.cos(angle)),0.,half*np.sin(angle)+seat_rise+.006]
    outside=np.array([.27,0.,1.04])
    move(c,grip,outside,rotation,6.,'carrier_tilt_outside_assembly')
    outside[2]=target[2]
    move(c,grip,outside,rotation,5.,'carrier_tilt_descend_in_front')
    move(c,grip,target,rotation,6.,'carrier_tilt_enter_lower_gap')
    move(c,grip,target-[0,0,.006],rotation,2.,'carrier_tilt_seat_back_rail')
    hp,hR=c.hand_pose(grip.side)
    for i in range(60):
        state=pose(c,grip.name)[3]
        if all(state['support_forces'].get(frame,0.)>.02 for frame in ('left_frame','right_frame')):break
        c.reach({grip.side:('palm',hp-[0,0,.0001*(i+1)],hR)},feedback=.4,rotation_feedback=.3);c.step()
    p,R,_,state=pose(c,grip.name)
    c.event('carrier_tilt_before_release',position=p.tolist(),rotation=R.tolist(),supports=state['support_forces'])
    if np.linalg.norm(p-(target-[0,0,.006]))>.015:
        raise RuntimeError('carrier: tilted insertion missed its physical release envelope')
    if not all(state['support_forces'].get(frame,0.)>.02 for frame in ('left_frame','right_frame')):
        raise RuntimeError('carrier: tilted rail has not established both real frame supports')
    hp,hR=c.hand_pose(grip.side);start=c.q.copy();opened=grip.curled(-grip.opening)
    joints=[grip.joint(j)for j in grip.shape]
    c.event('carrier_tilt_open_at_supported_edge')
    for i in range(30):
        a=smooth((i+1)/30);c.q[joints]=start[joints]+a*(opened[joints]-start[joints])
        c.reach({grip.side:('palm',hp,hR)},feedback=.4,rotation_feedback=.3);c.step()
    c.event('carrier_tilt_withdraw_front')
    c.move_hands({grip.side:('palm',hp+[-.14,0,.04],hR)},seconds=1.5,feedback=.4,rotation_feedback=.3)
    c.hold(2.)
    p,R,_,state=pose(c,grip.name)
    c.event('carrier_tilt_released_measurement',position=p.tolist(),rotation=R.tolist(),supports=state['support_forces'],status=c.env.status)
    if slot not in c.env.status['completed']:
        raise RuntimeError('carrier: gravity leveling did not satisfy the original released carrier predicate')
    c.event('carrier_tilt_placement_probe_success',slot=slot,object=grip.name)
    return grip
