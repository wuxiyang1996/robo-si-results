"""Acquire the turning tool only after measured palm convergence and contact."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import Pinch,pose,configure_ik
from humanoid.g1_gear_assembly.solution.stage_drive import TOOL_PROFILE,HANDLE_ANCHOR
from humanoid.g1_gear_assembly.solution.stage_gears import Held
from .reach_screen import goto
from .paired_grasp import acquire


def pick(c,squeeze=.3,finger_squeeze=None):
    configure_ik(c,waist_pitch=.48)
    # The repaired-task tool rests farther laterally after earlier contacts.
    # Use the existing hardware workspace; default +/-0.30 was a planner cap.
    c.ik.set_limit('waist_roll_joint',-.38,.38)
    c.event('turning_tool_use_authored_waist_workspace',planning_roll=[-.38,.38])
    grip=Pinch(c,'turning_tool','left',TOOL_PROFILE,anchor=HANDLE_ANCHOR,squeeze=squeeze,finger_squeeze=finger_squeeze)
    c.event('turning_tool_finger_closure_target',squeeze_radians=squeeze)
    c.event('turning_tool_screen_actual_approach')
    goto(c,grip.target(.12),seconds=3.,iters=600,self_clear=True)
    acquire(c,grip,protect_other=False)
    held=Held(grip);p,_,yaw,_=pose(c,'turning_tool');c.event('tool_lift')
    held.move(p+[0,0,.06],yaw,seconds=2.,settle=.6);held.level=True
    p2,R,_,state=pose(c,'turning_tool')
    result=dict(lift_m=float(p2[2]-p[2]),contact_force=state['robot_contact_force'],
                tilt_deg=float(np.degrees(np.arccos(np.clip(R[2,2],-1,1)))))
    c.event('tool_lift_result',**result)
    if result['lift_m']<.035 or result['contact_force']<.5:
        raise RuntimeError('turning tool: converged grasp did not sustain the original lift')
    return grip,held,result


def pick_parallel(c,squeeze=.45,anchor=HANDLE_ANCHOR,release_opening=0.):
    """Preserve actual distal pad angles while squeezing the square handle."""
    from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,release
    from .paired_grasp import acquire_hub
    configure_ik(c,waist_pitch=.48)
    c.ik.set_limit('waist_roll_joint',-.38,.38)
    _,_,yaw,_=pose(c,'turning_tool')
    profile=dict(TOOL_PROFILE,squeeze=squeeze,hook=0.)
    grip=HubGrip(c,'turning_tool','left',yaw,profile=profile,anchor=anchor)
    c.event('turning_tool_parallel_pad_grasp',squeeze_radians=squeeze,anchor_m=list(anchor))
    goto(c,grip.target(.12),seconds=3.,iters=600,self_clear=True)
    acquire_hub(c,grip,protect_other=False)
    # The common parking skill uses the Pinch release interface; retain the
    # HubGrip's measured distal feedback throughout its own opening sequence.
    opened_for_release=False
    def release_tool(seconds=.7,rise=.10):
        nonlocal opened_for_release
        if release_opening and not opened_for_release:
            from .rail_opening import widen
            widen(grip,release_opening);opened_for_release=True
            c.event('turning_tool_widen_before_release',parallel_proximal_opening_rad=release_opening)
        return release(c,grip,seconds=seconds)
    grip.release=release_tool
    held=Held(grip);p,_,yaw,_=pose(c,'turning_tool');c.event('tool_lift')
    held.move(p+[0,0,.06],yaw,seconds=2.,settle=.6);held.level=True
    p2,R,_,state=pose(c,'turning_tool')
    result=dict(lift_m=float(p2[2]-p[2]),contact_force=state['robot_contact_force'],
                tilt_deg=float(np.degrees(np.arccos(np.clip(R[2,2],-1,1)))))
    c.event('tool_lift_result',**result)
    if result['lift_m']<.035 or result['contact_force']<.5:
        raise RuntimeError('turning tool: parallel-pad grasp did not sustain its measured lift')
    return grip,held,result
