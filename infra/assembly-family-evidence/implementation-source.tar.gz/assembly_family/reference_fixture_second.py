"""Establish a second real released frame load on the same movable fixture."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,Pinch
from humanoid.g1_gear_assembly.solution.stage_base_hook import HOOK_PROFILE
from .pose_carry import move


def use(c,grip,m):
    name=grip.name;fixture=pose(c,'temporary_fixture')[0]
    # Put one authored foot over the support; the other foot can settle on
    # the real table. No attachment or initialized held state is introduced.
    target=fixture+[.0841,getattr(c,'fixture_foot_y',0.),.0125+.125+.002]
    move(c,grip,target+[0,0,.025],np.eye(3),5.,'second_fixture_frame_foot_hover')
    move(c,grip,target,np.eye(3),3.,'second_fixture_frame_foot_lower')
    hp,hR=c.hand_pose(grip.side)
    for i in range(80):
        state=pose(c,name)[3]
        if state['support_forces'].get('temporary_fixture',0)>.05:break
        c.reach({grip.side:('palm',hp-[0,0,.00015*(i+1)],hR)},feedback=.4,rotation_feedback=.3);c.step()
    if getattr(c,'fixture_directed_release',False):
        p,R,_,state=pose(c,name);pivot=p+R@np.array([-.0841,0.,-.125])
        turn=Rotation.from_euler('x',getattr(c,'fixture_release_roll',.20)).as_matrix()
        move(c,grip,pivot+turn@(p-pivot),turn@R,3.,'second_fixture_direct_fall_away_from_installed_frame',preserve_reference=True)
        c.hold(.2)
    p,R,_,state=pose(c,name);hp,hR=c.hand_pose(grip.side)
    local_p=R.T@(hp-p);local_R=R.T@hR
    c.event('second_fixture_frame_release',position=p.tolist(),supports=state['support_forces'])
    if state['support_forces'].get('temporary_fixture',0)<=.05:
        raise RuntimeError('fixture: second frame has not physically loaded the support')
    if getattr(c,'fixture_unhook_before_retreat',False):
        from humanoid.g1_gear_assembly.solution.skills import hook_release
        grip.opening=max(grip.opening,.45);grip.thumb_opening=max(grip.thumb_opening,.45)
        hook_release(c,[grip],out=.06,drop=.008,rise=.12,seconds=1.5)
    else:grip.release(seconds=1.5,rise=.12)
    c.hold(1.5)
    if name not in c.env.status.get('fixture_uses',{}):
        raise RuntimeError('fixture: second released frame did not establish the original use dwell')
    c.event('second_fixture_use_verified',uses=c.env.status['fixture_uses'])
    if getattr(c,'fixture_park_idle_before_regrasp',False):
        from .table_pair import joint_route
        from .grasp_clearance import ReceivingArm
        # Both hands are empty here. Screen the full joint route before
        # loading the right-hand grasp; the idle arm must stay high during
        # the later shared-waist motion.
        goal=c.actual_q().copy()
        for joint,value in [('shoulder_pitch',-2.5),('shoulder_roll',1.1),('shoulder_yaw',0.),('elbow',1.8),('wrist_roll',0.),('wrist_pitch',0.),('wrist_yaw',0.)]:
            goal[c.index['left_'+joint+'_joint']]=value
        screens=[ReceivingArm(c,name,s,protect_scene=True)for s in ('left','right')]
        route=joint_route(c,name,goal,screens,part_hand_clearance=.01)
        c.event('second_fixture_park_empty_left_arm_before_loaded_waist_turn')
        for waypoint in route[1:]:
            target=c.q.copy();target[c.ik.upper]=waypoint
            c.move_joints(target,seconds=max(2.,1.9*float(np.max(abs(target[c.ik.upper]-c.q[c.ik.upper])))/.5))
        if c.hand_pose('left')[0][2]<1.15:raise RuntimeError('fixture: idle left hand did not reach measured high clearance')
    if getattr(c,'fixture_regrasp_upward_face',False):
        from .released_frame_regrasp import acquire
        from .reference_carry_path import move as screened_move
        if getattr(c,'fixture_regrasp_upper_direct',False):
            regrasp=acquire(c,name,rail_local_z=getattr(c,'fixture_regrasp_rail',.0773333333),force_target=40.)
            hp,hR=c.hand_pose(regrasp.side)
            c.event('second_fixture_direct_rail_fixed_wrist_lift',rail_local_z_m=getattr(c,'fixture_regrasp_rail',.0773333333))
            if getattr(c,'fixture_guard_recovery_lift',False):
                from .grasp_clearance import ReceivingArm
                guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
                def guard(current):
                    for screen in guards:
                        tolerance=getattr(c,'fixture_hand_support_tolerance',0.)
                        options={'hand_scene_margins':{'temporary_fixture':-tolerance}} if tolerance else {}
                        if not screen.clear(current.actual_q(),scene_clearance=.005,hand_scene_clearance=0.,**options):
                            raise RuntimeError(name+': recovery lift lost measured arm clearance '+str(screen.blocked))
                c.joint_feedback['fixture_recovery_lift']=guard
            try:
                c.move_hands({regrasp.side:('palm',hp+[0,0,.28],hR)},seconds=5.,feedback=.5,rotation_feedback=.3)
                c.hold(.4)
            finally:c.joint_feedback.pop('fixture_recovery_lift',None)
            point,_,_,state=pose(c,name)
            recovered=False
            if getattr(c,'fixture_recover_released_upper',False) and state['robot_contact_force']<=.05:
                if not any(state['support_forces'].get(s,0.)>.05 for s in ('table','fixture','temporary_fixture')):
                    raise RuntimeError(name+': lost lower-rail grasp has no measured recovery support')
                c.event('second_fixture_detect_released_supported_frame_after_lift',position=point.tolist(),supports=state['support_forces'])
                prior=getattr(c,'fixture_regrasp_candidates',None)
                c.fixture_regrasp_candidates=[('left',np.pi,-.05),('left',np.pi,0.),('left',0.,.05),('right',np.pi,0.)]
                try:regrasp=acquire(c,name,rail_local_z=.0773333333,force_target=40.)
                finally:c.fixture_regrasp_candidates=prior
                hp,hR=c.hand_pose(regrasp.side)
                c.event('second_fixture_recovered_upper_rail_fixed_wrist_lift')
                if getattr(c,'fixture_guard_recovery_lift',False):c.joint_feedback['fixture_recovery_lift']=guard
                try:
                    c.move_hands({regrasp.side:('palm',hp+[0,0,.28],hR)},seconds=5.,feedback=.5,rotation_feedback=.3)
                    c.hold(.4);recovered=True
                finally:c.joint_feedback.pop('fixture_recovery_lift',None)
            point,_,_,state=pose(c,name)
            if state['robot_contact_force']<.5 or point[2]<c.env.cfg.table_height+.10:
                raise RuntimeError(name+': rail lift did not retain a physical grasp')
            if getattr(c,'fixture_upper_rail_handoff',False) and not recovered:
                from .frame_upper_handoff import transfer
                regrasp=transfer(c,regrasp)
            screened_move(c,regrasp,np.array([.30,-.02,1.02]),np.eye(3))
            return regrasp
        regrasp=acquire(c,name)
        if getattr(c,'fixture_slide_before_lift',False):
            from .supported_frame_slide import move as supported_slide
            supported_slide(c,regrasp,*getattr(c,'fixture_slide_displacement',(-.12,0.)))
            regrasp=acquire(c,name,rail_local_z=.0773333333,force_target=40.)
            hp,hR=c.hand_pose(regrasp.side)
            c.event('second_fixture_upper_rail_fixed_wrist_lift')
            c.move_hands({regrasp.side:('palm',hp+[0,0,.28],hR)},seconds=5.,feedback=.5,rotation_feedback=.3)
            c.hold(.4)
            screened_move(c,regrasp,np.array([.30,-.02,1.02]),np.eye(3))
            return regrasp
        before,R,_,_=pose(c,name)
        move(c,regrasp,before+[0,0,.10],R,3.,'second_fixture_frame_reacquire_lift')
        screened_move(c,regrasp,np.array([.30,-.02,1.02]),np.eye(3))
        return regrasp
    p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@local_p
    regrasp=Pinch(c,name,grip.side,HOOK_PROFILE,anchor=anchor,azimuth=0.,squeeze=.55,opening=.4)
    regrasp.offset=np.zeros(3);regrasp.rotation=R@local_R
    regrasp.grasp(hover=.12)
    before=pose(c,name)[0]
    move(c,regrasp,before+[0,0,.10],R,3.,'second_fixture_frame_reacquire_lift')
    move(c,regrasp,[.30,-.02,1.02],np.eye(3),5.,'second_fixture_frame_reorient_for_installation')
    return regrasp
