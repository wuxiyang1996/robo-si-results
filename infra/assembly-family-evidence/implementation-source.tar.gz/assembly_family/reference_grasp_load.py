"""Regulate a real opposed pinch by ordinary proximal finger targets."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import side_forces
from .grasp_clearance import ReceivingArm


def acquire(c,grip,target=60.):
    amount=float(grip.squeeze);key=grip.key+'_measured_normal_load'
    screen=ReceivingArm(c,grip.name,grip.side,protect_scene=True)
    def update(current):
        nonlocal amount
        force=side_forces(current,grip.name)[grip.side]
        if force>110.:raise RuntimeError(grip.name+': receiving pinch exceeded its planned force envelope')
        amount=float(np.clip(amount+np.clip(.00012*(target-force),-.002,.002),.25,.75))
        for joint,sign in [('thumb_1',grip.sign),('index_0',-grip.sign),('middle_0',-grip.sign)]:
            index=grip.joint(joint);current.q[index]=np.clip(grip.open[joint]+sign*amount,current.lo[index]+.03,current.hi[index]-.03)
    c.joint_feedback[key]=update
    stable=0
    c.event('carrier_receiver_settle_measured_pinch_load',target_force_n=target,maximum_closure_rad=.75)
    try:
        for i in range(250):
            c.step();force=side_forces(c,grip.name)[grip.side]
            if not screen.clear(c.actual_q(),scene_clearance=.025):
                raise RuntimeError(grip.name+': receiving pinch load convergence lost arm clearance')
            stable=stable+1 if .75*target<force<1.3*target else 0
            if i%25==0:c.event('carrier_receiver_actual_pinch_load',force_n=force,closure_rad=amount)
            if stable>=10:
                c.event('carrier_receiver_measured_pinch_load_settled',force_n=force,closure_rad=amount)
                return key
        raise RuntimeError(grip.name+': receiver did not reach a settled measured pinch load')
    except BaseException:
        c.joint_feedback.pop(key,None);raise
