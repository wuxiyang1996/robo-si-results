"""Clear the table with a fitted pinch before changing to an under-bar cradle."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import Pinch,pose,smooth
from humanoid.g1_gear_assembly.solution.stage_base_hook import HOOK_PROFILE
from .pose_carry import move
from .paired_grasp import fit_tilted_frame


def acquire_clearance(c,grip):
    name,side=grip.name,grip.side
    grip.squeeze_amount=.45;grip.finger_ratio=.40/.45
    start=c.q.copy();target=grip.curled(.45);joints=[grip.joint(j)for j in grip.shape]
    c.event('frame_fitted_pinch_pressure_before_flat_clearance')
    for i in range(60):
        a=smooth((i+1)/60);c.q[joints]=start[joints]+a*(target[joints]-start[joints])
        c.reach(grip.target(),feedback=.5,rotation_feedback=.3,iters=24);c.step()
    p,R,_,_=pose(c,name)
    move(c,grip,p+[0,0,.065],R,4.,'frame_preserve_pose_until_clear_of_table')
    actual,actual_R,yaw,state=pose(c,name)
    c.event('frame_flat_clearance_measurement',position=actual.tolist(),rotation=actual_R.tolist(),force=state['robot_contact_force'])
    if actual[2]<p[2]+.035 or state['robot_contact_force']<.5:
        raise RuntimeError('frame: fitted pinch did not sustain the real table-clearance lift')
    flat=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
    if np.linalg.norm(Rotation.from_matrix(flat@actual_R.T).as_rotvec())>.03:
        move(c,grip,actual,flat,3.,'frame_level_rail_before_cradle_transfer')
    p,R,yaw,_=pose(c,name)
    local=[0.,.003303960702 if name=='left_frame' else -.00329093125,.0773333333]
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@local
    cradle=Pinch(c,name,side,HOOK_PROFILE,anchor=anchor,azimuth=yaw,squeeze=.55,opening=.4)
    fit_tilted_frame(c,cradle)
    start=c.q.copy();target=cradle.curled(.55);joints=[cradle.joint(j)for j in cradle.shape]
    c.event('frame_change_to_cradle_above_table')
    for i in range(100):
        a=smooth((i+1)/100);c.q[joints]=start[joints]+a*(target[joints]-start[joints])
        c.reach(cradle.target(),feedback=.5,rotation_feedback=.3,iters=24);c.step()
    if pose(c,name)[3]['robot_contact_force']<.5:
        raise RuntimeError('frame: above-table cradle transition lost measured contact')
    c.event('frame_above_table_cradle_contact_established')
    return cradle
