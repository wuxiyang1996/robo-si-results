"""Table-supported carrier staging followed by a balanced two-hand lift."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,configure_ik,side_forces
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,Held
from humanoid.g1_gear_assembly.solution.stage_base_wrap import Carry
from .reach_screen import goto
from .held_ik import solve as held_solve
from .paired_grasp import acquire


def run(c,m,name,table_clearance_profile=False,edge_clearance=False,balanced_regrasp=False):
    configure_ik(c,waist_pitch=.48);fit=m.contract['grasp_profiles']['frame']
    if edge_clearance:
        from .policies import park_unused_arm_high
        if c.hand_pose('right')[0][2]<1.15:
            park_unused_arm_high(c,'right',measured_finish=True)
        c.ik.set_limit('waist_roll_joint',-.38,.38)
    p,R,yaw,_=pose(c,name)
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])+[0,0,.003 if table_clearance_profile else 0.],
                 hand=fit['hand_joints'],squeeze=.45 if edge_clearance else .30,hook=0.)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0.,-.1485,0.]
    left=HubGrip(c,name,'left',yaw-np.pi,profile=profile,anchor=anchor)
    c.event('carrier_far_tie_table_grasp')
    goto(c,left.target(.12),seconds=3.,iters=600,self_clear=True);left.grasp()
    if edge_clearance:
        from .reference_table_clearance import stage
        stage(c,left,turn_to_center=not balanced_regrasp)
    else:
        held=Held(left,level=True);start=pose(c,name)[0];table_z=float(start[2])
        held.move([start[0],.30,start[2]],yaw,seconds=2.,settle=.3)
        start=pose(c,name)[0]
        # Turn on the original supply side before crossing the torso. A long
        # carrier at x=.194 and yaw=90 degrees intersected the actual pelvis.
        held.move(start,np.pi,seconds=3.5,settle=.3)
        if not table_clearance_profile:
            c.event('carrier_clear_thumb_from_table_before_x_translation')
            held.move(start+[0,0,.015],np.pi,seconds=2.,settle=.3)
            start=pose(c,name)[0]
        else:c.event('carrier_higher_pad_grasp_preserving_table_support',palm_offset=profile['offset'].tolist())
        held.move([.285,start[1],start[2]],np.pi,seconds=2.,settle=.3)
        c.event('carrier_table_drag_to_balanced_workspace')
        held.move([.285,0.,start[2]],np.pi,seconds=5.,settle=1.)
        c.event('carrier_lower_to_table_for_receiving_grasp')
        held.move([.285,0.,table_z],np.pi,seconds=2.,settle=.5)
    p,R,yaw,state=pose(c,name)
    c.event('carrier_balanced_table_staging_measurement',position=p.tolist(),rotation=R.tolist(),supports=state['support_forces'])
    table_goal=[.285,.30 if balanced_regrasp else 0.]
    if np.linalg.norm(p[:2]-table_goal)>.015 or R[2,2]<.95 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('carrier: table-supported staging did not reach the balanced workspace')
    if balanced_regrasp:
        from humanoid.g1_gear_assembly.solution.stage_gears import release
        release(c,left,seconds=1.);c.hold(.5)
        c.ik.set_limit('left_shoulder_roll_joint',.03,1.5)
        c.ik.set_limit('right_shoulder_roll_joint',-1.5,-.03)
        p,R,yaw,_=pose(c,name)
        anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0.,.1485,0.]
        left=HubGrip(c,name,'left',yaw-np.pi,profile=profile,anchor=anchor)
        left.shape=left.open;left.opening=0.;left.squeeze_amount=profile['squeeze']
        def left_curled(amount):
            q=c.q.copy()
            for joint,value in left.open.items():q[left.joint(joint)]=value
            for joint,sign in [('thumb_1',left.sign),('index_0',-left.sign),('middle_0',-left.sign)]:
                q[left.joint(joint)]+=sign*amount
            return np.clip(q,c.lo+.03,c.hi-.03)
        left.curled=left_curled;left.preshape(seconds=.6)
        acquire(c,left,protect_other=False);left.closed=True
        p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0.,-.1485 if balanced_regrasp else .1485,0.]
    right=HubGrip(c,name,'right',yaw if balanced_regrasp else 0.,profile=profile,anchor=anchor)
    right.shape=right.open;right.opening=0.;right.squeeze_amount=.25
    def curled(amount):
        q=c.q.copy()
        for joint,value in right.open.items():q[right.joint(joint)]=value
        for joint,sign in [('thumb_1',right.sign),('index_0',-right.sign),('middle_0',-right.sign)]:
            q[right.joint(joint)]+=sign*amount
        return np.clip(q,c.lo+.03,c.hi-.03)
    right.curled=curled;right.preshape(seconds=.6)
    kp,kR=c.hand_pose('left');original=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        return held_solve(c.ik,root_pos,root_quat,q,dict(tasks,left=('palm',kp,kR)),'left',*args,**kwargs)
    c.ik.solve=keep
    try:acquire(c,right)
    finally:c.ik.solve=original
    right.closed=True
    forces=side_forces(c,name);c.event('carrier_bimanual_grasp_contacts',forces=forces)
    if min(forces.values())<.5:raise RuntimeError('carrier: both end ties require real hand contacts')
    carry=Carry(c,name=name,tilt_gain=.04,corr=.06);p=pose(c,name)[0]
    carry.move(p+[0,0,.12],yaw if balanced_regrasp else np.pi,seconds=4.,settle=.5)
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 or p[2]<c.env.cfg.table_height+.09:
        raise RuntimeError('carrier: balanced end-tie grips did not sustain a flat lift')
    c.event('carrier_bimanual_lift_probe_success',position=p.tolist())
    carry.move([.40,0.,1.04],0. if balanced_regrasp else np.pi,seconds=5.,settle=.5)
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p-[.40,0.,1.04])>.02 or R[2,2]<.95:
        raise RuntimeError('carrier: balanced transfer did not reach the measured flat hover')
    c.event('carrier_bimanual_transfer_probe_success',position=p.tolist())
    return left,right,carry
