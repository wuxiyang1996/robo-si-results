"""Drive from a measured solid top tooth face while measuring a real downward tool load."""
import math
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,smooth
from humanoid.g1_gear_assembly.solution.stage_drive import tool_pose,small_center


def pressure(c):
    gear=c.env.objects['small_gear'];links={link.idx for link in gear.links}
    contacts=gear.get_contacts(with_entity=c.env.objects['turning_tool'])
    force=np.zeros(3)
    for tag in ('a','b'):
        ids=contacts['link_'+tag].cpu().numpy();values=contacts['force_'+tag].cpu().numpy()
        for link,value in zip(ids,values):
            if int(link)in links:force+=value
    return max(0.,-float(force[2]))


def drive(c,held,strokes=10,pressure_target=2.,minimum_pressure=.8,minimum_z_offset=-.008,gentle_contact=False,sweep_window=None,entry_clearance=.012,converged=False,fixed_contact_rotation=False):
    if converged:
        c.ik.set_limit('waist_pitch_joint',-.46,.48)
        c.ik.set_limit('waist_roll_joint',-.48,.48)
        c.ik.set_limit('left_elbow_joint',-.8,1.8)
        c.event('repair_top_use_authored_close_workspace',hardware_limits_unchanged=True)
    def move(point,yaw,**kwargs):
        held.move(point,yaw,**kwargs)
        if not converged:return
        stable=0
        for _ in range(250):
            actual,R,_,state=pose(c,'turning_tool')
            error=float(np.linalg.norm(actual-point))
            angle=float(np.linalg.norm(Rotation.from_matrix(Rotation.from_euler('z',yaw).as_matrix()@R.T).as_rotvec()))
            stable=stable+1 if error<.0015 and angle<.025 and np.linalg.norm(state['linear_velocity'])<.008 else 0
            if stable>=10:
                c.event('repair_top_entry_pose_settled',position_error_m=error,rotation_error_rad=angle)
                return
            held.track(point,yaw,gain=.03)
        raise RuntimeError('tool: top-drive waypoint did not converge before advancing')
    sign=c.env.cfg.drive_sign;start=math.radians(180 if sign>0 else 218)
    radius=.0233;outside=.040;far=.095
    c.event('repair_tool_top_tooth_face_drive',tip_radius_m=radius,pressure_target_n=pressure_target,minimum_tool_origin_offset_m=minimum_z_offset,maximum_strokes=strokes,entry='robot_facing_side_below_cover_rail')
    for stroke in range(strokes):
        center,gear_yaw=small_center(c);surface=float(center[2]);height=surface+.0025
        tooth_pitch=2*math.pi/c.env.catalog['parts']['small_gear']['teeth']
        theta0=gear_yaw+round((start-gear_yaw)/tooth_pitch)*tooth_pitch
        theta1=theta0+sign*math.radians(38.)
        if sweep_window is not None:
            low,high=map(math.radians,sweep_window)
            theta0=gear_yaw+(math.ceil((low-gear_yaw)/tooth_pitch) if sign>0 else math.floor((high-gear_yaw)/tooth_pitch))*tooth_pitch
            theta1=min(high,theta0+math.radians(20.)) if sign>0 else max(low,theta0-math.radians(20.))
            if sign*(theta1-theta0)<math.radians(8.):raise RuntimeError('tool: no tooth face inside the collision-screened drive window')
        # The hub lip extends to r=22.5 mm above the disk. Enter from outside
        # below its underside, then descend onto the selected outer tooth.
        c.event('repair_top_choose_actual_tooth',stroke=stroke,angle_rad=theta0,stop_angle_rad=theta1,surface_z=surface,sweep_window_degrees=sweep_window)
        # Descend entirely outside the cover, then translate under its rail.
        # The former +y approach crossed the base lifting handle at this height.
        move(*tool_pose(center,theta0,far,height+.060),seconds=3.,settle=.6)
        move(*tool_pose(center,theta0,far,height+entry_clearance),seconds=2.,settle=.5)
        move(*tool_pose(center,theta0,outside,height+entry_clearance),seconds=2.,settle=.5)
        move(*tool_pose(center,theta0,radius,height+entry_clearance),seconds=1.5,settle=.5)
        z=height+entry_clearance
        def press(theta):
            nonlocal z
            load=pressure(c)
            if gentle_contact:
                tp,tR,_,_=pose(c,'turning_tool');tip_height=float((tp+tR@[.075,0,0])[2])
                approach=.00004 if tip_height>height+.002 else .000008
                change=-approach if load<.05 else np.clip(.00002*(load-pressure_target),-.000008,.000008)
            else:change=-.00012 if load<.05 else np.clip(.0001*(load-pressure_target),-.00015,.00015)
            z=float(np.clip(z+change,height+minimum_z_offset,height+.015))
            # Keep the settled wrist compensation during contact. Integrating
            # payload tilt here twists the handle inside its real pinch while
            # its tip is supported by the tooth (measured in a71).
            held.track(*tool_pose(small_center(c)[0],theta,radius,z),gain=.05,
                       **({'rot_gain':0.} if fixed_contact_rotation else {}))
            return load
        c.event('repair_top_tip_establish_downward_load',stroke=stroke,
                contact_rotation_integrator=not fixed_contact_rotation)
        ready=False;stable_load=0
        for i in range(1000 if gentle_contact else 350):
            load=press(theta0)
            if i%25==0:
                tp,tR,_,ts=pose(c,'turning_tool');tip=tp+tR@[.075,0,0]
                c.event('repair_top_actual_tip_load',stroke=stroke,downward_force_n=load,tip=tip.tolist(),tool_supports=ts['support_forces'],small_supports=pose(c,'small_gear')[3]['support_forces'])
            if load>12:raise RuntimeError('turning tool: top load exceeds the planned 12 N envelope')
            stable_load=stable_load+1 if minimum_pressure<load<5. and c.env.status['stage']==5 else 0
            if stable_load>=(10 if converged else 1):ready=True;break
        if not ready:raise RuntimeError('turning tool: no settled real top contact with the complete repaired assembly')
        c.event('repair_top_tip_loaded_sweep',stroke=stroke,downward_force_n=pressure(c))
        progress=0
        for i in range(600 if converged else 200):
            # Hold tangential progress while rebuilding a measured downward
            # load; this does not preserve or alter any scorer credit.
            if not converged or pressure(c)>minimum_pressure:progress=min(200,progress+1)
            theta=theta0+smooth(progress/200)*(theta1-theta0);load=press(theta)
            if load>12:raise RuntimeError('turning tool: top drive exceeded the planned force envelope')
            if progress==200:break
        if progress<200:raise RuntimeError('turning tool: downward load could not sustain the planned sweep')
        c.event('repair_top_drive_stroke_result',stroke=stroke,credited=c.env.status.get('credited_angles_rad'),completed=list(c.env.status['completed']))
        center,_=small_center(c)
        move(*tool_pose(center,theta1,radius,height+entry_clearance),seconds=1.2,settle=.5)
        move(*tool_pose(center,theta1,outside,height+entry_clearance),seconds=1.2,settle=.5)
        move(*tool_pose(center,theta1,far,height+entry_clearance),seconds=1.5,settle=.5)
        move(*tool_pose(center,theta1,far,height+.060),seconds=1.2,settle=.5)
        if 'drive_test'in c.env.status['completed']:break
    return dict(completed=list(c.env.status['completed']),credited=c.env.status.get('credited_angles_rad'))
