"""Read-only Slurm/heartbeat monitor; optional bounded local report refresh."""
import argparse,time,json
from .report import collect

def main():
    p=argparse.ArgumentParser();p.add_argument('--watch-seconds',type=int,default=0);p.add_argument('--interval',type=int,default=30);a=p.parse_args()
    deadline=time.monotonic()+a.watch_seconds
    while True:
        data=collect();live=0
        for task in data['tasks']:
            for run in task['attempts']:
                if run['result']:continue
                h=run['heartbeat'] or {};print(json.dumps({'task':task['task_id'],'attempt':run['id'],'slurm':run['status'],'simulation_seconds':h.get('time'),'phase':h.get('phase'),'joint_overrun':h.get('max_joint_overrun'),'joint':h.get('max_position_joint'),'forbidden_contact_peak':h.get('forbidden_contact_peak')}),flush=True)
                live+=run['status'] in ('RUNNING','PENDING','COMPLETING')
            for run in task['queue']:
                if run['state'] in ('RUNNING','PENDING','COMPLETING'):
                    print(json.dumps({'task':task['task_id'],'attempt':run['attempt'],'slurm':run['state'],'simulation_seconds':None,'phase':'awaiting_process_start'}),flush=True)
                    live+=1
        print(json.dumps({'snapshot':data['generated_utc'],'active_jobs':live,'task_scorer_passes':data['task_scorer_passes'],'certified_tasks':data['certified_tasks']}),flush=True)
        if time.monotonic()>=deadline or not live:break
        time.sleep(min(max(1,a.interval),60,max(0,deadline-time.monotonic())))
if __name__=='__main__':main()
