"""The independent query model must use the observed part transform."""
import unittest
from types import SimpleNamespace
import numpy as np
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from .grasp_clearance import ReceivingArm


class ObservedPartTests(unittest.TestCase):
    def test_part_follows_observation_in_query_model(self):
        ik=UpperBodyIK();q=np.zeros(len(ik.qadr));root=[0,0,.79]
        ik._set(root,[1,0,0,0],q)
        state=dict(position=ik.d.xpos[ik.m.body('left_elbow_link').id].copy(),quat=[1,0,0,0])
        env=SimpleNamespace(base_position=root,catalog={'parts':{'part':{'collision_boxes':[dict(pos=[0,0,0],size=[.04,.04,.04])]}}})
        c=SimpleNamespace(ik=ik,env=env,actual_q=lambda:q.copy(),object_state=lambda _:state)
        screen=ReceivingArm(c,'part','left')
        self.assertFalse(screen.clear(q))
        state['position']=np.array([3.,3.,3.])
        self.assertTrue(screen.clear(q))
        self.assertEqual(env.catalog['parts']['part']['collision_boxes'][0]['pos'],[0,0,0])

    def test_hover_checks_fingers_before_intended_contact(self):
        ik=UpperBodyIK();q=np.zeros(len(ik.qadr));root=[0,0,.79]
        ik._set(root,[1,0,0,0],q)
        point=ik.point(ik.m.body('left_hand_index_1_link').id,[.04,0,0])
        state=dict(position=point.copy(),quat=[1,0,0,0])
        env=SimpleNamespace(base_position=root,catalog={'parts':{'part':{'collision_boxes':[dict(pos=[0,0,0],size=[.01,.01,.01])]}}})
        c=SimpleNamespace(ik=ik,env=env,actual_q=lambda:q.copy(),object_state=lambda _:state)
        screen=ReceivingArm(c,'part','left')
        self.assertTrue(screen.clear(q))
        self.assertFalse(screen.clear(q,hand_clearance=.003))
        self.assertEqual(screen.blocked['reason'],'receiving_hand_touches_part_before_hover')


    def test_installed_frame_is_checked_during_receiver_motion(self):
        ik=UpperBodyIK();q=np.zeros(len(ik.qadr));root=[0,0,.79]
        ik._set(root,[1,0,0,0],q)
        wrist=ik.d.xpos[ik.m.body('right_wrist_yaw_link').id].copy()
        states={'payload':dict(position=[3.,3.,3.],quat=[1,0,0,0]),
                'installed_frame':dict(position=wrist,quat=[1,0,0,0])}
        box=dict(pos=[0,0,0],size=[.04,.04,.04])
        env=SimpleNamespace(base_position=root,catalog={'parts':{n:dict(collision_boxes=[box])for n in states}})
        c=SimpleNamespace(ik=ik,env=env,actual_q=lambda:q.copy(),object_state=lambda n:states[n])
        self.assertTrue(ReceivingArm(c,'payload','right').clear(q))
        screen=ReceivingArm(c,'payload','right',protect_scene=True)
        self.assertFalse(screen.clear(q))
        self.assertEqual(screen.blocked['object'],'installed_frame')
        states['installed_frame']['position']=[4.,4.,4.]
        self.assertTrue(screen.clear(q))


    def test_positive_hand_torso_margin_is_separate_from_penetration(self):
        from humanoid.g1_support_retrieval.task_spec import JOINT_NAMES
        ik=UpperBodyIK();q=np.zeros(len(ik.qadr))
        q[JOINT_NAMES.index('left_shoulder_roll_joint')]=.5
        q[JOINT_NAMES.index('right_shoulder_roll_joint')]=-.5
        state=dict(position=[3.,3.,3.],quat=[1,0,0,0])
        env=SimpleNamespace(base_position=[0,0,.79],catalog={'parts':{'part':{'collision_boxes':[dict(pos=[0,0,0],size=[.01,.01,.01])]}}})
        c=SimpleNamespace(ik=ik,env=env,actual_q=lambda:q.copy(),object_state=lambda _:state)
        self.assertTrue(ReceivingArm(c,'part','right').clear(q,self_clear=True))
        screen=ReceivingArm(c,'part','right',self_margin=1.)
        self.assertFalse(screen.clear(q,self_clear=True))
        self.assertEqual(screen.blocked['reason'],'hand_torso_clearance')
        self.assertGreater(screen.blocked['distance_m'],0.)


if __name__=='__main__':unittest.main()
