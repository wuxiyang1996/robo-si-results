"""Clear the composed stand's route with the existing physical sleeve grasp."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_tabletop_assembly.solution import sleeve


def clear(c):
    start_q=c.q.copy();lo,hi=c.ik.lo.copy(),c.ik.hi.copy()
    original_hands=c.move_hands
    def checked_hands(tasks,*args,**kwargs):
        result=original_hands(tasks,*args,**kwargs)
        if c.phase!='sleeve_lower_to_outer_walls':return result
        # The timed descent in a77 ended 28 mm high and eight degrees off,
        # so closing then pushed the tube away. Reach the real fitted pose.
        point,rotation=sleeve.grasp_pose(c)
        solution,errors=c.ik.solve(c.env.base_position,(1,0,0,0),c.q,{'left':('palm',point,rotation)},iters=600,damping=.02,w_rot=.5,max_step=.08)
        c.event('sleeve_stage_converged_approach',errors=errors)
        if errors['left']>.004:raise RuntimeError('sleeve staging: fitted grasp endpoint is unreachable')
        c.move_joints(solution,seconds=2.)
        cp=np.zeros(3);cr=np.zeros(3)
        for _ in range(250):
            point,rotation=sleeve.grasp_pose(c);hp,hR=c.hand_pose('left')
            error=point-hp;rv=Rotation.from_matrix(rotation@hR.T).as_rotvec()
            if np.linalg.norm(error)<.0015 and np.linalg.norm(rv)<.015:break
            cp=np.clip(cp+np.clip(.05*error,-.0004,.0004),-.02,.02)
            cr=np.clip(cr+np.clip(.025*rv,-.001,.001),-.15,.15)
            command_R=Rotation.from_rotvec(cr+.4*rv).as_matrix()@rotation
            c.reach({'left':('palm',point+cp,command_R)},feedback=.6,iters=24);c.step()
        c.event('sleeve_stage_measured_grasp_pose',position_error=float(np.linalg.norm(error)),rotation_error=float(np.linalg.norm(rv)))
        if np.linalg.norm(error)>.004 or np.linalg.norm(rv)>.04:
            raise RuntimeError('sleeve staging: palm has not physically reached the fitted grasp')
        return result
    c.move_hands=checked_hands
    try:
        from humanoid.g1_tabletop_assembly.solution.transition import positive_elbow_ready
        positive_elbow_ready(c)
        c.event('clear_stand_route_grasp_sleeve')
        result=sleeve.grasp(c,lift_height=.10,hold_seconds=1.,settle_timeout=1.)
        if not result['grasp_verified']:raise RuntimeError('sleeve staging: original physical grasp failed')
        state=c.object_state('sleeve');p=np.asarray(state['pos']);hp,hR=c.hand_pose('left')
        goal=np.array([.29,.25,c.env.cfg.table_height+c.env.cfg.sleeve_height/2+.001])
        c.event('clear_stand_route_carry_sleeve',goal=goal.tolist())
        c.move_hands({'left':('palm',hp+np.r_[goal[:2]-p[:2],0.],hR)},seconds=3.,feedback=.5)
        state=c.object_state('sleeve');p=np.asarray(state['pos']);hp,hR=c.hand_pose('left')
        if not state['hand_contact']:raise RuntimeError('sleeve staging: grasp lost before table landing')
        c.event('clear_stand_route_lower_sleeve')
        c.move_hands({'left':('palm',hp+goal-p,hR)},seconds=2.,feedback=.5)
        sleeve.release(c,seconds=1.)
        hp,hR=c.hand_pose('left');c.move_hands({'left':('palm',hp+[0,0,.20],hR)},seconds=2.,feedback=.5)
        c.hold(.5);state=c.object_state('sleeve')
        R=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
        if state['robot_contact'] or state['support_forces'].get('table',0)<.05 or np.linalg.norm(np.asarray(state['pos'])-goal)>.015 or R[2,2]<.95:
            raise RuntimeError('sleeve staging: released part is not stable at the cleared-route location')
        c.ik.lo[:],c.ik.hi[:]=lo,hi
        from .approach_path import move
        move(c,start_q,'left')
        c.event('sleeve_route_clear_probe_success',position=state['pos'])
    finally:
        c.move_hands=original_hands
        c.ik.lo[:],c.ik.hi[:]=lo,hi
        servo=getattr(c,'_sleeve_finger_servo',None)
        if servo is not None:servo.remove()
