"""An idle hand can disturb a credited frame when the shared waist turns."""
import unittest
from types import SimpleNamespace
import numpy as np
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from .reference_carry_path import arm_screens,clear_arms


class IdleArmTests(unittest.TestCase):
    def test_left_finger_collision_blocks_a_right_hand_carry(self):
        ik=UpperBodyIK();q=np.zeros(len(ik.qadr));root=[0,0,.79]
        ik._set(root,[1,0,0,0],q)
        finger=ik.point(ik.m.body('left_hand_middle_1_link').id,[.04,0,0])
        states={'payload':dict(position=[3.,3.,3.],quat=[1,0,0,0]),
                'installed_frame':dict(position=finger,quat=[1,0,0,0])}
        box=dict(pos=[0,0,0],size=[.025,.025,.025])
        env=SimpleNamespace(base_position=root,catalog={'parts':{n:dict(collision_boxes=[box])for n in states}})
        c=SimpleNamespace(ik=ik,env=env,actual_q=lambda:q.copy(),object_state=lambda n:states[n])
        screens=arm_screens(c,'payload')
        self.assertTrue(next(s for s in screens if s.side=='right').clear(q))
        clear,blocked=clear_arms(screens,q)
        self.assertFalse(clear)
        self.assertEqual(blocked['side'],'left')
        self.assertEqual(blocked['object'],'installed_frame')
        states['installed_frame']['position']=[4.,4.,4.]
        self.assertTrue(clear_arms(screens,q)[0])

    def test_only_the_loaded_hand_may_touch_the_carried_part(self):
        ik=UpperBodyIK();q=np.zeros(len(ik.qadr));root=[0,0,.79]
        ik._set(root,[1,0,0,0],q)
        point=ik.point(ik.m.body('left_hand_index_1_link').id,[.04,0,0])
        state=dict(position=point,quat=[1,0,0,0])
        box=dict(pos=[0,0,0],size=[.01,.01,.01])
        env=SimpleNamespace(base_position=root,catalog={'parts':{'payload':dict(collision_boxes=[box])}})
        c=SimpleNamespace(ik=ik,env=env,actual_q=lambda:q.copy(),object_state=lambda n:state)
        screens=arm_screens(c,'payload')
        self.assertTrue(clear_arms(screens,q,grasp_side='left')[0])
        clear,blocked=clear_arms(screens,q,grasp_side='right')
        self.assertFalse(clear)
        self.assertEqual(blocked['side'],'left')
        self.assertEqual(blocked['reason'],'receiving_hand_touches_part_before_hover')


if __name__=='__main__':unittest.main()
