"""Tool reacquisition must follow real release and update the final parking grip."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from .repair_pitched_drive import drive_regrasp


class PhysicalRegraspTests(unittest.TestCase):
    def make(self):
        ik=SimpleNamespace(lo=np.zeros(2),hi=np.ones(2),set_limit=lambda *a:None)
        c=SimpleNamespace(ik=ik,env=SimpleNamespace(status={'completed':[]}),event=lambda *a,**kw:None,hold=lambda *a:None)
        old=object();new=object()
        held=SimpleNamespace(grip=old,local=('old',),level=True,corr_p=np.ones(3),corr_r=np.ones(3))
        fresh=SimpleNamespace(grip=new,local=('new',),level=True,corr_p=np.zeros(3),corr_r=np.zeros(3))
        return c,held,fresh

    def test_new_physical_grip_is_used_for_later_strokes_and_final_parking(self):
        c,held,fresh=self.make();calls=[]
        def stroke(c,h,strokes):
            calls.append(('drive',h.grip,strokes))
            if len([x for x in calls if x[0]=='drive'])==2:c.env.status['completed']=['drive_test']
            return dict(completed=list(c.env.status['completed']))
        def park(c,g,h):calls.append(('park',g))
        def pick(*a,**kw):calls.append(('pick',fresh.grip));return fresh.grip,fresh,{}
        released=(np.zeros(3),np.eye(3),0.,dict(robot_contact_force=0.,support_forces={'table':1.}))
        with patch('assembly_family.repair_pitched_drive.drive',side_effect=stroke),patch('assembly_family.repair_pitched_drive.pose',return_value=released),patch('humanoid.g1_gear_assembly.solution.stage_drive.park_tool',side_effect=park),patch('assembly_family.tool_pick.pick_parallel',side_effect=pick):
            result=drive_regrasp(c,held,strokes=10)
        self.assertEqual([x[0]for x in calls],['drive','park','pick','drive'])
        self.assertIs(calls[1][1],calls[0][1])
        self.assertIs(calls[3][1],fresh.grip)
        self.assertIs(held.grip,fresh.grip)
        self.assertEqual(held.local,('new',))
        self.assertIn('drive_test',result['completed'])

    def test_contacting_tool_cannot_be_treated_as_released_for_regrasp(self):
        c,held,fresh=self.make()
        touching=(np.zeros(3),np.eye(3),0.,dict(robot_contact_force=.2,support_forces={'table':1.}))
        with patch('assembly_family.repair_pitched_drive.drive',return_value={}),patch('assembly_family.repair_pitched_drive.pose',return_value=touching),patch('humanoid.g1_gear_assembly.solution.stage_drive.park_tool'),patch('assembly_family.tool_pick.pick_parallel')as pick:
            with self.assertRaisesRegex(RuntimeError,'genuinely released'):drive_regrasp(c,held,strokes=4)
            pick.assert_not_called()


if __name__=='__main__':unittest.main()
