"""Receiving targets remain continuous while a carrier crosses vertical."""
import unittest
from types import SimpleNamespace
import numpy as np
from scipy.spatial.transform import Rotation
from .reference_handoff import bind_side_target


class ReceiverFrameTests(unittest.TestCase):
    def test_vertical_crossing_preserves_same_material_grasp(self):
        centre=np.array([.28,.08,.95]);local=np.array([-.08,-.08,.04])
        initial=Rotation.from_euler('y',89.99,degrees=True).as_matrix()
        wrist=Rotation.from_euler('xyz',[.3,-.2,.5]).as_matrix()
        state={}
        def update(rotation):
            state.update(position=centre.tolist(),quat=Rotation.from_matrix(rotation).as_quat()[[3,0,1,2]].tolist())
        update(initial)
        c=SimpleNamespace(object_state=lambda name:state)
        grip=SimpleNamespace(name='lower_crossbar',side='right',target=lambda:{'right':('palm',centre+initial@local,wrist)})
        target=bind_side_target(c,grip)
        first=target(.03)['right'][1]
        after=Rotation.from_euler('y',90.01,degrees=True).as_matrix();update(after)
        _,point,rotation=target(.03)['right']
        # Yaw jumps by pi here, but a 0.02-degree physical rotation must move
        # this grasp by less than a tenth of a millimetre, not to another rail.
        self.assertLess(np.linalg.norm(point-first),.0001)
        np.testing.assert_allclose(after.T@(point-centre),local+[0,0,.03],atol=1e-12)
        np.testing.assert_allclose(rotation,after@initial.T@wrist,atol=1e-12)


if __name__=='__main__':unittest.main()
