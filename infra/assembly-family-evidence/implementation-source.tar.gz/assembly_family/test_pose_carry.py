"""A settled grasp reference must survive the start of its carry skill."""
import unittest
from types import SimpleNamespace
import numpy as np
from scipy.spatial.transform import Rotation
from .pose_carry import move


class FirstStep(Exception):pass


class CarryContinuityTests(unittest.TestCase):
    def test_preserves_nominal_pose_without_applying_feedback_twice(self):
        part=np.array([.22,-.26,.78]);hand=part+[0.,0.,.08]
        actual_R=Rotation.from_euler('x',.4).as_matrix()
        nominal=hand+[-.028,.002,-.035]
        nominal_R=Rotation.from_euler('y',.21).as_matrix()@actual_R
        ik=SimpleNamespace(_set=lambda *args:None,hand_point=lambda *args:nominal,
                           d=SimpleNamespace(xmat=nominal_R.reshape(1,9)),wrist={'right':0})
        observed=[]
        c=SimpleNamespace(ik=ik,q=np.zeros(43),env=SimpleNamespace(base_position=[0,0,.79]),
                          object_state=lambda name:dict(position=part,quat=[1,0,0,0],robot_contact_force=30.),
                          hand_pose=lambda side:(hand,actual_R),event=lambda *args,**kwargs:None,
                          reach=lambda tasks,**kwargs:observed.append((tasks,kwargs)),
                          step=lambda:(_ for _ in ()).throw(FirstStep()))
        grip=SimpleNamespace(name='right_frame',side='right')
        with self.assertRaises(FirstStep):
            move(c,grip,part,np.eye(3),2.,'test',preserve_reference=True)
        tasks,kwargs=observed[0]
        np.testing.assert_allclose(tasks['right'][1],nominal,atol=1e-12)
        np.testing.assert_allclose(tasks['right'][2],nominal_R,atol=1e-12)
        self.assertEqual(kwargs['feedback'],0.)
        self.assertEqual(kwargs['rotation_feedback'],0.)


if __name__=='__main__':unittest.main()
