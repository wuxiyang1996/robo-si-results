"""Negative scoring tests: physical contact gates must not accept pose-only witnesses."""
import unittest
from dataclasses import asdict
from copy import deepcopy
from .assembly_extension import ExtensionConfig,ExtensionEvaluator
from .contracts import plan,DESIGN
import json

class LoadPathTests(unittest.TestCase):
    def fixture_state(self):
        cfg=ExtensionConfig();ev=ExtensionEvaluator(cfg)
        def raw():return dict(pos=[.59,0,.76],quat=[1,0,0,0],linear_velocity=[0,0,0],angular_velocity=[0,0,0],hand_contact=False,robot_contact=False,support_forces={})
        states={n:raw() for n in ('fixture','brace','shim')}
        states['fixture']['support_forces']={'shim':.3};states['shim']['support_forces']={'brace':.4};states['brace']['support_forces']={'table':1.}
        parsed=raw();parsed['pos']=cfg.fixture_center;parsed['rotation']=[[1,0,0],[0,1,0],[0,0,1]]
        ev.measured=states
        return ev,states,parsed
    def test_composite_requires_two_measured_bodies(self):
        ev,states,f=self.fixture_state();self.assertTrue(ev._brace_supported(None,f))
        states['fixture']['support_forces']={'brace':.3}
        self.assertFalse(ev._brace_supported(None,f))
    def test_touch_and_floating_stack_are_rejected(self):
        ev,states,f=self.fixture_state();states['brace']['robot_contact']=True
        self.assertFalse(ev._brace_supported(None,f))
        states['brace']['robot_contact']=False;states['brace']['support_forces']={}
        self.assertFalse(ev._brace_supported(None,f))
    def test_force_cycle_cannot_replace_ground_support(self):
        ev,states,f=self.fixture_state();states['brace']['support_forces']={'shim':1.}
        self.assertFalse(ev._brace_supported(None,f))
    def test_roundtrip_keeps_extension_geometry(self):
        for task in ('ASM-03','ASM-04'):
            cfg=ExtensionConfig(extension=task);other=ExtensionConfig(**json.loads(json.dumps(asdict(cfg))))
            self.assertEqual(cfg.scene_objects(),other.scene_objects())
    def test_all_ten_have_specific_plans_and_candidates(self):
        import ast
        tree=ast.parse(__import__('pathlib').Path(__file__).with_name('policies.py').read_text())
        names={x.name for x in tree.body if isinstance(x,ast.FunctionDef)}
        items=json.loads(DESIGN.read_text())['tasks'];self.assertEqual(len(items),10)
        for item in items:
            p=plan(item['id']);self.assertIn(item['id'].lower().replace('-','_'),names)
            self.assertTrue(all(x['low_level'] for x in p['high_level']))
            self.assertEqual(p['body'],'G-reference')

class ExtensionGateTests(unittest.TestCase):
    def gear_state(self):
        from .portable import catalog
        from humanoid.g1_gear_assembly.task_spec import TaskConfig
        data=catalog('GEAR');cfg=TaskConfig();objects={}
        for n,p in data['parts'].items():
            objects[n]=dict(position=[cfg.origin[i]+p['goal_local'][i] for i in range(3)],
                quat=p.get('goal_quat_wxyz',[1,0,0,0]),linear_velocity=[0,0,0],angular_velocity=[0,0,0],
                robot_contact_force=0.,support_forces={'table' if n in ('base','turning_tool') else 'base':1.},contact_forces={})
        return cfg,data,{'objects':objects}
    def test_repair_cannot_pass_by_spontaneous_settling(self):
        from .gear_extension import RepairEvaluator
        cfg,data,state=self.gear_state();ev=RepairEvaluator(cfg,data)
        bad=deepcopy(state);bad['objects']['medium_gear']['position'][0]+=.012
        ev.update(bad,.0025)
        for _ in range(1500):result=ev.update(state,.0025)
        self.assertEqual(result['stage'],2);self.assertFalse(result['success']);self.assertEqual(ev.extracted,set())
    def test_tool_choice_requires_held_contact_with_gear(self):
        from .gear_extension import ToolEvaluator
        cfg,data,state=self.gear_state()
        for n in ('thin_tool','wide_tool'):state['objects'][n]=deepcopy(state['objects']['turning_tool'])
        state['objects']['thin_tool']['robot_contact_force']=1.
        ev=ToolEvaluator(cfg,data);ev.update(state,.0025);self.assertIsNone(ev.selected)
        state['objects']['thin_tool']['contact_forces']['small_gear']=.2
        ev.update(state,.0025);self.assertEqual(ev.selected,'thin_tool')
    def test_fixture_aggregation_preserves_only_measured_forces(self):
        from .reference_extension import normalize
        raw={'objects':{'x':{'support_forces':{'fixture':1.,'temporary_fixture':.2,'access_wall':.3}}}}
        out=normalize(raw)
        self.assertAlmostEqual(out['objects']['x']['support_forces']['fixture'],1.2)
        self.assertEqual(raw['objects']['x']['support_forces']['temporary_fixture'],.2)
class ContactGeometryTests(unittest.TestCase):
    def test_shared_wrist_link_does_not_hide_wrist_casing(self):
        from .contact_audit import is_hand
        for side in ('left','right'):
            link=side+'_wrist_yaw_link'
            self.assertTrue(is_hand(link,side+'_hand_palm_link.STL'))
            self.assertFalse(is_hand(link,side+'_wrist_yaw_link.STL'))
            self.assertFalse(is_hand(link,''))
            self.assertFalse(is_hand(side+'_wrist_pitch_link',side+'_hand_palm_link.STL'))
    def test_geometry_trace_preserves_original_force_threshold(self):
        from .contact_audit import violations
        catalog={'1':{'link':'right_wrist_yaw_link','mesh_path':'right_hand_palm_link.STL'},
                 '2':{'link':'right_wrist_yaw_link','mesh_path':'right_wrist_yaw_link.STL'}}
        self.assertEqual(violations({'1|board':30.,'2|board':2.},catalog),[])
        bad=violations({'1|board':30.,'2|board':2.001},catalog)
        self.assertEqual(len(bad),1);self.assertEqual(bad[0]['robot_geom'],2)

if __name__=='__main__':unittest.main()

