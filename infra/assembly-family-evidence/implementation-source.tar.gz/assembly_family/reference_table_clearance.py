"""Keep a real rear table pivot while clearing the carrier's front edge."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose
from .pose_carry import move


def stage(c,grip,turn_to_center=True):
    name=grip.name;p,R,yaw,_=pose(c,name);table_z=float(p[2])
    half=np.asarray(c.env.catalog['parts'][name]['size'])/2
    pivot_local=np.array([0.,-half[1],-half[2]])
    pivot=p+R@pivot_local
    tilt=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',.04).as_matrix()
    target=pivot-tilt@pivot_local
    move(c,grip,target,tilt,2.5,'carrier_raise_front_edge_about_table_pivot')
    p,R,_,state=pose(c,name);front=p+R@[0,half[1],-half[2]]
    c.event('carrier_measured_front_edge_clearance',height=front[2]-c.env.cfg.table_height,supports=state['support_forces'])
    if front[2]<c.env.cfg.table_height+.003 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: front edge has no measured table-lip clearance')
    move(c,grip,[.285,p[1],p[2]],tilt,3.,'carrier_translate_inboard_before_turning')
    p=pose(c,name)[0];move(c,grip,[p[0],.30,p[2]],tilt,3.,'carrier_table_pivot_move_toward_center')
    if not turn_to_center:
        move(c,grip,[.285,.30,table_z],Rotation.from_euler('z',yaw).as_matrix(),3.,'carrier_flatten_before_balanced_regrasp')
        return
    p=pose(c,name)[0];turned=Rotation.from_euler('z',np.pi).as_matrix()@Rotation.from_euler('x',.04).as_matrix()
    move(c,grip,p,turned,5.,'carrier_turn_with_raised_front_edge')
    p=pose(c,name)[0];move(c,grip,[.285,0,p[2]],turned,5.,'carrier_cross_midline_inside_table_boundary')
    move(c,grip,[.285,0,table_z],Rotation.from_euler('z',np.pi).as_matrix(),3.,'carrier_flatten_on_table_for_balanced_pick')
