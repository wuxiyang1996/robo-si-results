"""Publishable execution snapshot, with immutable per-attempt evidence bundles."""
from pathlib import Path
import argparse,datetime,errno,gzip,hashlib,html,json,re,shutil,subprocess,tarfile,time
from .contracts import ROOT,DESIGN,plan,attempt_order

OUT=ROOT/'infra/assembly-family-evidence'
RUNS=ROOT/'assembly_family/runs'

def load(path,default=None):
    for attempt in range(3):
        try:return json.loads(path.read_text())
        except FileNotFoundError:return default
        except OSError as error:
            if error.errno!=errno.ESTALE or attempt==2:raise
            time.sleep(.02)
        except json.JSONDecodeError:
            # Older live recorders overwrite this one file in place. A snapshot
            # can omit a racing heartbeat; sealed evidence must remain strict.
            if path.name=='heartbeat.json':return default
            raise

def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n')

def collect():
    items=load(DESIGN)['tasks'];queue=load(ROOT/'assembly_family/queue.json',[])
    ids=sorted({str(x['job_id']) for x in queue}|{str(load(p,{}).get('job_id')) for p in RUNS.glob('*/*/started.json') if load(p,{}).get('job_id')})
    states={}
    if ids:
        r=subprocess.run(['squeue','-h','-j',','.join(ids),'-o','%i|%T'],capture_output=True,text=True)
        if r.returncode==0:states=dict(line.split('|',1) for line in r.stdout.splitlines())
    rows=[]
    for item in items:
        task=item['id'];attempts=[]
        for p in sorted((RUNS/task).glob('*'),key=attempt_order):
            if not p.is_dir():continue
            result=load(p/'outcome.json');start=load(p/'started.json',{})
            frozen=load(p/'plan.json',{})
            evidence_events=load(p/'events.json',[]) if result else []
            milestones=[x['phase'] for x in evidence_events if x.get('phase','').endswith(('_probe_success','_integrated_success'))]
            observed=[dict(phase=x['phase'],time=x.get('time')) for x in evidence_events if x.get('phase')in ('shim_undergrasp_stack_verified','carrier_side_pair_table_staging_success','carrier_side_pair_flat_lift_success')]
            if task=='ASM-03' and result:
                support=next((x for x in result.get('physics',{}).get('stage_history',[]) if x.get('stage')==1),None)
                if support:observed.append(dict(phase='original_support_stage_verified',time=support['time']))
                sleeve=next((x for x in result.get('physics',{}).get('stage_history',[]) if x.get('stage')==2),None)
                if sleeve:observed.append(dict(phase='original_sleeve_stage_verified',time=sleeve['time']))
            if not result or not result.get('physical_checks_pass') or not result.get('complete_artifacts'):observed=[]
            interruption=load(p/'infrastructure-interruption.json')
            record={'id':p.name,'job_id':start.get('job_id'),'body':'G-reference',
                    'status':'infrastructure_interrupted' if interruption else result['state'] if result else states.get(str(start.get('job_id')),'incomplete'),
                    'infrastructure_interruption':interruption,
                    'heartbeat':load(p/'heartbeat.json'),'result':result,'path':str(p.relative_to(ROOT)),
                    'policy':frozen.get('policy_entry'),'component_verified':bool(frozen.get('run_kind')=='component_probe' and milestones and result and result.get('physical_checks_pass') and result.get('complete_artifacts') and not result.get('error')),
                    'observed_milestones':observed,
                    'component_milestones':milestones}
            attempts.append(record)
        pending=[dict(x,state=states.get(str(x['job_id']),'not_in_queue')) for x in queue if x['task']==task and x['attempt'] not in [a['id'] for a in attempts]]
        usable=[a for a in attempts if a['result'] and (ROOT/a['path']/'trajectory.npz').exists() and (ROOT/a['path']/'video.mp4').exists()]
        passed=[a for a in usable if a['result'].get('goal_met')]
        def rank(a):
            r=a.get('result') or {};st=r.get('status') or {}
            physics=r.get('physics') or {}
            return (bool(r.get('goal_met')),bool(r.get('physical_goal_met')),float(st.get('progress',0)),bool(r.get('physical_checks_pass')),-len(physics.get('contacts',{}).get('forbidden',[])),attempt_order(a['id']))
        selected=max(usable,key=rank) if usable else attempts[-1] if attempts else None
        components={}
        for a in attempts:
            if a['component_verified']:components[a['policy']]=a['id']
        rows.append({'task_id':task,'name':item['name'],'planned_bodies':item['priority_embodiments'],
                     'candidate':'assembly_family/policies.py:'+task.lower().replace('-','_'),
                     'scope':'reference-body scene probe' if item['group']=='compatibility' else 'reference-body candidate expert',
                     'attempts':attempts,'queue':pending,'selected':selected['id'] if selected else None,'component_runs':list(components.values()),
                     'certified':bool(passed),'comparison_validated':False})
    data={'schema':'assembly-execution-snapshot/1','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'independent_tasks':10,'planned_body_configurations':13,'reference_body':'historical fixed-pelvis G1 MJCF, three-finger hands',
          'matched_official_body_adapters':'not implemented in this batch; G1 Dex3/Inspire and Stretch comparisons remain pending',
          'candidate_policies':10,'task_scorer_passes':sum(any(a['result'] and a['result'].get('physical_goal_met') for a in r['attempts']) for r in rows),
          'certified_tasks':sum(r['certified'] for r in rows),'tasks':rows}
    public=dict(data,tasks=[dict(r,attempts=[{k:v for k,v in a.items() if k!='result'}|{'result':{k:(a['result'] or {}).get(k) for k in ('state','goal_met','physical_goal_met','physical_checks_pass','complete_artifacts')}} for a in r['attempts']]) for r in rows]);dump(OUT/'status.json',public);dump(ROOT/'infra/planning/assembly-family/implementation-status.json',dict(generated_utc=data['generated_utc'],evidence='/infra/assembly-family-evidence/status.json',tasks=[dict(task_id=t['task_id'],attempts=[dict(id=a['id'],heartbeat=bool(a['heartbeat']),result={'physics':{'physics_samples':(a.get('result') or {}).get('physics',{}).get('physics_samples',0)}}) for a in t['attempts']]) for t in rows]))
    return data

def artifacts(data):
    import numpy as np
    audit=ROOT/'infra/planning/assembly-family/repair-support-rule-audit.json'
    if audit.exists():shutil.copyfile(audit,OUT/audit.name)
    for row in data['tasks']:
        (OUT/row['task_id']/'candidate-plan.json').unlink(missing_ok=True)
        for a in row['attempts']:
            if not a['result']:continue
            src=ROOT/a['path'];dest=OUT/row['task_id']/a['id'];dest.mkdir(parents=True,exist_ok=True)
            for obsolete in ('trajectory.npz','evidence.tar.gz'):
                (dest/obsolete).unlink(missing_ok=True)
            selected=a['id']==row['selected'] or a['id'] in row['component_runs']
            for name in ('plan.json','outcome.json','physics_checks.json','execution.json'):
                if name in ('execution.json','physics_checks.json') or (not selected and name!='outcome.json'):(dest/name).unlink(missing_ok=True)
                elif (src/name).exists():
                    payload=json.dumps(load(src/name),ensure_ascii=False,separators=(',',':')).encode()
                    (dest/(name+'.gz')).write_bytes(gzip.compress(payload,mtime=0))
                    (dest/name).unlink(missing_ok=True)
                if not selected and name!='outcome.json':(dest/(name+'.gz')).unlink(missing_ok=True)
            (dest/'final.png').unlink(missing_ok=True)
            if selected and (src/'video.mp4').exists():
                import imageio_ffmpeg
                target=dest/'video.mp4';stamp=dest/'video-preview.json'
                version={'source_sha256':hashlib.sha256((src/'video.mp4').read_bytes()).hexdigest(),'width':240,'crf':44,'fps':5}
                if load(stamp)!=version:
                    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-loglevel','error','-i',str(src/'video.mp4'),'-vf','scale=240:-2','-c:v','libx264','-crf','44','-preset','slow','-an','-movflags','+faststart',str(target)],check=True)
                    dump(stamp,version)
            elif not selected:
                (dest/'video.mp4').unlink(missing_ok=True);(dest/'video-preview.json').unlink(missing_ok=True)
            if selected and (src/'trajectory.npz').exists():
                with np.load(src/'trajectory.npz',allow_pickle=False) as raw:
                    np.savez_compressed(dest/'trajectory-control.npz',target_q_millirad=np.rint(raw['target_q'][::50]*1000).astype(np.int16),q_millirad=np.rint(raw['q'][::50]*1000).astype(np.int16),scale_rad=np.array(.001),time=raw['time'][::50],phase=raw['phase'][::50],high_level=raw['high_level'][::50])
            elif not selected:(dest/'trajectory-control.npz').unlink(missing_ok=True)
            if selected and (src/'sources.json').exists():
                sources=load(src/'sources.json')
                with tarfile.open(dest/'recorded-source.tar.gz','w:gz') as tf:
                    for rel,expected in sorted(sources.items()):
                        frozen=src/'sources'/rel
                        assert hashlib.sha256(frozen.read_bytes()).hexdigest()==expected,(src,rel)
                        tf.add(frozen,arcname='sources/'+rel)
                    for name in ('sources.json','source-load-manifest.json','evidence_limitations.json','plan.json','config.json','catalog.json','runtime.json','environment.json','limits.json','robot_collision_geometries.json'):
                        if (src/name).exists():tf.add(src/name,arcname=name)
            elif not selected:(dest/'recorded-source.tar.gz').unlink(missing_ok=True)
            mappings=load(src/'mapping.json',[])
            timeline=[{'phase':x['phase'],'high_level':x['high_level'], 'start_step':x['start_step'],'end_step':x['end_step']} for x in mappings]
            if (src/'trajectory.npz').exists():
                with np.load(src/'trajectory.npz',allow_pickle=False) as raw:
                    times=raw['time']
                    for x in timeline:
                        x['time']=float(times[x['start_step']-1]) if 0<x['start_step']<=len(times) else 0.
                        x['end_time']=float(times[x['end_step']-1]) if x['end_step'] and x['end_step']<=len(times) else x['time']
            if selected:dump(dest/'timeline.json',{'columns':['time','end_time','high_level','phase'],'segments':[[round(x['time'],3),round(x['end_time'],3),x['high_level'],x['phase']] for x in timeline]})
            else:(dest/'timeline.json').unlink(missing_ok=True)
            (dest/'manifest.json').unlink(missing_ok=True)
    with tarfile.open(OUT/'implementation-source.tar.gz','w:gz') as tf:
        for pattern in ('*.py','*.sbatch','*.md'):
            for p in sorted((ROOT/'assembly_family').glob(pattern)):tf.add(p,arcname='assembly_family/'+p.name)
        for p in sorted((ROOT/'assembly_family/grasp_candidates').glob('*/grasp.json')):tf.add(p,arcname=str(p.relative_to(ROOT)))
        tf.add(DESIGN,arcname=str(DESIGN.relative_to(ROOT)))
    index={str(p.relative_to(OUT)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in OUT.rglob('*') if p.is_file() and p.name!='artifact-index.json.gz'}
    (OUT/'artifact-index.json.gz').write_bytes(gzip.compress(json.dumps(index,separators=(',',':')).encode(),mtime=0))

def render(data,lang):
    zh=lang=='zh';e=html.escape
    title='装配任务 · 执行与证据' if zh else 'Assembly tasks · execution and evidence'
    intro=('10 个独立任务已接入候选专家与统一记录器。这里展示实际尝试，任务得分与物理审查分开。单次失败不代表任务不可行。' if zh else
           'Ten independent tasks have candidate experts and one recording pipeline. Actual attempts are shown with separate task and physics verdicts. One failed route does not prove infeasibility.')
    body_note=('当前执行身体为历史固定骨盆 G1 三指模型。相性任务当前只有场景探针；正式 G1 Dex3 / Inspire 五指与 Stretch 3 配对实验尚未实现，不能据此比较身体强弱。' if zh else
               'Runs use the historical fixed-pelvis G1 three-finger model. Compatibility tasks currently have scene probes only. Matched official G1 Dex3 / Inspire and Stretch 3 experiments remain unimplemented; these runs do not establish body rankings.')
    parts=[f'<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><link rel="stylesheet" href="assembly-family-evidence/evidence.css"></head><body><main>',
           f'<nav><a href="task-assembly-family-{lang}.html">{("任务设计" if zh else "Task design")}</a> · <a href="task-assembly-evidence-{("en" if zh else "zh")}.html">{("English" if zh else "中文")}</a></nav>',
           f'<p class="eyebrow">EMBODIED TERMINAL-BENCH / EXECUTION</p><h1>{title}</h1><p class="lead">{intro}</p>',
           f'<div class="metrics"><div><b>10</b><span>{("候选专家" if zh else "Candidate experts")}</span></div><div><b>{data["task_scorer_passes"]}</b><span>{("任务评分通过" if zh else "Task scorer passed")}</span></div><div><b>{data["certified_tasks"]}</b><span>{("全部检查通过" if zh else "All checks passed")}</span></div><div><b>13</b><span>{("计划身体配置" if zh else "Planned body configurations")}</span></div></div>',
           f'<aside>{body_note}</aside><p class="muted">{("记录快照" if zh else "Snapshot")}: {e(data["generated_utc"])} · <a href="assembly-family-evidence/status.json">JSON</a> · <a href="assembly-family-evidence/implementation-source.tar.gz">{("实现源码" if zh else "Implementation source")}</a> · <a href="assembly-family-evidence/artifact-index.json.gz">SHA-256 (gzip)</a> · <a href="assembly-family-evidence/release-readiness.json">{("发布证据检查" if zh else "Release evidence check")}</a></p>',
           '<label for="family">Family </label><select id="family"><option value="all">All / 全部</option><option>ASM</option><option>GEAR</option><option>REF</option></select>']
    for row in data['tasks']:
        task=row['task_id'];a=next((x for x in row['attempts'] if x['id']==row['selected']),None)
        status=('待运行' if zh else 'Awaiting run') if not a else a['status']
        parts.append(f'<article id="{task}" data-family="{task.split("-")[0]}"><div class="heading"><h2>{task} · {e(row["name"][lang])}</h2><span class="badge">{e(status)}</span></div>')
        if task=='GEAR-02':
            note=('评分版本：用户已确认从新运行 original_grace_v1 起，与原始齿轮任务统一采用 0.3 s 支撑丢失宽限。中断期间不计传动角，持续失支撑撤销进度；提离、工具接触、齿比、释放和全部物理限制不变。历史尝试仍按 immediate_v0 保留原判定，新规则必须从初态重新运行验收。' if zh else 'Scoring version: new original_grace_v1 runs use the original gear task’s 0.3 s support-loss grace, as approved by the user. Unsupported motion earns no angle credit; sustained loss revokes progress. Extraction, tool contact, ratios, release and all physical limits are unchanged. Historical immediate_v0 verdicts are preserved; acceptance under the new rule requires a fresh execution from the initial scene.')
            parts.append('<p class="muted">'+e(note)+' · <a href="assembly-family-evidence/repair-support-rule-audit.json">'+('规则与回归审计' if zh else 'Rule and regression audit')+'</a></p>')
        history_start=len(parts)
        if task=='ASM-03' and any(x['id']=='a49' and x['result'] for x in row['attempts']):
            note=('阶段进展：a49 在完整轨迹中记录了垫片释放后的真实支撑块承重，整段物理检查通过；后续抓取没有接触到支撑块，任务失败。a53 恢复规划范围后仍有约 7 cm 接近误差，后续候选改为从接触位姿反推可达路径。上述早期尝试均未完成两件支撑的搬运或完整装配；较新检查点见下方。'
                  if zh else 'Stage progress: a49 recorded a released shim physically supported by the brace and passed the trajectory physics audit, but its subsequent brace grasp missed and the task failed. Restoring planning bounds in a53 still left an approximately 7 cm approach error; later candidates derive the approach from a reachable contact pose. Those early attempts did not complete two-piece transport or the assembly; newer checkpoints appear below.')
            parts.append('<p class="muted">'+e(note)+'</p>')
        if task=='ASM-03' and any(x['id']=='a55' and x['result'] for x in row['attempts']):
            parts.append('<p class="muted">'+e('a55：反推路径已实际执行并接近接触位姿，但仍未夹起支撑块；独立物理检查通过，任务未通过。' if zh else 'a55 executed the screened approach and reached near the contact pose, but still failed to lift the brace. The independent physics audit passed; the task did not.')+'</p>')
        if task=='REF-01' and any(x['id']=='a58' and x['result'] for x in row['attempts']):
            note=('复现检查：a58 在原 GPU 节点再次完成右框架交接、直立与落位，物理检查通过，但因先放右框架触发原评分 wrong_order；a57 在另一节点交接前滑脱。尚未证明跨节点稳定性或八件连续装配。'
                  if zh else 'Reproduction check: a58 repeated the right-frame handoff, upright rotation and placement on the original GPU node and passed the physics audit, but the original scorer rejected right-first placement as wrong_order. a57 slipped before handoff on another node. Cross-node reliability and complete eight-part assembly remain unverified.')
            parts.append('<p class="muted">'+e(note)+'</p>')
        if task=='REF-01' and any(x['id']=='a61' and x['component_verified'] for x in row['attempts']):
            note=('连续子序列：a61 已按左框架 → 右框架的原任务顺序完成装配与松手，原评分到达 stage 2，独立物理检查通过。其冻结高层计划仍有右框架先行的旧文字；实际动作与轨迹记录为左先右后。其余六件尚未完成，不计入完整任务通过数。'
                  if zh else 'Continuous subsequence: a61 assembled and released the left frame, then the right frame in the original task order. The original scorer reached stage 2 and the independent physics audit passed. Its frozen high-level plan still contains stale right-first prose; the recorded actions and trajectory show left first, then right. Six parts remain, so this does not count as a complete task pass.')
            parts.append('<p class="muted">'+e(note)+'</p>')
        if len(parts)>history_start:
            history=parts[history_start:];del parts[history_start:]
            parts.append('<details><summary>'+('历史诊断记录（非当前验收结论）' if zh else 'Historical diagnostics (not the current verdict)')+'</summary>'+''.join(history)+'</details>')
        latest=row['attempts'][-1] if row['attempts'] else None
        if latest:
            lp=load(ROOT/latest['path']/'plan.json',{})
            hb=latest.get('heartbeat') or {};lr=latest.get('result') or {}
            label=('最新尝试' if zh else 'Latest attempt')+f' {latest["id"]} · '+lp.get('policy_entry','—')+' · '+latest['status']
            if lp.get('run_kind')=='component_probe':label+=' · '+('部件或子序列诊断，不是完整任务见证' if zh else 'component diagnostic, not a complete task witness')
            if hb:label+=f' · {hb.get("time",0):.1f} s · '+str(hb.get('phase','—'))
            parts.append('<p class="muted">'+e(label)+'</p>')
            if latest['id']!=row['selected'] and lr.get('error'):
                parts.append('<p class="failure">'+e(lr['error'].splitlines()[-1])+'</p>')
        # Plans beside a replay must be the ones frozen before that run,
        # including alternate candidates, rather than today's edited policy.
        current=load(ROOT/a['path']/'plan.json',plan(task)) if a else plan(task)
        parts.append(f'<p class="muted">{("展示运行的专家入口" if zh else "Expert entry for displayed run")}: <code>{e(current.get("policy_entry",task.lower().replace("-","_")))}</code></p>')
        parts.append(f'<p>{e(row["scope"])}</p><details><summary>{("High / low planning · 高低层计划" if zh else "High / low planning")}</summary><ol>')
        for stage in current['high_level']:parts.append(f'<li><strong>{e(stage["goal"])}</strong><br><small>{e(" → ".join(stage["low_level"]))}</small></li>')
        parts.append('</ol></details>')
        if a and a['result']:
            r=a['result'];base=f'assembly-family-evidence/{task}/{a["id"]}';dest=OUT/task/a['id']
            def verdict(v):return ('通过' if zh else 'pass') if v else ('未通过' if zh else 'not passed')
            parts.append(f'<p class="verdict">{("任务" if zh else "Task")}: {verdict(r.get("physical_goal_met"))} · {("物理" if zh else "Physics")}: {verdict(r.get("physical_checks_pass"))} · {("本地证据" if zh else "Local evidence")}: {verdict(r.get("complete_artifacts"))}</p>')
            if a.get('observed_milestones') and not r.get('goal_met'):
                checkpoints=' · '.join(f'{x["phase"]} @ {x["time"]:.2f} s'for x in a['observed_milestones'])
                parts.append('<p class="muted">'+('实测中间检查点；完整任务未通过：'if zh else 'Observed intermediate checkpoints; complete task not passed: ')+e(checkpoints)+'</p>')
            if (dest/'video.mp4').exists():
                parts.append(f'<video controls preload="none" src="{base}/video.mp4"></video><p class="muted">{("连续物理执行的压缩预览，240 px / 5 fps；完整录制保存在工作区。" if zh else "Compressed execution preview, 240 px / 5 fps; full recordings remain in the workspace.")}</p>')
                timeline=load(dest/'timeline.json',{})
                if timeline:
                    parts.append(f'<label>{("跳转计划段" if zh else "Jump to plan segment")} <select class="segment" data-timeline="{base}/timeline.json"><option value="0">0 s</option>')
                    parts.append('</select></label>')
            physics=r.get('physics',{})
            if physics:parts.append(f'<p class="numbers">Δq {physics.get("max_joint_overrun",0):.5f} rad · v / limit {physics.get("max_velocity_ratio",0):.3f} · τcmd / limit {physics.get("max_effort_ratio",0):.3f} · scorer mismatches {physics.get("scorer_mismatches","—")}</p>')
            stage=(r.get('status') or {})
            parts.append(f'<p>{("场景进度" if zh else "Scene progress")}: {100*stage.get("progress",0):.0f}% · {("展示尝试" if zh else "Displayed attempt")}: {a["id"]}</p>')
            reasons=[]
            if physics.get('max_joint_overrun',0)>.001:reasons.append('joint position exceeds 0.001 rad tolerance')
            if physics.get('contacts',{}).get('forbidden'):reasons.append('forbidden non-hand contact')
            if reasons:parts.append('<p class="failure">'+e('; '.join(reasons))+'</p>')
            err=r.get('error')
            if err:parts.append(f'<p class="failure">{e(err.splitlines()[-1])}</p>')
            links=[('plan.json.gz','Run plan (gzip)'),('timeline.json','Plan ↔ trajectory'),('trajectory-control.npz','Trajectory preview · 1 Hz / 1 mrad'),('outcome.json.gz','Result + physics checks (gzip)'),('recorded-source.tar.gz','Recorded source snapshot'),]
            parts.append('<p class="links">'+' · '.join(f'<a href="{base}/{f}">{label}</a>' for f,label in links if (dest/f).exists())+'</p>')
        supplementary=[x for x in row['component_runs']if x!=row['selected']]
        if supplementary:
            parts.append('<details><summary>'+('其它已通过的部件诊断 · 不计入完整任务' if zh else 'Other verified component diagnostics · not complete tasks')+'</summary>')
            for component in supplementary:
                x=next(x for x in row['attempts'] if x['id']==component)
                base=f'assembly-family-evidence/{task}/{component}'
                parts.append(f'<p><strong>{e(component)} · {e(x["policy"])}</strong><br><small>{e(" · ".join(x["component_milestones"]))}</small></p>')
                parts.append(f'<video controls preload="none" src="{base}/video.mp4"></video>')
                parts.append('<p class="links">'+' · '.join(f'<a href="{base}/{file}">{label}</a>' for file,label in [('plan.json.gz','Plan'),('trajectory-control.npz','Trajectory preview'),('outcome.json.gz','Physics verdict'),('recorded-source.tar.gz','Recorded source')])+'</p>')
            parts.append('</details>')
        # Scheduler and heartbeat entries describe the same attempt. Prefer
        # the recorded heartbeat status and display each attempt only once.
        running_by_id={x['attempt']:x for x in row['queue'] if x['state'] in ('RUNNING','PENDING','COMPLETING')}
        running_by_id.update({x['id']:x for x in row['attempts'] if not x['result']})
        running=[running_by_id[k] for k in sorted(running_by_id,key=lambda k:int(k[1:]))]
        if running:parts.append('<p class="muted">'+e(('进行中 / 排队：' if zh else 'Running / queued: ')+', '.join(str(x.get('id',x.get('attempt')))+' ('+str(x.get('status',x.get('state')))+')' for x in running))+'</p>')
        parts.append('<details><summary>'+('所有尝试' if zh else 'All attempts')+'</summary><ul>')
        for x in row['attempts']:
            label=e(x['id']+' · '+x['status'])
            if x['result']:label=f'<a href="assembly-family-evidence/{task}/{x["id"]}/outcome.json.gz">{label}</a>'
            parts.append('<li>'+label+'</li>')
        parts.append('</ul></details></article>')
    parts.append('<footer>'+('物理审查：逐物理步实测关节位置、速度，检查受限力矩命令与接触；禁止执行中位姿写入、绑定和参数修改。网页下载为 1 Hz 轨迹预览副本（q 与目标 q，1 mrad 量化，解码乘 0.001）及视频；逐物理步原始轨迹、接触和对应源码快照完整保存在仓库 assembly_family/runs/。独立评分是对记录状态的重算，尚不是第二次独立动力学回放。控制器使用特权测量，不是仅视觉策略。每个展示视频附有对应录制时的源码快照；页首实现源码为当前候选。新录制按碰撞体区分手掌与腕部，并从逐步接触记录重算；历史 link 级记录不追溯改判。' if zh else 'Physics audit: per-step measured joint position/velocity, bounded torque commands and contacts; runtime state writes, attachments and parameter changes are guarded. Web downloads are compact 1 Hz trajectory previews (q and target q quantized to 1 mrad; multiply by 0.001 to decode radians) and videos. Full per-physics-step traces, contacts and matching source snapshots remain in the repository under assembly_family/runs/. Independent scoring recomputes recorded measurements; it is not a second dynamics replay. Controllers use privileged measurements, not vision-only policies. Each selected video includes its matching recorded source snapshot; the header source archive is the current candidate. New recordings distinguish palm and wrist collision geometries and independently recompute contact verdicts. Historical link-only verdicts are preserved.')+'</footer></main><script src="assembly-family-evidence/evidence.js"></script></body></html>')
    (ROOT/f'infra/task-assembly-evidence-{lang}.html').write_text('\n'.join(parts))
    # Narrow markers preserve unrelated authored content in every existing task page.
    selected=[('tabletop-assembly','ASM'),('gear-assembly','GEAR'),('reference-assembly','REF'),('assembly-family',None)]
    for slug,family in selected:
        p=ROOT/f'infra/task-{slug}-{lang}.html'
        if not p.exists():continue
        block=f'<!-- assembly-execution:start --><section id="assembly-execution"><h2>{title}</h2><p>{intro}</p><p><a href="task-assembly-evidence-{lang}.html'+('#'+family+'-01' if family else '')+'">'+('查看专家、计划、轨迹、物理检查与视频' if zh else 'View experts, plans, trajectories, physics checks and videos')+'</a></p></section><!-- assembly-execution:end -->'
        old=p.read_text();pattern=r'<!-- assembly-execution:start -->.*?<!-- assembly-execution:end -->'
        p.write_text(re.sub(pattern,lambda _:block,old,flags=re.S) if re.search(pattern,old,re.S) else old.replace('</main>',block+'\n</main>',1))

def update_readme(data):
    lines=['<!-- execution-status:start -->','## 实际执行快照','',f"UTC：{data['generated_utc']}。任务评分通过 {data['task_scorer_passes']} / 10；全部检查通过 {data['certified_tasks']} / 10。",'', '| 任务 | 尝试数 | 展示尝试 | 场景进度 | 任务评分 | 物理检查 |','| --- | ---: | --- | ---: | --- | --- |']
    for row in data['tasks']:
        attempt=next((a for a in row['attempts'] if a['id']==row['selected']),None)
        result=(attempt or {}).get('result') or {};status=result.get('status') or {}
        lines.append(f"| {row['task_id']} | {len(row['attempts'])} | {row['selected']} | {status.get('progress',0):.0%} | {'通过' if result.get('physical_goal_met') else '未通过'} | {'通过' if result.get('physical_checks_pass') else '未通过'} |")
    lines+=['','[中文任务页](../infra/task-assembly-evidence-zh.html) · [执行状态 JSON](../infra/assembly-family-evidence/status.json)。完整证据在 `runs/<任务>/<尝试>/`。','<!-- execution-status:end -->']
    p=ROOT/'assembly_family/README.md';old=p.read_text();block='\n'.join(lines)
    p.write_text(re.sub(r'<!-- execution-status:start -->.*?<!-- execution-status:end -->',lambda _:block,old,flags=re.S) if '<!-- execution-status:start -->' in old else old+'\n'+block+'\n')

def main():
    from .release import readiness
    data=collect();gate=readiness();dump(OUT/'release-readiness.json',gate)
    data['task_evidence_release_ready']=gate['task_evidence_ready']
    update_readme(data);artifacts(data)
    for lang in ('zh','en'):render(data,lang)
    print(json.dumps({k:data[k] for k in ('generated_utc','candidate_policies','task_scorer_passes','certified_tasks')}))
if __name__=='__main__':main()
