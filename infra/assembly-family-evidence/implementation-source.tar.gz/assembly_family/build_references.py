"""Regenerate reference images from unchanged local CAD, with fresh fingerprints."""
from pathlib import Path
import argparse,copy,importlib,json
from .portable import catalog

def build(family,output,backend):
    prefix='humanoid.g1_gear_assembly' if family=='GEAR' else 'humanoid.g1_reference_assembly'
    assets=importlib.import_module(prefix+'.assets');data=catalog(family)
    assets.build_assets=lambda:copy.deepcopy(data)
    if family=='GEAR':
        import genesis as gs
        gs.init(backend=gs.gpu if backend=='gpu' else gs.cpu,precision='64',logging_level='warning')
    ref=importlib.import_module(prefix+'.reference')
    from PIL import ImageFont
    font=Path(__file__).parent/'fonts/NotoSansCJKsc-Regular.otf'
    ref._font=lambda size,bold=False:ImageFont.truetype(str(font),size)
    shared=importlib.import_module('humanoid.g1_reference_assembly.reference')
    shared._font=ref._font
    result=ref.build_reference_bundles(output,backend=backend,resolution=(640,480))
    print(json.dumps({'family':family,'output':str(output),'fingerprint':result['catalog_fingerprint']}),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--family',required=True);p.add_argument('--output',required=True);p.add_argument('--backend',default='gpu');a=p.parse_args()
    build(a.family,a.output,a.backend)
