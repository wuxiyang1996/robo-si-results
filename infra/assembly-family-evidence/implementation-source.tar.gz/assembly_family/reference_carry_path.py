"""Plan a carried reference part using its measured, physical grasp transform."""
import itertools
from types import SimpleNamespace
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from humanoid.g1_support_retrieval.task_spec import JOINT_NAMES
from humanoid.g1_gear_assembly.solution.skills import pose, side_forces
from .grasp_clearance import ReceivingArm


def arm_screens(c,name,clearance=.025):
    return [ReceivingArm(c,name,s,clearance=clearance,protect_scene=True)for s in ('left','right')]


def clear_arms(screens,q,grasp_side=None,**kwargs):
    for screen in screens:
        options=dict(kwargs)
        if grasp_side is not None and screen.side!=grasp_side:options['hand_clearance']=.010
        if not screen.clear(q,**options):return False,dict(side=screen.side,**(screen.blocked or {}))
    return True,None


def move(c, grip, goal, rotation):
    name, side = grip.name, grip.side
    base = c.actual_q().copy()
    p, R, _, _ = pose(c, name)
    hp, hR = c.hand_pose(side)
    local_p, local_R = R.T @ (hp-p), R.T @ hR
    states = {n: dict(c.object_state(n)) for n in c.env.objects}
    env = SimpleNamespace(base_position=c.env.base_position, catalog=c.env.catalog,
                          cfg=c.env.cfg, objects=c.env.objects)
    query = SimpleNamespace(ik=c.ik, env=env, actual_q=lambda: base,
                            object_state=lambda n: states[n])
    screens = arm_screens(query,name)
    screen = next(s for s in screens if s.side==side)
    fk = UpperBodyIK()
    # Preserve the settled motor target across the handoff boundary. The
    # carried-part plan uses actual geometry; the controller still needs the
    # outgoing servo's load compensation to avoid opening the grasp by motion.
    fk._set(c.env.base_position, (1, 0, 0, 0), c.q)
    reference_p = fk.hand_point(side, 'palm').copy()-hp
    reference_R = fk.d.xmat[fk.wrist[side]].reshape(3, 3).copy()@hR.T
    c.event('reference_carry_preserve_loaded_reference', part=name,
            position_bias=reference_p.tolist(),
            rotation_bias=Rotation.from_matrix(reference_R).as_rotvec().tolist())
    active = [int(i) for i in c.ik.upper if JOINT_NAMES[i].startswith(('waist', side+'_'))]
    slots = [list(c.ik.upper).index(i) for i in active]
    lo, hi = c.ik.lo[slots], c.ik.hi[slots]
    queries = 0
    blocked = None

    def clear(point):
        nonlocal queries, blocked
        blocked = None
        queries += 1
        q = base.copy(); q[active] = point
        fk._set(c.env.base_position, (1, 0, 0, 0), q)
        wrist = fk.d.xmat[fk.wrist[side]].reshape(3, 3)
        part_R = wrist @ local_R.T
        part_p = fk.hand_point(side, 'palm') - part_R @ local_p
        # Keep the load below the shoulder while changing the wrist branch.
        # A geometrically narrow high arc amplified real rail rolling.
        if part_p[2] > max(p[2], goal[2])+.03:
            blocked = dict(reason='payload_height',height_m=float(part_p[2]))
            return False
        states[name]['position'] = part_p.tolist()
        states[name]['quat'] = Rotation.from_matrix(part_R).as_quat()[[3, 0, 1, 2]].tolist()
        arms_clear,arm_blocked=clear_arms(screens,q,grasp_side=side,self_clear=True)
        if not arms_clear:
            blocked = arm_blocked
            return False
        for pg in screen.part:
            d, model = screen.ik.d, screen.ik.m
            extent = float(np.abs(d.geom_xmat[pg].reshape(3, 3)[2]) @ model.geom_size[pg])
            if d.geom_xpos[pg, 2]-extent < c.env.cfg.table_height+.015:
                blocked = dict(reason='payload_table_clearance',height_m=float(d.geom_xpos[pg,2]-extent))
                return False
            for sg, owner, _, _ in screen.scene:
                if np.linalg.norm(d.geom_xpos[pg]-d.geom_xpos[sg]) > model.geom_rbound[pg]+model.geom_rbound[sg]+.012:
                    continue
                distance = float(mujoco.mj_geomDistance(model, d, pg, sg, .012, None))
                if distance < .012:
                    blocked = dict(reason='payload_scene_clearance',object=owner,distance_m=distance)
                    return False
        return True

    def edge(a, b):
        count = max(1, int(np.ceil(np.max(abs(b-a))/.04)))
        return all(clear(a+(b-a)*i/count) for i in range(1, count+1))

    goal, rotation = np.asarray(goal), np.asarray(rotation)
    target = {side: ('palm', goal+rotation@local_p, rotation@local_R)}
    finish = None
    endpoint_diagnostics = []
    for yaw, shoulder, elbow in itertools.product((-1.2, 0., 1.2), (-1.5, 0., 1.5), (-.6, 1.2)):
        seed = base.copy()
        for joint, value in [('waist_yaw_joint', yaw), (side+'_shoulder_yaw_joint', shoulder), (side+'_elbow_joint', elbow)]:
            seed[c.index[joint]] = value
        solved, errors = c.ik.solve(c.env.base_position, (1, 0, 0, 0), seed, target,
                                    iters=400, damping=.02, w_rot=.5, max_step=.08)
        angle = np.linalg.norm(Rotation.from_matrix(target[side][2] @
            c.ik.d.xmat[c.ik.wrist[side]].reshape(3, 3).T).as_rotvec())
        reachable = errors[side] < .003 and angle < .04
        safe = clear(solved[active]) if reachable else False
        endpoint_diagnostics.append(dict(position_error_m=errors[side],rotation_error_rad=float(angle),clear=safe,blocked=blocked if reachable else None))
        if reachable and safe:
            finish = solved[active].copy(); break
    start = base[active].copy()
    start_clear = clear(start)
    c.event('reference_carried_path_endpoints',goal=goal.tolist(),start_clear=start_clear,start_blocked=blocked,candidates=endpoint_diagnostics)
    if finish is None or not start_clear:
        raise RuntimeError(name+': carried-path endpoint lacks measured clearance')
    path = [start, finish] if edge(start, finish) else None
    if path is None:
        rng = np.random.default_rng(3)
        trees = [([start], [-1]), ([finish], [-1])]

        def extend(tree, target):
            points, parents = tree
            index = int(np.argmin([np.linalg.norm(v-target) for v in points]))
            a = points[index]; distance = np.linalg.norm(target-a)
            b = a+(target-a)*min(1., .25/max(distance, 1e-12))
            if not edge(a, b): return None, False
            points.append(b); parents.append(index)
            return len(points)-1, distance <= .25

        def branch(tree, index):
            out = []
            while index != -1:
                out.append(tree[0][index]); index = tree[1][index]
            return out[::-1]

        for iteration in range(6000):
            which = iteration % 2; other = 1-which
            if rng.random() < .25:
                sample = trees[other][0][-1]
            elif rng.random() < .75:
                center = trees[which][0][rng.integers(len(trees[which][0]))]
                sample = np.clip(center+rng.normal(0., .5, len(active)), lo, hi)
            else:
                sample = rng.uniform(lo, hi)
            a, _ = extend(trees[which], sample)
            if a is None: continue
            for _ in range(50):
                b, reached = extend(trees[other], trees[which][0][a])
                if b is None: break
                if reached:
                    path = branch(trees[which], a)+branch(trees[other], b)[-2::-1]
                    if which: path = path[::-1]
                    break
            if path is not None: break
    if path is None:
        raise RuntimeError(name+': no collision-free carried path within bounded search')
    shortened = [path[0]]; index = 0
    while index < len(path)-1:
        last = len(path)-1
        while last > index+1 and not edge(path[index], path[last]): last -= 1
        shortened.append(path[last]); index = last
    c.event('reference_measured_grasp_carry_path', part=name, goal=goal.tolist(),
            active_joints=[JOINT_NAMES[i] for i in active], queries=queries,
            waypoints=[q.tolist() for q in shortened], arm_clearance_m=.025, payload_clearance_m=.012,
            execution='measured_part_pose_feedback_along_screened_joint_branch')
    actual_screens = arm_screens(c,name,clearance=.005)
    weak = 0

    def guard(current):
        nonlocal weak
        weak = weak+1 if side_forces(current, name)[side] < .05 else 0
        if weak > 10: raise RuntimeError(name+': physical grasp lost on carried path')
        arms_clear,blocked=clear_arms(actual_screens,current.actual_q(),grasp_side=side,scene_clearance=.010)
        if not arms_clear:
            raise RuntimeError(name+': measured carried-arm clearance lost: '+str(blocked))

    c.joint_feedback['reference_carried_path_guard'] = guard
    correction_p = np.zeros(3); correction_r = np.zeros(3)
    try:
        for segment,(previous, waypoint) in enumerate(zip(shortened, shortened[1:])):
            seconds = max(1.2, float(np.max(abs(waypoint-previous)))/.25)
            count = max(1, round(seconds/.02))
            final=segment==len(shortened)-2
            settle=getattr(c,'carried_endpoint_settle_seconds',.6) if final else .6
            for index in range(count+round(settle/.02)):
                fraction = min(1., (index+1)/count)
                fraction = fraction**3*(10.-15.*fraction+6.*fraction**2)
                seed = base.copy(); seed[active] = previous+fraction*(waypoint-previous)
                fk._set(c.env.base_position, (1, 0, 0, 0), seed)
                desired_R = fk.d.xmat[fk.wrist[side]].reshape(3, 3) @ local_R.T
                desired_p = fk.hand_point(side, 'palm')-desired_R@local_p
                actual_p, actual_R, _, _ = pose(c, name)
                correction_p = np.clip(correction_p+np.clip(.045*(desired_p-actual_p), -.0003, .0003), -.035, .035)
                error_r = Rotation.from_matrix(desired_R@actual_R.T).as_rotvec()
                correction_r = np.clip(correction_r+np.clip(.025*error_r, -.001, .001), -.22, .22)
                commanded_R = Rotation.from_rotvec(correction_r).as_matrix()@desired_R
                tasks = {side: ('palm', desired_p+correction_p+commanded_R@local_p+reference_p, reference_R@commanded_R@local_R)}
                solved, _ = c.ik.solve(c.env.base_position, (1, 0, 0, 0), seed, tasks,
                                       iters=24, damping=.015, w_rot=.5, max_step=.05)
                c.q[active] += np.clip(solved[active]-c.q[active], -.010, .010)
                c.step()
                if final and settle>.6 and index>=count+29:
                    measured_p,measured_R,_,_=pose(c,name)
                    ep=float(np.linalg.norm(measured_p-goal))
                    er=float(np.linalg.norm(Rotation.from_matrix(rotation@measured_R.T).as_rotvec()))
                    if ep<.004 and er<.04:break
            if final:
                measured_p,measured_R,_,_=pose(c,name)
                c.event('reference_carried_endpoint_measured',position_error_m=float(np.linalg.norm(measured_p-goal)),rotation_error_rad=float(np.linalg.norm(Rotation.from_matrix(rotation@measured_R.T).as_rotvec())),settle_limit_seconds=settle)
        c.hold(.4)
    finally:
        c.joint_feedback.pop('reference_carried_path_guard', None)
