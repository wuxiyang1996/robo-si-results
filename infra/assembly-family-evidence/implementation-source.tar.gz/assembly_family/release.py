"""Check release evidence without converting partial diagnostics into successes."""
import argparse,datetime,hashlib,json
from pathlib import Path
from .contracts import ROOT,DESIGN,attempt_order


def read(path,default=None):
    return json.loads(path.read_text()) if path.is_file() else default


def blockers(directory,task):
    d=Path(directory);result=read(d/'outcome.json',{});plan=read(d/'plan.json',{})
    reasons=[]
    if result.get('task_id')!=task or plan.get('task_id')!=task:reasons.append('task_identity_mismatch')
    if plan.get('run_kind')=='component_probe':reasons.append('component_diagnostic')
    for key in ('goal_met','physical_goal_met','physical_checks_pass','complete_artifacts','independent_verifier'):
        if result.get(key) is not True:reasons.append(key)
    if not (result.get('status')or{}).get('success'):reasons.append('original_task_not_complete')
    physics=result.get('physics',{})
    if physics.get('scorer_mismatches')!=0:reasons.append('independent_scorer_mismatch')
    if not physics.get('physics_samples',0):reasons.append('missing_physics_samples')
    if result.get('error'):reasons.append('execution_error')
    if (d/'infrastructure-interruption.json').exists():reasons.append('interrupted_execution')
    if read(d/'evidence_limitations.json',[]):reasons.append('evidence_limitations')
    for filename in ('trajectory.npz','physics.jsonl.gz','contacts.jsonl.gz','action_plan.jsonl.gz','low_plan.jsonl','mapping.json','video.mp4','execution.json'):
        p=d/filename
        if not p.is_file() or not p.stat().st_size:reasons.append('missing:'+filename)
    sources=read(d/'sources.json',{});manifest=read(d/'source-load-manifest.json',{})
    if plan.get('source_recording')!='import_bytes_v1' or manifest.get('method')!='compile_and_capture_source_at_import':
        reasons.append('source_at_import_not_recorded')
    if not sources or manifest.get('files')!=sources:reasons.append('source_manifest_mismatch')
    for rel,expected in sources.items():
        path=Path(rel)
        if path.is_absolute() or '..' in path.parts:
            reasons.append('invalid_source_path');continue
        frozen=d/'sources'/path
        if not frozen.is_file() or hashlib.sha256(frozen.read_bytes()).hexdigest()!=expected:reasons.append('source_hash:'+rel)
    return reasons


def readiness(runs=None):
    runs=Path(runs or ROOT/'assembly_family/runs');tasks=[]
    for item in read(DESIGN)['tasks']:
        task=item['id'];attempts=[]
        for d in sorted((runs/task).glob('*'),key=attempt_order):
            result=read(d/'outcome.json',{})
            if result.get('goal_met'):attempts.append((d,blockers(d,task)))
        eligible=[(d,b)for d,b in attempts if not b]
        selected=(eligible or attempts)[-1] if attempts else None
        tasks.append(dict(task_id=task,physical_witnesses=[d.name for d,_ in attempts],
                          release_attempt=selected[0].name if selected else None,
                          ready=bool(eligible),blockers=selected[1] if selected else ['no_complete_physical_witness']))
    return dict(schema='assembly-release-readiness/1',generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                scope='Single-seed reference-body task evidence; fixed-pelvis historical G1 with three-finger hands',
                task_evidence_ready=all(x['ready']for x in tasks),ready_tasks=sum(x['ready']for x in tasks),total_tasks=len(tasks),
                official_embodiment_comparisons_ready=False,
                remaining_scope='Official G1 Dex3/Inspire and Stretch adapters, paired comparisons and multi-seed evaluation remain unimplemented',tasks=tasks)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path);args=parser.parse_args()
    result=readiness();raw=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.output:args.output.write_text(raw)
    print(raw,end='');return 0 if result['task_evidence_ready'] else 2


if __name__=='__main__':raise SystemExit(main())
