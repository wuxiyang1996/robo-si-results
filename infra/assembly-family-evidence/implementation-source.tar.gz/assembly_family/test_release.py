"""Release gates must preserve failed, partial and mismatched evidence."""
import hashlib,json,tempfile,unittest
from pathlib import Path
from .release import blockers
from .contracts import attempt_order


class ReleaseTests(unittest.TestCase):
    def test_attempts_over_ninety_nine_are_chronological(self):
        self.assertEqual(sorted(['a100','a11','a99','a02'],key=attempt_order),['a02','a11','a99','a100'])
        self.assertGreater(attempt_order(Path('a100')),attempt_order(Path('a99')))

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.d=Path(self.temp.name)
        self.write('plan.json',dict(task_id='ASM-01',source_recording='import_bytes_v1'))
        self.write('outcome.json',dict(task_id='ASM-01',goal_met=True,physical_goal_met=True,physical_checks_pass=True,complete_artifacts=True,
                                     independent_verifier=True,status=dict(success=True),physics=dict(scorer_mismatches=0,physics_samples=1)))
        source=self.d/'sources/policy.py';source.parent.mkdir();source.write_text('pass\n');sources={'policy.py':hashlib.sha256(source.read_bytes()).hexdigest()}
        self.write('sources.json',sources);self.write('source-load-manifest.json',dict(method='compile_and_capture_source_at_import',files=sources))
        for name in ('trajectory.npz','physics.jsonl.gz','contacts.jsonl.gz','action_plan.jsonl.gz','low_plan.jsonl','mapping.json','video.mp4','execution.json'):(self.d/name).write_bytes(b'fixture')

    def write(self,name,value):(self.d/name).write_text(json.dumps(value))

    def test_rejects_component_even_if_flags_claim_success(self):
        self.assertEqual(blockers(self.d,'ASM-01'),[])
        p=json.loads((self.d/'plan.json').read_text());p['run_kind']='component_probe';self.write('plan.json',p)
        self.assertIn('component_diagnostic',blockers(self.d,'ASM-01'))

    def test_rejects_changed_source_or_interrupted_run(self):
        (self.d/'sources/policy.py').write_text('changed\n')
        self.write('infrastructure-interruption.json',dict(reason='ENOSPC'))
        self.assertIn('source_hash:policy.py',blockers(self.d,'ASM-01'))
        self.assertIn('interrupted_execution',blockers(self.d,'ASM-01'))

    def test_task_identity_and_original_scorer_are_required(self):
        self.assertIn('task_identity_mismatch',blockers(self.d,'ASM-02'))
        r=json.loads((self.d/'outcome.json').read_text());r['status']['success']=False;r['physics']['scorer_mismatches']=1;self.write('outcome.json',r)
        self.assertIn('original_task_not_complete',blockers(self.d,'ASM-01'))
        self.assertIn('independent_scorer_mismatch',blockers(self.d,'ASM-01'))


if __name__=='__main__':unittest.main()
