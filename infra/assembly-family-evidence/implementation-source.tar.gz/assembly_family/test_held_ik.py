"""Kinematic regressions for loaded-hand protection, not physical witnesses."""
import unittest
import numpy as np
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from humanoid.g1_support_retrieval.task_spec import JOINT_NAMES
from .held_ik import solve


class HeldIKTests(unittest.TestCase):
    def setUp(self):
        self.ik=UpperBodyIK();self.q=np.zeros(len(JOINT_NAMES))
        for side,sign in (('left',1.),('right',-1.)):
            for joint,value in (('shoulder_pitch',-.8),('shoulder_roll',sign),('elbow',1.2)):
                self.q[JOINT_NAMES.index(side+'_'+joint+'_joint')]=value
        self.ik._set([0,0,.79],[1,0,0,0],self.q)
        self.loaded=self.ik.hand_point('left','palm').copy()
        self.rotation=self.ik.d.xmat[self.ik.wrist['left']].reshape(3,3).copy()
        self.receiver=self.ik.hand_point('right','palm').copy()

    def run_target(self,delta,iters):
        return solve(self.ik,[0,0,.79],[1,0,0,0],self.q,
                     {'left':('palm',self.loaded,self.rotation),
                      'right':('palm',self.receiver+delta,None)},'left',iters=iters)

    def test_online_target_fits_controller_rate_box(self):
        q,errors=self.run_target(np.array([.03,0,.03]),10)
        self.assertLessEqual(np.max(abs(q[self.ik.upper]-self.q[self.ik.upper])),.01600001)
        self.assertLess(errors['left'],.001)

    def test_unreachable_receiver_preserves_loaded_hand(self):
        q,errors=self.run_target(np.array([1.,0,0]),80)
        self.assertGreater(errors['right'],.1)
        self.assertLess(errors['left'],.005)
        self.assertTrue(np.all(q[self.ik.upper]>=self.ik.lo-1e-8))
        self.assertTrue(np.all(q[self.ik.upper]<=self.ik.hi+1e-8))


if __name__=='__main__':unittest.main()
