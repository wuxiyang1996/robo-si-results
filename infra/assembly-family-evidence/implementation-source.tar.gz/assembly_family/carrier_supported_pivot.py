"""Receive a hanging carrier on real back receivers before lowering its front."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,smooth
from humanoid.g1_gear_assembly.solution.stage_gears import release
from .pose_carry import move
from .reference_carry_path import move as screened_move
from .grasp_clearance import ReceivingArm


def place(c,grip,slot='lower_crossbar'):
    name=grip.name;goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    half=.08349098346;rail_half_width=.00444063059;rail_half_height=.004129108335
    wall_top=goal[2]-rail_half_height+.012
    vertical=Rotation.from_euler('y',np.pi/2).as_matrix()
    screened_move(c,grip,np.array([.27,0.,1.06]),vertical)
    guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
    def guard(current):
        for screen in guards:
            if not screen.clear(current.actual_q(),scene_clearance=.005,hand_scene_clearance=0.):
                raise RuntimeError(name+': supported pivot lost measured arm clearance '+str(screen.blocked))
    c.joint_feedback['carrier_receiver_pivot_clearance']=guard
    try:
        hinge=np.array([goal[0]+half,goal[1],wall_top+rail_half_width+.001])
        centre=hinge-vertical@np.array([half,0.,0.])
        move(c,grip,np.array([.27,0.,centre[2]+.004]),vertical,5.,'carrier_vertical_descend_in_front_of_receivers',preserve_reference=True)
        move(c,grip,centre+[0.,0.,.004],vertical,6.,'carrier_vertical_enter_between_receiver_levels',preserve_reference=True)
        move(c,grip,centre,vertical,2.,'carrier_receive_back_rail_on_real_wall_tops',preserve_reference=True)
        hp,hR=c.hand_pose(grip.side)
        for i in range(100):
            p,R,_,state=pose(c,name)
            if all(state['support_forces'].get(frame,0.)>.02 for frame in ('left_frame','right_frame')):break
            c.reach({grip.side:('palm',hp-[0.,0.,.0001*(i+1)],hR)},feedback=.4,rotation_feedback=.3);c.step()
        p,R,_,state=pose(c,name)
        if not all(state['support_forces'].get(frame,0.)>.02 for frame in ('left_frame','right_frame')):
            raise RuntimeError(name+': back rail lacks both real receiver supports')
        actual_hinge=p+R@np.array([half,0.,0.])
        if np.linalg.norm(actual_hinge[:2]-hinge[:2])>.008:
            raise RuntimeError(name+': supported back rail missed its measured receiver envelope')
        hp,hR=c.hand_pose(grip.side);near=p+R@np.array([-half,.08,0.])
        c.ik._set(c.env.base_position,(1,0,0,0),c.q)
        bias=c.ik.hand_point(grip.side,'palm').copy()-hp
        bias_R=c.ik.d.xmat[c.ik.wrist[grip.side]].reshape(3,3).copy()@hR.T
        angle=float(np.arctan2(R[0,2],R[2,2]));axis=R[:,1].copy()
        cp=np.zeros(3);cr=np.zeros(3);weak=0
        c.event('carrier_pivot_on_both_frame_receivers',hinge=actual_hinge.tolist(),angle_rad=angle,supports=state['support_forces'])
        for i in range(350):
            fraction=smooth(min(1.,(i+1)/300));theta=angle*(1.-fraction)
            turn=Rotation.from_rotvec(-axis*angle*fraction).as_matrix()
            height=rail_half_width*abs(np.sin(theta))+rail_half_height*abs(np.cos(theta))
            start_height=rail_half_width*abs(np.sin(angle))+rail_half_height*abs(np.cos(angle))
            desired=hp+actual_hinge+turn@(near-actual_hinge)-near+[0.,0.,height-start_height]
            actual,actual_R=c.hand_pose(grip.side);ep=desired-actual;er=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
            cp=np.clip(cp+np.clip(.035*ep,-.0002,.0002),-.025,.025)
            cr=np.clip(cr+np.clip(.02*er,-.0005,.0005),-.10,.10)
            c.reach({grip.side:('palm',desired+bias+cp+np.clip(.4*ep,-.008,.008),bias_R@Rotation.from_rotvec(cr+.3*er).as_matrix()@hR)},rate=.4,iters=24);c.step()
            p,R,_,state=pose(c,name);weak=weak+1 if state['robot_contact_force']<.05 else 0
            if weak>10:raise RuntimeError(name+': supported pivot lost its physical hook')
            if i%25==0:c.event('carrier_receiver_pivot_measurement',position=p.tolist(),normal_z=float(R[2,2]),supports=state['support_forces'])
            if R[2,2]>.98 and np.linalg.norm(p[:2]-goal[:2])<.005 and all(state['support_forces'].get(frame,0.)>.02 for frame in ('left_frame','right_frame')):break
        p,R,_,state=pose(c,name)
        if R[2,2]<.98 or np.linalg.norm(p[:2]-goal[:2])>.005 or not all(state['support_forces'].get(frame,0.)>.02 for frame in ('left_frame','right_frame')):
            raise RuntimeError(name+': supported pivot did not reach a flat two-frame release envelope')
        release(c,grip,seconds=1.5);c.hold(2.)
        if slot not in c.env.status['completed']:
            raise RuntimeError(name+': original carrier predicate rejected the released placement')
        c.event('carrier_supported_pivot_placement_probe_success',slot=slot,object=name)
    finally:c.joint_feedback.pop('carrier_receiver_pivot_clearance',None)
    return grip
