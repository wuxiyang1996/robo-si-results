"""Independent offline scorer over per-physics-step measured state and actuator traces."""
from pathlib import Path
import gzip,hashlib,json,sys
import numpy as np

def verify(directory):
    d=Path(directory);plan=json.loads((d/'plan.json').read_text());family=plan['family']
    config=json.loads((d/'config.json').read_text());limits=json.loads((d/'limits.json').read_text())
    if family=='ASM':
        if plan['task_id'] in ('ASM-03','ASM-04'):
            from .assembly_extension import ExtensionConfig as TaskConfig,ExtensionEvaluator as Evaluator
        else:from humanoid.g1_tabletop_assembly.task_spec import TaskConfig,Evaluator
        evaluator=Evaluator(TaskConfig(**config))
    else:
        if family=='GEAR':from humanoid.g1_gear_assembly.task_spec import TaskConfig,Evaluator
        else:from humanoid.g1_reference_assembly.task_spec import TaskConfig,Evaluator
        if plan['task_id']=='GEAR-02':from .gear_extension import RepairEvaluator as Evaluator
        elif plan['task_id']=='GEAR-03':from .gear_extension import ToolEvaluator as Evaluator
        elif plan['task_id']=='REF-02':from .reference_extension import FixtureEvaluator as Evaluator
        elif plan['task_id']=='REF-03':from .reference_extension import ConstrainedEvaluator as Evaluator
        evaluator=Evaluator(TaskConfig(**config),json.loads((d/'catalog.json').read_text()),
                            **({'support_loss_rule':plan.get('repair_support_loss_rule','immediate_v0')} if plan['task_id']=='GEAR-02' else {}))
    count=0;mismatch=0;stage_history=[]
    with gzip.open(d/'physics.jsonl.gz','rt') as f:
        for line in f:
            row=json.loads(line);count+=1
            assert row['step']==count
            status=evaluator.update(row['state'],limits['physics_dt'])
            if status['stage']!=row['stage'] or status['success']!=row['status']['success'] or status['reason']!=row['status']['reason']:mismatch+=1
            if not stage_history or stage_history[-1]['stage']!=status['stage']:
                stage_history.append({'stage':status['stage'],'time':row['time'],'step':count})
    execution=json.loads((d/'execution.json').read_text())
    if (d/'termination_request.json').exists():execution['error']=json.loads((d/'termination_request.json').read_text())['reason']
    action_alignment=None
    with np.load(d/'trajectory.npz',allow_pickle=False) as raw:
        q,v,tau=[raw[k].reshape((-1,len(limits['names']))) for k in ('physics_q','physics_qd','physics_torque')]
        assert len(q)==len(v)==len(tau)==count
        if (d/'action_plan.jsonl.gz').exists():
            with gzip.open(d/'action_plan.jsonl.gz','rt') as f:actions=[json.loads(line) for line in f]
            targets=raw['target_q'];starts=raw['control_physics_start']
            action_alignment=len(actions)==len(targets) and all(row['action_id']==i and np.array_equal(row['target_q'],targets[i]) and row['physics_start']==starts[i] for i,row in enumerate(actions))
        finite=bool(np.isfinite(q).all() and np.isfinite(v).all() and np.isfinite(tau).all())
        pos=float(np.maximum(np.asarray(limits['lo'])-q,q-np.asarray(limits['hi'])).max(initial=0))
        speed=float((np.abs(v)/np.asarray(limits['velocity'])).max(initial=0))
        effort=float((np.abs(tau)/np.asarray(limits['effort'])).max(initial=0))
        violation=np.maximum(np.asarray(limits['lo'])-q,q-np.asarray(limits['hi']))
        overstep,overjoint=np.unravel_index(np.argmax(violation),violation.shape) if len(q) else (0,0)
        maxspeedjoint=limits['names'][int(np.argmax((np.abs(v)/limits['velocity']).max(axis=0)))] if len(v) else None
    physics={'finite':finite,'max_joint_overrun':pos,'max_velocity_ratio':speed,'max_effort_ratio':effort,
             'max_position_joint':limits['names'][overjoint] if len(q) else None,'max_position_time':(int(overstep)+1)*limits['physics_dt'] if len(q) else None,'max_velocity_joint':maxspeedjoint,'api_violations':execution['api_violations'],
             'action_alignment':action_alignment,'physics_samples':count,'scorer_mismatches':mismatch,'stage_history':stage_history}
    contact_path=d/'contact_summary.json'
    contacts=json.loads(contact_path.read_text()) if contact_path.exists() else {'audited':False}
    if contacts.get('version')=='collision_geometry_v2':
        from .contact_audit import violations
        catalog=json.loads((d/'robot_collision_geometries.json').read_text());peaks={};contact_count=0
        with gzip.open(d/'contacts.jsonl.gz','rt') as f:
            for line in f:
                row=json.loads(line);contact_count+=1
                assert row['step']==contact_count
                for geom,owner,force in row['contacts']:
                    assert str(geom) in catalog and np.isfinite(force) and force>=0
                    key=str(geom)+'|'+owner;peaks[key]=max(peaks.get(key,0.),force)
        assert contact_count==count
        assert peaks==contacts['geometry_peak_force_n']
        recomputed=violations(peaks,catalog)
        assert recomputed==contacts['forbidden']
        contacts['independently_recomputed']=True
    physics['contacts']=contacts
    physical_ok=bool(count) and action_alignment is not False and finite and pos<=.001 and speed<=1.001 and effort<=1.001 and not execution['api_violations'] and contacts.get('audited',False) and not contacts.get('forbidden',[])
    artifacts=execution['video_frames']>0 and execution['control_steps']>0 and all((d/name).is_file() for name in ['plan.json','low_plan.jsonl','mapping.json','trajectory.npz','video.mp4'])
    limitations=json.loads((d/'evidence_limitations.json').read_text()) if (d/'evidence_limitations.json').exists() else []
    if limitations:artifacts=False
    if plan.get('source_recording')=='import_bytes_v1':
        manifest=json.loads((d/'source-load-manifest.json').read_text())
        sources=json.loads((d/'sources.json').read_text())
        artifacts=artifacts and manifest['method']=='compile_and_capture_source_at_import' and manifest['files']==sources and bool(sources)
        artifacts=artifacts and all(hashlib.sha256((d/'sources'/rel).read_bytes()).hexdigest()==digest for rel,digest in sources.items())
    goal=bool(count and status['success'] and physical_ok and not mismatch and artifacts and not execution['error'])
    result={'task_id':plan['task_id'],'body':plan['body'],'state':'witnessed_full' if goal else 'failed_with_evidence',
            'goal_met':goal,'physical_goal_met':bool(count and status['success']),'physical_checks_pass':physical_ok,
            'complete_artifacts':artifacts,'status':status if count else None,'physics':physics,
            'error':execution['error'],'independent_verifier':True,'source':'recorded_per_physics_step_measurements'}
    if limitations:result['evidence_limitations']=limitations
    root=Path(__file__).resolve().parents[1];audit_sources={}
    for module in list(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if name and Path(name).suffix=='.py' and Path(name).is_relative_to(root):
            from .source_loading import loaded_bytes
            source=Path(name);rel=source.relative_to(root);raw=loaded_bytes(source)
            if raw is None:raise RuntimeError('Scorer source was not captured at import: '+str(rel))
            saved=d/'audit_sources'/rel;saved.parent.mkdir(parents=True,exist_ok=True)
            # Source caches may use hard links for identical frozen files.
            # Replace this path so a fresh audit never edits another record.
            temporary=saved.with_name(saved.name+'.new-audit')
            temporary.write_bytes(raw);temporary.replace(saved)
            audit_sources[str(rel)]=hashlib.sha256(raw).hexdigest()
    for name,value in [('audit_sources.json',audit_sources),('physics_checks.json',physics),('outcome.json',result)]:
        target=d/name;temporary=target.with_name(target.name+'.new-audit')
        temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(target)
    print(json.dumps({'task':plan['task_id'],'state':result['state'],'physical_goal':result['physical_goal_met'],
                     'position_overrun':pos,'velocity_ratio':speed,'effort_ratio':effort,'stage':status.get('stage') if count else None}),flush=True)
    return result

if __name__=='__main__':verify(sys.argv[1])
