"""Compile task modules from source and retain the exact bytes used at import."""
import importlib.abc
import importlib.machinery
import linecache
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
LOADED_SOURCES={}


class RecordedSourceLoader(importlib.machinery.SourceFileLoader):
    def get_code(self,fullname):
        raw=self.get_data(self.path)
        LOADED_SOURCES[str(Path(self.path).resolve())]=raw
        # Tracebacks must describe the compiled version too. The live expert
        # file may be edited while this separately frozen attempt is running.
        decoded=importlib.util.decode_source(raw)
        linecache.cache[self.path]=(len(raw),None,decoded.splitlines(keepends=True),self.path)
        # A timestamp-valid pyc may still describe an older shared-filesystem
        # source version. Compile the bytes that will also become evidence.
        return self.source_to_code(raw,self.path)


class RecordedSourceFinder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname!='humanoid' and not fullname.startswith(('assembly_family.','humanoid.')):
            return None
        spec=importlib.machinery.PathFinder.find_spec(fullname,path)
        if spec and isinstance(spec.loader,importlib.machinery.SourceFileLoader) and spec.origin:
            origin=Path(spec.origin).resolve()
            if origin.is_relative_to(ROOT):spec.loader=RecordedSourceLoader(fullname,str(origin))
        return spec


def loaded_bytes(path):
    return LOADED_SOURCES.get(str(Path(path).resolve()))


def install():
    if not any(isinstance(f,RecordedSourceFinder)for f in sys.meta_path):
        sys.meta_path.insert(0,RecordedSourceFinder())
    for path in (Path(__file__),Path(__file__).with_name('__init__.py')):
        LOADED_SOURCES[str(path.resolve())]=path.read_bytes()
