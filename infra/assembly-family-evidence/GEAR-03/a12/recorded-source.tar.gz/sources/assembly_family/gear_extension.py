"""Repair and candidate-tool evaluators; original gear predicates stay unchanged."""
from copy import deepcopy
from math import isfinite
from humanoid.g1_gear_assembly.task_spec import Evaluator,OBJECT_NAMES,ASSEMBLY_NAMES,GEAR_NAMES,_relative_yaws

class RepairEvaluator(Evaluator):
    """Rework is legal. A misplaced gear must be physically extracted before reseating."""
    def reset(self):
        self.initial_bad=None;self.extracted=set()
        return super().reset()
    def update(self,state,dt):
        if self._terminal is not None:return deepcopy(self._terminal)
        try:
            if not isfinite(dt) or not 0<dt<=self.cfg.control_dt*1.01:raise ValueError()
            objects={n:self._read_object(state['objects'][n]) for n in OBJECT_NAMES}
        except (KeyError,TypeError,ValueError):return self._finish('invalid_state')
        self.elapsed+=dt
        if self.elapsed>=self.cfg.max_episode_seconds:return self._finish('timeout')
        if any(x['position'][2]<self.cfg.table_height-self.cfg.drop_distance for x in objects.values()):return self._finish('object_dropped')
        self.conditions={n:self._condition(n,objects) for n in ASSEMBLY_NAMES}
        if self.initial_bad is None:
            self.initial_bad=[n for n in GEAR_NAMES if not self.conditions[n]['pose']]
            if not self.initial_bad:return self._finish('fault_not_observable')
        for n in self.initial_bad:
            if objects[n]['robot_contact_force']>.05 and objects[n]['position'][2]>self.goals[n][0][2]+.045:
                self.extracted.add(n)
        if self.stage<5:
            # Legal rework: revoke downstream credit when an earlier component moves.
            lost=[i for i,n in enumerate(ASSEMBLY_NAMES[:self.stage]) if not self.conditions[n]['structural_valid']]
            if lost:self.stage=min(lost);self.completed=list(ASSEMBLY_NAMES[:self.stage]);self.current_dwell=0.
            n=ASSEMBLY_NAMES[self.stage]
            valid=self.conditions[n]['stable_released'] and all(self.conditions[x]['structural_valid'] for x in self.completed)
            if n in self.initial_bad:valid=valid and n in self.extracted
            self.current_dwell=self.current_dwell+dt if valid else 0.
            if self.current_dwell>=self.cfg.stable_seconds:
                self.completed.append(n);self.stage+=1;self.current_dwell=0.
                if self.stage==5:self.previous_yaw=_relative_yaws(objects)
        elif self.stage==5:
            if not all(self.conditions[n]['structural_valid'] for n in ASSEMBLY_NAMES):
                self.stage=0;self.completed=[];self.current_dwell=0.;self.previous_yaw=None
                # Lost alignment invalidates prior transmission credit.
                self.drive_angles={n:0. for n in GEAR_NAMES};self.credited_angles={n:0. for n in GEAR_NAMES}
                self.mesh_contact_seconds={k:0. for k in self.mesh_contact_seconds}
                self.mesh_contact_impulse={k:0. for k in self.mesh_contact_impulse}
                self.mesh_contact_age={k:float('inf') for k in self.mesh_contact_age}
                self.drive_motion_seconds=self.tool_contact_seconds=0.
            elif self._drive(objects,dt):self.completed.append('drive_test');self.stage=6
        else:
            valid=all(self.conditions[n]['structural_valid'] for n in ASSEMBLY_NAMES)
            valid=valid and all(self._released(x) and self._slow(x) for x in objects.values())
            valid=valid and objects['turning_tool']['support_forces'].get('table',0)>self.cfg.support_force_min
            valid=valid and all(self._contact(objects,'turning_tool',n)<=self.cfg.tool_contact_force_min for n in GEAR_NAMES)
            self.final_dwell=self.final_dwell+dt if valid else 0.
            if self.final_dwell>=self.cfg.final_hold_seconds:
                self.completed.append('release');self.stage=7
                return self._finish('repaired_driven_released',success=True)
        result=self.status();result['initial_observed_faults']=self.initial_bad;result['extracted']=sorted(self.extracted)
        return result

class ToolEvaluator(Evaluator):
    CANDIDATES=('turning_tool','thin_tool','wide_tool')
    def reset(self):
        self.selected=None
        return super().reset()
    def update(self,state,dt):
        raw=state['objects']
        if any(raw[n]['position'][2]<self.cfg.table_height-self.cfg.drop_distance for n in self.CANDIDATES):
            return self._finish('candidate_tool_dropped')
        # Lock the identity on first real held-tool/gear contact; selection is measured.
        active=[n for n in self.CANDIDATES if n in raw and raw[n]['robot_contact_force']>.05
                and max(raw[n]['contact_forces'].get('small_gear',0),raw['small_gear']['contact_forces'].get(n,0))>.01]
        if self.selected is None and active:self.selected=active[0]
        selected=self.selected or 'turning_tool'
        mapped=deepcopy(state);mapped['objects']={n:deepcopy(raw[selected if n=='turning_tool' else n]) for n in OBJECT_NAMES}
        for obj in mapped['objects'].values():
            for field in ('support_forces','contact_forces'):
                forces={}
                for name,force in obj[field].items():
                    key='turning_tool' if name==selected else 'other' if name in self.CANDIDATES else name
                    forces[key]=forces.get(key,0.)+force
                obj[field]=forces
        # All unused tools must be released and settled before final success.
        if self.stage==6 and any(raw[n]['robot_contact_force']>.05 or not self._slow(raw[n]) or raw[n]['support_forces'].get('table',0)<=self.cfg.support_force_min for n in self.CANDIDATES if n!=selected):
            self.final_dwell=0.
        result=super().update(mapped,dt)
        result['selected_tool']=self.selected
        return result
