"""Change a hanging carrier grasp into a grasp that can place it horizontally."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from humanoid.g1_gear_assembly.solution.skills import pose,smooth,side_forces
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip
from .pose_carry import move
from .held_ik import solve as held_solve


def side_handoff(c,left,fit):
    # These are the authored model ranges, with conservative waist planning
    # margins. The old elbow>=0.2 planning restriction excluded the screened
    # side grasp; the physical robot limits and audit remain unchanged.
    original=UpperBodyIK();c.ik.lo[:],c.ik.hi[:]=original.lo,original.hi
    c.ik.set_limit('waist_pitch_joint',-.46,.46);c.ik.set_limit('waist_roll_joint',-.46,.46)
    vertical=Rotation.from_euler('y',np.pi/2).as_matrix()
    move(c,left,[.28,.12,.95],vertical,6.,'carrier_move_to_side_handoff')
    name=left.name;p,R,yaw,state=pose(c,name)
    if np.linalg.norm(p-[.28,.12,.95])>.02 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: hanging grasp did not reach the side handoff workspace')
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([-.08349098346,-.08,0.])
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset']),
                 hand=fit['hand_joints'],squeeze=.40,hook=.10)
    right=HubGrip(c,name,'right',0.,profile=profile,anchor=anchor)
    turn=R@Rotation.from_euler('z',-np.pi/2).as_matrix()
    right.rotation=turn@right.rotation;right.offset=turn@right.offset
    target=right.target();_,rp,rR=target['right'];normal=R[:,2]
    keep_side='left';kp,kR=c.hand_pose(keep_side);solve=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        actual,_=c.hand_pose(keep_side)
        return held_solve(c.ik,root_pos,root_quat,q,dict(tasks,**{keep_side:('palm',kp+np.clip(.4*(kp-actual),-.012,.012),kR)}),keep_side,*args,**kwargs)
    c.ik.solve=keep
    try:
        c.event('carrier_side_receiver_preshape');right.preshape(seconds=1.)
        # The parked arm starts behind the torso. Carry its palm around the
        # outside before turning it toward the part; a straight world-space
        # chord through the torso moved the loaded hand into the body.
        for waypoint in ([-.25,-.48,1.24],[.35,-.35,1.24]):
            c.event('carrier_side_receiver_outboard',waypoint=waypoint)
            c.move_hands({'right':('palm',np.asarray(waypoint),None)},seconds=5.,feedback=.4)
            actual,_=c.hand_pose('left')
            if np.linalg.norm(actual-kp)>.02:
                raise RuntimeError('carrier: loaded palm drifted during the receiver clearance route')
        c.event('carrier_side_receiver_hover')
        c.move_hands({'right':('palm',rp+normal*.05,rR)},seconds=6.,feedback=.5,rotation_feedback=.3)
        c.event('carrier_side_receiver_enter')
        c.move_hands(target,seconds=3.,feedback=.5,rotation_feedback=.3)
        for _ in range(150):
            hp,hR=c.hand_pose('right')
            if np.linalg.norm(hp-rp)<.006 and np.linalg.norm(Rotation.from_matrix(rR@hR.T).as_rotvec())<.04:break
            c.reach(target,feedback=.5,rotation_feedback=.3,iters=24);c.step()
        if np.linalg.norm(c.hand_pose('right')[0]-rp)>.012:
            raise RuntimeError('carrier: receiver has not physically reached the side grasp')
        c.event('carrier_side_receiver_close');right.closed=True;start=c.q.copy()
        indices=[right.joint(j)for j in ('thumb_1','middle_0','index_0')]
        for i in range(60):
            c.q[indices]=start[indices]+smooth((i+1)/60)*np.array([-1.,1.,1.])*right.squeeze
            c.reach(target,feedback=.5,rotation_feedback=.3,iters=16);c.step()
        forces=side_forces(c,name);c.event('carrier_side_receiver_contact_check',forces=forces)
        if forces['right']<.5:raise RuntimeError('carrier: side receiver established no real grasp')
        keep_side='right';kp,kR=c.hand_pose(keep_side)
        left.release(seconds=1.5,rise=.12)
        hp,hR=c.hand_pose('left');c.move_hands({'left':('palm',hp+[0,.12,.04],hR)},seconds=2.)
    finally:c.ik.solve=solve
    if side_forces(c,name)['right']<.5:raise RuntimeError('carrier: side grasp was lost after handoff')
    move(c,right,[.40,0.,1.04],np.eye(3),6.,'carrier_side_grasp_flatten')
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p-[.40,0.,1.04])>.02 or R[2,2]<.95 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: side regrasp did not reach a held horizontal pose')
    c.event('crossbar_side_handoff_probe_success',position=p.tolist(),rotation=R.tolist())
    return right
