"""Screen a low thumb approach without sweeping the shoulder through the jig."""
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK,XML
from .contact_audit import is_hand


def candidates(c,point,rotation,axis=0,kind='thumb'):
    root=ET.parse(XML).getroot();root.find('compiler').set('meshdir',str(XML.parent/'assets'))
    world=root.find('worldbody')
    def box(name,position,quat,size):
        text=lambda v:' '.join(str(float(x))for x in v)
        ET.SubElement(world,'geom',name=name,type='box',pos=text(position),quat=text(quat),size=text(np.asarray(size)/2))
    fixture=c.object_state('fixture');cfg=c.env.cfg
    box('push_fixture',fixture['pos'],fixture['quat'],cfg.fixture_size)
    R=Rotation.from_quat(np.asarray(fixture['quat'])[[1,2,3,0]]).as_matrix()
    box('push_post',np.asarray(fixture['pos'])+R@np.r_[cfg.post_offset,(cfg.fixture_size[2]+cfg.post_height)/2],fixture['quat'],[*cfg.post_size,cfg.post_height])
    box('push_table',[*cfg.table_center,cfg.table_height-cfg.table_size[2]/2],[1,0,0,0],cfg.table_size)
    shim=c.object_state('shim');box('push_shim',shim['pos'],shim['quat'],c.env.specs['shim']['size'])
    ik=UpperBodyIK();ik.m=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'));ik.d=mujoco.MjData(ik.m)
    obstacles={n:ik.m.geom('push_'+n).id for n in ('fixture','post','table','shim')}
    robot=[]
    for g in range(ik.m.ngeom):
        link=ik.m.body(ik.m.geom_bodyid[g]).name
        if not ik.m.geom_contype[g]or not any(link.startswith(s+'_')for s in ('left','right')):continue
        if not any(k in link for k in ('shoulder','elbow','wrist','hand')):continue
        mesh=ik.m.mesh(ik.m.geom_dataid[g]).name if ik.m.geom_type[g]==mujoco.mjtGeom.mjGEOM_MESH else ''
        robot.append((g,is_hand(link,mesh),link))
    blocked={}
    def clear(q):
        ik._set(c.env.base_position,(1,0,0,0),q)
        for g,hand,link in robot:
            for name,obstacle in obstacles.items():
                if hand and name=='table':continue
                clearance=(.001 if name=='shim'else .003)if hand else .012
                distance=mujoco.mj_geomDistance(ik.m,ik.d,g,obstacle,clearance,None)
                if distance<clearance:
                    blocked.clear();blocked.update(link=link,obstacle=name,distance=float(distance));return False
        return True
    results=[];diagnostics=[]
    for wy in (-1.2,0.,1.2):
        for sy in (-1.5,0.,1.5):
            seed=c.q.copy();seed[c.index['waist_yaw_joint']]=wy;seed[c.index['left_shoulder_yaw_joint']]=sy;seed[c.index['left_elbow_joint']]=1.2
            path=[];reason=None
            outward=np.zeros(3);outward[axis]=-.10 if axis==0 else .04
            offsets=[outward*a for a in np.linspace(0.,1.,11)]+[outward+[0,0,dz]for dz in np.linspace(.01,.15,15)]
            for offset in offsets:
                seed,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,{'left':(kind,np.asarray(point)+offset,rotation)},iters=250,damping=.02,w_rot=.5,max_step=.08)
                re=np.linalg.norm(Rotation.from_matrix(rotation@c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3).T).as_rotvec())
                if errors['left']>.004 or re>.04:reason='unreachable';break
                if not clear(seed):reason='obstacle';break
                path.append(seed.copy())
            diagnostics.append(dict(waist_seed=wy,shoulder_seed=sy,result=reason or 'clear',blocked=dict(blocked)if reason=='obstacle'else None))
            if reason is None:results.append(path)
    c.event('screened_low_thumb_paths',candidates=diagnostics)
    return sorted(results,key=lambda path:np.linalg.norm(path[-1][c.ik.upper]-c.q[c.ik.upper]))


def prepare(c,point,rotation,axis=0,kind='thumb'):
    from .approach_path import plan,move
    for path in candidates(c,point,rotation,axis,kind):
        try:plan(c,path[-1],'left')
        except RuntimeError:continue
        move(c,path[-1],'left')
        for target in path[-2::-1]:c.move_joints(target,seconds=.25)
        return
    raise RuntimeError('stand push: no screened low thumb approach clears the jig and shim')
