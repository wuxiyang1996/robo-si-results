"""Prioritize the loaded hand while the other arm changes its IK branch."""
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.optimize import lsq_linear
from humanoid.g1_support_retrieval.oracle.upper_ik import PALM,THUMB_TIP


def solve(ik,root_pos,root_quat,q,tasks,primary,iters=8,damping=.03,w_rot=.3,max_step=.15):
    q=np.asarray(q,dtype=float).copy();cols=ik.dadr[ik.upper]
    q[ik.upper]=np.clip(q[ik.upper],ik.lo,ik.hi)
    origin=q[ik.upper].copy()
    # Controller.reach limits every target change to .8 rad/s * .02 s.
    # Include that box during online solves so its later clipping cannot
    # destroy the loaded-hand constraint a second time. Longer offline
    # endpoint searches are allowed to explore the complete planning range.
    budget=.016 if iters<=30 else np.inf
    jp,jr=np.zeros((3,ik.m.nv)),np.zeros((3,ik.m.nv))
    for _ in range(iters):
        ik._set(root_pos,root_quat,q);rows=[];errors=[]
        for side,(kind,pos,rotation)in tasks.items():
            weight=12. if side==primary else 1.
            body=ik.wrist[side]if kind=='palm'else ik.thumb[side]
            point=ik.point(body,PALM[side]if kind=='palm'else THUMB_TIP[side])
            mujoco.mj_jac(ik.m,ik.d,jp,jr,point,body)
            rows.append(weight*jp[:,cols].copy());errors.append(weight*(np.asarray(pos)-point))
            if rotation is not None:
                mujoco.mj_jacBody(ik.m,ik.d,None,jr,ik.wrist[side])
                actual=ik.d.xmat[ik.wrist[side]].reshape(3,3)
                rows.append(weight*w_rot*jr[:,cols].copy())
                errors.append(weight*w_rot*Rotation.from_matrix(np.asarray(rotation)@actual.T).as_rotvec())
        J,e=np.vstack(rows),np.concatenate(errors)
        # Clipping a free least-squares solution joint by joint destroys its
        # loaded-hand constraint. Solve inside the actual planning bounds.
        lower=np.maximum(np.maximum(ik.lo,origin-budget)-q[ik.upper],-max_step)
        upper=np.minimum(np.minimum(ik.hi,origin+budget)-q[ik.upper],max_step)
        matrix=np.vstack([J,damping*np.eye(len(ik.upper))])
        rhs=np.r_[e,np.zeros(len(ik.upper))]
        delta=lsq_linear(matrix,rhs,bounds=(lower,upper),method='bvls',tol=1e-8,max_iter=100).x
        q[ik.upper]+=delta
    ik._set(root_pos,root_quat,q)
    return q,{s:float(np.linalg.norm(np.asarray(p)-ik.hand_point(s,k)))for s,(k,p,_)in tasks.items()}
