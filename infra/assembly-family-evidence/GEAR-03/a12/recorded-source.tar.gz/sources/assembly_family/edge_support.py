"""Table-edge-assisted shim manipulation, with ordinary measured joint control."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_tabletop_assembly.solution.tool import safe_ready
from humanoid.g1_gear_assembly.solution.skills import Pinch
from humanoid.g1_gear_assembly.solution.stage_drive import TOOL_PROFILE
from humanoid.g1_gear_assembly.solution.skills import goto


def push_to_edge(c,fit,side='right',target_x=.215,ready=True):
    if ready:safe_ready(c)
    s=c.object_state('shim');p=np.asarray(s['pos'])
    mirror=np.diag([1.,-1.,1.]) if side=='right' else np.eye(3)
    turn=Rotation.from_euler('z',np.pi/2 if side=='right' else -np.pi/2).as_matrix()
    rot=turn@mirror@np.asarray(fit['rotation'])@mirror
    offset=turn@mirror@np.asarray(fit['palm_offset']);offset[2]-=.004
    q=c.q.copy()
    sign=-1. if side=='right' else 1.
    for j,v in fit['hand_joints'].items():q[c.index[side+'_hand_'+j+'_joint']]=v if j=='thumb_0' else sign*v
    q[c.index[side+'_hand_thumb_0_joint']]=0.
    q[c.index[side+'_hand_thumb_1_joint']]=sign*1.0
    q[c.index[side+'_hand_thumb_2_joint']]=sign*1.45
    c.event('shim_push_preshape');c.move_joints(q,seconds=1.2)
    palm=p+offset
    c.event('shim_push_approach');c.move_hands({side:('palm',palm+[0,0,.12],rot)},seconds=3.)
    c.move_hands({side:('palm',palm,rot)},seconds=3.)
    c.event('shim_push_to_front_edge',target_x=target_x,contact='index and middle distal links')
    target=palm+np.array([target_x-p[0],0,0])
    c.move_hands({side:('palm',target,rot)},seconds=4.,feedback=.5)
    c.move_hands({side:('palm',target+[0,0,.12],rot)},seconds=1.5);c.hold(.4)
    s=c.object_state('shim')
    if abs(s['pos'][0]-target_x)>.017 or not s['support_contact']:
        raise RuntimeError('shim: table-edge push missed its supported staging region')


def edge_pick(c,goal,side,long_edge=False):
    name='shim';p=np.asarray(c.object_state(name)['pos']);q0=c.object_state(name)['quat']
    yaw=Rotation.from_quat(np.asarray(q0)[[1,2,3,0]]).as_euler('xyz')[2]
    # The rectangular shim has identical front edges under a half turn.
    yaw=(yaw+np.pi/2)%np.pi-np.pi/2
    if long_edge:
        edge=Rotation.from_euler('z',yaw).apply([0,np.sign(np.sin(yaw))*.055,0])
        yaw-=np.sign(np.sin(yaw))*np.pi/2
    else:edge=Rotation.from_euler('z',yaw).apply([-.030,0,0])
    angle=np.pi/2 if side=='left' else -np.pi/2
    turn=Rotation.from_euler('z',yaw+angle).as_matrix()@Rotation.from_euler('x',-angle).as_matrix()
    grip=Pinch(c,name,side,TOOL_PROFILE,squeeze=.3,opening=.25)
    rotation=turn@grip.rotation;offset=turn@grip.offset
    # The exposed 30 mm edge permits a thumb/fingers-underneath grasp.
    palm=p+edge+offset
    c.event(name+'_edge_preshape');c.move_joints(grip.curled(-.25),seconds=1.2)
    front=Rotation.from_euler('z',yaw).apply([-.075,0,0])
    c.event(name+'_edge_front_approach');goto(c,{side:('palm',palm+front+[0,0,.12],rotation)},seconds=2.5)
    c.move_hands({side:('palm',palm+front,rotation)},seconds=2.)
    c.event(name+'_edge_insert_fingers');c.move_hands({side:('palm',palm,rotation)},seconds=2.)
    c.event(name+'_edge_contact_pose_convergence')
    for _ in range(150):
        actual,actual_R=c.hand_pose(side)
        error=np.linalg.norm(actual-palm)
        angle=np.linalg.norm(Rotation.from_matrix(rotation@actual_R.T).as_rotvec())
        if error<.006 and angle<.04:break
        c.reach({side:('palm',palm,rotation)},feedback=.5,iters=24);c.step()
    if np.linalg.norm(c.hand_pose(side)[0]-palm)>.012:
        raise RuntimeError('shim: undergrasp has not physically reached its contact pose')
    c.event(name+'_edge_close');c.move_joints(grip.curled(.3),seconds=1.3)
    hand,rot=c.hand_pose(side)
    c.event(name+'_edge_lift');c.move_hands({side:('palm',hand+[0,0,.17 if long_edge else .12],rot)},seconds=2.5)
    s=c.object_state(name)
    if not s['hand_contact'] or s['pos'][2]<p[2]+.035:raise RuntimeError('shim: edge grasp failed lift probe')
    if long_edge:
        from .supported_carry import place
        return place(c,grip,goal)
    weak=[0]
    def guard(current):
        if current.phase!='shim_edge_front_corridor':return
        held=current.object_state(name)['hand_contact'];weak[0]=0 if held else weak[0]+1
        if weak[0]>5:raise RuntimeError('shim: sustained grasp lost during edge carry')
    c.joint_feedback['shim_edge_carry_guard']=guard
    if side=='left':
        corridor=.225 if long_edge else .275
        for waypoint in ([corridor,s['pos'][1],s['pos'][2]],[corridor,goal[1],s['pos'][2]]):
            part=np.asarray(c.object_state(name)['pos']);hand,rot=c.hand_pose(side)
            c.event(name+'_edge_front_corridor')
            c.move_hands({side:('palm',hand+np.asarray(waypoint)-part,rot)},seconds=max(1.5,np.linalg.norm(np.asarray(waypoint)-part)/.12),feedback=.5)
    # The high, close-to-torso midline pose is outside this wrist's workspace.
    # Lower in place before traversing the clear strip along the table front.
    hand,rot=c.hand_pose(side)
    c.event(name+'_edge_lower_to_transfer_corridor')
    c.move_hands({side:('palm',hand+[0,0,-.065],rot)},seconds=1.5)
    supported_release=False
    for height in (.045,.015,.001):
        for _ in range(3):
            s=c.object_state(name)
            if not s['hand_contact']:
                if s['support_forces'].get('table',0)>.05 and np.linalg.norm(np.asarray(s['pos'])-goal)<.012:
                    c.event(name+'_edge_supported_setdown',position=s['pos'])
                    supported_release=True;break
                raise RuntimeError('shim: edge grasp lost in transfer')
            delta=np.asarray(goal)+[0,0,height]-s['pos']
            if np.linalg.norm(delta)<.003:break
            hand,rot=c.hand_pose(side);c.event(name+'_edge_transfer')
            c.move_hands({side:('palm',hand+delta,rot)},seconds=max(1.5,np.linalg.norm(delta)/.12),feedback=.5)
        if supported_release:break
    c.joint_feedback.pop('shim_edge_carry_guard',None)
    c.event(name+'_edge_release');c.move_joints(grip.curled(-.25),seconds=1.3)
    hand,rot=c.hand_pose(side);c.move_hands({side:('palm',hand+front,rot)},seconds=1.5)
    c.move_hands({side:('palm',hand+front+[0,0,.15],rot)},seconds=1.5);c.hold(.5)
    s=c.object_state(name)
    if s['robot_contact'] or np.linalg.norm(np.asarray(s['pos'])-goal)>.015:raise RuntimeError('shim: edge placement missed released target')


def slide_to_left(c,fit):
    """Use table support during the lateral transfer; no airborne handoff."""
    p=np.asarray(c.object_state('shim')['pos']);mirror=np.diag([1.,-1.,1.])
    rot=mirror@np.asarray(fit['rotation'])@mirror
    # Centre one index pad on the 70 mm edge. The two pads were only 6 mm
    # from its corners; small yaw shed one contact and spun the shim off-edge.
    # Keep the unused pad above the table instead of dragging it on the surface.
    palm=p+mirror@np.asarray(fit['palm_offset'])+[-.0285,-.055,-.001]
    q=c.q.copy()
    for j,v in fit['hand_joints'].items():q[c.index['right_hand_'+j+'_joint']]=v if j=='thumb_0' else -v
    q[c.index['right_hand_thumb_0_joint']]=0.;q[c.index['right_hand_thumb_1_joint']]=-1.;q[c.index['right_hand_thumb_2_joint']]=-1.45
    c.event('shim_lateral_push_preshape');c.move_joints(q,seconds=1.2)
    goto(c,{'right':('palm',palm+[0,0,.12],rot)},seconds=2.5)
    c.move_hands({'right':('palm',palm,rot)},seconds=2.5,feedback=.5)
    target=palm+[0,.25-p[1],0]
    c.event('shim_slide_along_table_front',target_y=.25)
    pad=mirror@np.asarray(fit['contacts']['index']['point'])-mirror@np.asarray(fit['palm_offset'])
    for i in range(400):
        fraction=(i+1)/400;a=fraction**3*(10-15*fraction+6*fraction*fraction)
        state=c.object_state('shim');actual=np.asarray(state['pos'])
        if actual[0]<.21:raise RuntimeError('shim: stop sliding before losing table support')
        yaw=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_euler('xyz')[2]
        # Steer the pushed face itself: its normal determines force direction.
        # A wrist heading correction alone cannot redirect a flat box face.
        desired_yaw=np.clip(8*(actual[0]-p[0]),-.18,.18)
        yaw_rate=float(state.get('ang',[0,0,0])[2])
        lever=np.clip(-.04*(yaw-desired_yaw)-.005*yaw_rate,-.02,.02)
        turn=Rotation.from_euler('z',yaw).as_matrix()
        point=palm+a*(target-palm)
        contact_x=actual[0]+(turn@np.array([lever,-.09,0]))[0]
        point[0]=contact_x-(turn@pad)[0]
        c.reach({'right':('palm',point,turn@rot)},feedback=.5)
        c.step()
    c.move_hands({'right':('palm',target+[0,0,.12],rot)},seconds=1.5);c.hold(.3)
    s=c.object_state('shim')
    if abs(s['pos'][1]-.25)>.045 or abs(s['pos'][0]-p[0])>.025 or s['support_forces'].get('table',0)<.05:
        raise RuntimeError('shim: lateral table-supported transfer missed the left grasp region')
