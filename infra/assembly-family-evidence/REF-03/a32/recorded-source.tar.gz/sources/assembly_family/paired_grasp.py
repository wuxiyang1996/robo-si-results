"""Close a receiving pinch only after its measured palm reaches the target."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import smooth,side_forces,pose


def acquire_hub(c,grip,protect_other=False,hover=.12,receiver_clearance=False,elbow_branches=False):
    """Use measured endpoint convergence with a parallel-finger HubGrip."""
    grip.shape=grip.open;grip.opening=0.;grip.squeeze_amount=grip.squeeze
    def curled(amount):
        q=c.q.copy()
        for joint,value in grip.open.items():q[grip.joint(joint)]=value
        for joint,sign in [('thumb_1',grip.sign),('index_0',-grip.sign),('middle_0',-grip.sign)]:
            q[grip.joint(joint)]+=sign*amount
        return np.clip(q,c.lo+.03,c.hi-.03)
    grip.curled=curled
    grip.paired_feedback_start=lambda:grip.c.joint_feedback.update({grip.key:grip.feedback})
    if not protect_other:grip.preshape(seconds=.6)
    acquire(c,grip,protect_other=protect_other,hover=hover,receiver_clearance=receiver_clearance,elbow_branches=elbow_branches)
    grip.closed=True;grip.c.joint_feedback[grip.key]=grip.feedback
    return grip


def fit_tilted_frame(c,grip):
    """Fit the flat-frame rail profile to its measured full 3-D orientation."""
    p,R,yaw,_=pose(c,grip.name)
    flat=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
    tilt=R@flat.T
    grip.offset=tilt@grip.offset;grip.rotation=tilt@grip.rotation
    local_p=R.T@(Rotation.from_euler('z',yaw).as_matrix()@grip.anchor+grip.offset)
    local_R=R.T@grip.rotation
    def target(height=0.):
        p,R,_,_=pose(c,grip.name)
        return {grip.side:('palm',p+R@local_p+[0,0,height],R@local_R)}
    grip.target=target
    c.event(grip.name+'_fit_measured_rail_tilt',rotation=R.tolist(),palm_local=local_p.tolist())


def acquire(c,grip,protect_other=True,receiver_clearance=False,hover=.12,close=True,elbow_branches=False):
    side=grip.side
    screen=None
    if receiver_clearance:
        from .grasp_clearance import ReceivingArm
        screen=ReceivingArm(c,grip.name,side)
    other='right'if side=='left'else 'left';other_p,other_R=c.hand_pose(other)
    part_cp=np.zeros(3);part_cr=np.zeros(3);loaded_cp=np.zeros(3);loaded_cr=np.zeros(3)
    if protect_other:
        donor_state=c.object_state(grip.name);donor_p=np.asarray(donor_state['position'])
        donor_R=Rotation.from_quat(np.asarray(donor_state['quat'])[[1,2,3,0]]).as_matrix()
        donor_local_p=donor_R.T@(other_p-donor_p);donor_local_R=donor_R.T@other_R
    def measured_loaded_target():
        state=c.object_state(grip.name);observed=np.asarray(state['position'])
        observed_R=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
        object_error=donor_p-observed;object_rv=Rotation.from_matrix(donor_R@observed_R.T).as_rotvec()
        part_cp[:]=np.clip(part_cp+np.clip(.04*object_error,-.0002,.0002),-.015,.015)
        part_cr[:]=np.clip(part_cr+np.clip(.025*object_rv,-.001,.001),-.12,.12)
        corrected_R=Rotation.from_rotvec(part_cr).as_matrix()@donor_R
        point=donor_p+part_cp+corrected_R@donor_local_p;rotation=corrected_R@donor_local_R
        actual,actual_R=c.hand_pose(other);error=point-actual
        rv=Rotation.from_matrix(rotation@actual_R.T).as_rotvec()
        loaded_cp[:]=np.clip(loaded_cp+np.clip(.03*error,-.00015,.00015),-.015,.015)
        loaded_cr[:]=np.clip(loaded_cr+np.clip(.02*rv,-.0005,.0005),-.10,.10)
        return ('palm',point+loaded_cp+np.clip(.5*error,-.008,.008),Rotation.from_rotvec(loaded_cr+.3*rv).as_matrix()@rotation)
    from .held_ik import solve as hold_loaded
    c.event(grip.name+'_paired_receiver_preshape',side=side)
    if protect_other:
        start=c.q.copy();opened=grip.curled(-grip.opening);joints=[grip.joint(j)for j in grip.shape]
        for i in range(30):
            c.q[joints]=start[joints]+smooth((i+1)/30)*(opened[joints]-start[joints])
            reference,_=hold_loaded(c.ik,c.env.base_position,(1,0,0,0),c.q,{other:measured_loaded_target()},other,iters=24,damping=.015,w_rot=.5,max_step=.05)
            c.q[c.ik.upper]=reference[c.ik.upper];c.step()
    else:c.move_joints(grip.curled(-grip.opening),seconds=.6)
    if hasattr(grip,'paired_feedback_start'):grip.paired_feedback_start()
    correction=np.zeros(3);rotation_correction=np.zeros(3)
    def track(height):
        target=grip.target(height);_,p,R=target[side];hp,hR=c.hand_pose(side)
        error=p-hp;rv=Rotation.from_matrix(R@hR.T).as_rotvec()
        correction[:]=np.clip(correction+np.clip(.06*error,-.0004,.0004),-.035,.035)
        rotation_correction[:]=np.clip(rotation_correction+np.clip(.025*rv,-.001,.001),-.12,.12)
        commanded=Rotation.from_rotvec(rotation_correction).as_matrix()@R
        goals={side:('palm',p+correction,commanded)}
        if protect_other:goals[other]=measured_loaded_target()
        c.reach(goals,feedback=.5,rotation_feedback=.3,iters=24);c.step()
        return float(np.linalg.norm(error)),float(np.linalg.norm(rv))
    for height,seconds in ((hover,2.5),(0.,2.5)):
        target=grip.target(height);_,p,R=target[side]
        c.event(grip.name+'_paired_receiver_approach',height=height)
        seeds=[c.q.copy()]
        for yaw in (-1.2,0.,1.2):
            for shoulder in (-1.5,1.5):
                for donor_shoulder in ((-1.5,1.5) if protect_other else (None,)):
                    seed=c.q.copy();seed[c.index['waist_yaw_joint']]=yaw
                    seed[c.index[side+'_shoulder_yaw_joint']]=shoulder
                    if donor_shoulder is not None:seed[c.index[other+'_shoulder_yaw_joint']]=donor_shoulder
                    seeds.append(seed)
        if elbow_branches:
            expanded=[]
            for seed in seeds:
                for receiving,donating in ((-.6,-.6),(-.6,1.2),(1.2,-.6),(1.2,1.2)):
                    candidate=seed.copy();candidate[c.index[side+'_elbow_joint']]=receiving;candidate[c.index[other+'_elbow_joint']]=donating
                    expanded.append(candidate)
            seeds+=expanded
        candidates=[];diagnostics=[]
        for seed in seeds:
            solution,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,target,iters=400,damping=.02,w_rot=.5,max_step=.08)
            checked=((side,R),(other,other_R)) if protect_other else ((side,R),)
            angles=[float(np.linalg.norm(Rotation.from_matrix(want@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec()))for s,want in checked]
            reachable=max(errors.values())<.004 and max(angles)<.04
            clear=screen.clear(solution,hand_clearance=.003 if height>0 else None,self_clear=True) if screen is not None and reachable else screen is None
            diagnostics.append(dict(position=errors,rotation=angles,receiving_arm_clear=clear,blocked=screen.blocked if screen is not None else None))
            if reachable and clear:
                distance=float(np.linalg.norm(solution[c.ik.upper]-c.q[c.ik.upper]))
                cost=(distance,-screen.minimum) if screen is not None else (distance,0.)
                candidates.append((cost,solution.copy()))
                if len(diagnostics)==1 and screen is None:break
        c.event(grip.name+'_paired_receiver_endpoint',candidates=diagnostics)
        if not candidates:
            raise RuntimeError(grip.name+': paired receiver endpoint is not jointly reachable')
        if protect_other:
            # An endpoint IK constraint does not hold the loaded hand along
            # a joint-space chord. Project each small reference step through
            # the caller's loaded-hand constraint before applying it.
            start=c.q.copy();planned=None;rejected=[]
            for _,solution in sorted(candidates,key=lambda item:item[0]):
                duration=max(seconds,1.9*float(np.max(abs(solution[c.ik.upper]-start[c.ik.upper])))/.35)
                count=max(1,round(duration/.02));previous=start.copy();path=[];reason=None
                for i in range(count):
                    desired=start+smooth((i+1)/count)*(solution-start)
                    seed=previous.copy();seed[c.ik.upper]+=np.clip(desired[c.ik.upper]-seed[c.ik.upper],-.008,.008)
                    projected,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,{},iters=24,damping=.02,w_rot=.5,max_step=.05)
                    if max(errors.values(),default=0.)>.004:
                        reason=dict(reason='loaded_hand_projection_unreachable',fraction=(i+1)/count,errors=errors);break
                    if screen is not None and not screen.clear(projected,hand_clearance=.003 if height>0 else None,self_clear=True):
                        reason=dict(reason='loaded_transition_collision',fraction=(i+1)/count,blocked=screen.blocked);break
                    path.append(projected.copy());previous=projected
                if reason is None:planned=path;break
                rejected.append(reason)
            if rejected:c.event(grip.name+'_paired_loaded_path_rejections',candidates=rejected)
            if planned is None:raise RuntimeError(grip.name+': no collision-free loaded receiver transition')
            c.event(grip.name+'_paired_receiver_loaded_projection',target_q=solution.tolist())
            weak=0
            for step,projected in enumerate(planned):
                force=side_forces(c,grip.name)[other]
                weak=weak+1 if force<.5 else 0
                if weak>10:raise RuntimeError(grip.name+': donor contact lost during loaded receiver transition')
                actual,actual_R=c.hand_pose(other);error=other_p-actual
                rv=Rotation.from_matrix(other_R@actual_R.T).as_rotvec()
                reference=c.q.copy();reference[c.ik.upper]+=np.clip(projected[c.ik.upper]-reference[c.ik.upper],-.008,.008)
                desired={other:measured_loaded_target()}
                commanded,_=hold_loaded(c.ik,c.env.base_position,(1,0,0,0),reference,desired,other,iters=24,damping=.015,w_rot=.5,max_step=.05)
                if screen is not None and not screen.clear(commanded,hand_clearance=.003 if height>0 else None,self_clear=True):
                    c.event(grip.name+'_paired_feedback_path_blocked',step=step,blocked=screen.blocked)
                    raise RuntimeError(grip.name+': measured loaded-hand correction has no collision-free command')
                if step%25==0:c.event(grip.name+'_paired_measured_donor_hold',step=step,force_n=force,position_error=float(np.linalg.norm(error)),rotation_error=float(np.linalg.norm(rv)))
                c.q[c.ik.upper]=commanded[c.ik.upper];c.step()
        else:c.move_joints(min(candidates,key=lambda item:item[0])[1],seconds=seconds)
        goals=dict(target)
        if protect_other:goals[other]=measured_loaded_target()
        c.move_hands(goals,seconds=.6,feedback=.5,rotation_feedback=.3)
        for _ in range(250):
            target=grip.target(height);_,p,R=target[side]
            hp,hR=c.hand_pose(side)
            if np.linalg.norm(hp-p)<.0015 and np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())<.02:break
            track(height)
        hp,hR=c.hand_pose(side)
        c.event(grip.name+'_paired_receiver_pose_check',height=height,position_error=float(np.linalg.norm(hp-p)),rotation_error=float(np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())),position_correction=correction.tolist(),rotation_correction=rotation_correction.tolist(),actual_palm=hp.tolist(),target_palm=p.tolist())
        if np.linalg.norm(hp-p)>.004 or np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())>.04:
            raise RuntimeError(grip.name+': paired receiver has not physically reached its grasp')
    if not close:
        c.event(grip.name+'_paired_pose_only_reached_no_grasp_claim')
        return
    joints=[grip.joint(j)for j in grip.shape];target=grip.target()
    c.event(grip.name+'_paired_receiver_close')
    for amount in (0.,grip.squeeze_amount):
        start=c.q.copy();goal=grip.curled(amount)
        for i in range(30):
            a=smooth((i+1)/30);c.q[joints]=start[joints]+a*(goal[joints]-start[joints])
            track(0.)
    forces=side_forces(c,grip.name);c.event(grip.name+'_paired_receiver_contact_check',forces=forces)
    if forces[side]<.5:raise RuntimeError(grip.name+': paired receiver established no measured contact')
    if screen is not None:
        clear=screen.clear(c.actual_q())
        c.event(grip.name+'_paired_actual_arm_clearance',clear=clear,minimum_m=screen.minimum,blocked=screen.blocked)
        if not clear:raise RuntimeError(grip.name+': loaded receiver lacks actual non-hand clearance before donor release')
