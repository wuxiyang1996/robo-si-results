"""Check a receiving arm against the observed part using a separate planning model."""
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK,XML
from .contact_audit import is_hand


class ReceivingArm:
    def __init__(self,c,name,side,clearance=.025):
        self.c,self.name,self.side,self.clearance=c,name,side,clearance
        root=ET.parse(XML).getroot();root.find('compiler').set('meshdir',str(XML.parent/'assets'))
        world=root.find('worldbody');self.boxes=c.env.catalog['parts'][name]['collision_boxes']
        for i,box in enumerate(self.boxes):
            ET.SubElement(world,'geom',name=f'grasp_part_{i}',type='box',size=' '.join(map(str,np.asarray(box['size'])/2)))
        self.ik=UpperBodyIK();self.ik.m=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'));self.ik.d=mujoco.MjData(self.ik.m)
        m=self.ik.m;self.part=[m.geom(f'grasp_part_{i}').id for i in range(len(self.boxes))];self.arm=[];self.hand=[]
        for g in range(m.ngeom):
            link=m.body(m.geom_bodyid[g]).name
            if not m.geom_contype[g] or not link.startswith(side+'_'):continue
            mesh=m.mesh(m.geom_dataid[g]).name if m.geom_type[g]==mujoco.mjtGeom.mjGEOM_MESH else ''
            if is_hand(link,mesh):self.hand.append(g)
            elif any(k in link for k in ('shoulder','elbow','wrist')):self.arm.append(g)
        self.blocked=None

    def clear(self,solution,hand_clearance=None,self_clear=False):
        state=self.c.object_state(self.name);p=np.asarray(state['position']);R=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
        q=self.c.actual_q().copy();q[self.c.ik.upper]=np.asarray(solution)[self.c.ik.upper]
        self.ik._set(self.c.env.base_position,(1,0,0,0),q)
        if self_clear:
            mujoco.mj_collision(self.ik.m,self.ik.d)
            for contact in self.ik.d.contact[:self.ik.d.ncon]:
                if contact.dist<-.001 and min(self.ik.m.geom_bodyid[contact.geom])>0:
                    self.minimum=float(contact.dist);self.blocked=dict(reason='robot_self_collision',links=[self.ik.m.body(self.ik.m.geom_bodyid[g]).name for g in contact.geom],distance_m=self.minimum)
                    return False
        # These arrays belong solely to the independent kinematic query model.
        # World geoms compiled at the origin can cache an identity sameframe;
        # place their query transforms explicitly after robot FK.
        for i,box in zip(self.part,self.boxes):
            self.ik.d.geom_xpos[i]=p+R@np.asarray(box['pos'])
            self.ik.d.geom_xmat[i]=R.reshape(9)
        self.minimum=.10;self.blocked=None
        for g in self.arm:
            for part in self.part:
                distance=mujoco.mj_geomDistance(self.ik.m,self.ik.d,g,part,.10,None)
                if distance<self.minimum:
                    self.minimum=float(distance)
                    self.blocked=dict(link=self.ik.m.body(self.ik.m.geom_bodyid[g]).name,distance_m=self.minimum)
        if self.minimum>=self.clearance:self.blocked=None
        if self.minimum<self.clearance:return False
        if hand_clearance is not None:
            for g in self.hand:
                for part in self.part:
                    distance=mujoco.mj_geomDistance(self.ik.m,self.ik.d,g,part,hand_clearance,None)
                    if distance<hand_clearance:
                        self.blocked=dict(reason='receiving_hand_touches_part_before_hover',link=self.ik.m.body(self.ik.m.geom_bodyid[g]).name,distance_m=float(distance))
                        return False
        return True
