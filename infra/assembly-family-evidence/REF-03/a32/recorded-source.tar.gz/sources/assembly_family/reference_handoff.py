"""Change a hanging carrier grasp into a grasp that can place it horizontally."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from humanoid.g1_gear_assembly.solution.skills import pose,smooth,side_forces
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip
from .pose_carry import move
from .held_ik import solve as held_solve


def side_handoff(c,left,fit):
    # These are the authored model ranges, with conservative waist planning
    # margins. The old elbow>=0.2 planning restriction excluded the screened
    # side grasp; the physical robot limits and audit remain unchanged.
    original=UpperBodyIK();c.ik.lo[:],c.ik.hi[:]=original.lo,original.hi
    c.ik.set_limit('waist_pitch_joint',-.46,.46);c.ik.set_limit('waist_roll_joint',-.46,.46)
    vertical=Rotation.from_euler('y',np.pi/2).as_matrix()
    move(c,left,[.28,.12,.95],vertical,6.,'carrier_move_to_side_handoff')
    name=left.name;p,R,yaw,state=pose(c,name)
    if np.linalg.norm(p-[.28,.12,.95])>.02 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: hanging grasp did not reach the side handoff workspace')
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([-.08349098346,-.08,0.])
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset']),
                 hand=fit['hand_joints'],squeeze=.40,hook=.10)
    right=HubGrip(c,name,'right',0.,profile=profile,anchor=anchor)
    turn=R@Rotation.from_euler('z',-np.pi/2).as_matrix()
    right.rotation=turn@right.rotation;right.offset=turn@right.offset
    target=right.target();_,rp,rR=target['right'];normal=R[:,2]
    keep_side='left';kp,kR=c.hand_pose(keep_side);solve=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        combined={keep_side:('palm',kp,kR),**tasks}
        if kwargs.get('iters',0)>30:return solve(root_pos,root_quat,q,combined,*args,**kwargs)
        actual,actual_R=c.hand_pose(keep_side)
        rv=Rotation.from_matrix(kR@actual_R.T).as_rotvec()
        if keep_side not in tasks:combined[keep_side]=('palm',kp+np.clip(.5*(kp-actual),-.010,.010),Rotation.from_rotvec(.3*rv).as_matrix()@kR)
        return held_solve(c.ik,root_pos,root_quat,q,combined,keep_side,*args,**kwargs)
    c.ik.solve=keep
    try:
        from .paired_grasp import acquire_hub
        c.event('carrier_side_receiver_screened_loaded_path')
        original_target=right.target
        def side_target(height=0.):
            targets=original_target();kind,point,rotation=targets['right']
            return {'right':(kind,np.asarray(point)+normal*height,rotation)}
        right.target=side_target
        try:acquire_hub(c,right,protect_other=True,hover=.03,receiver_clearance=True,elbow_branches=True)
        finally:right.target=original_target
        forces=side_forces(c,name);c.event('carrier_side_receiver_contact_check',forces=forces)
        if forces['right']<.5:raise RuntimeError('carrier: side receiver established no real grasp')
        keep_side='right';kp,kR=c.hand_pose(keep_side)
        left.release(seconds=1.5,rise=.12)
        hp,hR=c.hand_pose('left');c.move_hands({'left':('palm',hp+[0,.12,.04],hR)},seconds=2.)
    finally:c.ik.solve=solve
    if side_forces(c,name)['right']<.5:raise RuntimeError('carrier: side grasp was lost after handoff')
    move(c,right,[.40,0.,1.04],np.eye(3),6.,'carrier_side_grasp_flatten')
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p-[.40,0.,1.04])>.02 or R[2,2]<.95 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: side regrasp did not reach a held horizontal pose')
    c.event('crossbar_side_handoff_probe_success',position=p.tolist(),rotation=R.tolist())
    return right
