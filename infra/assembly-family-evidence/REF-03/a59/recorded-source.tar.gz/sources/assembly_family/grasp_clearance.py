"""Check a receiving arm against the observed part using a separate planning model."""
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK,XML
from .contact_audit import is_hand


class ReceivingArm:
    def __init__(self,c,name,side,clearance=.025,protect_scene=False,self_margin=0.):
        self.c,self.name,self.side,self.clearance=c,name,side,clearance
        self.self_margin=self_margin
        root=ET.parse(XML).getroot();root.find('compiler').set('meshdir',str(XML.parent/'assets'))
        world=root.find('worldbody');self.boxes=c.env.catalog['parts'][name]['collision_boxes']
        for i,box in enumerate(self.boxes):
            ET.SubElement(world,'geom',name=f'grasp_part_{i}',type='box',size=' '.join(map(str,np.asarray(box['size'])/2)))
        scene=[]
        if protect_scene:
            for owner,spec in c.env.catalog['parts'].items():
                if owner==name:continue
                for box in spec['collision_boxes']:scene.append((owner,box,None))
            cfg=getattr(c.env,'cfg',None)
            if cfg is not None and hasattr(cfg,'table_size'):
                scene.append(('table',dict(pos=[0,0,0],size=cfg.table_size),np.array([*cfg.table_center,cfg.table_height-cfg.table_size[2]/2])))
                for box in c.env.catalog.get('fixture',[]):scene.append(('fixture',dict(pos=[0,0,0],size=box['size']),np.asarray(cfg.origin)+box['pos_local']))
                from humanoid.g1_reference_assembly.genesis_env import supply_layout
                _,racks=supply_layout(c.env.catalog,cfg.seed,cfg.table_height)
                for box in racks:scene.append(('supply_rack',dict(pos=[0,0,0],size=box['size']),np.asarray(box['pos'])))
                from .scene_extensions import extras
                for box in extras('REF-03' if 'access_wall'in c.env.objects else 'REF-02' if 'temporary_fixture'in c.env.objects else 'REF-01',cfg.table_height):
                    scene.append((box['name'],dict(pos=[0,0,0],size=box['size']),None))
        for i,(_,box,_) in enumerate(scene):ET.SubElement(world,'geom',name=f'grasp_scene_{i}',type='box',size=' '.join(map(str,np.asarray(box['size'])/2)))
        self.ik=UpperBodyIK();self.ik.m=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'));self.ik.d=mujoco.MjData(self.ik.m)
        m=self.ik.m;self.part=[m.geom(f'grasp_part_{i}').id for i in range(len(self.boxes))];self.arm=[];self.hand=[]
        for g in range(m.ngeom):
            link=m.body(m.geom_bodyid[g]).name
            if not m.geom_contype[g] or not link.startswith(side+'_'):continue
            mesh=m.mesh(m.geom_dataid[g]).name if m.geom_type[g]==mujoco.mjtGeom.mjGEOM_MESH else ''
            if is_hand(link,mesh):self.hand.append(g)
            elif any(k in link for k in ('shoulder','elbow','wrist')):self.arm.append(g)
        self.torso=[g for g in range(m.ngeom) if m.geom_contype[g] and m.body(m.geom_bodyid[g]).name in ('torso_link','pelvis','pelvis_contour_link')]
        self.scene=[(m.geom(f'grasp_scene_{i}').id,owner,box,fixed)for i,(owner,box,fixed)in enumerate(scene)]
        self.blocked=None;self._measurement_step=None

    def clear(self,solution,hand_clearance=None,self_clear=False,scene_clearance=.05,hand_scene_clearance=.015):
        step=getattr(self.c,'steps',None)
        if step is None or step!=self._measurement_step:
            self._measurement_step=step;self._actual=self.c.actual_q().copy()
            if hasattr(self.c.env,'trusted_state'):self._states=self.c.env.trusted_state()['objects']
            else:self._states={owner:self.c.object_state(owner)for owner in {self.name,*[x[1]for x in self.scene if x[3]is None]}}
        state=self._states[self.name];p=np.asarray(state['position']);R=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
        q=self._actual.copy();q[self.c.ik.upper]=np.asarray(solution)[self.c.ik.upper]
        self.ik._set(self.c.env.base_position,(1,0,0,0),q)
        if self_clear:
            mujoco.mj_collision(self.ik.m,self.ik.d)
            for contact in self.ik.d.contact[:self.ik.d.ncon]:
                if contact.dist<-.001 and min(self.ik.m.geom_bodyid[contact.geom])>0:
                    self.minimum=float(contact.dist);self.blocked=dict(reason='robot_self_collision',links=[self.ik.m.body(self.ik.m.geom_bodyid[g]).name for g in contact.geom],distance_m=self.minimum)
                    return False
            if self.self_margin>0:
                for hand in self.hand:
                    for torso in self.torso:
                        distance=float(mujoco.mj_geomDistance(self.ik.m,self.ik.d,hand,torso,self.self_margin,None))
                        if distance<self.self_margin:
                            self.minimum=distance;self.blocked=dict(reason='hand_torso_clearance',links=[self.ik.m.body(self.ik.m.geom_bodyid[g]).name for g in (hand,torso)],distance_m=distance)
                            return False
        # These arrays belong solely to the independent kinematic query model.
        # World geoms compiled at the origin can cache an identity sameframe;
        # place their query transforms explicitly after robot FK.
        for i,box in zip(self.part,self.boxes):
            self.ik.d.geom_xpos[i]=p+R@np.asarray(box['pos'])
            self.ik.d.geom_xmat[i]=R.reshape(9)
        for geom,owner,box,fixed in self.scene:
            if fixed is None:
                state=self._states[owner];op=np.asarray(state['position']);oR=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
                self.ik.d.geom_xpos[geom]=op+oR@np.asarray(box['pos']);self.ik.d.geom_xmat[geom]=oR.reshape(9)
            else:self.ik.d.geom_xpos[geom]=fixed;self.ik.d.geom_xmat[geom]=np.eye(3).reshape(9)
        scene_ids=np.asarray([x[0]for x in self.scene],dtype=int)
        scene_positions=self.ik.d.geom_xpos[scene_ids];scene_radii=self.ik.m.geom_rbound[scene_ids]
        for robot,required in [(g,scene_clearance)for g in self.arm]+[(g,hand_scene_clearance)for g in self.hand]:
            # Bounding spheres only skip pairs that provably cannot enter the
            # required margin; exact mesh queries decide every remaining pair.
            nearby=np.flatnonzero(np.linalg.norm(scene_positions-self.ik.d.geom_xpos[robot],axis=1)<scene_radii+self.ik.m.geom_rbound[robot]+required)
            for index in nearby:
                geom,owner,_,_=self.scene[index]
                distance=float(mujoco.mj_geomDistance(self.ik.m,self.ik.d,robot,geom,required,None))
                if distance<required:
                    self.minimum=distance;self.blocked=dict(reason='receiving_arm_scene_collision',link=self.ik.m.body(self.ik.m.geom_bodyid[robot]).name,object=owner,distance_m=distance)
                    return False
        self.minimum=.10;self.blocked=None
        for g in self.arm:
            for part in self.part:
                distance=mujoco.mj_geomDistance(self.ik.m,self.ik.d,g,part,.10,None)
                if distance<self.minimum:
                    self.minimum=float(distance)
                    self.blocked=dict(link=self.ik.m.body(self.ik.m.geom_bodyid[g]).name,distance_m=self.minimum)
        if self.minimum>=self.clearance:self.blocked=None
        if self.minimum<self.clearance:return False
        if hand_clearance is not None:
            for g in self.hand:
                for part in self.part:
                    distance=mujoco.mj_geomDistance(self.ik.m,self.ik.d,g,part,hand_clearance,None)
                    if distance<hand_clearance:
                        self.blocked=dict(reason='receiving_hand_touches_part_before_hover',link=self.ik.m.body(self.ik.m.geom_bodyid[g]).name,distance_m=float(distance))
                        return False
        return True
