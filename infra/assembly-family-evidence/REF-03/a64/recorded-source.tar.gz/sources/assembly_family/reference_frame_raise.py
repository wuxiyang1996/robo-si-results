"""Raise the hooked post so the receiving fingers clear the real table."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,smooth
from .reference_frame_settle import wait


def raise_rail(c,grip):
    p,R,_,_=pose(c,grip.name);hp,hR=c.hand_pose(grip.side)
    pivot=p+R@np.array([.0841,-.00329093125,0.])
    near=p+R@np.array([-.0841,-.00329093125,0.])
    turn=Rotation.from_rotvec(-R[:,2]*.50).as_matrix()
    delta=pivot+turn@(near-pivot)-near
    c.ik._set(c.env.base_position,(1,0,0,0),c.q)
    bias=c.ik.hand_point(grip.side,'palm').copy()-hp
    bias_R=c.ik.d.xmat[c.ik.wrist[grip.side]].reshape(3,3).copy()@hR.T
    correction=np.zeros(3);rotation_correction=np.zeros(3);weak=0
    c.event('frame_raise_hooked_post_for_receiver_table_clearance',palm_displacement_m=delta.tolist(),wrist_orientation='held',receiver_rail_offset_m=.02)
    for i in range(180):
        desired=hp+smooth(min(1.,(i+1)/150))*delta
        actual,actual_R=c.hand_pose(grip.side)
        error=desired-actual;rv=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
        correction=np.clip(correction+np.clip(.04*error,-.0002,.0002),-.025,.025)
        rotation_correction=np.clip(rotation_correction+np.clip(.025*rv,-.0005,.0005),-.10,.10)
        c.reach({grip.side:('palm',desired+bias+correction+np.clip(.5*error,-.008,.008),bias_R@Rotation.from_rotvec(rotation_correction+.3*rv).as_matrix()@hR)},rate=.4,iters=20)
        c.step()
        state=c.object_state(grip.name)
        weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>10:raise RuntimeError('frame: post hook lost contact while exposing the receiving rail')
    wait(c,grip)
    p,R,_,state=pose(c,grip.name);rail=p+R@np.array([.02,-.00329093125,.0773333333])
    c.event('frame_raised_receiver_rail_measurement',position=p.tolist(),rotation=R.tolist(),rail=rail.tolist(),robot_contact_force_n=state['robot_contact_force'],supports=state['support_forces'])
    if rail[2]<c.env.cfg.table_height+.047 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('frame: receiving rail still lacks measured table clearance and far-post support')
