"""Let the real post hook settle before fitting the receiving rail target."""
from collections import deque
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose


def wait(c,grip):
    history=deque(maxlen=26);weak=0
    c.event('frame_settle_real_post_hook_before_receiver_fit')
    for step in range(400):
        p,R,_,state=pose(c,grip.name)
        # The contact solver can report one unloaded sample as the rail rolls
        # onto the hook. As in Held.track, reject a sustained loss, and never
        # accept a settled pose without current measured contact.
        weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>25:raise RuntimeError('frame: post contact lost while settling')
        history.append((p.copy(),R.copy()))
        if len(history)==history.maxlen:
            displacement=float(np.linalg.norm(p-history[0][0]))
            rotation=float(np.linalg.norm(Rotation.from_matrix(R@history[0][1].T).as_rotvec()))
            if weak==0 and displacement<.001 and rotation<.015 and np.linalg.norm(state['linear_velocity'])<.005 and np.linalg.norm(state['angular_velocity'])<.03:
                c.event('frame_post_hook_measured_settled',seconds=step*.02,position=p.tolist(),rotation=R.tolist(),position_drift_m=displacement,rotation_drift_rad=rotation,robot_contact_force_n=state['robot_contact_force'],supports=state['support_forces'])
                return
        c.step()
    raise RuntimeError('frame: real post hook did not settle before fitting the receiver')
