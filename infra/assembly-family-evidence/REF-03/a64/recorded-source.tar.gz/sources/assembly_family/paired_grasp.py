"""Close a receiving pinch only after its measured palm reaches the target."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import smooth,side_forces,pose


def acquire_hub(c,grip,protect_other=False,hover=.12,receiver_clearance=False,elbow_branches=False,protect_scene=False):
    """Use measured endpoint convergence with a parallel-finger HubGrip."""
    grip.shape=grip.open;grip.opening=0.;grip.squeeze_amount=grip.squeeze
    def curled(amount):
        q=c.q.copy()
        for joint,value in grip.open.items():q[grip.joint(joint)]=value
        for joint,sign in [('thumb_1',grip.sign),('index_0',-grip.sign),('middle_0',-grip.sign)]:
            q[grip.joint(joint)]+=sign*amount
        return np.clip(q,c.lo+.03,c.hi-.03)
    grip.curled=curled
    grip.paired_feedback_start=lambda:grip.c.joint_feedback.update({grip.key:grip.feedback})
    if not protect_other:grip.preshape(seconds=.6)
    acquire(c,grip,protect_other=protect_other,hover=hover,receiver_clearance=receiver_clearance,elbow_branches=elbow_branches,protect_scene=protect_scene)
    grip.closed=True;grip.c.joint_feedback[grip.key]=grip.feedback
    return grip


def fit_tilted_frame(c,grip):
    """Fit the flat-frame rail profile to its measured full 3-D orientation."""
    p,R,yaw,_=pose(c,grip.name)
    flat=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
    tilt=R@flat.T
    grip.offset=tilt@grip.offset;grip.rotation=tilt@grip.rotation
    local_p=R.T@(Rotation.from_euler('z',yaw).as_matrix()@grip.anchor+grip.offset)
    local_R=R.T@grip.rotation
    def target(height=0.):
        p,R,_,_=pose(c,grip.name)
        return {grip.side:('palm',p+R@local_p+[0,0,height],R@local_R)}
    grip.target=target
    c.event(grip.name+'_fit_measured_rail_tilt',rotation=R.tolist(),palm_local=local_p.tolist())


def acquire(c,grip,protect_other=True,receiver_clearance=False,hover=.12,close=True,elbow_branches=False,protect_scene=False):
    side=grip.side
    screen=None
    if receiver_clearance or protect_scene:
        from .grasp_clearance import ReceivingArm
        screen=ReceivingArm(c,grip.name,side,protect_scene=protect_scene,self_margin=.010 if protect_scene else 0.)
    # The nominal motor reference includes compliant load compensation and
    # is distinct from measured geometry. Retain the 25 mm actual clearance
    # and endpoint planning margin; allow 20 mm for compensated commands.
    command_screen=ReceivingArm(c,grip.name,side,clearance=.020,protect_scene=True,self_margin=.005) if protect_scene else screen
    if protect_scene and hasattr(grip,'scene_clearance_m'):
        # Keep a skill's offline and online path queries on the same margin.
        # Explicit measured-pose margins below retain their own values.
        from functools import partial
        screen.clear=partial(screen.clear,scene_clearance=grip.scene_clearance_m)
        command_screen.clear=partial(command_screen.clear,scene_clearance=grip.scene_clearance_m)
    other='right'if side=='left'else 'left';other_p,other_R=c.hand_pose(other)
    part_cp=np.zeros(3);part_cr=np.zeros(3);loaded_cp=np.zeros(3);loaded_cr=np.zeros(3)
    donor_reference_p=np.zeros(3);donor_reference_R=np.eye(3)
    if protect_other:
        donor_state=c.object_state(grip.name);donor_p=np.asarray(donor_state['position'])
        donor_R=Rotation.from_quat(np.asarray(donor_state['quat'])[[1,2,3,0]]).as_matrix()
        donor_local_p=donor_R.T@(other_p-donor_p);donor_local_R=donor_R.T@other_R
        if getattr(grip,'preserve_donor_reference',False):
            c.ik._set(c.env.base_position,(1,0,0,0),c.q)
            donor_reference_p=c.ik.hand_point(other,'palm').copy()-other_p
            donor_reference_R=c.ik.d.xmat[c.ik.wrist[other]].reshape(3,3).copy()@other_R.T
            c.event(grip.name+'_preserve_loaded_donor_reference',position_bias=donor_reference_p.tolist(),rotation_bias=Rotation.from_matrix(donor_reference_R).as_rotvec().tolist())
    def measured_loaded_target():
        state=c.object_state(grip.name);observed=np.asarray(state['position'])
        observed_R=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_matrix()
        object_error=donor_p-observed;object_rv=Rotation.from_matrix(donor_R@observed_R.T).as_rotvec()
        part_cp[:]=np.clip(part_cp+np.clip(.04*object_error,-.0002,.0002),-.015,.015)
        part_cr[:]=np.clip(part_cr+np.clip(.025*object_rv,-.001,.001),-.12,.12)
        corrected_R=Rotation.from_rotvec(part_cr).as_matrix()@donor_R
        point=donor_p+part_cp+corrected_R@donor_local_p;rotation=corrected_R@donor_local_R
        if getattr(grip,'donor_pose_only',False):point,rotation=other_p,other_R
        actual,actual_R=c.hand_pose(other);error=point-actual
        rv=Rotation.from_matrix(rotation@actual_R.T).as_rotvec()
        loaded_cp[:]=np.clip(loaded_cp+np.clip(.03*error,-.00015,.00015),-.015,.015)
        loaded_cr[:]=np.clip(loaded_cr+np.clip(.02*rv,-.0005,.0005),-.10,.10)
        if getattr(grip,'preserve_donor_reference',False):
            return ('palm',point+donor_reference_p+loaded_cp+np.clip(.5*error,-.008,.008),donor_reference_R@Rotation.from_rotvec(loaded_cr+.3*rv).as_matrix()@rotation)
        return ('palm',point+loaded_cp+np.clip(.5*error,-.008,.008),Rotation.from_rotvec(loaded_cr+.3*rv).as_matrix()@rotation)
    from .held_ik import solve as hold_loaded
    c.event(grip.name+'_paired_receiver_preshape',side=side)
    if protect_other:
        start=c.q.copy();opened=grip.curled(-grip.opening);joints=[grip.joint(j)for j in grip.shape]
        for i in range(30):
            c.q[joints]=start[joints]+smooth((i+1)/30)*(opened[joints]-start[joints])
            reference,_=hold_loaded(c.ik,c.env.base_position,(1,0,0,0),c.q,{other:measured_loaded_target()},other,iters=24,damping=.015,w_rot=.5,max_step=.05)
            c.q[c.ik.upper]=reference[c.ik.upper];c.step()
    else:c.move_joints(grip.curled(-grip.opening),seconds=.6)
    if hasattr(grip,'paired_feedback_start'):grip.paired_feedback_start()
    correction=np.zeros(3);rotation_correction=np.zeros(3);closure_target=None
    def track(height):
        target=closure_target if closure_target is not None else grip.target(height);_,p,R=target[side];hp,hR=c.hand_pose(side)
        error=p-hp;rv=Rotation.from_matrix(R@hR.T).as_rotvec()
        correction[:]=np.clip(correction+np.clip(.06*error,-.0004,.0004),-.035,.035)
        rotation_limit=getattr(grip,'pose_rotation_correction_limit',.12)
        rotation_correction[:]=np.clip(rotation_correction+np.clip(.025*rv,-.001,.001),-rotation_limit,rotation_limit)
        commanded=Rotation.from_rotvec(rotation_correction).as_matrix()@R
        goals={side:('palm',p+correction,commanded)}
        if protect_other:goals[other]=measured_loaded_target()
        if protect_scene:
            if not screen.clear(c.actual_q(),scene_clearance=.025):
                c.event(grip.name+'_paired_settle_actual_margin_lost',height=height,blocked=screen.blocked)
                raise RuntimeError(grip.name+': receiving arm lost actual clearance during grasp convergence')
            before=c.q.copy()
            c.reach(goals,feedback=.5,rotation_feedback=.3,iters=24)
            if not screen.clear(c.q,hand_clearance=.003 if height>0 else None,self_clear=True):
                c.q=before
                c.event(grip.name+'_paired_settle_command_blocked',height=height,blocked=screen.blocked)
                raise RuntimeError(grip.name+': grasp convergence would cross the screened scene')
        else:c.reach(goals,feedback=.5,rotation_feedback=.3,iters=24)
        c.step()
        return float(np.linalg.norm(error)),float(np.linalg.norm(rv))
    contact_continuation=None
    for height,seconds in ((hover,2.5),(0.,2.5)):
        target=grip.target(height);_,p,R=target[side]
        c.event(grip.name+'_paired_receiver_approach',height=height)
        seeds=[c.q.copy()]
        for yaw in (-1.2,0.,1.2):
            for shoulder in (-1.5,1.5):
                for donor_shoulder in ((-1.5,1.5) if protect_other else (None,)):
                    seed=c.q.copy();seed[c.index['waist_yaw_joint']]=yaw
                    seed[c.index[side+'_shoulder_yaw_joint']]=shoulder
                    if donor_shoulder is not None:seed[c.index[other+'_shoulder_yaw_joint']]=donor_shoulder
                    seeds.append(seed)
        if elbow_branches:
            expanded=[]
            for seed in seeds:
                for receiving,donating in ((-.6,-.6),(-.6,1.2),(1.2,-.6),(1.2,1.2)):
                    candidate=seed.copy();candidate[c.index[side+'_elbow_joint']]=receiving;candidate[c.index[other+'_elbow_joint']]=donating
                    expanded.append(candidate)
            seeds+=expanded
        if protect_scene and height==0. and contact_continuation is not None:seeds=[contact_continuation.copy()]
        candidates=[];diagnostics=[];continuations={}
        for seed in seeds:
            solution,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,target,iters=400,damping=.02,w_rot=.5,max_step=.08)
            checked=((side,R),(other,other_R)) if protect_other else ((side,R),)
            angles=[float(np.linalg.norm(Rotation.from_matrix(want@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec()))for s,want in checked]
            reachable=max(errors.values())<.004 and max(angles)<.04
            clear=screen.clear(solution,hand_clearance=.003 if height>0 else None,self_clear=True) if screen is not None and reachable else screen is None
            diagnostics.append(dict(position=errors,rotation=angles,receiving_arm_clear=clear,blocked=screen.blocked if screen is not None else None))
            if reachable and clear and protect_scene and height>0.:
                continuation=solution.copy()
                for fraction in np.linspace(0.,1.,11):
                    remaining=height*(1.-fraction);future=grip.target(remaining)
                    continuation,future_errors=c.ik.solve(c.env.base_position,(1,0,0,0),continuation,future,iters=150,damping=.015,w_rot=.5,max_step=.05)
                    future_angles=[float(np.linalg.norm(Rotation.from_matrix(want@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec()))for s,want in ((side,future[side][2]),(other,other_R))]
                    # The last centimetre is the intended finger-to-part
                    # approach. Keep arm/self/scene margins throughout, while
                    # permitting those grasping fingers to make real contact.
                    future_clear=screen.clear(continuation,hand_clearance=.003 if remaining>.010 else None,self_clear=True)
                    if max(future_errors.values())>.003 or max(future_angles)>.04 or not future_clear:
                        diagnostics[-1]['contact_path_blocked']=dict(fraction=float(fraction),position=future_errors,rotation=future_angles,blocked=screen.blocked)
                        clear=False;break
                diagnostics[-1]['contact_path_continuous']=clear
                if clear:continuations[solution.tobytes()]=continuation.copy()
            if reachable and clear:
                distance=float(np.linalg.norm(solution[c.ik.upper]-c.q[c.ik.upper]))
                clearance_priority=getattr(grip,'receiving_clearance_priority',None)
                if screen is not None and clearance_priority is not None:
                    cost=(max(0.,clearance_priority-screen.minimum),distance)
                    diagnostics[-1]['endpoint_clearance_m']=screen.minimum
                else:cost=(distance,-screen.minimum) if screen is not None else (distance,0.)
                duplicate=next((i for i,(_,prior)in enumerate(candidates)if np.max(abs(prior[c.ik.upper]-solution[c.ik.upper]))<1e-6),None)
                if duplicate is None:candidates.append((cost,solution.copy()))
                elif cost<candidates[duplicate][0]:candidates[duplicate]=(cost,solution.copy())
                if len(diagnostics)==1 and screen is None:break
        c.event(grip.name+'_paired_receiver_endpoint',candidates=diagnostics)
        if not candidates:
            raise RuntimeError(grip.name+': paired receiver endpoint is not jointly reachable')
        if protect_other:
            # An endpoint IK constraint does not hold the loaded hand along
            # a joint-space chord. Project each small reference step through
            # the caller's loaded-hand constraint before applying it.
            start=c.q.copy();planned=None;rejected=[]
            if protect_scene and height>0 and getattr(grip,'overhead_receiver_route',False):
                from .receiver_overhead_path import plan as overhead_plan
                planned,overhead_contact=overhead_plan(c,grip,screen,height)
                if planned is not None:
                    solution=planned[-1]
                    continuations[solution.tobytes()]=overhead_contact
            for candidate_index,(_,solution) in enumerate(sorted(candidates,key=lambda item:item[0])):
                if planned is not None:
                    solution=planned[-1];break
                transition_rate=.15 if getattr(grip,'preserve_donor_reference',False) else .35
                duration=max(seconds,1.9*float(np.max(abs(solution[c.ik.upper]-start[c.ik.upper])))/transition_rate)
                count=max(1,round(duration/.02));previous=start.copy();path=[];reason=None
                c.event(grip.name+'_paired_loaded_path_candidate',candidate=candidate_index,candidates=len(candidates),planning_samples=count)
                for i in range(count):
                    desired=start+smooth((i+1)/count)*(solution-start)
                    seed=previous.copy();seed[c.ik.upper]+=np.clip(desired[c.ik.upper]-seed[c.ik.upper],-.008,.008)
                    projected,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,{},iters=24,damping=.02,w_rot=.5,max_step=.05)
                    if max(errors.values(),default=0.)>.004:
                        reason=dict(reason='loaded_hand_projection_unreachable',fraction=(i+1)/count,errors=errors);break
                    if screen is not None and not screen.clear(projected,hand_clearance=.003 if height>0 else None,self_clear=True):
                        reason=dict(reason='loaded_transition_collision',fraction=(i+1)/count,blocked=screen.blocked);break
                    path.append(projected.copy());previous=projected
                if reason is None:planned=path;break
                rejected.append(reason)
                c.event(grip.name+'_paired_loaded_path_candidate_rejected',candidate=candidate_index,**reason)
            if rejected:c.event(grip.name+'_paired_loaded_path_rejections',candidates=rejected)
            if planned is None:raise RuntimeError(grip.name+': no collision-free loaded receiver transition')
            if protect_scene and height>0.:contact_continuation=continuations.get(solution.tobytes())
            c.event(grip.name+'_paired_receiver_loaded_projection',target_q=solution.tolist())
            weak=0;receiving_cp=np.zeros(3);receiving_cr=np.zeros(3)
            for step,projected in enumerate(planned):
                force=side_forces(c,grip.name)[other]
                weak=weak+1 if force<.5 else 0
                if weak>10:raise RuntimeError(grip.name+': donor contact lost during loaded receiver transition')
                actual,actual_R=c.hand_pose(other);error=other_p-actual
                rv=Rotation.from_matrix(other_R@actual_R.T).as_rotvec()
                if getattr(grip,'preserve_donor_reference',False) and (np.linalg.norm(error)>.0025 or np.linalg.norm(rv)>.020):
                    c.event(grip.name+'_pause_receiver_for_loaded_hand',step=step,position_error=float(np.linalg.norm(error)),rotation_error=float(np.linalg.norm(rv)))
                    for settle in range(250):
                        command,_=hold_loaded(c.ik,c.env.base_position,(1,0,0,0),c.q,{other:measured_loaded_target()},other,iters=24,damping=.015,w_rot=.5,max_step=.05)
                        if screen is not None and not screen.clear(command,hand_clearance=.003 if height>0 else None,self_clear=True):
                            raise RuntimeError(grip.name+': donor recovery lacks receiver clearance')
                        c.q[c.ik.upper]=command[c.ik.upper];c.step()
                        actual,actual_R=c.hand_pose(other);error=other_p-actual
                        rv=Rotation.from_matrix(other_R@actual_R.T).as_rotvec()
                        if np.linalg.norm(error)<.0015 and np.linalg.norm(rv)<.012:break
                    else:raise RuntimeError(grip.name+': loaded donor did not settle before receiver advance')
                reference=c.q.copy();reference[c.ik.upper]+=np.clip(projected[c.ik.upper]-reference[c.ik.upper],-.008,.008)
                desired={other:measured_loaded_target()}
                if protect_scene:
                    if not screen.clear(c.actual_q(),scene_clearance=.025):
                        c.event(grip.name+'_paired_actual_scene_margin_lost',step=step,blocked=screen.blocked)
                        raise RuntimeError(grip.name+': actual receiver lost its scene clearance before the next command')
                    c.ik._set(c.env.base_position,(1,0,0,0),projected)
                    expected=c.ik.hand_point(side,'palm').copy();expected_R=c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).copy()
                    actual_receiver,actual_receiver_R=c.hand_pose(side)
                    receiving_error=expected-actual_receiver
                    receiving_rv=Rotation.from_matrix(expected_R@actual_receiver_R.T).as_rotvec()
                    receiving_cp=np.clip(receiving_cp+np.clip(.03*receiving_error,-.0002,.0002),-.035,.035)
                    receiving_cr=np.clip(receiving_cr+np.clip(.02*receiving_rv,-.0005,.0005),-.10,.10)
                    desired[side]=('palm',expected+receiving_cp+np.clip(.5*receiving_error,-.012,.012),Rotation.from_rotvec(receiving_cr+.3*receiving_rv).as_matrix()@expected_R)
                commanded,_=hold_loaded(c.ik,c.env.base_position,(1,0,0,0),reference,desired,other,iters=24,damping=.015,w_rot=.5,max_step=.05)
                if command_screen is not None and not command_screen.clear(commanded,hand_clearance=.003 if height>0 else None,self_clear=True):
                    c.event(grip.name+'_paired_feedback_path_blocked',step=step,blocked=command_screen.blocked)
                    raise RuntimeError(grip.name+': measured loaded-hand correction has no collision-free command')
                if step%25==0:c.event(grip.name+'_paired_measured_donor_hold',step=step,force_n=force,position_error=float(np.linalg.norm(error)),rotation_error=float(np.linalg.norm(rv)))
                c.q[c.ik.upper]=commanded[c.ik.upper];c.step()
        else:c.move_joints(min(candidates,key=lambda item:item[0])[1],seconds=seconds)
        goals=dict(target)
        if protect_other:goals[other]=measured_loaded_target()
        if protect_scene:
            for _ in range(30):track(height)
        else:c.move_hands(goals,seconds=.6,feedback=.5,rotation_feedback=.3)
        for _ in range(250):
            target=grip.target(height);_,p,R=target[side]
            hp,hR=c.hand_pose(side)
            if np.linalg.norm(hp-p)<.0015 and np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())<.02:break
            track(height)
        hp,hR=c.hand_pose(side)
        c.event(grip.name+'_paired_receiver_pose_check',height=height,position_error=float(np.linalg.norm(hp-p)),rotation_error=float(np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())),position_correction=correction.tolist(),rotation_correction=rotation_correction.tolist(),actual_palm=hp.tolist(),target_palm=p.tolist())
        if np.linalg.norm(hp-p)>.004 or np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())>.04:
            raise RuntimeError(grip.name+': paired receiver has not physically reached its grasp')
    if not close:
        c.event(grip.name+'_paired_pose_only_reached_no_grasp_claim')
        return
    joints=[grip.joint(j)for j in grip.shape];target=grip.target()
    c.event(grip.name+'_paired_receiver_close')
    contact_target=getattr(grip,'measured_close_force_n',None)
    if contact_target is not None:
        # Hold the converged world-frame palm while closing. Following the
        # rail's new pose during closure can turn an initial pad push into
        # an upward transport command before the donor has been released.
        closure_target={s:(kind,point.copy(),rotation.copy())for s,(kind,point,rotation)in grip.target().items()}
        c.event(grip.name+'_receiver_fixed_palm_contact_closure',target_force_n=contact_target)
    for amount in (0.,grip.squeeze_amount):
        start=c.q.copy();goal=grip.curled(amount);count=100 if contact_target is not None and amount>0 else 30;loaded=0
        for i in range(count):
            a=smooth((i+1)/count);c.q[joints]=start[joints]+a*(goal[joints]-start[joints])
            track(0.)
            if contact_target is not None and amount>0:
                force=side_forces(c,grip.name)[side];loaded=loaded+1 if force>=contact_target else 0
                if loaded>=3:
                    c.event(grip.name+'_receiver_stop_closure_on_actual_contact',force_n=force,fraction=a)
                    break
    if contact_target is not None:
        for _ in range(20):track(0.)
    forces=side_forces(c,grip.name);c.event(grip.name+'_paired_receiver_contact_check',forces=forces)
    if forces[side]<.5:raise RuntimeError(grip.name+': paired receiver established no measured contact')
    if screen is not None:
        clear=screen.clear(c.actual_q())
        c.event(grip.name+'_paired_actual_arm_clearance',clear=clear,minimum_m=screen.minimum,blocked=screen.blocked)
        if not clear:raise RuntimeError(grip.name+': loaded receiver lacks actual non-hand clearance before donor release')
