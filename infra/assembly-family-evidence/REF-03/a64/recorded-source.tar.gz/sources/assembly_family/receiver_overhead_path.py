"""Screen a receiving hand's detour while preserving the loaded donor pose."""
import numpy as np
from scipy.spatial.transform import Rotation, Slerp


def plan(c, grip, screen, height):
    side=grip.side;other='right' if side=='left' else 'left'
    base=c.actual_q().copy()
    c.ik._set(c.env.base_position,(1,0,0,0),base)
    palms={s:('palm',c.ik.hand_point(s,'palm').copy(),
              c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).copy()) for s in (side,other)}
    start=palms[side];target=grip.target(height)[side]
    for x,z in ((.45,1.25),(.38,1.25),(.45,1.15),(.38,1.15)):
        waypoints=[start,('palm',np.array([x,start[1][1],z]),start[2]),
                   ('palm',np.array([x,target[1][1],z]),target[2]),target]
        previous=base.copy();path=[];reason=None
        for a,b in zip(waypoints,waypoints[1:]):
            rotations=Slerp([0,1],Rotation.from_matrix([a[2],b[2]]))
            for fraction in np.linspace(0,1,41)[1:]:
                goals={other:palms[other],side:('palm',a[1]+fraction*(b[1]-a[1]),rotations(fraction).as_matrix())}
                solved,errors=c.ik.solve(c.env.base_position,(1,0,0,0),previous,goals,
                                        iters=120,damping=.015,w_rot=.5,max_step=.05)
                angles=[float(np.linalg.norm(Rotation.from_matrix(t[2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())) for s,t in goals.items()]
                delta=float(np.max(abs(solved[c.ik.upper]-previous[c.ik.upper])))
                if max(errors.values())>.003 or max(angles)>.04 or delta>.4:
                    reason=dict(reason='overhead_ik',position=errors,rotation=angles,joint_delta=delta);break
                count=max(10,int(np.ceil(delta/.003)))
                segment=[previous+f*(solved-previous) for f in np.linspace(0,1,count+1)[1:]]
                for query in segment:
                    if not screen.clear(query,hand_clearance=.003,self_clear=True):
                        reason=dict(reason='overhead_scene',blocked=screen.blocked);break
                if reason is not None:break
                path.extend(segment);previous=solved
            if reason is not None:break
        continuation=previous.copy()
        if reason is None:
            for fraction in np.linspace(0,1,11):
                remaining=height*(1-fraction)
                goals={other:palms[other],**grip.target(remaining)}
                continuation,errors=c.ik.solve(c.env.base_position,(1,0,0,0),continuation,goals,
                                             iters=150,damping=.015,w_rot=.5,max_step=.05)
                angles=[float(np.linalg.norm(Rotation.from_matrix(t[2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())) for s,t in goals.items()]
                if max(errors.values())>.003 or max(angles)>.04 or not screen.clear(continuation,hand_clearance=.003 if remaining>.01 else None,self_clear=True):
                    reason=dict(reason='overhead_contact_continuation',position=errors,rotation=angles,blocked=screen.blocked);break
        c.event(grip.name+'_overhead_receiver_path',x=x,z=z,steps=len(path),accepted=reason is None,rejection=reason)
        if reason is None:return path,continuation
    return None,None
