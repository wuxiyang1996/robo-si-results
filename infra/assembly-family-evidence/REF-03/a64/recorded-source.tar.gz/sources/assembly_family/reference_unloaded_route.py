"""Reach a supplied unloaded joint posture through measured scene clearance."""
import numpy as np
from .grasp_clearance import ReceivingArm


def frame_approach(c):
    from .reference_frame_waypoint import MEASURED_Q,SOURCE_ATTEMPT,SOURCE_TIME_S
    base=c.actual_q().copy();active=c.ik.upper
    finish=np.clip(np.asarray(MEASURED_Q)[active],c.ik.lo+.002,c.ik.hi-.002)
    screens=[ReceivingArm(c,'right_frame',side,protect_scene=True)for side in ('left','right')]
    def clear(point):
        q=base.copy();q[active]=point
        return all(s.clear(q,self_clear=True,scene_clearance=.030,hand_scene_clearance=.030)for s in screens)
    def edge(a,b):
        count=max(1,int(np.ceil(np.max(abs(a-b))/.04)))
        return all(clear(a+(b-a)*i/count)for i in range(1,count+1))
    start=base[active]
    if not clear(finish):raise RuntimeError('frame: witnessed unloaded approach posture is obstructed in this scene '+str([s.blocked for s in screens]))
    path=[start,finish] if edge(start,finish) else None
    if path is None:
        rng=np.random.default_rng(17);points=[start];parents=[-1]
        for iteration in range(5000):
            sample=finish if rng.random()<.35 else rng.uniform(c.ik.lo,c.ik.hi)
            parent=int(np.argmin([np.linalg.norm(q-sample)for q in points]));a=points[parent]
            b=a+(sample-a)*min(1.,.30/max(np.linalg.norm(sample-a),1e-9))
            if not edge(a,b):continue
            points.append(b);parents.append(parent)
            if edge(b,finish):
                path=[finish];index=len(points)-1
                while index!=-1:path.append(points[index]);index=parents[index]
                path=path[::-1];break
    if path is None:raise RuntimeError('frame: no clear route to the unloaded approach posture')
    shortened=[path[0]];index=0
    while index<len(path)-1:
        last=len(path)-1
        while last>index+1 and not edge(path[index],path[last]):last-=1
        shortened.append(path[last]);index=last
    c.event('frame_reach_witnessed_unloaded_approach',source_attempt=SOURCE_ATTEMPT,source_time_s=SOURCE_TIME_S,waypoints=[x.tolist()for x in shortened],execution='ordinary_joint_targets_with_actual_clearance_guard')
    guards=[ReceivingArm(c,'right_frame',side,clearance=.005,protect_scene=True)for side in ('left','right')]
    def guard(current):
        for screen in guards:
            if not screen.clear(current.actual_q(),scene_clearance=.005):raise RuntimeError('frame: measured unloaded approach clearance lost '+str(screen.blocked))
    c.joint_feedback['unloaded_frame_approach']=guard
    try:
        for waypoint in shortened[1:]:
            goal=c.q.copy();goal[active]=waypoint
            c.move_joints(goal,seconds=max(2.,1.9*float(np.max(abs(goal[active]-c.q[active])))/.35))
        c.hold(.5)
    finally:c.joint_feedback.pop('unloaded_frame_approach',None)
