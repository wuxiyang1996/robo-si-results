"""Change a hanging carrier grasp into a grasp that can place it horizontally."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_support_retrieval.oracle.upper_ik import UpperBodyIK
from humanoid.g1_gear_assembly.solution.skills import pose,smooth,side_forces
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip
from .pose_carry import move
from .held_ik import solve as held_solve


def bind_side_target(c,grip):
    """Keep the receiving palm fixed in the measured 3-D carrier frame.

    A vertical carrier's yaw is undefined. Recomputing a yaw-frame anchor
    there can jump across the carrier during an otherwise tiny pose change.
    """
    p,R,_,_=pose(c,grip.name)
    _,point,rotation=grip.target()[grip.side]
    local_point=R.T@(np.asarray(point)-p);local_rotation=R.T@rotation
    def target(height=0.):
        actual,actual_R,_,_=pose(c,grip.name)
        return {grip.side:('palm',actual+actual_R@(local_point+[0.,0.,height]),actual_R@local_rotation)}
    return target


def side_handoff(c,left,fit):
    # These are the authored model ranges, with conservative waist planning
    # margins. The old elbow>=0.2 planning restriction excluded the screened
    # side grasp; the physical robot limits and audit remain unchanged.
    original=UpperBodyIK();c.ik.lo[:],c.ik.hi[:]=original.lo,original.hi
    c.ik.set_limit('waist_pitch_joint',-.46,.46);c.ik.set_limit('waist_roll_joint',-.46,.46)
    c.ik.set_limit('right_wrist_pitch_joint',-1.45,1.45);c.ik.set_limit('right_wrist_yaw_joint',-1.45,1.45)
    reversed_receiver=getattr(c,'carrier_reversed_receiver',False)
    vertical=Rotation.from_euler('y',np.pi/2).as_matrix()
    handoff_goal=np.array([.28,0.,.95] if reversed_receiver else [.28,.08,.95])
    if reversed_receiver:vertical=Rotation.from_euler('z',-45.,degrees=True).as_matrix()@vertical
    move(c,left,handoff_goal,vertical,6.,'carrier_move_to_side_handoff')
    name=left.name;p,R,yaw,state=pose(c,name)
    if np.linalg.norm(p-handoff_goal)>.02 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: hanging grasp did not reach the side handoff workspace')
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([-.08349098346,-.08,0.])
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset']),
                 hand=fit['hand_joints'],squeeze=.40,hook=getattr(c,'carrier_receiver_hook',.10))
    right=HubGrip(c,name,'right',0.,profile=profile,anchor=anchor)
    right.receiving_clearance_priority=.06
    reversed_receiver=getattr(c,'carrier_reversed_receiver',False)
    if reversed_receiver:
        right.preserve_donor_reference=True
        right.donor_pose_only=True
        c.event('carrier_receiver_hold_actual_donor_wrist',preserve_nominal_load_reference=True,transition_joint_rate_rad_s=.15)
    turn=R@Rotation.from_euler('z',np.pi/2 if reversed_receiver else -np.pi/2).as_matrix()
    c.event('carrier_receiver_grasp_orientation',reversed_receiver=reversed_receiver)
    right.rotation=turn@right.rotation;right.offset=turn@right.offset
    if getattr(c,'carrier_center_receiver_pads',False):
        # a165's measured distal contacts were 1.8--2.7 mm above
        # the rail midplane; its index escaped across the +4.13 mm edge.
        # Translate this free-space grasp toward the rail midplane.
        right.offset-=R@np.array([0.,0.,.0025])
        c.event('carrier_center_receiver_pads_on_measured_rail',normal_offset_m=-.0025)
    receiving_target=bind_side_target(c,right)
    keep_side='left';kp,kR=c.hand_pose(keep_side);solve=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        combined={keep_side:('palm',kp,kR),**tasks}
        if kwargs.get('iters',0)>30:return solve(root_pos,root_quat,q,combined,*args,**kwargs)
        actual,actual_R=c.hand_pose(keep_side)
        rv=Rotation.from_matrix(kR@actual_R.T).as_rotvec()
        if keep_side not in tasks:combined[keep_side]=('palm',kp+np.clip(.5*(kp-actual),-.010,.010),Rotation.from_rotvec(.3*rv).as_matrix()@kR)
        return held_solve(c.ik,root_pos,root_quat,q,combined,keep_side,*args,**kwargs)
    c.ik.solve=keep
    try:
        from .paired_grasp import acquire_hub
        c.event('carrier_side_receiver_screened_loaded_path')
        original_target=right.target
        right.target=receiving_target
        try:acquire_hub(c,right,protect_other=True,hover=.05,receiver_clearance=True,elbow_branches=True,protect_scene=True)
        finally:right.target=original_target
        forces=side_forces(c,name);c.event('carrier_side_receiver_contact_check',forces=forces)
        if forces['right']<.5:raise RuntimeError('carrier: side receiver established no real grasp')
        if getattr(c,'carrier_two_hand_carry',False):
            c.ik.solve=solve
            from .reference_two_hand_carry import move as two_hand_move
            two_hand_move(c,left,right)
            c.event('crossbar_two_hand_probe_success',position=pose(c,name)[0].tolist())
            return right
        keep_side='right';kp,kR=c.hand_pose(keep_side)
        left.release(seconds=1.5,rise=.12)
        if reversed_receiver and getattr(c,'carrier_direct_after_release',False):
            # A full-scene query on the measured released posture admits a
            # direct carried path. Avoid the optional idle-arm fold that
            # displaced the loaded wrist during a165.
            c.event('carrier_keep_released_left_for_screened_direct_carry')
        elif reversed_receiver:
            from .policies import park_unused_arm_high
            c.event('carrier_park_released_left_without_shared_waist_motion')
            park_unused_arm_high(c,'left')
        else:
            hp,hR=c.hand_pose('left');c.move_hands({'left':('palm',hp+[0,.12,.04],hR)},seconds=2.)
    finally:c.ik.solve=solve
    if side_forces(c,name)['right']<.5:raise RuntimeError('carrier: side grasp was lost after handoff')
    from .reference_carry_path import move as planned_carry
    # Clear the shoulder while the rail remains vertical. Combining the
    # first forward motion with flattening let the real thin-rail grasp roll
    # toward the shoulder before the planned rigid transform could follow.
    p,R,_,_=pose(c,name)
    if not reversed_receiver:
        planned_carry(c,right,p+[.03,.05,0],R)
        c.event('carrier_vertical_translation_clear_of_shoulder',position=pose(c,name)[0].tolist())
    flat_goal=np.array([.40,-.20,1.04] if reversed_receiver else [.25,-.30,.85])
    planned_carry(c,right,flat_goal,np.eye(3))
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p-flat_goal)>.02 or R[2,2]<.95 or state['robot_contact_force']<.5:
        raise RuntimeError('carrier: side regrasp did not reach a held horizontal pose')
    c.event('crossbar_side_handoff_probe_success',position=p.tolist(),rotation=R.tolist())
    return right
