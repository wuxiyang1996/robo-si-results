"""Open topological assembly with one measured, reusable temporary fixture."""
from copy import deepcopy
from math import dist,isfinite
from humanoid.g1_reference_assembly.task_spec import Evaluator,OBJECT_NAMES,PHYSICAL_DEPENDENCIES


def normalize(state):
    """Aggregate real fixture contact under the original support category."""
    state=deepcopy(state)
    for obj in state['objects'].values():
        f=obj['support_forces'];temporary=f.pop('temporary_fixture',0.)
        if temporary:f['fixture']=f.get('fixture',0.)+temporary
        wall=f.pop('access_wall',0.)
        if wall:f['other']=f.get('other',0.)+wall
    return state

class ConstrainedEvaluator(Evaluator):
    def update(self,state,dt):return super().update(normalize(state),dt)

class FixtureEvaluator(Evaluator):
    def reset(self):
        self.fixture_uses={};self.dwells={};self.fixture_use_dwell={};self.last_use_position=None
        return super().reset()
    def update(self,state,dt):
        if self._terminal is not None:return deepcopy(self._terminal)
        try:
            if not isfinite(dt) or not 0<dt<=self.cfg.control_dt*1.01:raise ValueError()
            raw=state['objects'];fixture=raw['temporary_fixture']
            normalized=normalize(state)['objects']
            objects={n:self._read_object(normalized[n]) for n in OBJECT_NAMES}
        except (KeyError,TypeError,ValueError):return self._finish('invalid_state')
        self.elapsed+=dt
        if self.elapsed>=self.cfg.max_episode_seconds:return self._finish('timeout')
        if any(x['position'][2]<self.cfg.table_height-self.cfg.drop_distance for x in objects.values()):return self._finish('object_dropped')
        self.conditions={slot:self._condition(slot,actual,objects) for slot,actual in self.assignments.items()}
        for slot in self.completed:
            intact=self.conditions[slot]['structural_valid']
            self.loss_dwell[slot]=0. if intact else self.loss_dwell[slot]+dt
            if self.loss_dwell[slot]>=self.cfg.support_loss_grace_seconds:return self._finish('structure_lost',detail={'slot':slot})
        # Any currently eligible node can finish; iteration does not let a later
        # node use an assignment created in this same sample.
        eligible=[s for s in self.sequence if s not in self.assignments and all(d in self.assignments for d in PHYSICAL_DEPENDENCIES[s])]
        for slot in eligible:
            candidates=self._candidates(slot)
            for actual in candidates:
                key=slot+'|'+actual
                cond=self._condition(slot,actual,objects)
                self.dwells[key]=self.dwells.get(key,0.)+dt if cond['stable_released'] else 0.
                if self.dwells[key]>=self.cfg.stable_seconds:
                    self.assignments[slot]=actual;self.completed.append(slot);self.loss_dwell[slot]=0.;break
        self.stage=len(self.completed)
        for slot in ('left_frame','right_frame'):
            actual=self.assignments.get(slot,slot)
            valid=raw[actual]['support_forces'].get('temporary_fixture',0)>.05 and self._released(objects[actual]) and self._slow(objects[actual])
            valid=valid and fixture['robot_contact_force']<=.05 and self._slow(fixture)
            self.fixture_use_dwell[slot]=self.fixture_use_dwell.get(slot,0.)+dt if valid else 0.
            if self.fixture_use_dwell[slot]>=.5 and slot not in self.fixture_uses:
                p=fixture['position']
                if self.last_use_position is None or dist(p,self.last_use_position)>.10:
                    self.fixture_uses[slot]={'time':self.elapsed,'position':p};self.last_use_position=list(p)
        if self.stage==len(self.sequence):
            stable=all(self._condition(slot,actual,objects)['stable_released'] for slot,actual in self.assignments.items())
            parked=dist(fixture['position'],(.30,.30,self.cfg.table_height+.015))<.05
            clear=all(raw[n]['support_forces'].get('temporary_fixture',0)<.01 for n in OBJECT_NAMES)
            valid=stable and parked and clear and len(self.fixture_uses)==2 and fixture['robot_contact_force']<=.05 and self._slow(fixture)
            self.final_dwell=self.final_dwell+dt if valid else 0.
            if self.final_dwell>=self.cfg.final_hold_seconds:return self._finish('assembled_fixture_reused_and_parked',success=True)
        result=self.status();result['fixture_uses']=self.fixture_uses;return result
