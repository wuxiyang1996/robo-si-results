"""Measured frame alignment and release into the unchanged original fixture."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,shift_hands
from .frame_slots import envelope

def frame(c,grip,slot,time_scale=1.):
    if getattr(c,'continuous_frame_seating',False):return fast_frame(c,grip,slot)
    name,side=grip.name,grip.side
    goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    c.event(name+'_transfer_to_frame_slot',slot=slot)
    if getattr(c,'fast_frame_transfer',False):
        from .pose_carry import move
        for height,seconds in ((.08,3.),(.032,2.)):
            move(c,grip,goal+[0,0,height],np.eye(3),seconds,name+'_continuous_measured_slot_transfer')
    else:
        for height in (.08,.032):
            for _ in range(8):
                p,R,_,state=pose(c,name)
                if state['robot_contact_force']<.05:raise RuntimeError(name+': grasp lost before frame placement')
                error=goal+[0,0,height]-p
                rv=Rotation.from_matrix(R.T).as_rotvec()
                if np.linalg.norm(error)<.0005 and np.linalg.norm(rv)<.006:break
                correction=Rotation.from_rotvec(rv*min(1.,.10/max(np.linalg.norm(rv),1e-9))).as_matrix()
                # Keep the loaded transfer settling time. Shortening these moves
                # left a ten-degree pitch error that the foot servo cannot remove.
                shift_hands(c,[side],np.clip(error,-.04,.04),seconds=1.2,pivot=p,rot=correction)
    c.event(name+'_align_feet')
    for _ in range(8):
        p,R,_,_=pose(c,name);foot=p+R@[0,0,-.125]
        delta=np.r_[goal[:2]-foot[:2],0.]
        if np.linalg.norm(delta)<.00025:break
        shift_hands(c,[side],np.clip(delta,-.004,.004),seconds=.6)
    c.event(name+'_insert_feet')
    for iteration in range(70):
        p,R,_,_=pose(c,name)
        if p[2]<goal[2]+.003:break
        if iteration%5==0:
            guided,details=envelope(c.env,name,slot,p,R)
            if guided:
                c.event(name+'_feet_engaged_in_guiding_slots',details=details)
                break
        foot=p+R@[0,0,-.125];xy=goal[:2]-foot[:2]
        yaw=Rotation.from_matrix(R).as_euler('xyz')[2]
        feet_error=max(np.linalg.norm(xy+np.array([x,0])-(R@[x,0,0])[:2]) for x in (-.0841,.0841))
        dz=-.0015/time_scale if feet_error<.00040 and abs(yaw)<.002 else 0.
        shift_hands(c,[side],np.r_[np.clip(.6*xy,-.0008,.0008),dz],seconds=.6*time_scale,pivot=p,yaw=np.clip(-.6*yaw,-.008,.008))
    p,R,_,_=pose(c,name)
    rotation_error=float(np.linalg.norm(Rotation.from_matrix(R).as_rotvec()))
    if p[2]>goal[2]+.006 or np.linalg.norm(p[:2]-goal[:2])>.003 or rotation_error>.025:
        # The bounded insertion loop can end with a foot on a slot wall.
        # Lift, recenter from measured part pose, and retry; never open high.
        guided,details=envelope(c.env,name,slot,p,R)
        c.event(name+'_actual_slot_release_envelope',valid=guided,details=details)
        if not guided:
            c.event(name+'_measured_placement_retry',position=p.tolist(),rotation_error=rotation_error)
            return fast_frame(c,grip,slot)
        c.event(name+'_gravity_release_inside_guiding_slots',position=p.tolist())
    if getattr(c,'fast_frame_transfer',False):
        # The low-opening acquisition remains useful beside the supply rack.
        # At the installed rail, open the hook before rising so it cannot lift
        # a newly credited frame back out of its slots.
        grip.opening=max(grip.opening,.25);grip.thumb_opening=max(grip.thumb_opening,.25)
        from humanoid.g1_gear_assembly.solution.skills import hook_release
        hook_release(c,[grip],out=.04,drop=.008,rise=.10,seconds=1.)
    else:grip.release(seconds=1.,rise=.10)
    c.hold(.8)


def fast_frame(c,grip,slot):
    """Continuous measured foot servo through the unchanged narrow slots."""
    from .pose_carry import move
    name,side=grip.name,grip.side
    goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    preserve=getattr(c,'continuous_frame_seating',False)
    move(c,grip,goal+[0,0,.045],np.eye(3),5.,name+'_continuous_slot_hover',preserve_reference=preserve)
    c.event(name+'_continuous_foot_alignment')
    weak=0
    for iteration in range(1000):
        p,R,_,state=pose(c,name)
        weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>10:raise RuntimeError(name+': grasp lost during continuous foot placement')
        if iteration%5==0:
            guided,details=envelope(c.env,name,slot,p,R)
            if guided:
                c.event(name+'_feet_engaged_in_guiding_slots',details=details)
                break
        foot=p+R@[0,0,-.125]
        xy=goal[:2]-foot[:2]
        yaw=float(np.arctan2(R[1,0],R[0,0]))
        feet_error=max(np.linalg.norm(xy+np.array([x,0.])-(R@[x,0.,0.])[:2])for x in(-.0841,.0841))
        rv=Rotation.from_matrix(R.T).as_rotvec()
        if p[2]<goal[2]+.003 and feet_error<.0005 and np.linalg.norm(rv)<.012:break
        dz=max(-.00025,min(0.,goal[2]+.001-p[2])) if feet_error<.0004 and abs(yaw)<.002 and np.linalg.norm(rv)<.012 else 0.
        # Correct lean before translating the feet. Moving the upper bar
        # sideways while a foot rested on a wall increased the lean instead.
        tilted=np.linalg.norm(rv[:2])>.02
        delta=np.zeros(3) if tilted else np.r_[np.clip(.15*xy,-.0008,.0008),dz]
        step=rv*min(.05,.002/max(np.linalg.norm(rv),1e-9));dR=Rotation.from_rotvec(step).as_matrix()
        hp,hR=c.hand_pose(side)
        if preserve:
            # Keep the settled motor reference while integrating the small
            # measured-foot corrections. Rebuilding every command from the
            # loaded measured wrist discards compliance compensation.
            c.ik._set(c.env.base_position,(1,0,0,0),c.q)
            hp=c.ik.hand_point(side,'palm').copy()
            hR=c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).copy()
        pivot=foot if tilted else p
        c.reach({side:('palm',pivot+delta+dR@(hp-pivot),dR@hR)},feedback=0. if preserve else .4,rotation_feedback=0. if preserve else .3,iters=20);c.step()
    p,R,_,_=pose(c,name)
    if p[2]>goal[2]+.006 or np.linalg.norm(p[:2]-goal[:2])>.003 or np.linalg.norm(Rotation.from_matrix(R).as_rotvec())>.025:
        guided,details=envelope(c.env,name,slot,p,R)
        if not guided:
            raise RuntimeError(name+': continuous foot placement did not physically align and seat the frame; '+str(details))
        c.event(name+'_gravity_release_inside_guiding_slots',details=details)
    if getattr(c,'fast_frame_transfer',False):
        grip.opening=max(grip.opening,.25);grip.thumb_opening=max(grip.thumb_opening,.25)
        from humanoid.g1_gear_assembly.solution.skills import hook_release
        hook_release(c,[grip],out=.04,drop=.008,rise=.10,seconds=1.)
    else:grip.release(seconds=1.,rise=.10)
    c.hold(.8)
