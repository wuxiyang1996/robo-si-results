"""Continuous, monitored expert runs. No source task or historical evidence edits."""
import argparse
import faulthandler
import gzip
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from dataclasses import asdict
import numpy as np

from .contracts import plan, ROOT, VELOCITY_SOURCE, VELOCITY_SHA
from .contact_audit import VERSION as CONTACT_VERSION, geometry_catalog, forbidden, violations

def plain(v):
    if hasattr(v,'detach'):return v.detach().cpu().numpy().tolist()
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [plain(x) for x in v]
    return v

def write(p,v):
    p=Path(p);p.write_text(json.dumps(plain(v),ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def snapshot_loaded(output,snapshots):
    for module in list(sys.modules.values()):
        path=getattr(module,'__file__',None)
        if path and Path(path).suffix=='.py' and Path(path).is_relative_to(ROOT):
            p=Path(path);rel=p.relative_to(ROOT)
            if str(rel) in snapshots:continue
            raw=p.read_bytes();target=output/'sources'/rel
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
            snapshots[str(rel)]=hashlib.sha256(raw).hexdigest()
    write(output/'sources.json',snapshots)


def velocity_limits(names):
    assert sha(VELOCITY_SOURCE)==VELOCITY_SHA
    values={j.get('name'):float(j.find('limit').get('velocity')) for j in ET.parse(VELOCITY_SOURCE).iter('joint')
            if j.find('limit') is not None and j.find('limit').get('velocity')}
    return np.array([values[n] for n in names])

class Monitor:
    def __init__(self,env,output,contract):
        self.e=env;self.out=output;self.contract=contract;self.controller=None
        self.dt=getattr(env,'sim_dt',.0025 if contract['family']=='GEAR' else .005)
        from humanoid.g1_tabletop.genesis_env import JOINT_NAMES
        self.names=list(JOINT_NAMES);self.velocity=velocity_limits(self.names)
        self.steps=0;self.controls=[];self.phases=[];self.high=[];self.events=[];self.mapping=[]
        self.q=[];self.qd=[];self.times=[];self.physq=[];self.physqd=[];self.tau=[]
        self.trace=gzip.open(output/'physics.jsonl.gz','wt',encoding='utf8')
        self.low=open(output/'low_plan.jsonl','w',encoding='utf8')
        self.live_events=open(output/'events-live.jsonl','w',encoding='utf8')
        self.actions=gzip.open(output/'action_plan.jsonl.gz','wt',encoding='utf8')
        self.contact_trace=gzip.open(output/'contacts.jsonl.gz','wt',encoding='utf8')
        self.control_start=[];self.control_end=[]
        self.guards=[];self.violations=[];self.last_torque=np.zeros(len(self.names));self.forbidden_contacts=[]
        self.step0=env.scene.step;self.force0=env.robot.control_dofs_force
        self.control0=env.step_targets
        self.update0=env.evaluator.update
        self.high_id=contract['high_level'][0]['id']
        self.contact_peaks={};self.contact_peak_context={}
        self.qlo=np.asarray(plain(env.lo));self.qhi=np.asarray(plain(env.hi));self.max_overrun=0.;self.overrun_joint=None;self.max_speed_ratio=0.
        self.robot_links={link.idx:link.name for link in env.robot.links}
        self.robot_geoms=geometry_catalog(env.robot);self.geom_peaks={}
        write(output/'robot_collision_geometries.json',self.robot_geoms)
        self.owners=dict(env.link_owners)
        from humanoid.g1_support_retrieval.solution.step_up.video import VideoWriter
        self.video=VideoWriter(output/'video.mp4',fps=5)
        self.frame_count=0;self.next_frame=0.;self.started=time.time()
        write(output/'config.json',asdict(env.cfg))
        import genesis,torch,platform
        from humanoid.g1_tabletop.genesis_env import anchored_robot_xml
        body_path=anchored_robot_xml()
        provenance={'python':platform.python_version(),'genesis':getattr(genesis,'__version__',None),'torch':torch.__version__,
                    'body_file':str(body_path),'body_sha256':sha(body_path),'rigid_options':env.scene.rigid_solver._options.model_dump()}
        (output/'runtime.json').write_text(json.dumps(plain(provenance),default=str,indent=2)+'\n')
        write(output/'initial_state.json',self.state())
        write(output/'environment.json',{'physics':getattr(env,'physics_metadata',{}),'specs':getattr(env,'specs',{}),'base_position':env.base_position,'body_model':contract['implementation_body']})
        write(output/'limits.json',{'names':self.names,'lo':plain(env.lo),'hi':plain(env.hi),
                'effort':plain(env.effort),'velocity':self.velocity,'physics_dt':self.dt})

    def state(self):return self.e.state() if self.contract['family']=='ASM' else self.e.trusted_state()

    def guard(self,obj,name):
        if not hasattr(obj,name):return
        value=getattr(obj,name);owned=name in obj.__dict__
        def deny(*a,**kw):
            self.violations.append({'method':name,'step':self.steps});raise RuntimeError('Forbidden runtime state/parameter write: '+name)
        setattr(obj,name,deny);self.guards.append((obj,name,value,owned))

    def start(self):
        from humanoid.g1_gear_assembly.solution.recording import EpisodeAudit
        for entity in self.e.scene.entities:
            for name in EpisodeAudit.ENTITY_METHODS+('set_friction','set_mass','set_dofs_kp','set_dofs_kv','set_dofs_damping','set_dofs_stiffness'):self.guard(entity,name)
        for obj,names in [(self.e,['reset']),(self.e.scene,['reset','set_state','add_entity']),
                          (self.e.scene.rigid_solver,['set_state','add_weld_constraint','delete_weld_constraint'])]:
            for name in names:self.guard(obj,name)
        def force(torque,*a,**kw):
            self.last_torque=np.asarray(plain(torque));return self.force0(torque,*a,**kw)
        self.e.robot.control_dofs_force=force
        def scene_step(*a,**kw):
            result=self.step0(*a,**kw);self.steps+=1
            q=np.asarray(plain(self.e.robot.get_dofs_position(self.e.dofs)))
            v=np.asarray(plain(self.e.robot.get_dofs_velocity(self.e.dofs)))
            self.physq.append(q);self.physqd.append(v);self.tau.append(self.last_torque.copy())
            overrun=np.maximum(self.qlo-q,q-self.qhi);j=int(np.argmax(overrun))
            if overrun[j]>self.max_overrun:self.max_overrun=float(overrun[j]);self.overrun_joint=self.names[j]
            self.max_speed_ratio=max(self.max_speed_ratio,float(np.max(np.abs(v)/self.velocity)))
            contacts=self.e.robot.get_contacts()
            contact_rows=[]
            for la,lb,ga,gb,force in zip(plain(contacts['link_a']),plain(contacts['link_b']),plain(contacts['geom_a']),plain(contacts['geom_b']),plain(contacts['force_a'])):
                la,lb=int(la),int(lb)
                if la in self.robot_links and lb in self.robot_links:continue
                robot,other=(la,lb) if la in self.robot_links else (lb,la)
                if robot not in self.robot_links:continue
                link=self.robot_links[robot];owner=self.owners.get(other,'fixed_environment')
                magnitude=float(np.linalg.norm(force));key=link+'|'+owner
                geom=int(ga if la in self.robot_links else gb);geom_key=str(geom)+'|'+owner
                contact_rows.append([geom,owner,magnitude])
                self.geom_peaks[geom_key]=max(magnitude,self.geom_peaks.get(geom_key,0.))
                if magnitude>self.contact_peaks.get(key,0.):
                    self.contact_peaks[key]=magnitude
                    self.contact_peak_context[key]={'time':self.steps*self.dt,'phase':self.controller.phase,'high_level':self.high_id}
            self.contact_trace.write(json.dumps({'step':self.steps,'contacts':contact_rows},separators=(',',':'),allow_nan=False)+'\n')
            return result
        self.e.scene.step=scene_step
        def update(state,dt):
            result=self.update0(state,dt)
            self.trace.write(json.dumps({'step':self.steps,'time':self.steps*self.dt,'state':plain(state),
                    'stage':result.get('stage'), 'status':result},separators=(',',':'),allow_nan=False)+'\n')
            return result
        self.e.evaluator.update=update
        def control(target):
            margin=self.contract.get('joint_target_interior_margin',0.)
            lo,hi=np.asarray(plain(self.e.lo)),np.asarray(plain(self.e.hi))
            target=np.asarray(target).copy()
            if self.contract.get('joint_limit_damping'):
                q=np.asarray(plain(self.e.robot.get_dofs_position(self.e.dofs)))
                v=np.asarray(plain(self.e.robot.get_dofs_velocity(self.e.dofs)))
                hand_mask=np.array(['_hand_' in n for n in self.names])
                near_high=hand_mask&(q>hi-.12)&(v>0);near_low=hand_mask&(q<lo+.12)&(v<0)
                # Proprioceptive braking through the same joint-target API.
                # Gains/effort/friction and physics are unchanged.
                target[near_high]=np.minimum(target[near_high],(q-.10*v)[near_high])
                target[near_low]=np.maximum(target[near_low],(q-.10*v)[near_low])
            if margin:target=np.clip(target,lo+margin,hi-margin)
            if self.contract['family']=='ASM' and self.high_id in ('support','sleeve','cap'):
                self.high_id=['support','sleeve','cap'][min(2,self.e.status.get('stage',0))]
            self.actions.write(json.dumps({'action_id':len(self.controls),'physics_start':self.steps,'high_level':self.high_id,'phase':self.controller.phase,'target_q':plain(target)},allow_nan=False)+'\n');self.actions.flush()
            self.control_start.append(self.steps)
            result=self.control0(target)
            self.control_end.append(self.steps)
            self.controls.append(np.asarray(plain(target)));self.q.append(np.asarray(plain(self.e.robot.get_dofs_position(self.e.dofs))))
            self.qd.append(np.asarray(plain(self.e.robot.get_dofs_velocity(self.e.dofs))))
            self.times.append(self.steps*self.dt);self.phases.append(self.controller.phase if self.controller else 'init');self.high.append(self.high_id)
            now=self.steps*self.dt
            if now+1e-8>=self.next_frame:
                from PIL import Image
                frame=np.asarray(Image.fromarray(self.e.render()).resize((640,450)))
                self.video.append_data(frame);self.frame_count+=1;self.next_frame=now+.2
            if len(self.controls)%10==0:
                self.trace.flush()
                faulthandler.dump_traceback_later(180,repeat=True)
                write(self.out/'heartbeat.json',{'time':now,'stage':self.e.status.get('stage'),'phase':self.phases[-1],
                    'completed':self.e.status.get('completed',[]),'credited_angles_rad':self.e.status.get('credited_angles_rad'),
                    'wall_seconds':time.time()-self.started,'physics_steps':self.steps,'commands':len(self.controls),
                    'max_joint_overrun':self.max_overrun,'max_position_joint':self.overrun_joint,'max_velocity_ratio':self.max_speed_ratio,
                    'forbidden_contact_peak':max((v for k,v in self.geom_peaks.items() if forbidden(self.robot_geoms[k.split('|')[0]],k.split('|')[1])),default=0.),'contact_audit_version':CONTACT_VERSION})
            if self.contract.get('stop_on_physics_violation'):
                bad_contacts=violations(self.geom_peaks,self.robot_geoms)
                if self.max_overrun>.001 or self.max_speed_ratio>1.001 or bad_contacts:
                    raise RuntimeError(f'Physical audit early stop: joint={self.overrun_joint}, overrun={self.max_overrun:.6f}, speed={self.max_speed_ratio:.4f}, contacts={bad_contacts}')
            return result
        self.e.step_targets=control

    def instrument(self,c):
        self.controller=c
        def event(phase,**metadata):
            c.phase=phase;c.events.append(dict(phase=phase,time=self.steps*self.dt,**metadata))
            self.live_events.write(json.dumps(plain(c.events[-1]),allow_nan=False)+'\n');self.live_events.flush()
        c.event=event
        for name in ['move_hands','move_joints','hold']:
            original=getattr(c,name)
            def call(*args,_name=name,_fn=original,**kwargs):
                # Parameterized motion is frozen before its first control action.
                index=len(self.mapping);start=len(self.controls)
                row={'segment_id':index,'high_level':self.high_id,'primitive':_name,'phase':c.phase,
                     'args':plain(args),'kwargs':plain(kwargs),'start_step':start,'entry_state':self.state()}
                self.low.write(json.dumps(row,allow_nan=False)+'\n');self.low.flush()
                self.mapping.append(dict(row,end_step=None))
                try:return _fn(*args,**kwargs)
                finally:
                    self.mapping[index].update(end_step=len(self.controls),exit_state=self.state())
            setattr(c,name,call)
        original=c.move_joints
        def slow(target,seconds=1.):
            speed_scale=np.array([self.contract.get('hand_speed_scale',.45) if '_hand_' in name else .45 for name in self.names])
            needed=1.875*float(np.max(np.abs(np.asarray(target)-c.q)/(speed_scale*self.velocity)))
            return original(target,seconds=max(seconds,needed))
        c.move_joints=slow

    def finish(self,error):
        self.trace.close();self.low.close();self.actions.close();self.live_events.close();self.contact_trace.close()
        try:self.video.close()
        except Exception:
            video_error=traceback.format_exc();write(self.out/'video_error.json',{'error':video_error})
            error=(error or '')+'\nVideo finalization failed: '+video_error
        self.e.scene.step=self.step0;self.e.robot.control_dofs_force=self.force0
        self.e.step_targets=self.control0;self.e.evaluator.update=self.update0
        for obj,name,value,owned in reversed(self.guards):
            if owned:setattr(obj,name,value)
            else:delattr(obj,name)
        np.savez_compressed(self.out/'trajectory.npz',target_q=self.controls,q=self.q,qd=self.qd,time=self.times,
                phase=np.array(self.phases),high_level=np.array(self.high),physics_q=self.physq,physics_qd=self.physqd,
                physics_torque=self.tau,control_physics_start=self.control_start,control_physics_end=self.control_end)
        write(self.out/'mapping.json',self.mapping)
        write(self.out/'events.json',self.controller.events if self.controller else [])
        bad_contacts=violations(self.geom_peaks,self.robot_geoms)
        write(self.out/'contact_summary.json',{'audited':True,'version':CONTACT_VERSION,'per_physics_step':True,'peak_force_n':self.contact_peaks,'geometry_peak_force_n':self.geom_peaks,'peak_context':self.contact_peak_context,'forbidden':bad_contacts})
        write(self.out/'execution.json',{'final_status':self.e.status,'physics_steps':self.steps,'control_steps':len(self.controls),
             'error':error,'api_violations':self.violations,'video_frames':self.frame_count,'video_fps':5,
             'real_time_claim':False,'wall_seconds':time.time()-self.started,'job_id':os.environ.get('SLURM_JOB_ID')})
        from PIL import Image
        Image.fromarray(self.e.render()).save(self.out/'final.png')

def run(task,output,policy=None,backend='gpu',joint_margin=0.,joint_limit_damping=False,hand_speed_scale=.45,stop_on_physics_violation=False):
    if not np.isfinite(hand_speed_scale) or not .02<=hand_speed_scale<=.45:raise ValueError('hand_speed_scale must be in [.02,.45]')
    if not np.isfinite(joint_margin) or not 0<=joint_margin<=.10:raise ValueError('joint margin must be in [0, .10] rad')
    faulthandler.dump_traceback_later(180,repeat=True)
    output=Path(output).resolve();output.mkdir(parents=True,exist_ok=False)
    contract=plan(task);contract['contact_audit_version']=CONTACT_VERSION;contract['backend']=backend;contract['stop_on_physics_violation']=stop_on_physics_violation;contract['policy_entry']=policy or task.lower().replace('-','_');contract['hand_speed_scale']=hand_speed_scale;contract['joint_target_interior_margin']=joint_margin;contract['joint_limit_damping']=joint_limit_damping;contract['damping_scope']='hand joints only';write(output/'plan.json',contract)
    if policy=='asm_edge':
        contract['high_level'][0]['low_level']=['inspect_table_edge_clearance','push_shim_with_fingers','edge_grasp_and_lift_check','table_supported_handoff','left_edge_grasp','stack_on_stand','release_check']
        write(output/'plan.json',contract)
    if policy in ('asm_slide','asm_pinch_slide'):
        contract['high_level'][0]['low_level']=['push_shim_to_front','slide_with_table_support','park_right_hand','left_edge_grasp','stack_on_stand','release_check']
        if policy=='asm_pinch_slide':contract['high_level'][0]['low_level']=['push_shim_to_front','right_pinch_slide_with_quarter_turn','park_right_hand','left_reversed_pinch','carry_around_front_of_fixture','restore_orientation_and_release','left_edge_grasp','stack_on_stand','release_check']
        write(output/'plan.json',contract)
    if policy in ('ref_board_probe','ref_board_place_probe','ref_right_probe'):
        component='bottom_shelf' if policy.startswith('ref_board') else 'right_frame'
        steps=(['side_grasp','clear_rack_beam','extract_horizontally','lift_check','return_to_rack','release']
               if policy=='ref_board_probe' else ['near_upright_grasp','lift_check','reorient','hold_check'])
        if policy=='ref_board_place_probe':steps=['side_grasp','clear_rack_beam','extract_horizontally','lift_check','rotate','table_edge_set_down','release_check']
        contract['run_kind']='component_probe'
        contract['evidence_scope']='Fresh original scene, one component diagnostic; not a complete shelf solution'
        contract['high_level']=[{'id':component,'goal':'Test physical manipulation of '+component,'low_level':steps}]
        write(output/'plan.json',contract)
    if policy in ('ref_fixture_probe','ref_fixture_slide_probe'):
        contract['run_kind']='component_probe';contract['evidence_scope']='Fixture handling diagnostic in the original REF-02 scene; not a complete assembly'
        contract['high_level']=[{'id':'deploy_fixture','goal':'Verify fixture grasp and released relocation','low_level':['fitted_grasp','lift_check','relocate','set_down','release_check']}]
        if policy=='ref_fixture_slide_probe':contract['high_level'][0]['low_level']=['fitted_grasp','slide_with_table_support','support_check','release_check']
        write(output/'plan.json',contract)
    if policy=='ref_frame_pivot_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='Table-supported frame pivot and handoff diagnostic; not a complete shelf solution'
        contract['high_level']=[{'id':'right_frame','goal':'Expose the upper rail and transfer a physical grasp','low_level':['push_to_front_overhang','near_post_grasp','partial_pivot','upper_rail_handoff','lift','reorient_check']}]
        write(output/'plan.json',contract)
    if policy=='ref_crossbar_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='Exposed carrier grasp and orientation diagnostic; not a complete shelf solution'
        contract['high_level']=[{'id':'lower_crossbar','goal':'Acquire and rotate an exposed interchangeable carrier','low_level':['select_highest_supply','inner_rail_grasp','lift_check','reorient_check']}]
        write(output/'plan.json',contract)
    if policy=='ref_fixture_use_probe':
        contract['run_kind']='component_probe';contract['evidence_scope']='One measured released frame/fixture load path; second use and full assembly remain unverified'
        contract['high_level']=[{'id':'deploy_fixture','goal':'Relocate the support on the table','low_level':['fitted_grasp','table_slide','release_check']},{'id':'left_frame','goal':'Establish an original measured fixture-use predicate','low_level':['rail_grasp','lift','align_with_fixture','lower','release','verify_support_dwell']}]
        write(output/'plan.json',contract)
    if policy=='ref_frames_integrated':
        contract['run_kind']='component_probe';contract['evidence_scope']='Two-frame continuous assembly diagnostic; six shelf parts remain unassembled'
        contract['high_level']=[{'id':'right_frame','goal':'Assemble and release right frame before left-frame scoring','low_level':['push_to_overhang','partial_pivot','upper_rail_handoff','park_idle_arm','reorient','align_feet','insert','release']},
                                {'id':'left_frame','goal':'Assemble left frame and verify both original slot predicates','low_level':['grasp','lift','reorient','align_feet','insert','release']}]
        write(output/'plan.json',contract)
    write(output/'started.json',{'wall_time':time.time(),'job_id':os.environ.get('SLURM_JOB_ID'),'task_id':task})
    env=mon=None;error=None;snapshots={}
    try:
        # Freeze candidate imports and their source bytes before slow scene build.
        from . import policies
        snapshot_loaded(output,snapshots)
        from .portable import make_env
        env=make_env(task,output,backend=backend)
        if hasattr(env,'sensor_cam'):env.sensor_cam=None  # privileged expert; spectator video remains enabled
        if task.startswith('ASM'):
            from humanoid.g1_tabletop_assembly.solution.controller import Controller
        else:
            from humanoid.g1_gear_assembly.solution.controller import Controller
        from . import policies
        fn=getattr(policies,policy or task.lower().replace('-','_'))
        c=Controller(env)
        snapshot_loaded(output,snapshots)
        mon=Monitor(env,output,contract);mon.instrument(c);mon.start()
        fn(c,mon)
    except (Exception,KeyboardInterrupt):
        error=traceback.format_exc();print(error,flush=True);write(output/'error.json',{'error':error})
    finally:
        if mon:
            try:mon.finish(error)
            except Exception:write(output/'recording_error.json',{'error':traceback.format_exc()})
        if env:env.close()
        faulthandler.cancel_dump_traceback_later()
    if mon:
        import subprocess
        checked=subprocess.run([sys.executable,'-m','assembly_family.verify',str(output)],check=False)
        if checked.returncode:
            write(output/'outcome.json',{'task_id':task,'body':contract['body'],'state':'audit_failed','goal_met':False,'error':'Independent audit failed; inspect error.json, recording_error.json and the Slurm log','verifier_exit_code':checked.returncode})
    else:write(output/'outcome.json',{'state':'setup_failed','goal_met':False,'error':error})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--task',required=True);p.add_argument('--output',required=True)
    p.add_argument('--policy');p.add_argument('--stop-on-physics-violation',action='store_true');p.add_argument('--hand-speed-scale',type=float,default=.45);p.add_argument('--joint-limit-damping',action='store_true');p.add_argument('--joint-margin',type=float,default=0.);p.add_argument('--backend',default='gpu',choices=['cpu','gpu']);a=p.parse_args()
    run(a.task,a.output,a.policy,a.backend,a.joint_margin,a.joint_limit_damping,a.hand_speed_scale,a.stop_on_physics_violation)
