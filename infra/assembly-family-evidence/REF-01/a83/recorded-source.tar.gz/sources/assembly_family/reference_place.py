"""Measured frame alignment and release into the unchanged original fixture."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,shift_hands

def frame(c,grip,slot):
    name,side=grip.name,grip.side
    goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    c.event(name+'_transfer_to_frame_slot',slot=slot)
    for height in (.08,.032):
        for _ in range(8):
            p,R,_,state=pose(c,name)
            if state['robot_contact_force']<.05:raise RuntimeError(name+': grasp lost before frame placement')
            error=goal+[0,0,height]-p
            rv=Rotation.from_matrix(R.T).as_rotvec()
            if np.linalg.norm(error)<.0005 and np.linalg.norm(rv)<.006:break
            correction=Rotation.from_rotvec(rv*min(1.,.10/max(np.linalg.norm(rv),1e-9))).as_matrix()
            shift_hands(c,[side],np.clip(error,-.04,.04),seconds=1.2,pivot=p,rot=correction)
    c.event(name+'_align_feet')
    for _ in range(8):
        p,R,_,_=pose(c,name);foot=p+R@[0,0,-.125]
        delta=np.r_[goal[:2]-foot[:2],0.]
        if np.linalg.norm(delta)<.00025:break
        shift_hands(c,[side],np.clip(delta,-.004,.004),seconds=.6)
    c.event(name+'_insert_feet')
    for _ in range(70):
        p,R,_,_=pose(c,name)
        if p[2]<goal[2]+.003:break
        foot=p+R@[0,0,-.125];xy=goal[:2]-foot[:2]
        yaw=Rotation.from_matrix(R).as_euler('xyz')[2]
        feet_error=max(np.linalg.norm(xy+np.array([x,0])-(R@[x,0,0])[:2]) for x in (-.0841,.0841))
        dz=-.0015 if feet_error<.00040 and abs(yaw)<.002 else 0.
        shift_hands(c,[side],np.r_[np.clip(.6*xy,-.0008,.0008),dz],seconds=.6,pivot=p,yaw=np.clip(-.6*yaw,-.008,.008))
    grip.release(seconds=1.,rise=.10);c.hold(.8)


def fast_frame(c,grip,slot):
    """Continuous measured foot servo through the unchanged narrow slots."""
    from .pose_carry import move
    name,side=grip.name,grip.side
    goal=np.asarray(c.env.cfg.origin)+c.env.catalog['parts'][slot]['goal_local']
    move(c,grip,goal+[0,0,.045],np.eye(3),5.,name+'_continuous_slot_hover')
    c.event(name+'_continuous_foot_alignment')
    weak=0
    for _ in range(1000):
        p,R,_,state=pose(c,name)
        weak=weak+1 if state['robot_contact_force']<.05 else 0
        if weak>10:raise RuntimeError(name+': grasp lost during continuous foot placement')
        foot=p+R@[0,0,-.125]
        xy=goal[:2]-foot[:2]
        yaw=float(np.arctan2(R[1,0],R[0,0]))
        feet_error=max(np.linalg.norm(xy+np.array([x,0.])-(R@[x,0.,0.])[:2])for x in(-.0841,.0841))
        rv=Rotation.from_matrix(R.T).as_rotvec()
        if p[2]<goal[2]+.003 and feet_error<.0005 and np.linalg.norm(rv)<.012:break
        dz=max(-.00025,min(0.,goal[2]+.001-p[2])) if feet_error<.0004 and abs(yaw)<.002 and np.linalg.norm(rv)<.012 else 0.
        delta=np.r_[np.clip(.15*xy,-.0008,.0008),dz]
        step=rv*min(.05,.002/max(np.linalg.norm(rv),1e-9));dR=Rotation.from_rotvec(step).as_matrix()
        hp,hR=c.hand_pose(side)
        c.reach({side:('palm',p+delta+dR@(hp-p),dR@hR)},feedback=.4,rotation_feedback=.3,iters=20);c.step()
    p,R,_,_=pose(c,name)
    if p[2]>goal[2]+.006:raise RuntimeError(name+': continuous foot placement did not reach slot height')
    grip.release(seconds=1.,rise=.10);c.hold(.8)
