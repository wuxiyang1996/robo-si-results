"""Translate a released two-piece stand by pushing its lower body on the table."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import smooth
from .reach_screen import goto


def check(c):
    brace=c.object_state('brace');shim=c.object_state('shim')
    R=Rotation.from_quat(np.asarray(shim['quat'])[[1,2,3,0]]).as_matrix()
    if brace['robot_contact'] or shim['robot_contact'] or brace['support_forces'].get('table',0)<.05 or shim['support_forces'].get('brace',0)<.05 or R[2,2]<.95:
        raise RuntimeError('composed stand: released measured support path was lost')


def move(c):
    check(c)
    c.hand_preset('left','open',seconds=1.)
    q=c.q.copy();q[c.index['left_hand_thumb_1_joint']]=.8
    c.event('compose_push_prepare_thumb');c.move_joints(q,seconds=1.)
    target=np.array([c.env.cfg.brace_goal_xy[0]-.013,
                     c.env.cfg.fixture_size[1]/2+c.env.cfg.brace_size[1]/2+.042])
    for axis,angle,label in [(1,np.pi/6,'north'),(0,np.pi/2,'west')]:
        before=np.asarray(c.object_state('brace')['pos'])
        rotation=Rotation.from_euler('z',angle).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
        point=np.array([before[0],before[1]+c.env.cfg.brace_size[1]/2+.02,c.env.cfg.table_height+.015]) if axis==1 else np.array([before[0]-c.env.cfg.brace_size[0]/2-.02,before[1]+.02,c.env.cfg.table_height+.015])
        c.event('compose_push_'+label+'_approach')
        goto(c,{'left':('thumb',point+[0,0,.15],rotation)},seconds=3.,iters=600)
        c.move_hands({'left':('thumb',point,rotation)},seconds=2.5,feedback=.4)
        origin,_=c.hand_pose('left','thumb');correction=0.
        delta=target[axis]-before[axis]
        c.event('compose_push_'+label,axis=axis,target=float(target[axis]))
        for i in range(250):
            actual=np.asarray(c.object_state('brace')['pos'])
            desired=before[axis]+smooth((i+1)/250)*delta
            correction=float(np.clip(correction+np.clip(.05*(desired-actual[axis]),-.0005,.0005),-.045,.045))
            command=origin.copy();command[axis]+=desired-before[axis]+correction
            c.reach({'left':('thumb',command,rotation)},rate=.8,feedback=.4,iters=16);c.step()
        thumb,_=c.hand_pose('left','thumb')
        c.event('compose_push_'+label+'_withdraw')
        c.move_hands({'left':('thumb',thumb+[0,0,.15],rotation)},seconds=2.)
        c.hold(.6);check(c)
        after=np.asarray(c.object_state('brace')['pos'])
        if abs(after[axis]-target[axis])>.02:
            raise RuntimeError('composed stand: table push did not reach '+label+' target')
        c.event('compose_push_'+label+'_verified',position=after.tolist())
    c.event('composed_stand_staging_verified',position=c.object_state('brace')['pos'])
