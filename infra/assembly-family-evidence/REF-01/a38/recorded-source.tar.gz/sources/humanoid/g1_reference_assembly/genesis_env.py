"""Image-and-instruction conditioned G1 assembly, with real rigid-body contacts.

Only joint targets are actions. The public observation has RGB, proprioception,
and the frozen instruction bundle; trusted_state()/diagnostics() are evaluator
APIs and must not be passed to a policy. This in-process development adapter is
not a security sandbox. The old tabletop environment is not changed.
"""
from __future__ import annotations

from pathlib import Path
import math

import genesis as gs
import numpy as np
import torch

from humanoid.g1_box_stair_transport.robot import JOINT_NAMES, JOINT_LIMITS
from humanoid.g1_tabletop.genesis_env import (
    SIM_DT, CONTROL_DT, ACTION_SCALE, anchored_robot_xml, actuator_parameters,
)
from .assets import build_assets
from .instruction import ReferenceInstruction
from .provenance import validate_reference_bundle
from .task_spec import TaskConfig, Evaluator

HERE = Path(__file__).resolve().parent


def quaternion_matrix(q):
    w, x, y, z = np.asarray(q, dtype=float) / np.linalg.norm(q)
    return np.array([
        [1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
        [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
        [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)],
    ])


def supply_layout(catalog, seed, table_height):
    """Collision-free racks and flat side frames; seeds swap identical parts.

    Racks are setup furniture, not action mechanisms. Their open fronts provide
    finger clearance. Randomization changes which interchangeable instance is
    on each level, and the two flat frames' small planar offsets.
    """
    rng = np.random.default_rng(seed)
    poses, rack_boxes = {}, []
    for name, y in (("left_frame", .43), ("right_frame", -.43)):
        size = catalog["parts"][name]["size"]
        poses[name] = dict(
            pos=(.28 + rng.uniform(-.004, .004), y + rng.uniform(-.006, .006),
                 table_height + size[1]/2 + .003),
            quat=(math.sqrt(.5), math.sqrt(.5), 0., 0.))
    for family, y in (("crossbar", .43), ("shelf", -.43)):
        names = [name for name in catalog["parts"] if name.endswith(family)]
        for level, name in enumerate(rng.permutation(names)):
            z = table_height + .035 + level*.060
            size = catalog["parts"][name]["size"]
            poses[str(name)] = dict(pos=(.58, y, z+size[2]/2+.001),
                                    quat=(math.sqrt(.5), 0., 0., math.sqrt(.5)))
            # Two narrow rails under the module ends, leaving its centre open.
            for x in (.435, .725):
                rack_boxes.append(dict(size=(.012, .21, .008), pos=(x, y, z-.004)))
        for x in (.435, .725):
            for dy in (-.10, .10):
                rack_boxes.append(dict(size=(.012, .012, .17),
                    pos=(x, y+dy, table_height+.085)))
    return poses, rack_boxes


class G1ReferenceAssembly:
    def __init__(self, cfg=None, *, backend="cpu", camera=True, show_viewer=False,
                 instruction_dir=None):
        self.cfg = cfg or TaskConfig()
        if backend not in ("cpu", "gpu"):
            raise ValueError("backend must be cpu or gpu")
        if not math.isclose(self.cfg.control_dt, CONTROL_DT):
            raise ValueError("control_dt must be 0.02")
        self.catalog = build_assets()
        self.evaluator = Evaluator(self.cfg, self.catalog)
        bundle_path = instruction_dir or HERE / "references" / self.cfg.recipe
        self.instruction = ReferenceInstruction.load(bundle_path)
        self.instruction_digest = validate_reference_bundle(bundle_path, self.cfg.recipe, self.catalog)
        # A caller cannot silently pair another recipe with this evaluator.
        expected = tuple(self.evaluator.order)
        if tuple(step.id for step in self.instruction.steps) != expected:
            raise ValueError("instruction step order does not match configured recipe")
        if not gs._initialized:
            gs.init(backend=gs.cpu if backend == "cpu" else gs.gpu,
                    seed=int(self.cfg.seed), logging_level="warning")
        self.device, self.num_actions = gs.device, len(JOINT_NAMES)
        self.base_position = (0., 0., .79)
        eye, lookat = (1.50, -1.65, 1.65), (.43, 0., .83)
        self.scene = gs.Scene(
            sim_options=gs.options.SimOptions(dt=SIM_DT, substeps=1),
            rigid_options=gs.options.RigidOptions(enable_self_collision=True,
                enable_neutral_collision=True, box_box_detection=True, max_collision_pairs=2048),
            viewer_options=gs.options.ViewerOptions(camera_pos=eye, camera_lookat=lookat),
            vis_options=gs.options.VisOptions(background_color=(.88, .91, .94),
                ambient_light=(.4, .4, .4), shadow=True, plane_reflection=False),
            show_viewer=show_viewer)
        add = self.scene.add_entity
        self.ground = add(gs.morphs.Plane(), material=gs.materials.Rigid(friction=.8),
                         surface=gs.surfaces.Default(color=(.20, .23, .27)))
        c = self.cfg
        self.table = add(gs.morphs.Box(size=c.table_size,
            pos=(*c.table_center, c.table_height-c.table_size[2]/2), fixed=True),
            material=gs.materials.Rigid(friction=.8),
            surface=gs.surfaces.Default(color=(.66, .59, .48)))
        for x in (-1, 1):
            for y in (-1, 1):
                add(gs.morphs.Box(size=(.04, .04, c.table_height-c.table_size[2]),
                    pos=(c.table_center[0]+x*(c.table_size[0]/2-.04),
                         c.table_center[1]+y*(c.table_size[1]/2-.04),
                         (c.table_height-c.table_size[2])/2), fixed=True),
                    surface=gs.surfaces.Default(color=(.21, .24, .28)))
        add(gs.morphs.Box(size=(.08, .10, .72), pos=(-.14, 0., .36), fixed=True),
            surface=gs.surfaces.Default(color=(.30, .32, .35)))
        self.robot = add(gs.morphs.MJCF(file=str(anchored_robot_xml()), pos=self.base_position))
        self.fixtures = []
        for spec in self.catalog.get("fixture", []):
            self.fixtures.append(add(gs.morphs.Box(size=spec["size"],
                pos=tuple(np.asarray(c.origin)+np.asarray(spec["pos_local"])), fixed=True),
                material=gs.materials.Rigid(friction=.8),
                surface=gs.surfaces.Default(color=tuple(spec.get("color", (.26, .30, .34))))))
        poses, rack_boxes = supply_layout(self.catalog, c.seed, c.table_height)
        self.racks = [add(gs.morphs.Box(**spec, fixed=True),
            material=gs.materials.Rigid(friction=.8),
            surface=gs.surfaces.Default(color=(.34, .38, .41))) for spec in rack_boxes]
        self.objects = {}
        for name, spec in self.catalog["parts"].items():
            self.objects[name] = add(gs.morphs.URDF(file=str(spec["urdf"]),
                **poses[name], fixed=False, convexify=False, decimate=False,
                watertighten=None, merge_fixed_links=True), material=gs.materials.Rigid(friction=.7))
        self.cam = self.scene.add_camera(res=(1280, 900), pos=eye, lookat=lookat,
                                        fov=43, GUI=False) if camera else None
        self.sensor_cam = self.scene.add_camera(res=(640, 480),
            pos=(.10, 0., 1.28), lookat=(.56, 0., .78), fov=90, GUI=False) if camera else None
        self.scene.build()
        self.dofs = [self.robot.get_joint(n).dofs_idx_local[0] for n in JOINT_NAMES]
        self.robot_ids = {link.idx for link in self.robot.links}
        self.link_owners = {link.idx: name for name, ent in self.objects.items()
                            for link in ent.links}
        for owner, entities in (("table", [self.table]), ("ground", [self.ground]),
                                ("fixture", self.fixtures), ("supply_rack", self.racks)):
            self.link_owners.update({link.idx: owner for ent in entities for link in ent.links})
        tensor = lambda values: torch.tensor(values, dtype=torch.float32, device=self.device)
        self.kp, self.kd, self.effort = map(tensor, actuator_parameters())
        self.lo, self.hi = tensor(JOINT_LIMITS).unbind(-1)
        self.default_q = torch.zeros(self.num_actions, device=self.device)
        posture = dict(left_hip_pitch_joint=-.1, right_hip_pitch_joint=-.1,
            left_knee_joint=.3, right_knee_joint=.3,
            left_ankle_pitch_joint=-.2, right_ankle_pitch_joint=-.2,
            left_shoulder_pitch_joint=.25, right_shoulder_pitch_joint=.25,
            left_shoulder_roll_joint=.2, right_shoulder_roll_joint=-.2,
            left_elbow_joint=.8, right_elbow_joint=.8)
        for name, value in posture.items():
            self.default_q[JOINT_NAMES.index(name)] = value
        self.robot.set_dofs_kp(torch.zeros(self.num_actions), self.dofs)
        self.robot.set_dofs_kv(torch.zeros(self.num_actions), self.dofs)
        self.robot.set_dofs_force_range(-self.effort.cpu(), self.effort.cpu(), self.dofs)
        self.robot.set_dofs_armature(torch.full((self.num_actions,), .02), self.dofs)
        self.reset()

    @staticmethod
    def _array(value):
        return value.detach().cpu().numpy()

    def reset(self):
        self.scene.reset()
        self.robot.set_dofs_position(self.default_q, self.dofs, zero_velocity=True)
        base = self._array(self.robot.get_link("pelvis").get_pos())
        if not np.allclose(base, self.base_position, atol=1e-5):
            raise RuntimeError(f"unexpected anchored pelvis: {base}")
        self.physics_steps = 0
        self.target = self.default_q.clone()
        self.max_applied_torque = torch.zeros_like(self.target)
        self.evaluator.reset()
        self.status = self.evaluator.status()
        return self.observe()

    def trusted_state(self):
        """Private actual measurements; not included in observations or info."""
        objects = {}
        for name, entity in self.objects.items():
            link, own = entity.links[0], {item.idx for item in entity.links}
            contacts = entity.get_contacts()
            a, b, fa, fb = (self._array(contacts[k]) for k in
                            ("link_a", "link_b", "force_a", "force_b"))
            normals = self._array(contacts["normal"])
            support, robot_force = {}, 0.
            for index in range(len(a)):
                if int(a[index]) in own:
                    other, force = int(b[index]), fa[index]
                elif int(b[index]) in own:
                    other, force = int(a[index]), fb[index]
                else:
                    continue
                if other in self.robot_ids:
                    robot_force += float(np.linalg.norm(force))
                elif other not in own:
                    owner = self.link_owners.get(other, "other")
                    normal = normals[index]
                    normal_force = np.dot(force, normal)*normal / max(float(np.dot(normal, normal)), 1e-12)
                    support[owner] = support.get(owner, 0.)+float(normal_force[2])
            objects[name] = dict(position=self._array(link.get_pos()).tolist(),
                quat=self._array(link.get_quat()).tolist(),
                linear_velocity=self._array(link.get_vel()).tolist(),
                angular_velocity=self._array(link.get_ang()).tolist(),
                robot_contact_force=robot_force,
                support_forces={k: max(0., v) for k, v in support.items()})
        return {"objects": objects, "time": self.physics_steps*SIM_DT}

    def sensor_rgb(self):
        if self.sensor_cam is None:
            return None
        torso = self.robot.get_link("torso_link")
        pos, q = self._array(torso.get_pos()), self._array(torso.get_quat())
        rotation = quaternion_matrix(q)
        self.sensor_cam.set_pose(pos=pos+rotation@np.array((.1, 0., .43)),
            lookat=pos+rotation@np.array((.56, 0., -.05)), up=rotation[:, 2])
        return self.sensor_cam.render()[0]

    def observe(self):
        return dict(rgb=self.sensor_rgb(),
            joint_names=list(JOINT_NAMES),
            joint_position=self._array(self.robot.get_dofs_position(self.dofs)),
            joint_velocity=self._array(self.robot.get_dofs_velocity(self.dofs)),
            time=self.physics_steps*SIM_DT,
            instruction=self.instruction.public_observation(),
            observation_mode="rgb_proprio_reference" if self.cam else "physics_diagnostic")

    def advance_targets(self, target):
        """Trusted low-level stepping, avoids rendering when running diagnostics."""
        target = torch.as_tensor(target, dtype=torch.float32, device=self.device)
        if target.shape != (self.num_actions,) or not torch.isfinite(target).all():
            raise ValueError(f"target must have {self.num_actions} finite angles")
        if ((target < self.lo) | (target > self.hi)).any():
            raise ValueError("joint target outside G1 limits")
        if self.status["terminated"]:
            raise RuntimeError("episode terminated; call reset()")
        self.target = target.clone()
        for _ in range(round(CONTROL_DT/SIM_DT)):
            q, qd = self.robot.get_dofs_position(self.dofs), self.robot.get_dofs_velocity(self.dofs)
            torque = torch.clamp(self.kp*(target-q)-self.kd*qd, -self.effort, self.effort)
            self.max_applied_torque = torch.maximum(self.max_applied_torque, torque.abs())
            self.robot.control_dofs_force(torque, self.dofs)
            self.scene.step()
            self.physics_steps += 1
            self.status = self.evaluator.update(self.trusted_state(), SIM_DT)
            if self.status["terminated"]:
                break

    def step_targets(self, target):
        self.advance_targets(target)
        reward = float(self.status["success"])-float(self.status["failed"])
        # No stage, scoring measurements, target pose, or object ID is disclosed.
        return self.observe(), reward, self.status["terminated"], {
            "success": self.status["success"], "failed": self.status["failed"]}

    def step(self, action):
        action = torch.as_tensor(action, dtype=torch.float32, device=self.device)
        if action.shape != (self.num_actions,) or not torch.isfinite(action).all():
            raise ValueError(f"action must have {self.num_actions} finite values")
        return self.step_targets(torch.clamp(self.default_q+ACTION_SCALE*action,
                                            self.lo, self.hi))

    def diagnostics(self):
        return dict(status=dict(self.status), state=self.trusted_state(),
            max_applied_torque=self._array(self.max_applied_torque).tolist(),
            effort_caps=self._array(self.effort).tolist(),
            physics_steps=self.physics_steps)

    def render(self):
        if self.cam is None:
            raise RuntimeError("construct with camera=True")
        return self.cam.render()[0]

    def close(self):
        self.scene.destroy()
