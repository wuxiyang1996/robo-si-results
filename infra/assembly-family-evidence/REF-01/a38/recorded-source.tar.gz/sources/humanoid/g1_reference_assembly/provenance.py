"""Portable geometry/image fingerprints used to keep instructions and scene paired."""
import hashlib
import json
from pathlib import Path


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def catalog_fingerprint(catalog):
    public_geometry = {
        "parts": {name: {key: part[key] for key in
            ("mass", "size", "goal_local", "goal_quat_wxyz", "collision_boxes", "mesh_sha256", "urdf_sha256")}
            for name, part in catalog["parts"].items()},
        "fixture": catalog["fixture"],
        "texture_sha256": sha256(Path(catalog["asset_root"])/"steel_frame_shelves_01.png"),
        "material_sha256": sha256(Path(catalog["asset_root"])/"material.mtl"),
    }
    data = json.dumps(public_geometry, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def validate_reference_bundle(bundle, recipe, catalog):
    """Reject a stale render or a recipe paired with other images/text.

    The manifest is trusted development metadata, not a signed security proof.
    It is never passed to the policy.
    """
    bundle = Path(bundle)
    if not bundle.is_dir() and bundle.name != "bundle.json":
        raise ValueError("A rendered instruction manifest must be named bundle.json")
    directory = bundle if bundle.is_dir() else bundle.parent
    manifest = json.loads((directory.parent / "render_manifest.json").read_text(encoding="utf-8"))
    if manifest.get("catalog_fingerprint") != catalog_fingerprint(catalog):
        raise ValueError("Reference geometry is stale; regenerate with python -m humanoid.g1_reference_assembly.reference")
    expected = manifest["bundles"][recipe]
    instructions = json.loads((directory/"bundle.json").read_text(encoding="utf-8"))
    if len(expected["step_image_sha256"]) != len(instructions["steps"]):
        raise ValueError("Step image count does not match the instruction recipe")
    if sha256(directory/"bundle.json") != expected["bundle_sha256"]:
        raise ValueError("Instruction recipe differs from the rendered bundle")
    if sha256(directory/"goal.png") != expected["goal_image_sha256"]:
        raise ValueError("Goal image differs from the rendered reference")
    for i, digest in enumerate(expected["step_image_sha256"], 1):
        if sha256(directory/f"steps/{i:02d}.png") != digest:
            raise ValueError(f"Step {i} differs from the rendered reference")
    return expected["bundle_sha256"]
