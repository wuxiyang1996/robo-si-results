"""Build the eight-piece shelf from an existing, textured Poly Haven asset.

This module never creates a simulator.  Original triangles and UV coordinates
are retained; the tall source side frames are cut down to a desktop size.
Visible receiver shoes and carrier end ties are explicitly authored additions.
All joints in the assembled shelf are ordinary unilateral contact surfaces.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import numpy as np
import trimesh

PACKAGE = Path(__file__).resolve().parent
SOURCE = PACKAGE.parent / "g1_support_retrieval/assets/cabinets/steel_frame_shelves_01_low"
NAMES = ("left_frame", "right_frame", "lower_crossbar", "middle_crossbar",
         "upper_crossbar", "bottom_shelf", "middle_shelf", "top_shelf")
DISPLAY = ("左侧框", "右侧框", "下层承托框", "中层承托框", "上层承托框",
           "底层板", "中层板", "顶层板")
SCHEMA_VERSION = 1
BUILD_VERSION = 2


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _numbers(v):
    return " ".join(f"{float(x):.9g}" for x in v)


def _bounds(mesh, ids):
    v = mesh.vertices[mesh.faces[ids]].reshape(-1, 3)
    return v.min(0), v.max(0)


def _clip_triangle_z(vertices, uv, cutoff):
    """Clip one textured triangle, interpolating UVs across the cut plane."""
    polygon = [(v.copy(), t.copy()) for v, t in zip(vertices, uv)]
    result = []
    for a, b in zip(polygon, polygon[1:] + polygon[:1]):
        ina, inb = a[0][2] <= cutoff, b[0][2] <= cutoff
        if ina:
            result.append(a)
        if ina != inb:
            t = (cutoff - a[0][2]) / (b[0][2] - a[0][2])
            result.append((a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])))
    return [(np.array([result[0][0], result[i][0], result[i+1][0]]),
             np.array([result[0][1], result[i][1], result[i+1][1]]))
            for i in range(1, len(result)-1)]


def _source_triangles(mesh, ids, transform, cutoff=None):
    rows = []
    for face in mesh.faces[ids]:
        vertices, uv = mesh.vertices[face], mesh.visual.uv[face]
        pieces = [(vertices, uv)] if cutoff is None else _clip_triangle_z(vertices, uv, cutoff)
        for points, tex in pieces:
            points = transform(points)
            if np.linalg.norm(np.cross(points[1]-points[0], points[2]-points[0])) > 1e-13:
                rows.append((points, tex, "steel_frame_shelves_01"))
    return rows


def _box(center, size, role):
    return {"pos": np.asarray(center, float).tolist(), "size": np.asarray(size, float).tolist(), "role": role}


def _box_triangles(box):
    mesh = trimesh.creation.box(extents=box["size"])
    mesh.apply_translation(box["pos"])
    return [(mesh.vertices[f], np.zeros((3, 2)), "authored_connector") for f in mesh.faces]


def _write_obj(path, rows, center):
    lines = ["# UV-preserving extraction; see asset_sources.json", "mtllib material.mtl"]
    for vertices, uv, _ in rows:
        for v in vertices - center:
            lines.append("v " + _numbers(v))
        for t in uv:
            lines.append("vt " + _numbers(t))
    material = None
    for i, (_, _, mat) in enumerate(rows):
        if mat != material:
            lines.append("usemtl " + mat)
            material = mat
        indices = np.arange(3*i+1, 3*i+4)
        lines.append("f " + " ".join(f"{k}/{k}" for k in indices))
    path.write_text("\n".join(lines)+"\n", encoding="utf-8")


def _write_urdf(path, name, mesh_name, boxes, mass, size):
    robot = ET.Element("robot", name=name)
    link = ET.SubElement(robot, "link", name=name)
    inertial = ET.SubElement(link, "inertial")
    # A frame's bounding-box center is shifted inward by its receivers.
    # Place its COM at the component-volume centroid instead of treating the
    # large empty aperture and receiver overhang as uniformly filled material.
    volumes = np.array([np.prod(box["size"]) for box in boxes])
    masses = mass*volumes/volumes.sum()
    centers = np.asarray([box["pos"] for box in boxes])
    com = np.sum(centers*masses[:, None], axis=0)/mass
    inertia = np.zeros((3, 3))
    for box, component_mass, center in zip(boxes, masses, centers):
        x, y, z = box["size"]
        inertia += np.diag([component_mass*(y*y+z*z)/12,
                            component_mass*(x*x+z*z)/12,
                            component_mass*(x*x+y*y)/12])
        offset = center-com
        inertia += component_mass*(np.dot(offset, offset)*np.eye(3)-np.outer(offset, offset))
    ET.SubElement(inertial, "origin", xyz=_numbers(com), rpy="0 0 0")
    ET.SubElement(inertial, "mass", value=str(mass))
    ET.SubElement(inertial, "inertia", ixx=str(inertia[0, 0]), iyy=str(inertia[1, 1]), izz=str(inertia[2, 2]),
                  ixy=str(inertia[0, 1]), ixz=str(inertia[0, 2]), iyz=str(inertia[1, 2]))
    visual = ET.SubElement(link, "visual", name="textured_source_mesh")
    geometry = ET.SubElement(visual, "geometry")
    ET.SubElement(geometry, "mesh", filename=mesh_name, scale="1 1 1")
    for i, box in enumerate(boxes):
        collision = ET.SubElement(link, "collision", name=f"{box['role']}_{i}")
        ET.SubElement(collision, "origin", xyz=_numbers(box["pos"]), rpy="0 0 0")
        geometry = ET.SubElement(collision, "geometry")
        ET.SubElement(geometry, "box", size=_numbers(box["size"]))
    ET.indent(robot)
    ET.ElementTree(robot).write(path, encoding="utf-8", xml_declaration=True)


def _jig(x_centers, y_centers):
    """Open-bottom four-foot jig: the feet themselves still rest on the table."""
    boxes = []
    def add(name, pos, size, role):
        boxes.append({"name": name, "pos_local": list(pos), "size": list(size),
                      "role": role, "rgba": [0.12, 0.21, 0.28, 1]})
    add("jig_center_plate", (0, 0, .002), (.150, .380, .004), "base")
    add("jig_center_bridge", (0, 0, .002), (.220, .020, .004), "base")
    for sign in (-1, 1):
        add(f"jig_x_rim_{sign}", (sign*.108, 0, .002), (.004, .380, .004), "base")
        add(f"jig_y_rim_{sign}", (0, sign*.188, .002), (.212, .004, .004), "base")
    # Two pairs of orthogonal walls; there is no hidden collision box in a slot.
    inner = np.array([.0134, .0103])
    wall, height = .002, .024
    slots = []
    for i, x in enumerate(x_centers):
        for j, y in enumerate(y_centers):
            slots.append({"center_local": [float(x), float(y), 0], "inner_size": inner.tolist(),
                          "depth": height, "bottom": "table"})
            for axis in (0, 1):
                for sign in (-1, 1):
                    pos = [float(x), float(y), height/2]
                    pos[axis] += sign*(inner[axis]+wall)/2
                    size = [inner[0]+2*wall, inner[1]+2*wall, height]
                    size[axis] = wall
                    add(f"jig_slot_{i}_{j}_{axis}_{sign}", pos, size, "slot_wall")
    return boxes, slots


def build_assets(output_dir=None):
    """Create deterministic local assets and return the complete private catalog.

    ``goal_local`` is an xyz position measured from the center of the tabletop
    assembly footprint. Quaternions are separately named ``goal_quat_wxyz``.
    Each OBJ and URDF is centered at its combined visual/collision bounding box.
    This catalog is simulator setup data, not a policy observation.
    """
    out = Path(output_dir) if output_dir is not None else PACKAGE / "assets" / "shelf"
    out.mkdir(parents=True, exist_ok=True)
    mesh = trimesh.load(SOURCE / "visual.obj", force="mesh", process=False)
    welded = mesh.copy()
    welded.merge_vertices(merge_tex=True, merge_norm=True, digits_vertex=5)
    components = list(trimesh.graph.connected_components(welded.face_adjacency,
                                                       nodes=np.arange(len(welded.faces))))
    components.sort(key=lambda ids: -np.prod(np.ptp(welded.vertices[welded.faces[ids]].reshape(-1, 3), axis=0)))
    if len(components) != 52 or len(components[0]) != 1050 or len(components[1]) != 1050:
        raise ValueError("Source mesh topology changed; re-audit the component extraction")
    source_bounds = mesh.bounds
    source_center_x = float((source_bounds[0, 0]+source_bounds[1, 0])/2)
    source_center_y = float((source_bounds[0, 1]+source_bounds[1, 1])/2)
    scale = np.array([.18/.5021175384521488, .34/(2*.5487069487571716), 1/3])
    def transform(v):
        return (v-np.array([source_center_x, source_center_y, 0])) * scale
    shutil.copyfile(SOURCE / "steel_frame_shelves_01.png", out / "steel_frame_shelves_01.png")
    material = (SOURCE / "visual.mtl").read_text(encoding="utf-8")
    material += "\nnewmtl authored_connector\nKa 0.10 0.10 0.10\nKd 0.18 0.20 0.21\nKs 0.10 0.10 0.10\nNs 20\n"
    (out / "material.mtl").write_text(material, encoding="utf-8")

    # Use the same rail geometry in every carrier; different names denote slots,
    # not geometrically unique keys. The same is true of all three shelf boards.
    rail_ids = [components[16], components[17]]
    rail_bboxes = [_bounds(mesh, ids) for ids in rail_ids]
    rail_mid_source = float(np.mean([(.5*(lo+hi))[2] for lo, hi in rail_bboxes]))
    rail_low_source = min(lo[2] for lo, _ in rail_bboxes)
    rail_high_source = max(hi[2] for _, hi in rail_bboxes)
    rail_height = (rail_high_source-rail_low_source)*scale[2]
    source_level_mids = [rail_mid_source, .3702185, .6902185]
    rail_z = np.asarray(source_level_mids)*scale[2]
    rail_x_centers = sorted(float(transform((lo+hi)[None, :]/2)[0, 0]) for lo, hi in rail_bboxes)
    rail_width = float((rail_bboxes[0][1][0]-rail_bboxes[0][0][0])*scale[0])
    frame_y = []
    frame_x = []
    for sign, cid in ((1, 0), (-1, 1)):
        lo, hi = _bounds(mesh, components[cid])
        frame_y.append(float(transform(((lo+hi)/2)[None, :])[0, 1]))
    # These are the original upright centers, not the support receiver centers.
    frame_x = [-.0841, .0841]
    raw = {}
    for sign, cid, name in ((1, 0, "left_frame"), (-1, 1, "right_frame")):
        y = frame_y[0 if sign == 1 else 1]
        ids = list(components[cid])
        for component in components[28:]:
            lo, hi = _bounds(mesh, component)
            if lo[2] < .75 and sign*(lo[1]+hi[1])/2 > 0:
                ids.extend(component)
        rows = _source_triangles(mesh, np.asarray(ids), transform, cutoff=.75)
        # Uprights and the two actual original side rails remain distinct boxes.
        boxes = [_box((x, y, .125), (.0118, .00864, .25), "upright") for x in frame_x]
        boxes += [_box((0, y, z), (.1566, .00864, .00869), "source_side_rail")
                  for z in (.1005/3, .607/3)]
        added = []
        for level, z in enumerate(rail_z):
            bottom = float(z-rail_height/2)
            for end, x in enumerate(rail_x_centers):
                # Upward-open U receivers. Their inner y edge (.154) stays
                # outside the .150 m shelf edge; they cannot support a shelf.
                cy = sign*.161
                added.append(_box((x, cy, bottom-.0015), (.0156, .014, .003), "receiver_floor"))
                for side in (-1, 1):
                    added.append(_box((x+side*(rail_width/2+.0018), cy, bottom+.006),
                                      (.002, .014, .012), "receiver_wall"))
        boxes += added
        for box in added:
            rows.extend(_box_triangles(box))
        raw[name] = (rows, boxes, .24, ["table", "fixture"], "side_frame")
    for level, name in enumerate(NAMES[2:5]):
        shift = float(rail_z[level]-rail_mid_source*scale[2])
        def rail_transform(v, shift=shift):
            points = transform(v)+np.array([0, 0, shift])
            # Original rail ends touched the tall source upright surface.
            # A 0.3205 m carrier leaves 0.7 mm clearance from the adapted
            # uprights, so vertical insertion has a real open path.
            points[:, 1] = (v[:, 1]-(rail_bboxes[0][0][1]+rail_bboxes[0][1][1])/2) * (.3205/(rail_bboxes[0][1][1]-rail_bboxes[0][0][1]))
            return points
        rows, boxes = [], []
        for ids, (lo, hi) in zip(rail_ids, rail_bboxes):
            rows += _source_triangles(mesh, ids, rail_transform)
            rail_size = (hi-lo)*scale
            rail_size[1] = .3205
            boxes.append(_box(rail_transform(((lo+hi)/2)[None, :])[0], rail_size, "source_long_rail"))
        # The rigid end ties make a graspable preassembled carrier. They stop
        # before the U receivers and leave the large central aperture open.
        for sign in (-1, 1):
            box = _box((0, sign*.1485, float(rail_z[level])), (.166, .008, rail_height), "authored_end_tie")
            boxes.append(box)
            rows.extend(_box_triangles(box))
        raw[name] = (rows, boxes, .085, ["left_frame", "right_frame"], "carrier")
    shelf_source = components[4]
    lo, hi = _bounds(mesh, shelf_source)
    shelf_source_center = (lo+hi)/2
    shelf_size = np.array([float((hi[0]-lo[0])*scale[0]), .300, .008])
    for level, name in enumerate(NAMES[5:]):
        center = np.array([0, 0, rail_z[level]+rail_height/2+.004])
        def shelf_transform(v, center=center):
            return (v-shelf_source_center)*shelf_size/(hi-lo)+center
        rows = _source_triangles(mesh, shelf_source, shelf_transform)
        boxes = [_box(center, shelf_size, "source_board")]
        raw[name] = (rows, boxes, .13, [NAMES[2+level]], "shelf_board")

    parts = {}
    for name, display in zip(NAMES, DISPLAY):
        rows, boxes, mass, support, role = raw[name]
        vertices = np.concatenate([v for v, _, _ in rows])
        lows = [vertices.min(0)]+[np.asarray(b["pos"])-np.asarray(b["size"])/2 for b in boxes]
        highs = [vertices.max(0)]+[np.asarray(b["pos"])+np.asarray(b["size"])/2 for b in boxes]
        low, high = np.min(lows, axis=0), np.max(highs, axis=0)
        center, size = (low+high)/2, high-low
        relative_boxes = [{**b, "pos": (np.asarray(b["pos"])-center).tolist()} for b in boxes]
        obj, urdf = out / f"{name}.obj", out / f"{name}.urdf"
        _write_obj(obj, rows, center)
        _write_urdf(urdf, name, obj.name, relative_boxes, mass, size)
        parts[name] = {"urdf": str(urdf.resolve()), "mesh": str(obj.resolve()),
                       "mass": mass, "size": size.tolist(), "goal_local": center.tolist(),
                       "goal_quat_wxyz": [1, 0, 0, 0], "support": support, "role": role,
                       "display_name": display, "collision_boxes": relative_boxes,
                       "source_triangle_count": sum(mat == "steel_frame_shelves_01" for _, _, mat in rows),
                       "authored_triangle_count": sum(mat != "steel_frame_shelves_01" for _, _, mat in rows),
                       "mesh_sha256": _sha(obj), "urdf_sha256": _sha(urdf)}
    fixture, slots = _jig(frame_x, frame_y)
    source_files = {name: {"relative_path": str((SOURCE / name).relative_to(PACKAGE.parents[1])).replace("\\", "/"),
                           "sha256": _sha(SOURCE / name)}
                    for name in ("visual.obj", "visual.mtl", "steel_frame_shelves_01.png", "meta.json")}
    provenance = {"source": "https://polyhaven.com/a/steel_frame_shelves_01", "model": "steel_frame_shelves_01",
                  "author": "James Ray Cock", "license": "CC0",
                  "license_url": "https://polyhaven.com/license", "source_verified_date": "2026-10-20",
                  "license_evidence": "Existing source meta.json and official Poly Haven asset/license pages",
                  "source_files": source_files, "global_xyz_scale": scale.tolist(), "source_cut_height_m": .75,
                  "processing": ["Extract connected original components without replacing their triangles or UVs",
                                 "Clip original side frame triangles at source z=.75 with interpolated UVs",
                                 "Retain original feet, visible bolts, side rails, and source texture",
                                 "Repeat the same original lower rail pair and shelf in three interchangeable instances",
                                 "Resize carrier rails to 320.5 mm length for 0.7 mm upright insertion clearance",
                                 "Resize shelf board to 300 mm width and 8 mm thickness to avoid direct receiver support"],
                  "authored_additions": ["Six visible U receivers per side frame, matching collision boxes",
                                         "Two visible rigid end ties per preassembled carrier, matching collision boxes",
                                         "Open-bottom four-slot locating jig, static geometric boxes"],
                  "mechanics": "Unilateral rigid contact only; no snap, weld-on-seat, magnets, or simulated threads",
                  "limitations": ["Desktop adaptation of a real shelf asset, not a dimensionally exact manufacturer CAD kit",
                                  "Mass properties use component-volume weighted COM and parallel-axis inertia, with uniform-density and overlapping-box approximations",
                                  "Small tube interiors are simplified to solid boxes; the large frame/carrier openings are preserved",
                                  "Robot assembly policy and contact stability require independent physics validation"]}
    catalog = {"schema_version": SCHEMA_VERSION, "build_version": BUILD_VERSION,
               "asset_root": str(out.resolve()), "parts": parts, "fixture": fixture,
               "collision_contract": {"primitive_boxes": True, "convexify": False, "watertighten": None,
                                      "genesis_rigid_options": {"box_box_detection": True},
                                      "reason": "Analytical face contact is required for thin board/rail pairs; default MPR was observed to select a lateral normal at sub-mm vertical penetration."},
               "fixture_slots": slots, "assembly_origin_convention": "tabletop center; x depth, y width, z up",
               "recommended_origin_world": [.48, 0, .74], "size": [.182582, .340001, .25],
               "interchangeable_groups": [list(NAMES[2:5]), list(NAMES[5:])],
               "clearances": {"board_to_receiver_y": .004, "receiver_lateral_half_clearance": .0008,
                              "slot_depth": .024,
                              "board_width": .300, "board_thickness": .008},
               "source": provenance}
    (out / "asset_sources.json").write_text(json.dumps(provenance, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    (out / "catalog.json").write_text(json.dumps(catalog, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    return catalog


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    catalog = build_assets(args.output_dir)
    print(json.dumps({name: {k: part[k] for k in ("size", "goal_local", "support")}
                      for name, part in catalog["parts"].items()}, indent=2))


if __name__ == "__main__":
    main()
