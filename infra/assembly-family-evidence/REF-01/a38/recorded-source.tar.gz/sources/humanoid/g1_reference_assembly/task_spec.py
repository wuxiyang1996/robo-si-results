"""Private, read-only scoring for the reference-driven steel shelf assembly.

The recipe is a workflow constraint, separate from the physical load path:
every carrier needs both side frames and every board needs its carrier. The
three carriers are interchangeable, as are the three boards; either group can
be rotated 180 degrees about its upright axis. The mirrored side frames can be
swapped when turned 180 degrees to keep their bearing ears facing inward. Slot
assignments come from measured poses and contacts, never from an instance label.

``Evaluator.update`` consumes trusted simulator measurements, in metres,
seconds, radians and newtons::

    {"objects": {object_name: {
        "position": [x, y, z], "quat": [w, x, y, z],
        "linear_velocity": [vx, vy, vz], "angular_velocity": [wx, wy, wz],
        "robot_contact_force": 0.0,
        "support_forces": {supporting_object_name: upward_normal_force}
    }}}

For each supporting body, support_forces is the net vertical component of its
measured contact-normal forces on the object, clamped at zero. Tangential
friction, proximity flags, gravity estimates and commanded forces do not
qualify. Jig contacts are aggregated under ``fixture``. No method edits a physics entity,
creates an attachment, or supplies target poses to the public observation.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from math import acos, degrees, isfinite, sqrt
from collections.abc import Mapping


TABLE_HEIGHT = .74
MAX_EPISODE_SECONDS = 360.
FRAME_NAMES = ("left_frame", "right_frame")
CROSSBAR_NAMES = ("lower_crossbar", "middle_crossbar", "upper_crossbar")
SHELF_NAMES = ("bottom_shelf", "middle_shelf", "top_shelf")
OBJECT_NAMES = FRAME_NAMES + CROSSBAR_NAMES + SHELF_NAMES
object_names = OBJECT_NAMES
RECIPES = {
    "bottom_up": ("left_frame", "right_frame", "lower_crossbar", "bottom_shelf",
                  "middle_crossbar", "middle_shelf", "upper_crossbar", "top_shelf"),
    "top_down": ("left_frame", "right_frame", "upper_crossbar", "top_shelf",
                 "middle_crossbar", "middle_shelf", "lower_crossbar", "bottom_shelf"),
}
PHYSICAL_DEPENDENCIES = {
    **{name: () for name in FRAME_NAMES},
    **{name: FRAME_NAMES for name in CROSSBAR_NAMES},
    **{shelf: (bar,) for shelf, bar in zip(SHELF_NAMES, CROSSBAR_NAMES)},
}
_SUPPORT_NAMES = frozenset(("table", "fixture", "supply_rack", "ground", "other") + OBJECT_NAMES)


def _finite(value):
    if isinstance(value, bool):
        raise ValueError("boolean is not a physical measurement")
    result = float(value)
    if not isfinite(result):
        raise ValueError("non-finite measurement")
    return result


def _vector(value, size):
    if len(value) != size:
        raise ValueError(f"expected {size} coordinates")
    return tuple(_finite(item) for item in value)


def _norm(value):
    return sqrt(sum(item * item for item in value))


def _quaternion(value):
    result = _vector(value, 4)
    length = _norm(result)
    if length < 1e-12:
        raise ValueError("zero quaternion")
    return tuple(item / length for item in result)


@dataclass(frozen=True)
class TaskConfig:
    """Trusted evaluator/environment configuration; not a policy observation."""

    seed: int = 0
    recipe: str = "bottom_up"
    table_height: float = TABLE_HEIGHT
    table_center: tuple = (.52, 0.)
    table_size: tuple = (.68, 1.3, .05)
    origin: tuple = (.48, 0., TABLE_HEIGHT)
    control_dt: float = .02
    max_episode_seconds: float = MAX_EPISODE_SECONDS
    object_names: tuple = OBJECT_NAMES
    position_tolerance: float = .008
    angle_tolerance_degrees: float = 12.
    stable_seconds: float = .5
    final_hold_seconds: float = 2.
    support_loss_grace_seconds: float = .3
    linear_speed_max: float = .025
    angular_speed_max: float = .15
    robot_contact_force_max: float = .05
    frame_support_force_min: float = .02
    crossbar_support_force_min: float = .02
    shelf_support_force_min: float = .05
    drop_distance: float = .12

    def __post_init__(self):
        if isinstance(self.seed, bool) or not isinstance(self.seed, int):
            raise ValueError("seed must be an integer")
        if self.recipe not in RECIPES:
            raise ValueError(f"unknown recipe: {self.recipe!r}")
        if tuple(self.object_names) != OBJECT_NAMES:
            raise ValueError("object_names must name the eight catalog instances")
        for name in ("table_height", "control_dt", "max_episode_seconds",
                     "position_tolerance", "angle_tolerance_degrees", "stable_seconds",
                     "final_hold_seconds", "support_loss_grace_seconds", "linear_speed_max",
                     "angular_speed_max", "robot_contact_force_max", "frame_support_force_min",
                     "crossbar_support_force_min", "shelf_support_force_min", "drop_distance"):
            if _finite(getattr(self, name)) <= 0:
                raise ValueError(f"{name} must be positive")
        _vector(self.table_center, 2)
        if any(value <= 0 for value in _vector(self.table_size, 3)):
            raise ValueError("table_size must be positive")
        origin = _vector(self.origin, 3)
        if abs(origin[2] - self.table_height) > 1e-9:
            raise ValueError("assembly origin must lie on the table surface")
        if self.angle_tolerance_degrees >= 180:
            raise ValueError("angle tolerance must be below 180 degrees")

    @property
    def sequence(self):
        return RECIPES[self.recipe]


class Evaluator:
    """Contact-based, terminal-latching evaluator with interchangeable parts."""

    def __init__(self, config, catalog):
        self.cfg = config
        self.sequence = tuple(config.sequence)
        self.order = self.sequence
        self.goals = {}
        parts = catalog["parts"]
        for name in OBJECT_NAMES:
            part = parts[name]
            local = _vector(part["goal_local"], 3)
            quat = _quaternion(part.get("goal_quat_wxyz", (1., 0., 0., 0.)))
            supports = part.get("support", ())
            if isinstance(supports, str):
                supports = (supports,)
            if any(support not in _SUPPORT_NAMES for support in supports):
                raise ValueError(f"unknown catalog support for {name}")
            self.goals[name] = (
                tuple(config.origin[i] + local[i] for i in range(3)), quat,
            )
        self.reset()

    def reset(self):
        self.elapsed = 0.
        self.stage = 0
        self.completed = []
        self.assignments = {}
        self.current_dwell = 0.
        self.final_dwell = 0.
        self.loss_dwell = {}
        self.conditions = {}
        self.success = False
        self.failed = False
        self.reason = "in_progress"
        self.failure_detail = None
        self._candidate = None
        self._previous_final = False
        self._terminal = None
        return self.status()

    def status(self):
        if self._terminal is not None:
            return deepcopy(self._terminal)
        count = len(self.sequence)
        fraction = (self.current_dwell / self.cfg.stable_seconds if self.stage < count
                    else self.final_dwell / self.cfg.final_hold_seconds)
        return {
            "stage": self.stage,
            "stage_name": self.sequence[self.stage] if self.stage < count else "final_release",
            "completed": list(self.completed),
            "assignments": dict(self.assignments),
            "score": int(self.success),
            "progress": 1. if self.success else (self.stage + min(1., fraction)) / (count + 1),
            "success": self.success, "failed": self.failed,
            "terminated": self.success or self.failed,
            "terminal": self.success or self.failed,
            "reason": self.reason,
            "failure_reason": self.reason if self.failed else None,
            "failure_detail": deepcopy(self.failure_detail),
            "elapsed_seconds": self.elapsed,
            "current_stable_seconds": self.current_dwell,
            "final_hold_seconds": self.final_dwell,
            "support_lost_seconds": dict(self.loss_dwell),
            "conditions": deepcopy(self.conditions),
        }

    def _finish(self, reason, *, success=False, detail=None):
        self.success, self.failed = success, not success
        self.reason, self.failure_detail = reason, detail
        self._terminal = self.status()
        return deepcopy(self._terminal)

    @staticmethod
    def _read_object(raw):
        forces = raw["support_forces"]
        if not isinstance(forces, Mapping) or any(name not in _SUPPORT_NAMES for name in forces):
            raise ValueError("unknown support identity")
        result = {
            "position": _vector(raw["position"], 3),
            "quat": _quaternion(raw["quat"]),
            "linear_velocity": _vector(raw["linear_velocity"], 3),
            "angular_velocity": _vector(raw["angular_velocity"], 3),
            "robot_contact_force": _finite(raw["robot_contact_force"]),
            "support_forces": {name: _finite(force) for name, force in forces.items()},
        }
        if result["robot_contact_force"] < 0 or any(force < 0 for force in result["support_forces"].values()):
            raise ValueError("contact force magnitudes must be nonnegative")
        return result

    @staticmethod
    def _group(slot):
        if slot in FRAME_NAMES:
            return FRAME_NAMES
        if slot in CROSSBAR_NAMES:
            return CROSSBAR_NAMES
        if slot in SHELF_NAMES:
            return SHELF_NAMES
        return (slot,)

    def _near(self, slot, actual, obj):
        goal_pos, goal_quat = self.goals[slot]
        # q_goal * q_z(pi): a half turn around the part's local upright axis.
        w, x, y, z = goal_quat
        half_turn = (-z, y, -x, w)
        if slot in FRAME_NAMES:
            orientations = (goal_quat,) if actual == slot else (half_turn,)
        else:
            orientations = (goal_quat, half_turn)
        dot = min(1., max(abs(sum(a * b for a, b in zip(obj["quat"], orientation)))
                         for orientation in orientations))
        return (
            all(abs(obj["position"][i] - goal_pos[i]) <= self.cfg.position_tolerance for i in range(3))
            and degrees(2 * acos(dot)) <= self.cfg.angle_tolerance_degrees + 1e-9
        )

    def _slow(self, obj):
        return (_norm(obj["linear_velocity"]) <= self.cfg.linear_speed_max
                and _norm(obj["angular_velocity"]) <= self.cfg.angular_speed_max)

    def _released(self, obj):
        return obj["robot_contact_force"] <= self.cfg.robot_contact_force_max

    def _supported(self, slot, actual, objects, *, allow_unassigned_support=False):
        forces = objects[actual]["support_forces"]
        if slot in FRAME_NAMES:
            return max(forces.get("table", 0.), forces.get("fixture", 0.)) > self.cfg.frame_support_force_min
        if slot in CROSSBAR_NAMES:
            return all(forces.get(self.assignments.get(frame, frame), 0.) > self.cfg.crossbar_support_force_min
                       for frame in FRAME_NAMES)
        bar_slot = PHYSICAL_DEPENDENCIES[slot][0]
        if bar_slot in self.assignments:
            return forces.get(self.assignments[bar_slot], 0.) > self.cfg.shelf_support_force_min
        if not allow_unassigned_support:
            return False
        # Wrong-order detection must also work before the future carrier was
        # credited. Find its real instance by geometry and bilateral contact.
        return any(
            self._near(bar_slot, bar, objects[bar])
            and self._supported(bar_slot, bar, objects)
            and forces.get(bar, 0.) > self.cfg.shelf_support_force_min
            for bar in CROSSBAR_NAMES
        )

    def _condition(self, slot, actual, objects, *, allow_unassigned_support=False):
        obj = objects[actual]
        pose = self._near(slot, actual, obj)
        support = self._supported(slot, actual, objects, allow_unassigned_support=allow_unassigned_support)
        slow, released = self._slow(obj), self._released(obj)
        return {"object": actual, "pose": pose, "supported": support,
                "slow": slow, "released": released,
                "structural_valid": pose and support,
                "seated": pose and support and slow,
                "stable_released": pose and support and slow and released}

    def _candidates(self, slot):
        used = set(self.assignments.values())
        return [actual for actual in self._group(slot) if actual not in used]

    def update(self, state, dt):
        if self._terminal is not None:
            return deepcopy(self._terminal)
        try:
            dt = _finite(dt)
            if dt <= 0 or dt > self.cfg.control_dt * 1.01:
                return self._finish("invalid_sample_interval")
        except (ValueError, TypeError, OverflowError):
            return self._finish("invalid_sample_interval")
        try:
            objects = {name: self._read_object(state["objects"][name]) for name in OBJECT_NAMES}
        except (ValueError, TypeError, KeyError, OverflowError):
            return self._finish("invalid_state")
        self.elapsed += dt
        for name, obj in objects.items():
            if obj["position"][2] < self.cfg.table_height - self.cfg.drop_distance:
                return self._finish("object_dropped", detail={"object": name})
        if self.elapsed + 1e-9 >= self.cfg.max_episode_seconds:
            return self._finish("timeout")

        # Completed structures may be held while another component is fitted,
        # but their pose and physical load path must remain intact.
        self.conditions = {
            slot: self._condition(slot, actual, objects)
            for slot, actual in self.assignments.items()
        }
        for slot in self.completed:
            intact = self.conditions[slot]["structural_valid"]
            self.loss_dwell[slot] = 0. if intact else self.loss_dwell[slot] + dt
            if self.loss_dwell[slot] + 1e-9 >= self.cfg.support_loss_grace_seconds:
                return self._finish("structure_lost", detail={"slot": slot, "object": self.assignments[slot]})

        # Use the stage at sample entry. Releasing a future part cannot finish
        # its predecessor and satisfy the workflow in the same observation.
        for slot in self.sequence[self.stage + 1:]:
            for actual in self._candidates(slot):
                condition = self._condition(slot, actual, objects, allow_unassigned_support=True)
                if condition["stable_released"]:
                    return self._finish("wrong_order", detail={"slot": slot, "object": actual,
                                        "expected_slot": self.sequence[self.stage]})

        previous_intact = all(self.conditions[slot]["structural_valid"] for slot in self.completed)
        if self.stage < len(self.sequence):
            slot = self.sequence[self.stage]
            dependencies_complete = all(name in self.assignments for name in PHYSICAL_DEPENDENCIES[slot])
            qualified = []
            for actual in self._candidates(slot):
                condition = self._condition(slot, actual, objects)
                if condition["pose"] or slot not in self.conditions:
                    self.conditions[slot] = condition
                if previous_intact and dependencies_complete and condition["stable_released"]:
                    qualified.append(actual)
            candidate = self._candidate if self._candidate in qualified else (qualified[0] if qualified else None)
            self.current_dwell = (self.current_dwell + dt if candidate is not None and candidate == self._candidate else 0.)
            self._candidate = candidate
            if candidate is not None and self.current_dwell + 1e-9 >= self.cfg.stable_seconds:
                self.assignments[slot] = candidate
                self.completed.append(slot)
                self.loss_dwell[slot] = 0.
                self.stage += 1
                self.current_dwell = 0.
                self._candidate = None
        else:
            qualifies = all(self.conditions[slot]["stable_released"] for slot in self.completed)
            self.final_dwell = self.final_dwell + dt if qualifies and self._previous_final else 0.
            self._previous_final = qualifies
            if self.final_dwell + 1e-9 >= self.cfg.final_hold_seconds:
                return self._finish("assembled_and_released", success=True)
        return self.status()
