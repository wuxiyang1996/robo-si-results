"""Fresh-reset assembly candidate, using measured poses and joint commands only.

Unlike the legacy expert, this controller never reads a recorded action prefix.
Physical validation, including failures, is kept by solution.run_expert.
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from .expert import parts_after_support
from .tool import safe_ready


def _move(c, phase, tasks, seconds):
    c.event(phase)
    c.move_hands(tasks, seconds=seconds, rate=1.)


def _yaw(state):
    q = np.asarray(state["quat"])
    r = Rotation.from_quat(q[[1, 2, 3, 0]]).as_matrix()
    return math.atan2(r[1, 0], r[0, 0])


def preposition_brace(c):
    """Pinch the measured brace, then carry it beside the fixture."""
    cfg = c.env.cfg
    state = c.object_state("brace")
    center = np.asarray(state["pos"])
    yaw = _yaw(state)
    turn = Rotation.from_euler("z", yaw).as_matrix()
    rot = turn @ Rotation.from_euler("x", np.pi / 2).as_matrix()
    q = c.q.copy()
    for finger in ("index", "middle"):
        q[c.index[f"left_hand_{finger}_0_joint"]] = -1.15
        q[c.index[f"left_hand_{finger}_1_joint"]] = 0.
    q[c.index["left_hand_thumb_0_joint"]] = 0.
    q[c.index["left_hand_thumb_1_joint"]] = -.70
    q[c.index["left_hand_thumb_2_joint"]] = 0.
    c.move_joints(q, seconds=.5)
    palm = center + turn @ np.array([.001, 0., .08375])
    high = palm.copy()
    high[2] = cfg.table_height + .31
    _move(c, "brace_hover", {"left": ("palm", high, rot)}, 4.)
    _move(c, "brace_lower", {"left": ("palm", palm, rot)}, 4.)
    q = c.q.copy()
    for finger in ("index", "middle"):
        q[c.index[f"left_hand_{finger}_0_joint"]] = -1.4
        q[c.index[f"left_hand_{finger}_1_joint"]] = -.5-np.clip((cfg.brace_size[0]-.070)/.0021, 0., 1.)*.15
    q[c.index["left_hand_thumb_1_joint"]] = -.10
    q[c.index["left_hand_thumb_2_joint"]] = .5
    c.event("brace_close")
    c.move_joints(q, seconds=2.)
    high[2] = cfg.table_height + .25
    _move(c, "brace_lift", {"left": ("palm", high, rot)}, 4.)
    measured = c.object_state("brace")
    if not measured["hand_contact"] or measured["pos"][2] < center[2] + .025:
        raise RuntimeError("brace did not establish a physical lifted grasp")
    # Keep the long side parallel to the fixture edge. The palm-to-part
    # displacement is measured; it is not assumed to be a rigid attachment.
    # This pinch rolls toward the fingertips as the arm extends. Set down on
    # the near side of the corridor; the measured push below removes residual
    # lateral error instead of treating the grasp as a rigid attachment.
    staging = np.array([cfg.brace_goal_xy[0]-.013,
                        cfg.fixture_pivot_xy[1] + cfg.fixture_size[1]/2
                        + cfg.brace_size[1]/2 + .042,
                        measured["pos"][2]])
    start = np.asarray(measured["pos"])
    start_palm, _ = c.hand_pose("left")
    correction = np.zeros(3)
    goal_rot = Rotation.from_euler("x", np.pi / 2).as_matrix()
    c.event("brace_transfer_feedback")
    for i in range(300):
        a = (i+1)/300
        a = a*a*a*(10-15*a+6*a*a)
        state = c.object_state("brace")
        if i % 25 == 0:
            c.events.append(dict(phase="brace_transfer_contacts", time=c.env.physics_steps*.005,
                                 contacts=c.contacts("brace"), state=state))
        if i > 150 and state["hand_contact"] and np.linalg.norm(np.asarray(state["pos"][:2])-staging[:2]) < .009:
            c.event("brace_staging_reached", position=state["pos"])
            break
        if not state["hand_contact"]:
            if np.linalg.norm(np.asarray(state["pos"][:2])-staging[:2]) > .018:
                raise RuntimeError("brace grasp lost before reaching the staging area")
            # The legacy pinch releases as the arm reaches the staging area.
            # Accept that physical set-down only after real table support.
            c.hold(.6)
            state = c.object_state("brace")
            if not state["support_contact"] or abs(state["pos"][2]-cfg.brace_goal[2]) > .01:
                raise RuntimeError("brace did not settle on the table after staging release")
            c.event("brace_staging_released", position=state["pos"])
            break
        desired = start + a*(staging-start)
        error = desired - np.asarray(state["pos"])
        correction += np.clip(.5*cfg.control_dt*error, -.0003, .0003)
        correction = np.clip(correction, -.025, .025)
        rotation = Rotation.from_rotvec(a*Rotation.from_matrix(goal_rot @ rot.T).as_rotvec()).as_matrix() @ rot
        c.reach({"left": ("palm", start_palm + desired-start + correction, rotation)},
                rate=1., feedback=.25)
        c.step()
    # Lower and open at the measured staging location before changing arm branch.
    palm, rot = c.hand_pose("left")
    state = c.object_state("brace")
    start_obj = np.asarray(state["pos"])
    goal = np.array([*staging[:2], cfg.brace_goal[2]])
    initial_palm = palm.copy()
    correction = np.zeros(2)
    c.event("brace_set_down_feedback")
    for i in range(75):
        a = (i+1)/75
        a = a*a*a*(10-15*a+6*a*a)
        desired = start_obj + a*(goal-start_obj)
        state = c.object_state("brace")
        if state["hand_contact"]:
            correction += np.clip(4.*cfg.control_dt*(desired[:2]-np.asarray(state["pos"][:2])), -.0008, .0008)
            correction = np.clip(correction, -.04, .04)
        palm = initial_palm + desired-start_obj
        palm[:2] += correction
        c.reach({"left": ("palm", palm, rot)}, rate=1., feedback=.25)
        c.step()
    c.event("brace_confirm_table_support")
    for _ in range(50):
        state = c.object_state("brace")
        if state["support_contact"] and state["support_forces"].get("table", 0.) > .05:
            break
        palm[2] -= np.clip(state["pos"][2]-goal[2], 0., .0007)
        c.reach({"left": ("palm", palm, rot)}, rate=1., feedback=.25)
        c.step()
    state = c.object_state("brace")
    if not state["support_contact"] or state["support_forces"].get("table", 0.) <= .05:
        raise RuntimeError("brace was not supported by the table before opening")
    q = c.q.copy()
    for finger in ("index", "middle"):
        q[c.index[f"left_hand_{finger}_0_joint"]] = 0.
    q[c.index["left_hand_thumb_1_joint"]] = -.70
    c.move_joints(q, seconds=.4)
    _move(c, "brace_clear", {"left": ("palm", palm + [0., 0., .16], rot)}, 1.)
    if abs(c.object_state("brace")["pos"][0]-cfg.brace_goal_xy[0]) > .015:
        raise RuntimeError(f"brace staging x misaligned: {c.object_state('brace')['pos']}")


def support_fixture(c, *, push_heading=0., steer=False, fixed_push_x=False, push_height=.020,
                    lateral_gain=0., lateral_damping=0., finish_push=False, fine_pitch=75.,
                    push_steps=350, uniform_push=False, force_steering=False):
    cfg = c.env.cfg
    preposition_brace(c)
    _move(c, "press_retract_before_rebranch", {
        "left": ("palm", (.06, .27, 1.03), None),
        "right": ("palm", (.06, -.27, 1.03), None),
    }, 1.5)
    ready = np.asarray([
        -.10, 0., 0., .30, -.20, 0., -.10, 0., 0., .30, -.20, 0.,
        0., 0., -.4987725, .5844294, .4259725, .3010576, -.3043091,
        -.0473653, -.7010527, .1189222, 0., 1.0393806, 1.0428044,
        -.0007776, -.0001165, -.0016268, -.0003442,
        .5843495, -.4259823, -.3010773, -.3043895, .0473741,
        -.701085, -.1189297, 0., -1.0440409, -1.0599315,
        .0007767, .0001155, .0016003, .0003467,
    ])
    c.event("press_restore_safe_branch")
    c.move_joints(np.clip(ready, c.lo, c.hi), seconds=1.5)
    c.hand_preset("left", "squeeze", seconds=.5)
    px, py = np.asarray(cfg.fixture_pivot_xy) + [-.16, -.035]
    pz = cfg.fixture_center[2] + .05
    down = Rotation.from_euler("x", -np.pi/2).as_matrix()
    for z, seconds, phase in [(cfg.table_height+.30, 2., "fixture_approach"),
                              (cfg.table_height+.22, 1., "fixture_hover"),
                              (pz, 4., "fixture_press")]:
        _move(c, phase, {"right": ("palm", (px, py, z), down)}, seconds)
    # Only proceed once the real hinge has opened sufficient clearance.
    pitch = 2*np.arcsin(np.clip(c.object_state("fixture")["quat"][2], -1., 1.))
    if pitch > -.005:
        c.event("fixture_press_feedback", initial_pitch=float(pitch))
        initial_height = pz
        for _ in range(75):
            pitch = 2*np.arcsin(np.clip(c.object_state("fixture")["quat"][2], -1., 1.))
            if pitch <= -.012:
                break
            pz = max(initial_height-.025, pz-min(.0004, .20*cfg.control_dt*(pitch+.02)))
            c.reach({"right": ("palm", (px, py, pz), down)}, rate=1., feedback=.25)
            c.step()
    if pitch > -.005:
        raise RuntimeError(f"fixture did not open brace clearance: pitch={pitch:.4f}")
    # Once the plate has opened, remove the extra pressing displacement. It
    # otherwise consumes the shared waist's reach while the left thumb lowers.
    pz = cfg.fixture_center[2] + .05
    c.ik.set_limit("waist_pitch_joint", -.4, .35)
    c.ik.set_limit("right_shoulder_roll_joint", -1.55, 0.)
    c.hand_preset("left", "open", seconds=.5)
    q = c.q.copy()
    q[c.index["left_hand_thumb_1_joint"]] = .8
    c.move_joints(q, seconds=.5)
    bx, by, _ = c.object_state("brace")["pos"]
    rot = Rotation.from_euler("x", np.pi/2).as_matrix()
    right = ("palm", (px, py, pz), down)
    # Seed the redundant two-arm solve on the screened pressing branch. The
    # optimizer still solves the measured scene; the seed is never a physical
    # state assignment or an archived sequence of actions.
    seed = c.q.copy()
    seed[c.ik.upper] = [
        -.55452591, -.48837557, .34150395,
        -.53228337, 2.1014812, .26650357, .81457025, .2690191, -.2614502, -.32834587,
        -.933604, -.00043696, 1.40045154, -.07523575, -.40597957, 1.04051328, -.80992085,
    ]
    options = []
    for dx, dz in ((dx, dz) for dz in (.21, .19, .17) for dx in (.025, .020, .015, .010, .005, 0.)):
        hover = {"left": ("thumb", (bx+dx, by+cfg.brace_size[1]/2+.02, cfg.table_height+dz), rot),
                 "right": right}
        solution, errors = c.ik.solve(c.env.base_position, (1, 0, 0, 0), seed, hover,
                                      iters=150, damping=.015, w_rot=.35, max_step=.10)
        if max(errors.values()) <= .003:
            options.append((solution, errors, dx, dz))
            break
    if not options:
        raise RuntimeError(f"thumb hover not reachable on the screened branch: {errors}")
    solution, errors, dx, dz = options[0]
    c.event("thumb_hover_branch", errors=errors, offset=[dx, dz])
    c.move_joints(solution, seconds=3.)
    for z, seconds, phase in [(cfg.table_height+push_height, 4., "thumb_lower")]:
        _move(c, phase, {"left": ("thumb", (bx+dx, by+cfg.brace_size[1]/2+.02, z), rot),
                         "right": right}, seconds)
    start, _ = c.hand_pose("left", "thumb")
    offset = dx
    lateral_velocity = 0.
    contact_x = start[0]
    force_heading = 0.
    force_ratio = 0.
    c.event("brace_push_feedback")
    for i in range(push_steps):
        state = c.object_state("brace")
        yaw = _yaw(state)
        a = (i+1)/push_steps
        if uniform_push:
            # A trapezoid limits peak sliding speed while retaining smooth
            # acceleration and braking at both ends.
            ramp = .15
            a = (a*a/(2*ramp*(1-ramp)) if a < ramp else
                 1-(1-a)**2/(2*ramp*(1-ramp)) if a > 1-ramp else (a-ramp/2)/(1-ramp))
        else:
            a = a*a*a*(10-15*a+6*a*a)
        contacts = [r for r in c.contacts("brace")
                    if r["link"].startswith("left_") and r["force"][1] > .1]
        if contacts:
            weights = [r["force"][1] for r in contacts]
            center = np.average([r["position"][0] for r in contacts], weights=weights)
            thumb, _ = c.hand_pose("left", "thumb")
            offset = .9*offset + .1*np.clip(thumb[0]-center, -.01, .06)
            if force_steering:
                force = np.sum([r["force"] for r in contacts], axis=0)
                force_ratio = .8*force_ratio + .2*float(np.clip(force[0]/max(force[1], .1), -1., 1.))
                desired_ratio = 8.*(state["pos"][0]-cfg.brace_goal_xy[0])+.8*state["linear_velocity"][0]
                force_heading = float(np.clip(force_heading+np.clip(.04*(force_ratio-desired_ratio), -.003, .003), -.20, .20))
        push_x = cfg.brace_goal_xy[0] if fixed_push_x else state["pos"][0]
        # Pushing to the right of the measured centre produces negative yaw,
        # which turns the leading face toward decreasing x. Moving the contact
        # directly to the desired x would instead amplify a lateral error.
        lateral_velocity = .8*lateral_velocity + .2*state["linear_velocity"][0]
        steering_offset = np.clip(lateral_gain*(state["pos"][0]-cfg.brace_goal_xy[0])
                                  + lateral_damping*lateral_velocity, -.015, .015)
        if force_steering:
            lateral_error = state["pos"][0]-cfg.brace_goal_xy[0]
            steering_offset = np.clip(.4*np.sign(lateral_error)*max(abs(lateral_error)-.008, 0.), -.008, .008)
        goal = np.array([push_x+offset+.10*yaw+steering_offset,
                         cfg.brace_goal_xy[1]+cfg.brace_size[1]/2+.006,
                         cfg.table_height+push_height])
        point = start+a*(goal-start)
        contact_x += np.clip(goal[0]-contact_x, -.0012, .0012) if lateral_damping else goal[0]-contact_x
        point[0] = contact_x
        heading = (float(np.clip(-.15 - 7.*(state["pos"][0]-cfg.brace_goal_xy[0]), -.45, .25))
                   if steer else push_heading)
        if force_steering:
            heading = force_heading
        rot = (Rotation.from_euler("z", heading).as_matrix() @
               Rotation.from_euler("x", 90.-15.*np.clip((a-.4)/.6, 0., 1.), degrees=True).as_matrix())
        c.reach({"left": ("thumb", point, rot), "right": right}, rate=1., feedback=.25)
        c.step()
        if i % 25 == 0:
            c.events.append(dict(phase="brace_push_diagnostic", time=c.env.physics_steps*.005,
                                 position=state["pos"], yaw=float(yaw), thumb_target=point.tolist(),
                                 contact_offset=float(offset), contacts=contacts))
    if finish_push:
        c.event("brace_push_fine_alignment")
        fine_start, _ = c.hand_pose("left", "thumb")
        for i in range(100):
            state = c.object_state("brace")
            error_x = state["pos"][0]-cfg.brace_goal_xy[0]
            if abs(error_x) < .010 and abs(_yaw(state)) < .06 and abs(state["pos"][1]-cfg.brace_goal_xy[1]) < .014:
                break
            if state["pos"][1] < cfg.brace_goal_xy[1]-.012:
                break
            lateral_velocity = .8*lateral_velocity + .2*state["linear_velocity"][0]
            goal_x = state["pos"][0]+offset+.10*_yaw(state)+np.clip(
                lateral_gain*error_x+lateral_damping*lateral_velocity, -.015, .015)
            if force_steering:
                goal_x += np.clip(.4*np.sign(error_x)*max(abs(error_x)-.008, 0.), -.008, .008)
            contact_x += np.clip(goal_x-contact_x, -.0012, .0012)
            fraction = (i+1)/100
            fraction = fraction**3*(10-15*fraction+6*fraction**2)
            rot = Rotation.from_euler("x", 75.+fraction*(fine_pitch-75.), degrees=True).as_matrix()
            point = [contact_x,
                     fine_start[1]+fraction*(cfg.brace_goal_xy[1]+cfg.brace_size[1]/2-.010-fine_start[1]),
                     cfg.table_height+push_height]
            c.reach({"left": ("thumb", point, rot), "right": right}, rate=1., feedback=.25)
            c.step()
            if i % 25 == 0:
                c.events.append(dict(phase="brace_fine_diagnostic", time=c.env.physics_steps*.005,
                                     position=state["pos"], thumb_target=point,
                                     brace_contacts=c.contacts("brace"), fixture_contacts=c.contacts("fixture")))
    _move(c, "thumb_clear", {"left": ("thumb", (bx+.025, cfg.brace_goal_xy[1]+.22,
                                               cfg.table_height+.20), rot), "right": right}, 2. if finish_push else 3.)
    _move(c, "fixture_release", {
        "left": ("thumb", (bx, cfg.brace_goal_xy[1]+.22, cfg.table_height+.30), rot),
        "right": ("palm", (px, py, cfg.table_height+.30), down),
    }, 2. if finish_push else 3.)
    c.hold(.8 if finish_push else 1.)
    if c.env.status["stage"] < 1:
        raise RuntimeError("released brace did not physically support the fixture")


def run(c):
    """Measured-state release candidate, with no archived action prefix."""
    return run_force_guided_cap(c)


def run_heading_positive(c):
    safe_ready(c)
    support_fixture(c, push_heading=.15)
    return parts_after_support(c)


def run_heading_negative(c):
    safe_ready(c)
    support_fixture(c, push_heading=-.15)
    return parts_after_support(c)


def run_heading_feedback(c):
    safe_ready(c)
    support_fixture(c, steer=True)
    return parts_after_support(c)


def run_heading_negative_more(c):
    safe_ready(c)
    support_fixture(c, push_heading=-.3)
    return parts_after_support(c)


def run_heading_fixed(c):
    safe_ready(c)
    support_fixture(c, push_heading=-.15, fixed_push_x=True)
    return parts_after_support(c)


def run_reachable_push(c):
    safe_ready(c)
    support_fixture(c, fixed_push_x=True, push_height=.015)
    return parts_after_support(c)


def run_contact_steering(c):
    safe_ready(c)
    support_fixture(c, push_height=.015, lateral_gain=.5)
    return parts_after_support(c)


def run_contact_damped(c):
    safe_ready(c)
    support_fixture(c, push_height=.015, lateral_gain=.3, lateral_damping=.12)
    return parts_after_support(c)


def run_contact_finish(c):
    safe_ready(c)
    support_fixture(c, push_height=.015, lateral_gain=.3, lateral_damping=.12, finish_push=True)
    return parts_after_support(c)


def run_contact_finish_clearance(c):
    safe_ready(c)
    support_fixture(c, push_height=.015, lateral_gain=.3, lateral_damping=.12,
                    finish_push=True, fine_pitch=60.)
    return parts_after_support(c)


def run_slow_push(c):
    safe_ready(c)
    support_fixture(c, push_height=.015, lateral_gain=.3, lateral_damping=.3,
                    finish_push=True, fine_pitch=60., push_steps=450, uniform_push=True)
    return parts_after_support(c)


def run_force_steering(c):
    safe_ready(c)
    support_fixture(c, push_height=.015, force_steering=True,
                    finish_push=True, fine_pitch=60., push_steps=450, uniform_push=True)
    return parts_after_support(c)


def run_force_guided_cap(c):
    from . import cap, sleeve
    from .parts import insert_held_part
    from .transition import positive_elbow_ready

    safe_ready(c)
    support_fixture(c, push_height=.015, force_steering=True,
                    finish_push=True, fine_pitch=60., push_steps=450, uniform_push=True)
    positive_elbow_ready(c)
    grasp = sleeve.grasp(c, lift_height=.25, hold_seconds=1., settle_timeout=1.)
    if not grasp["grasp_verified"]:
        raise RuntimeError(f"sleeve: physical grasp was not verified: {grasp}")
    insert_held_part(c, "sleeve", "left", sleeve.release)
    return cap.run_cap(c, release_clearance=.004, release_seconds=1.0, approach_seconds=3.5)
