"""Execution contracts; plans are persisted before constructing the simulator."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
DESIGN = ROOT / 'infra/planning/assembly-family/task-design.json'
VELOCITY_SOURCE = Path('/fs/gamma-projects/vlm-robot/robo-si-local-tests/h1-implementation-20261027/asset-cache/unitree_ros/robots/g1_description/g1_29dof_with_hand_rev_1_0.urdf')
VELOCITY_SHA = '97da67732d067c3147fc5fb7b7bafc8982718f4e7f8c92ff82266a4d9c07200d'

def plan(task, body='G-reference'):
    item = next(x for x in json.loads(DESIGN.read_text())['tasks'] if x['id'] == task)
    family = item['family']
    if family == 'ASM':
        stages = [('support', 'Select, acquire and deploy a released load-bearing support',
                   ['inspect_candidates', 'approach', 'grasp_or_push', 'deploy', 'release_and_check_load_path']),
                  ('sleeve', 'Grasp sleeve, align its bore, insert and release',
                   ['approach', 'pinch', 'lift', 'align', 'insert', 'release']),
                  ('cap', 'Grasp cap, insert above sleeve and withdraw both hands',
                   ['approach', 'pinch', 'lift', 'align', 'insert', 'release', 'final_dwell'])]
    elif family == 'GEAR':
        stages = [(n, 'Assemble and verify '+n, ['approach', 'grasp', 'lift', 'align', 'seat', 'release_and_verify'])
                  for n in ['base', 'large_gear', 'medium_gear', 'small_gear', 'cover']]
        stages += [('drive', 'Acquire physical tool and test contact transmission',
                    ['approach_tool', 'grasp', 'engage_teeth', 'sweep', 'retract', 'repeat_until_measured_angle']),
                   ('release', 'Park tool and release all contacts', ['park_tool', 'open_hand', 'withdraw', 'final_dwell'])]
    else:
        stages = [(n, 'Install and release '+n, ['choose_grasp', 'approach', 'grasp', 'lift', 'orient', 'align', 'seat', 'release_and_verify'])
                  for n in ['left_frame','right_frame','lower_crossbar','bottom_shelf','middle_crossbar','middle_shelf','upper_crossbar','top_shelf']]
        stages += [('release', 'Withdraw and verify complete support chain', ['withdraw', 'final_dwell'])]
    if task=='ASM-03':
        stages.insert(0,('compose_support','Physically stack stand and shim before deploying the released support',['grasp_shim','lift_check','front_corridor_to_central_staging','regrasp_with_left_hand','place_on_stand','release_check']))
    elif task=='ASM-04':
        stages.insert(0,('select_method','Screen grasp/place, push-in wedge and composed-support methods',['measure_geometry','check_grasp_and_access','choose_deployment']))
    elif task=='GEAR-02':
        stages=[('diagnose','Locate misseating from observed pose and contacts',['inspect_each_gear','compare_axis_and_height']),('extract_reseat','Extract, flip and reseat the diagnosed inverted gear',['grasp_rim','lift_clear_of_shaft','move_to_clearance','flip','handoff_to_hub_grasp','align','reseat','release_check'])]+stages[4:]
    elif task=='GEAR-03':
        stages.insert(0,('select_tool','Choose from physical drive tools',['measure_handle','check_tip_and_clearance','grasp_probe']))
    elif task=='REF-02':
        stages.insert(0,('deploy_fixture','Plan a legal topological assembly order and reuse the one temporary fixture',['grasp_fixture','place_under_frame','verify_load','relocate_to_other_frame']))
        stages.insert(-1,('park_fixture','Return the released fixture after both frame uses',['remove_after_load_transfer','park','verify_final_clearance']))
    elif task=='REF-03':
        stages.insert(0,('access_plan','Plan front approaches around the collision wall',['measure_workspace','choose_holding_or_fixture_method','check_withdrawal']))
    result={'task_id':task,'body':body,'family':family,'seed':0,'case_version':'inverted-middle-gear-v2' if task=='GEAR-02' else 'scene-v1','implementation_body':'historical fixed-pelvis G1 MJCF with three-finger hands',
            'evidence_scope':'reference-body scene probe; not the registered matched official-body comparison' if task in ('ASM-04','GEAR-03','REF-03') else 'single reference-body expert attempt','source':'privileged_measured_state_expert',
            'high_level':[{'id':s,'goal':g,'low_level':l} for s,g,l in stages],
            'online_planning':'Each motion goal is written to low_plan.jsonl before execution, then mapped to measured entry/exit steps.',
            'physical_rules':{'joint_position_overrun_max':.001,'effort_ratio_max':1.001,'velocity_ratio_max':1.001,
                 'velocity_source':str(VELOCITY_SOURCE),'velocity_source_sha256':VELOCITY_SHA,
                 'state_writes_after_start':False,'runtime_attachments':False,'runtime_parameter_changes':False,
                 'base':'fixed pelvis for reference G1; does not establish free-standing performance',
                 'prohibited_contacts':'non-hand robot links against table or movable task objects, force > 2 N; intentional hand contacts allowed',
                 'evidence_scope':'development API audit, not adversarial sandbox'},
            'registered_design':item}

    keys=['shim'] if task=='ASM-03' else ['frame','fixture'] if family=='REF' else ['inverted_gear'] if task=='GEAR-02' else []
    result['grasp_profiles']={key:json.loads((ROOT/'assembly_family/grasp_candidates'/key/'grasp.json').read_text()) for key in keys if (ROOT/'assembly_family/grasp_candidates'/key/'grasp.json').exists()}
    return result
