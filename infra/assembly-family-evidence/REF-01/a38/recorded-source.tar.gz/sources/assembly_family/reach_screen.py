"""Kinematic candidate selection before issuing an ordinary joint-space move."""
import numpy as np
from scipy.spatial.transform import Rotation


def goto(c,tasks,seconds=2.5):
    seeds=[c.q.copy()]
    for shoulder_yaw in (-1.5,0.,1.5):
        q=c.q.copy();q[c.index['waist_yaw_joint']]=0.
        for side in tasks:
            q[c.index[side+'_shoulder_yaw_joint']]=shoulder_yaw
            q[c.index[side+'_elbow_joint']]=1.2
        seeds.append(q)
    candidates=[];diagnostics=[]
    for index,seed in enumerate(seeds):
        q,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,tasks,iters=300,damping=.02,w_rot=.5,max_step=.08)
        angles={side:float(np.linalg.norm(Rotation.from_matrix(np.asarray(rot)@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec()))
                for side,(_,_,rot) in tasks.items() if rot is not None}
        diagnostics.append(dict(seed=index,position_errors=errors,rotation_errors=angles))
        if max(errors.values())<.004 and max(angles.values(),default=0.)<.04:
            candidates.append((np.linalg.norm(q[c.ik.upper]-c.q[c.ik.upper]),q))
            if index==0:break
    c.event('screened_approach',candidates=diagnostics)
    if not candidates:raise RuntimeError('No reachable approach within 4 mm / 0.04 rad planning tolerances')
    q=min(candidates,key=lambda x:x[0])[1]
    c.move_joints(q,seconds=seconds)
