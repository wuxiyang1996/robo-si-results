"""Table-edge-assisted shim manipulation, with ordinary measured joint control."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_tabletop_assembly.solution.tool import safe_ready
from humanoid.g1_gear_assembly.solution.skills import Pinch
from humanoid.g1_gear_assembly.solution.stage_drive import TOOL_PROFILE
from humanoid.g1_gear_assembly.solution.skills import goto


def push_with_sleeve(c,target_x=.235):
    """Use the neighbouring sleeve as a real table-supported push surface."""
    from .reach_screen import goto as screened_goto
    c.hand_preset('left','open',seconds=1.)
    q=c.q.copy()
    for joint,value in [('index_0',-.05),('index_1',-.05),('middle_0',-1.3),('middle_1',-1.0)]:q[c.index['left_hand_'+joint+'_joint']]=value
    c.event('shim_sleeve_push_prepare_index');c.move_joints(q,seconds=1.)
    c.ik._set(c.env.base_position,(1,0,0,0),c.actual_q())
    tip=c.ik.point(c.ik.m.body('left_hand_index_1_link').id,[.04,0,0])
    local=c.ik.d.xmat[c.ik.wrist['left']].reshape(3,3).T@(c.ik.hand_point('left','palm')-tip)
    sleeve=c.object_state('sleeve');brace=c.object_state('brace');start=np.asarray(c.object_state('shim')['pos'])
    east=float(sleeve['pos'][0]+c.env.cfg.sleeve_outer_size[0]/2)
    west=float(brace['pos'][0]-c.env.cfg.brace_size[0]/2)
    if west-east<.014:raise RuntimeError('shim: no physical index clearance between sleeve and staged stand')
    rotation=Rotation.from_euler('y',np.pi/2).as_matrix()
    contact=np.array([(east+west)/2,sleeve['pos'][1],c.env.cfg.table_height+.006])+rotation@local
    c.event('shim_sleeve_push_hover',gap_m=west-east)
    screened_goto(c,{'left':('palm',contact+[0,0,.13],rotation)},seconds=3.,iters=600,self_clear=True)
    c.move_hands({'left':('palm',contact,rotation)},seconds=2.5,feedback=.5)
    hp,_=c.hand_pose('left');c.event('shim_sleeve_push_contact')
    for i in range(80):
        if c.object_state('sleeve')['hand_contact']:break
        c.reach({'left':('palm',hp+[-.0004*(i+1),0,0],rotation)},feedback=.4,iters=20);c.step()
    if not c.object_state('sleeve')['hand_contact']:raise RuntimeError('shim: index established no real sleeve contact')
    hp,_=c.hand_pose('left');before=np.asarray(c.object_state('shim')['pos']);correction=0.
    c.event('shim_push_through_actual_sleeve',target_x=target_x)
    for i in range(200):
        a=(i+1)/200;a=a*a*a*(10-15*a+6*a*a)
        actual=c.object_state('shim');desired=before[0]+a*(target_x-before[0])
        correction=float(np.clip(correction+np.clip(.06*(desired-actual['pos'][0]),-.0005,.0005),-.04,.04))
        c.reach({'left':('palm',hp+[desired-before[0]+correction,0,0],rotation)},feedback=.4,iters=20);c.step()
    hp,hR=c.hand_pose('left');c.event('shim_sleeve_push_withdraw')
    c.move_hands({'left':('palm',hp+[0,0,.14],hR)},seconds=1.5);c.hold(.5)
    state=c.object_state('shim')
    if abs(state['pos'][0]-target_x)>.015 or state['robot_contact'] or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('shim: sleeve push did not establish the released front overhang')
    if np.linalg.norm(np.asarray(c.object_state('brace')['pos'])-brace['pos'])>.01:
        raise RuntimeError('shim: sleeve push disturbed the staged stand')
    c.event('shim_sleeve_push_probe_success',position=state['pos'])


def push_to_edge(c,fit,side='right',target_x=.215,ready=True):
    if ready:safe_ready(c)
    s=c.object_state('shim');p=np.asarray(s['pos'])
    mirror=np.diag([1.,-1.,1.]) if side=='right' else np.eye(3)
    turn=Rotation.from_euler('z',np.pi/2 if side=='right' else -np.pi/2).as_matrix()
    rot=turn@mirror@np.asarray(fit['rotation'])@mirror
    offset=turn@mirror@np.asarray(fit['palm_offset']);offset[2]-=.004
    q=c.q.copy()
    sign=-1. if side=='right' else 1.
    for j,v in fit['hand_joints'].items():q[c.index[side+'_hand_'+j+'_joint']]=v if j=='thumb_0' else sign*v
    q[c.index[side+'_hand_thumb_0_joint']]=0.
    q[c.index[side+'_hand_thumb_1_joint']]=sign*1.0
    q[c.index[side+'_hand_thumb_2_joint']]=sign*1.45
    c.event('shim_push_preshape');c.move_joints(q,seconds=1.2)
    palm=p+offset
    c.event('shim_push_approach')
    from .reach_screen import goto as screened_goto
    screened_goto(c,{side:('palm',palm+[0,0,.12],rot)},seconds=3.,iters=600,self_clear=True)
    c.move_hands({side:('palm',palm,rot)},seconds=3.)
    c.event('shim_push_contact_pose_convergence')
    correction=np.zeros(3);rotation_correction=np.zeros(3)
    for _ in range(200):
        actual,actual_R=c.hand_pose(side)
        error=palm-actual;rv=Rotation.from_matrix(rot@actual_R.T).as_rotvec()
        if np.linalg.norm(error)<.002 and np.linalg.norm(rv)<.025:break
        correction=np.clip(correction+np.clip(.06*error,-.0004,.0004),-.025,.025)
        rotation_correction=np.clip(rotation_correction+np.clip(.025*rv,-.001,.001),-.12,.12)
        c.reach({side:('palm',palm+correction,Rotation.from_rotvec(rotation_correction).as_matrix()@rot)},feedback=.5,iters=24);c.step()
    actual,actual_R=c.hand_pose(side)
    contact_force=sum(float(np.linalg.norm(row['force']))for row in c.contacts('shim')
                      if row['link'].startswith(side+'_hand_') and row['link'].endswith('_1_link'))
    angle=float(np.linalg.norm(Rotation.from_matrix(rot@actual_R.T).as_rotvec()))
    c.event('shim_push_measured_contact_pose',position_error=float(np.linalg.norm(actual-palm)),rotation_error=angle,distal_contact_force_n=contact_force)
    established=contact_force>2. and np.linalg.norm(actual-palm)<.02 and angle<.15
    if np.linalg.norm(actual-palm)>.004 and not established:
        raise RuntimeError('shim: pusher did not physically reach its contact height')
    if established:palm,rot=actual.copy(),actual_R.copy()
    c.event('shim_push_to_front_edge',target_x=target_x,contact='index and middle distal links')
    target=palm+np.array([target_x-p[0],0,0])
    c.move_hands({side:('palm',target,rot)},seconds=4.,feedback=.5)
    c.move_hands({side:('palm',target+[0,0,.12],rot)},seconds=1.5);c.hold(.4)
    s=c.object_state('shim')
    if abs(s['pos'][0]-target_x)>.017 or not s['support_contact']:
        raise RuntimeError('shim: table-edge push missed its supported staging region')


def edge_pick(c,goal,side,long_edge=False,stack_clearance=.10):
    name='shim';p=np.asarray(c.object_state(name)['pos']);q0=c.object_state(name)['quat']
    yaw=Rotation.from_quat(np.asarray(q0)[[1,2,3,0]]).as_euler('xyz')[2]
    # The rectangular shim has identical front edges under a half turn.
    yaw=(yaw+np.pi/2)%np.pi-np.pi/2
    if long_edge:
        edge=Rotation.from_euler('z',yaw).apply([0,np.sign(np.sin(yaw))*.055,0])
        yaw-=np.sign(np.sin(yaw))*np.pi/2
    else:edge=Rotation.from_euler('z',yaw).apply([-.030,0,0])
    angle=np.pi/2 if side=='left' else -np.pi/2
    turn=Rotation.from_euler('z',yaw+angle).as_matrix()@Rotation.from_euler('x',-angle).as_matrix()
    grip=Pinch(c,name,side,TOOL_PROFILE,squeeze=.3,opening=.25)
    rotation=turn@grip.rotation;offset=turn@grip.offset
    # The exposed 30 mm edge permits a thumb/fingers-underneath grasp.
    palm=p+edge+offset
    c.event(name+'_edge_preshape');c.move_joints(grip.curled(-.25),seconds=1.2)
    front=Rotation.from_euler('z',yaw).apply([-.060 if side=='right' and long_edge else -.075,0,0])
    c.event(name+'_edge_front_approach')
    if side=='right' and long_edge:
        from .reach_screen import approach_from_contact
        c.ik.set_limit('waist_pitch_joint',-.48,.48)
        c.ik.set_limit('waist_roll_joint',-.48,.48)
        joint=c.index['right_wrist_roll_joint']
        c.ik.set_limit('right_wrist_roll_joint',c.lo[joint]+.04,c.hi[joint]-.04)
        approach_from_contact(c,side,palm+front,rotation,height=.12,protected=(name,))
    else:goto(c,{side:('palm',palm+front+[0,0,.12],rotation)},seconds=2.5)
    c.move_hands({side:('palm',palm+front,rotation)},seconds=2.)
    c.event(name+'_edge_insert_fingers');c.move_hands({side:('palm',palm,rotation)},seconds=2.)
    c.event(name+'_edge_contact_pose_convergence')
    for _ in range(150):
        actual,actual_R=c.hand_pose(side)
        error=np.linalg.norm(actual-palm)
        angle=np.linalg.norm(Rotation.from_matrix(rotation@actual_R.T).as_rotvec())
        if error<.006 and angle<.04:break
        c.reach({side:('palm',palm,rotation)},feedback=.5,iters=24);c.step()
    if np.linalg.norm(c.hand_pose(side)[0]-palm)>.012:
        raise RuntimeError('shim: undergrasp has not physically reached its contact pose')
    c.event(name+'_edge_close');c.move_joints(grip.curled(.3),seconds=1.3)
    hand,rot=c.hand_pose(side)
    c.event(name+'_edge_lift');c.move_hands({side:('palm',hand+[0,0,.17 if long_edge else .12],rot)},seconds=2.5)
    s=c.object_state(name)
    if not s['hand_contact'] or s['pos'][2]<p[2]+.035:raise RuntimeError('shim: edge grasp failed lift probe')
    if long_edge:
        from .supported_carry import place
        return place(c,grip,goal,clearance_height=stack_clearance)
    weak=[0]
    def guard(current):
        if current.phase!='shim_edge_front_corridor':return
        held=current.object_state(name)['hand_contact'];weak[0]=0 if held else weak[0]+1
        if weak[0]>5:raise RuntimeError('shim: sustained grasp lost during edge carry')
    c.joint_feedback['shim_edge_carry_guard']=guard
    if side=='left':
        corridor=.225 if long_edge else .275
        for waypoint in ([corridor,s['pos'][1],s['pos'][2]],[corridor,goal[1],s['pos'][2]]):
            part=np.asarray(c.object_state(name)['pos']);hand,rot=c.hand_pose(side)
            c.event(name+'_edge_front_corridor')
            c.move_hands({side:('palm',hand+np.asarray(waypoint)-part,rot)},seconds=max(1.5,np.linalg.norm(np.asarray(waypoint)-part)/.12),feedback=.5)
    # The high, close-to-torso midline pose is outside this wrist's workspace.
    # Lower in place before traversing the clear strip along the table front.
    hand,rot=c.hand_pose(side)
    c.event(name+'_edge_lower_to_transfer_corridor')
    c.move_hands({side:('palm',hand+[0,0,-.065],rot)},seconds=1.5)
    supported_release=False
    for height in (.045,.015,.001):
        for _ in range(3):
            s=c.object_state(name)
            if not s['hand_contact']:
                if s['support_forces'].get('table',0)>.05 and np.linalg.norm(np.asarray(s['pos'])-goal)<.012:
                    c.event(name+'_edge_supported_setdown',position=s['pos'])
                    supported_release=True;break
                raise RuntimeError('shim: edge grasp lost in transfer')
            delta=np.asarray(goal)+[0,0,height]-s['pos']
            if np.linalg.norm(delta)<.003:break
            hand,rot=c.hand_pose(side);c.event(name+'_edge_transfer')
            c.move_hands({side:('palm',hand+delta,rot)},seconds=max(1.5,np.linalg.norm(delta)/.12),feedback=.5)
        if supported_release:break
    c.joint_feedback.pop('shim_edge_carry_guard',None)
    c.event(name+'_edge_release');c.move_joints(grip.curled(-.25),seconds=1.3)
    hand,rot=c.hand_pose(side);c.move_hands({side:('palm',hand+front,rot)},seconds=1.5)
    c.move_hands({side:('palm',hand+front+[0,0,.15],rot)},seconds=1.5);c.hold(.5)
    s=c.object_state(name)
    if s['robot_contact'] or np.linalg.norm(np.asarray(s['pos'])-goal)>.015:raise RuntimeError('shim: edge placement missed released target')


def slide_to_left(c,fit):
    """Use table support during the lateral transfer; no airborne handoff."""
    p=np.asarray(c.object_state('shim')['pos']);mirror=np.diag([1.,-1.,1.])
    rot=mirror@np.asarray(fit['rotation'])@mirror
    # Centre one index pad on the 70 mm edge. The two pads were only 6 mm
    # from its corners; small yaw shed one contact and spun the shim off-edge.
    # Keep the unused pad above the table instead of dragging it on the surface.
    palm=p+mirror@np.asarray(fit['palm_offset'])+[-.0285,-.055,-.001]
    q=c.q.copy()
    for j,v in fit['hand_joints'].items():q[c.index['right_hand_'+j+'_joint']]=v if j=='thumb_0' else -v
    q[c.index['right_hand_thumb_0_joint']]=0.;q[c.index['right_hand_thumb_1_joint']]=-1.;q[c.index['right_hand_thumb_2_joint']]=-1.45
    c.event('shim_lateral_push_preshape');c.move_joints(q,seconds=1.2)
    goto(c,{'right':('palm',palm+[0,0,.12],rot)},seconds=2.5)
    c.move_hands({'right':('palm',palm,rot)},seconds=2.5,feedback=.5)
    target=palm+[0,.25-p[1],0]
    c.event('shim_slide_along_table_front',target_y=.25)
    pad=mirror@np.asarray(fit['contacts']['index']['point'])-mirror@np.asarray(fit['palm_offset'])
    for i in range(400):
        fraction=(i+1)/400;a=fraction**3*(10-15*fraction+6*fraction*fraction)
        state=c.object_state('shim');actual=np.asarray(state['pos'])
        if actual[0]<.21:raise RuntimeError('shim: stop sliding before losing table support')
        yaw=Rotation.from_quat(np.asarray(state['quat'])[[1,2,3,0]]).as_euler('xyz')[2]
        # Steer the pushed face itself: its normal determines force direction.
        # A wrist heading correction alone cannot redirect a flat box face.
        desired_yaw=np.clip(8*(actual[0]-p[0]),-.18,.18)
        yaw_rate=float(state.get('ang',[0,0,0])[2])
        lever=np.clip(-.04*(yaw-desired_yaw)-.005*yaw_rate,-.02,.02)
        turn=Rotation.from_euler('z',yaw).as_matrix()
        point=palm+a*(target-palm)
        contact_x=actual[0]+(turn@np.array([lever,-.09,0]))[0]
        point[0]=contact_x-(turn@pad)[0]
        c.reach({'right':('palm',point,turn@rot)},feedback=.5)
        c.step()
    c.move_hands({'right':('palm',target+[0,0,.12],rot)},seconds=1.5);c.hold(.3)
    s=c.object_state('shim')
    if abs(s['pos'][1]-.25)>.045 or abs(s['pos'][0]-p[0])>.025 or s['support_forces'].get('table',0)<.05:
        raise RuntimeError('shim: lateral table-supported transfer missed the left grasp region')
