"""Let gravity orient a high-held frame while its bar remains in a top pinch."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,configure_ik,raise_hands,Pinch
from humanoid.g1_gear_assembly.solution.stage_base_hook import HOOK_PROFILE


def run(c,m,both=False):
    from .policies import prepare_interior_hands,park_unused_arm
    prepare_interior_hands(c);configure_ik(c,waist_pitch=.48);raise_hands(c,seconds=2.)
    park_unused_arm(c,'right');name='left_frame';m.high_id=name
    p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0.,.003303960702,.0773333333]
    grip=Pinch(c,name,'left',HOOK_PROFILE,anchor=anchor,azimuth=yaw,squeeze=.55,opening=.4);grip.grasp(hover=.12)
    finish(c,m,grip)
    if not both:return
    from .policies import park_unused_arm_high,reposition_right_frame
    hp,hR=c.hand_pose('left')
    c.event('clear_released_left_frame_before_right_gravity_grasp')
    c.move_hands({'left':('palm',hp+[0,0,.18],hR)},seconds=3.,feedback=.4,rotation_feedback=.3)
    hp,hR=c.hand_pose('left')
    c.event('clear_left_wrist_back_from_installed_frame')
    c.move_hands({'left':('palm',hp+[-.16,0,0],hR)},seconds=2.5,feedback=.4,rotation_feedback=.3)
    park_unused_arm_high(c,'left',measured_finish=True)
    configure_ik(c,waist_pitch=.48);name='right_frame';m.high_id=name
    reposition_right_frame(c)
    p,R,yaw,_=pose(c,name)
    anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@[0.,-.00329093125,.0773333333]
    fit=m.contract['grasp_profiles']['frame']
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset']),hand=fit['hand_joints'])
    # The right upper rail sits 6.6 mm lower than the left rail on the table.
    # The 14 mm handle cradle penetrated the table here; fit the actual fine rail.
    grip=Pinch(c,name,'right',profile,anchor=anchor,azimuth=yaw,squeeze=.30,opening=0.)
    from .reach_screen import goto
    from .paired_grasp import acquire
    goto(c,grip.target(.12),seconds=3.,iters=600,self_clear=True)
    acquire(c,grip,protect_other=False)
    return finish(c,m,grip,cradle_upgrade=True)


def finish(c,m,grip,high_palm_z=None,time_scale=1.,cradle_upgrade=False):
    from .reference_place import frame
    if cradle_upgrade:
        from .frame_cradle import acquire_clearance
        grip=acquire_clearance(c,grip)
    name,side=grip.name,grip.side
    if pose(c,name)[3]['robot_contact_force']<.5:
        raise RuntimeError('frame: fitted bar pinch established no measured load')
    hp,hR=c.hand_pose(side);c.event('frame_high_bar_lift_for_gravity_orientation')
    target=hp+[0,0,.30]
    if high_palm_z is not None:target[2]=max(hp[2],high_palm_z)
    c.move_hands({side:('palm',target,hR)},seconds=5.,feedback=.6,rotation_feedback=.3);c.hold(2.)
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 and state['robot_contact_force']>5.:
        target=c.q.copy()
        for joint,delta in [('thumb_1',-.06),('index_0',.06),('middle_0',.06)]:target[grip.joint(joint)]+=delta*(1. if side=='left' else -1.)
        c.event('frame_reduce_pinch_torque_for_gravity_roll');c.move_joints(target,seconds=1.);c.hold(2.)
    p,R,_,state=pose(c,name)
    if .90<R[2,2]<.95 and state['robot_contact_force']>.5:
        from .pose_carry import move
        move(c,grip,p,np.eye(3),3.,'frame_trim_measured_gravity_lean',
             stop_when=lambda p,R,s:R[2,2]>.98 and s['robot_contact_force']>.5)
        c.hold(.7);p,R,_,state=pose(c,name)
    c.event('frame_gravity_hang_measurement',position=p.tolist(),rotation=R.tolist(),force=state['robot_contact_force'])
    if p[2]<c.env.cfg.table_height+.16 or R[2,2]<.95 or state['robot_contact_force']<.5:
        raise RuntimeError('frame: high bar pinch did not establish a held upright frame')
    c.event('frame_gravity_hang_probe_success',position=p.tolist())
    frame(c,grip,name,time_scale=time_scale);c.hold(1.)
    if name not in c.env.status['completed']:
        raise RuntimeError('frame: gravity-oriented installation did not pass the original predicate')
    c.event('frame_gravity_install_probe_success')
