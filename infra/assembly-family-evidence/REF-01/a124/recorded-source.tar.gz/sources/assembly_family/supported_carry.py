"""Carry an undergrasped shim, then withdraw over its physical support."""
import numpy as np
from scipy.spatial.transform import Rotation
from .approach_path import move,plan
from humanoid.g1_gear_assembly.solution.skills import smooth


def pose(c,name):
    s=c.object_state(name)
    return np.asarray(s['pos']),Rotation.from_quat(np.asarray(s['quat'])[[1,2,3,0]]).as_matrix(),s


def place(c,grip,goal,clearance_height=.10):
    name,side=grip.name,grip.side;goal=np.asarray(goal)
    if goal[0]>.52:
        # Restore the authored waist workspace for the far staging area.
        # The nearer table-slide restrictions made the clear approach unreachable.
        c.ik.set_limit('waist_pitch_joint',-.50,.50)
        c.ik.set_limit('waist_roll_joint',-.50,.50)
    p,R,state=pose(c,name);hp,hR=c.hand_pose(side)
    # Crosswise placement gives the undergrasp an overhanging edge outside
    # the narrow stand. The old half-turn left its fingers over the stand
    # and its retreat facing the fixture post.
    desired_R=Rotation.from_euler('z',np.pi/2 if goal[0]>.52 else np.pi).as_matrix()
    target_p=goal+[0,0,clearance_height]+desired_R@R.T@(hp-p);target_R=desired_R@R.T@hR
    solution=None;rejections=[]
    for sy in (1.5,0.,-1.5):
        seed=c.actual_q();seed[c.index['waist_yaw_joint']]=0.;seed[c.index[side+'_shoulder_yaw_joint']]=sy
        solved,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,{side:('palm',target_p,target_R)},iters=600,damping=.02,w_rot=.5,max_step=.08)
        re=np.linalg.norm(Rotation.from_matrix(target_R@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec())
        if errors[side]<.004 and re<.04:
            candidate=c.q.copy();candidate[c.ik.upper]=solved[c.ik.upper]
            try:plan(c,candidate,side,carried=name)
            except RuntimeError as error:
                rejections.append(dict(shoulder_yaw=sy,reason=str(error)));continue
            solution=candidate;break
    if rejections:c.event('shim_stacking_branch_rejections',candidates=rejections)
    if solution is None:raise RuntimeError('shim: no collision-free reachable undergrasp stacking hover; '+str(rejections))
    move(c,solution,side,carried=name)
    # The far hand branch cannot lower to the table with this undergrasp.
    # Release from its screened, level hover and let the real stand receive it.
    start=pose(c,name)[0];landing=goal+[0,0,clearance_height if goal[0]>.52 else .085]
    c.event('shim_undergrasp_stack_approach',goal=landing.tolist())
    for i in range(200):
        p,R,state=pose(c,name)
        if not state['hand_contact']:raise RuntimeError('shim: undergrasp lost before stack release')
        hp,hR=c.hand_pose(side);desired=start+smooth(min(1.,(i+1)/150))*(landing-start)
        c.reach({side:('palm',desired+desired_R@R.T@(hp-p),desired_R@R.T@hR)},feedback=.5,iters=16);c.step()
    p,R,state=pose(c,name)
    if np.linalg.norm(p-landing)>.012 or R[2,2]<.97:
        raise RuntimeError('shim: outside the supported stack release envelope')
    hp,hR=c.hand_pose(side);outward=hp-p;outward[2]=0;outward=.12*outward/max(np.linalg.norm(outward),1e-9)
    start=c.q.copy();opened=grip.curled(-.25);indices=[grip.joint(j)for j in grip.shape]
    c.event('shim_undergrasp_open_in_place')
    for i in range(50):
        a=smooth((i+1)/50);c.q[indices]=start[indices]+a*(opened[indices]-start[indices])
        c.reach({side:('palm',hp,hR)},feedback=.5,iters=16);c.step()
    c.hold(.3);c.event('shim_undergrasp_withdraw_after_open')
    if goal[0]>.52:
        # Lifting the still-underlying hand flipped the shim in a67. Slide
        # out horizontally first, measuring the load transfer after each step.
        for distance in (.04,.08,.12):
            c.event('shim_far_slide_open_hand_out',distance=distance)
            c.move_hands({side:('palm',hp+[-distance,0,0],hR)},seconds=.6,feedback=.5)
            state=pose(c,name)[2]
            if not state['robot_contact'] and state['support_forces'].get('brace',0)>.05:break
        actual_hand,actual_R=c.hand_pose(side)
        c.move_hands({side:('palm',actual_hand+[0,0,.14],actual_R)},seconds=1.5)
    else:
        retreat=outward+[0,0,-.02]
        c.move_hands({side:('palm',hp+retreat,hR)},seconds=1.5,feedback=.5)
        c.move_hands({side:('palm',hp+retreat+[0,0,.14],hR)},seconds=1.5)
    c.hold(.6)
    p,R,state=pose(c,name)
    brace=np.asarray(c.object_state('brace')['pos'])
    if np.any(np.abs((p-brace)[:2])>np.array([.030,.075])) or R[2,2]<.95 or state['robot_contact'] or state['support_forces'].get('brace',0)<.05:
        raise RuntimeError('shim: released stack lacks measured brace support')
    c.event('shim_undergrasp_stack_verified',position=p.tolist())
