"""Open a near-contact rail profile before its vertical approach."""


def widen(grip,amount):
    # Opposite distal motion retains the fitted pad orientation. HubGrip's
    # measured distal-sum feedback uses that same unchanged sum.
    for proximal,distal,direction in [('thumb_1','thumb_2',-grip.sign),('middle_0','middle_1',grip.sign),('index_0','index_1',grip.sign)]:
        grip.open[proximal]+=direction*amount
        grip.open[distal]-=direction*amount
    grip.squeeze+=amount
