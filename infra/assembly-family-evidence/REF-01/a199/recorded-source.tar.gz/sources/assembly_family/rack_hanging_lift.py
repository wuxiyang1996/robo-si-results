"""Let a single supported rail hang naturally while lifting it off the rack."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose,smooth,side_forces
from .grasp_clearance import ReceivingArm
from .rail_contact_depth import measure


def lift(c,grip,initial_height):
    side,name=grip.side,grip.name
    hp,hR=c.hand_pose(side)
    c.ik._set(c.env.base_position,(1,0,0,0),c.q)
    bias=c.ik.hand_point(side,'palm').copy()-hp
    bias_R=c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).copy()@hR.T
    guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
    cp=np.zeros(3);cr=np.zeros(3);weak=0
    c.event('carrier_rack_fixed_wrist_hanging_lift',wrist_rise_m=.25,seconds=5.,settle_seconds=1.)
    for i in range(300):
        desired=hp+[0.,0.,.25*smooth(min(1.,(i+1)/250))]
        actual,actual_R=c.hand_pose(side);ep=desired-actual;er=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
        cp=np.clip(cp+np.clip(.04*ep,-.0002,.0002),-.025,.025)
        cr=np.clip(cr+np.clip(.025*er,-.001,.001),-.12,.12)
        for screen in guards:
            if not screen.clear(c.actual_q(),scene_clearance=.005,hand_scene_clearance=0.):
                raise RuntimeError(name+': hanging lift lost measured arm clearance '+str(screen.blocked))
        c.reach({side:('palm',desired+bias+cp,bias_R@Rotation.from_rotvec(cr).as_matrix()@hR)},iters=24,rate=.5);c.step()
        weak=weak+1 if side_forces(c,name)[side]<.05 else 0
        if weak>10:raise RuntimeError(name+': hanging lift lost its physical hook')
        if i%25==0:
            p,R,_,state=pose(c,name)
            c.event('carrier_rack_hanging_measurement',position=p.tolist(),rotation=R.tolist(),contacts=measure(c,name),supports=state['support_forces'])
    p,R,_,state=pose(c,name)
    if p[2]<initial_height+.10 or side_forces(c,name)[side]<.5 or any(state['support_forces'].get(s,0.)>.05 for s in ('table','supply_rack')):
        raise RuntimeError(name+': hanging acquisition did not clear the original rack')
    c.event('carrier_rack_hanging_lift_probe_success',position=p.tolist(),rotation=R.tolist(),contacts=measure(c,name))
