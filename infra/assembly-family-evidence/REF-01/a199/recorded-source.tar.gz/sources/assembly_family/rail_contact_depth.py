"""Measure rail-contact height from real contact points, without modifying state."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import pose


def measure(c,name):
    obj=c.env.objects[name];raw=obj.get_contacts(with_entity=c.env.robot)
    links={link.idx:link.name for link in c.env.robot.links}
    own={link.idx for link in obj.links};p,R,_,_=pose(c,name);group={}
    points=raw['position'].cpu().numpy();a=raw['link_a'].cpu().numpy();b=raw['link_b'].cpu().numpy()
    forces_a=raw['force_a'].cpu().numpy();forces_b=raw['force_b'].cpu().numpy()
    for i,point in enumerate(points):
        if int(a[i]) in own and int(b[i]) in links:link=links[int(b[i])];force=forces_a[i]
        elif int(b[i]) in own and int(a[i]) in links:link=links[int(a[i])];force=forces_b[i]
        else:continue
        side=next((s for s in ('left','right') if link.startswith(s+'_')),None)
        if side is None:continue
        amount=float(np.linalg.norm(force))
        if amount<.01:continue
        local=R.T@(point-p);group.setdefault(side,[]).append((amount,float(local[2]),link,np.asarray(force,dtype=float)))
    return {side:dict(force_n=sum(x[0]for x in rows),local_z_m=sum(x[0]*x[1]for x in rows)/sum(x[0]for x in rows),
                      force_on_part_world_n=np.sum([x[3]for x in rows],axis=0).tolist(),
                      points=[dict(force_n=f,local_z_m=z,link=link,force_on_part_world_n=force.tolist(),force_on_part_local_n=(R.T@force).tolist())for f,z,link,force in rows])for side,rows in group.items()}
