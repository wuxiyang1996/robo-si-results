"""Acquire both carrier end ties after a measured, released table staging."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import pose, smooth, side_forces
from humanoid.g1_gear_assembly.solution.stage_gears import HubGrip,Held
from humanoid.g1_gear_assembly.solution.stage_base_wrap import Carry
from .grasp_clearance import ReceivingArm


def joint_route(c, name, finish, screens, part_hand_clearance=None):
    """Plan only in a separate geometry model; execute ordinary joint targets."""
    base=c.actual_q().copy();active=c.ik.upper;start=base[active];finish=finish[active]
    def clear(point):
        q=base.copy();q[active]=point
        return all(s.clear(q,self_clear=True,scene_clearance=.025,hand_scene_clearance=.01,hand_clearance=part_hand_clearance)for s in screens)
    def edge(a,b):
        count=max(1,int(np.ceil(np.max(abs(a-b))/.025)))
        return all(clear(a+(b-a)*i/count)for i in range(1,count+1))
    if not clear(finish):raise RuntimeError(name+': table grasp hover is obstructed')
    path=[start,finish] if edge(start,finish) else None
    if path is None:
        rng=np.random.default_rng(17);points=[start];parents=[-1]
        for iteration in range(5000):
            sample=finish if rng.random()<.35 else rng.uniform(c.ik.lo,c.ik.hi)
            parent=int(np.argmin([np.linalg.norm(q-sample)for q in points]));a=points[parent]
            b=a+(sample-a)*min(1.,.30/max(np.linalg.norm(sample-a),1e-9))
            if not edge(a,b):continue
            points.append(b);parents.append(parent)
            if edge(b,finish):
                path=[finish];index=len(points)-1
                while index!=-1:path.append(points[index]);index=parents[index]
                path=path[::-1];break
    if path is None:raise RuntimeError(name+': no clear unloaded route to table grasp')
    shortened=[path[0]];index=0
    while index<len(path)-1:
        last=len(path)-1
        while last>index+1 and not edge(path[index],path[last]):last-=1
        shortened.append(path[last]);index=last
    c.event(name+'_table_grasp_unloaded_route',waypoints=[x.tolist()for x in shortened])
    return shortened


def lift(c,m,name,palm_height_adjustment=.003):
    p,R,yaw,state=pose(c,name)
    initial_height=float(p[2]);support=getattr(c,'table_grasp_support','table')
    if R[2,2]<.97 or state['support_forces'].get(support,0)<.05 or state['robot_contact_force']>.05:
        raise RuntimeError(name+': balanced regrasp requires a flat released part supported by '+support)
    fit=m.contract['grasp_profiles']['frame']
    if getattr(c,'table_grasp_profile',None)=='under_edge':
        from .carrier_under_edge_profile import PROFILE
        fit=PROFILE;c.event('carrier_under_rail_geometry_candidate',profile=fit,support=support)
    profile=dict(rotation=np.asarray(fit['rotation']),offset=np.asarray(fit['palm_offset'])+[0,0,palm_height_adjustment],
                 hand=fit['hand_joints'],squeeze=.30,hook=0.)
    c.ik.set_limit('waist_pitch_joint',-.46,.48);c.ik.set_limit('waist_roll_joint',-.48,.48)
    for side in ('left','right'):c.ik.set_limit(side+'_elbow_joint',-.8,1.8)
    grips={}
    single=getattr(c,'table_front_single',False)
    locations=[('left',-.08349098346,0.,-np.pi/2)] if single else [('left',0.,.1485,np.pi),('right',0.,-.1485,np.pi)]
    front_pair=getattr(c,'table_front_pair',False)
    if front_pair:locations=[('left',-.08349098346,.08,-np.pi/2),('right',-.08349098346,-.08,np.pi/2)]
    locations=getattr(c,'table_grasp_locations',locations)
    for side,x,y,turn in locations:
        anchor=Rotation.from_euler('z',-yaw).as_matrix()@R@np.array([x,y,0.])
        grips[side]=HubGrip(c,name,side,yaw+turn,profile=profile,anchor=anchor)
        g=grips[side];opening=getattr(c,'table_grasp_opening',0.)
        if opening:
            # The fitted under-edge pose is already almost closed. Descending
            # in that shape catches the upper rail corners before reaching
            # the lower edge. Open proximals while retaining distal pad angles.
            from .rail_opening import widen
            widen(g,opening)
    opened=c.q.copy()
    for g in grips.values():
        for j,v in g.open.items():opened[g.joint(j)]=v
    c.move_joints(opened,seconds=.8)
    if getattr(c,'table_pair_parallel_feedback',False):
        for g in grips.values():c.joint_feedback[g.key]=g.feedback
        c.hold(.6)
        c.event('carrier_parallel_preshape_feedback_enabled',measured_q=c.actual_q().tolist())
    c.event('carrier_table_pair_planning_limits',lo=c.ik.lo.tolist(),hi=c.ik.hi.tolist())
    screens=[ReceivingArm(c,name,s,protect_scene=True)for s in ('left','right')]
    base=c.actual_q().copy();planned=None
    # Each endpoint must admit a continuous, screened descent on its IK branch.
    seeds=((0.,0.,.5),(-1.,1.5,1.2),(1.,-1.5,1.2),(-1.,-1.5,-.6),(1.,1.5,-.6))
    expanded_seeds=front_pair or getattr(c,'table_grasp_expanded_seeds',False)
    if expanded_seeds:
        import itertools
        seeds=itertools.product((0.,-.8,.8),(-1.5,0.,1.5),(-.6,.5,1.2))
    if getattr(c,'table_grasp_compensation_reserve',0.):
        import itertools
        seeds=itertools.product((0.,-1.5,1.5),(-2.,-.5,1.2),(.3,1.4),(-1.5,1.5),(-.6,1.2))
    for values in seeds:
        if len(values)==5:wy,sp,sr,sy,el=values
        else:
            wy,sy,el=values;sp,sr=-.5,.3
        seed=base.copy();seed[c.index['waist_yaw_joint']]=wy
        for side in grips:
            seed[c.index[side+'_shoulder_yaw_joint']]=sy;seed[c.index[side+'_elbow_joint']]=el
            if expanded_seeds:
                sign=1. if side=='left' else -1.
                for joint,value in [('shoulder_pitch',sp),('shoulder_roll',sign*sr),('shoulder_yaw',sign*sy),('wrist_roll',0.),('wrist_pitch',0.),('wrist_yaw',0.)]:seed[c.index[side+'_'+joint+'_joint']]=value
        goals={s:g.target(.10)[s]for s,g in grips.items()}
        sol,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,goals,iters=350,damping=.02,w_rot=.5,max_step=.08)
        if max(errors.values())>.003 or not all(s.clear(sol,self_clear=True,scene_clearance=.025,hand_scene_clearance=.01)for s in screens):
            c.event('carrier_table_pair_hover_rejected',errors=errors,blocked=[s.blocked for s in screens]);continue
        hover=sol.copy();path=[]
        for f in np.linspace(0,1,31):
            goals={s:g.target(.10*(1-f))[s]for s,g in grips.items()}
            sol,errors=c.ik.solve(c.env.base_position,(1,0,0,0),sol,goals,iters=150,damping=.015,w_rot=.5,max_step=.05)
            angles=[np.linalg.norm(Rotation.from_matrix(goals[s][2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())for s in grips]
            part_margin=.001 if getattr(c,'table_grasp_opening',0.) and f<.9 else None
            if max(errors.values())>.003 or max(angles)>.04 or not all(s.clear(sol,self_clear=True,scene_clearance=.025,hand_scene_clearance=.003 if f<.8 else 0.,hand_clearance=part_margin)for s in screens):
                c.event('carrier_table_pair_descent_rejected',fraction=float(f),errors=errors,angles=angles,blocked=[s.blocked for s in screens]);break
            path.append(sol.copy())
        if len(path)==31:
            reserve=getattr(c,'table_grasp_compensation_reserve',0.)
            if reserve:
                reserved={side:(kind,point-[0.,0.,reserve],rot)for side,(kind,point,rot)in goals.items()}
                _,error=c.ik.solve(c.env.base_position,(1,0,0,0),sol,reserved,iters=200,damping=.015,w_rot=.5,max_step=.05)
                angles=[np.linalg.norm(Rotation.from_matrix(reserved[s][2]@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec())for s in grips]
                if max(error.values())>.003 or max(angles)>.04:
                    c.event('carrier_grasp_reject_insufficient_servo_workspace',reserve_m=reserve,errors=error,angles=angles);continue
            route=joint_route(c,name,hover,screens);planned=(route,path);break
    if planned is None:raise RuntimeError(name+': no continuous pair of table grasps')
    guards=[ReceivingArm(c,name,s,clearance=.005,protect_scene=True)for s in ('left','right')]
    def guard(current):
        for screen in guards:
            tolerance=getattr(c,'table_grasp_hand_table_tolerance',0.)
            options={'hand_scene_margins':{'table':-tolerance}} if tolerance else {}
            if not screen.clear(current.actual_q(),scene_clearance=.005,hand_scene_clearance=0.,**options):
                raise RuntimeError(name+': measured grasp clearance lost '+str(screen.blocked))
    c.joint_feedback['table_pair_clearance']=guard
    try:
        route,path=planned
        for waypoint in route[1:]:
            goal=c.q.copy();goal[c.ik.upper]=waypoint
            c.move_joints(goal,seconds=max(2.,1.9*float(np.max(abs(goal[c.ik.upper]-c.q[c.ik.upper])))/.35))
        for waypoint in path[1:]:
            goal=c.q.copy();goal[c.ik.upper]=waypoint[c.ik.upper]
            c.move_joints(goal,seconds=max(.16,1.9*float(np.max(abs(goal[c.ik.upper]-c.q[c.ik.upper])))/.35))
        target={s:g.target()[s]for s,g in grips.items()}
        cp={s:np.zeros(3)for s in grips};cr={s:np.zeros(3)for s in grips}
        height_bias={s:0. for s in grips}
        def track():
            goals={};errors=[]
            for s,(_,point,rot)in target.items():
                point=point+np.array([0.,0.,height_bias[s]])
                hp,hR=c.hand_pose(s);error=point-hp;rv=Rotation.from_matrix(rot@hR.T).as_rotvec()
                cp[s]=np.clip(cp[s]+np.clip(.04*error,-.0002,.0002),-.035,.035)
                cr[s]=np.clip(cr[s]+np.clip(.025*rv,-.001,.001),-.12,.12)
                goals[s]=('palm',point+cp[s]+.5*error,Rotation.from_rotvec(cr[s]+.3*rv).as_matrix()@rot)
                errors.append((float(np.linalg.norm(error)),float(np.linalg.norm(rv))))
            c.reach(goals,iters=24,rate=.4);c.step();return errors
        for _ in range(250):
            errors=track()
            if all(p<.0015 and r<.02 for p,r in errors):break
        if not all(p<.004 and r<.04 for p,r in errors):
            c.event('carrier_grasp_palm_convergence_failed',errors=errors,target={s:dict(position=t[1].tolist(),rotation=t[2].tolist())for s,t in target.items()},measured={s:dict(position=c.hand_pose(s)[0].tolist(),rotation=c.hand_pose(s)[1].tolist())for s in grips})
            raise RuntimeError(name+': table grasp palms did not converge')
        c.event('carrier_table_pair_converged',errors=errors)
        for g in grips.values():
            g.closed=True;c.joint_feedback[g.key]=g.feedback
        start=c.q.copy();stopped={s:False for s in grips}
        for i in range(100):
            for side,g in grips.items():
                if stopped[side]:continue
                for j,sign in [('thumb_1',g.sign),('index_0',-g.sign),('middle_0',-g.sign)]:
                    idx=g.joint(j);c.q[idx]=start[idx]+sign*g.squeeze*smooth((i+1)/100)
            track();forces=side_forces(c,name)
            for side in grips:stopped[side]=stopped[side] or forces[side]>=getattr(c,'table_pair_closure_force',10.)
            if all(stopped.values()):break
        for _ in range(20):track()
        if hasattr(c,'table_contact_depth_target'):
            from .rail_contact_depth import measure
            c.event('carrier_pad_depth_before_centering',contacts=measure(c,name))
            for i in range(150):
                contacts=measure(c,name)
                for side in grips:
                    observed=contacts.get(side)
                    if observed and observed['force_n']>.5:
                        error=c.table_contact_depth_target-observed['local_z_m']
                        height_bias[side]=float(np.clip(height_bias[side]+np.clip(.025*error,-.00006,.00006),-.008,.002))
                track()
                if i%25==0:c.event('carrier_pad_depth_centering',contacts=contacts,palm_height_bias_m=height_bias.copy())
            c.event('carrier_pad_depth_after_centering',contacts=measure(c,name),palm_height_bias_m=height_bias.copy())
        forces=side_forces(c,name);c.event('carrier_table_pair_contacts',forces=forces)
        if min(forces[s]for s in grips)<.5:raise RuntimeError(name+': each selected table grip requires measured contact')
        if getattr(c,'table_require_under_rail',False):
            from .rail_contact_depth import measure
            contacts=measure(c,name);c.event('carrier_rack_undergrasp_contact_check',contacts=contacts)
            if any(s not in contacts or not any(v['local_z_m']<-.002 and v['force_n']>.1 for v in contacts[s]['points'])for s in grips):
                raise RuntimeError(name+': rack acquisition has not established measured under-rail contact')
    finally:c.joint_feedback.pop('table_pair_clearance',None)
    if getattr(c,'table_grasp_hanging_lift',False):
        from .rack_hanging_lift import lift as hanging_lift
        hanging_lift(c,grips['left'],initial_height)
        return grips,None
    carry=Held(grips['left'],level=True) if single else Carry(c,name=name,tilt_gain=.04,corr=.06)
    p,R,yaw,_=pose(c,name)
    if getattr(c,'table_pair_preserve_loaded_reference',False):
        # Preserve the outgoing palm servo's settled nominal motor reference.
        # These are controller targets, not altered measured object transforms.
        actual={side:c.hand_pose(side)for side in grips}
        c.ik._set(c.env.base_position,(1,0,0,0),c.q)
        references={side:(c.ik.hand_point(side,'palm').copy(),c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).copy())for side in grips}
        if single:
            hp,hR=references['left'];carry.local=(R.T@(hp-p),R.T@hR)
        else:
            carry.local={side:(R.T@(hp-p),R.T@hR)for side,(hp,hR)in references.items()}
        c.event('carrier_preserve_loaded_palm_reference',bias={side:dict(position_m=(hp-actual[side][0]).tolist(),rotation_rad=Rotation.from_matrix(hR@actual[side][1].T).as_rotvec().tolist())for side,(hp,hR)in references.items()})
    if getattr(c,'table_pair_preserve_loaded_reference',False):
        from .rail_contact_depth import measure
        original_track=carry.track
        observations=[0]
        depth_shift={side:0. for side in grips}
        def track_with_contacts(*args,**kwargs):
            if getattr(c,'table_pair_dynamic_contact_centering',False):
                contacts=measure(c,name)
                for side in grips:
                    observed=contacts.get(side)
                    if observed and observed['force_n']>.5:
                        delta=float(np.clip(.05*(.001-observed['local_z_m']),-.0001,.0001))
                        updated=float(np.clip(depth_shift[side]+delta,-.020,.005))
                        change=updated-depth_shift[side];depth_shift[side]=updated
                        lp,lR=carry.local[side];lp=lp.copy();lp[2]+=change;carry.local[side]=(lp,lR)
            result=original_track(*args,**kwargs);observations[0]+=1
            if observations[0]%25==0:
                point,rotation,_,state=pose(c,name)
                c.event('carrier_lift_contact_measurement',position=point.tolist(),normal_z=float(rotation[2,2]),contacts=measure(c,name),supports=state['support_forces'],depth_reference_shift_m=depth_shift.copy())
            return result
        carry.track=track_with_contacts
    if getattr(c,'table_pair_under_rail_transition',False):
        from .rail_undergrasp import transition,sequential
        origin=p.copy()
        alternate=getattr(c,'table_pair_alternating_undergrasp',False)
        carry.move(origin+[0,0,.04 if alternate else .02],yaw,seconds=2.,settle=.2)
        carry=(sequential if alternate else transition)(c,name,grips)
        carry.move(origin+[0,0,.12],yaw,seconds=3.,settle=3.)
    elif getattr(c,'table_pair_curl_after_lift',False):
        origin=p.copy();first=origin+[0,0,.02]
        carry.move(first,yaw,seconds=2.,settle=.2)
        actual,_,_,state=pose(c,name)
        if actual[2]<c.env.cfg.table_height+.015 or state['support_forces'].get('table',0)>.05:
            raise RuntimeError(name+': fingers may curl only after measured table clearance')
        c.event('carrier_curl_under_rail_after_table_clearance',hook_rad=.08,position=actual.tolist())
        for i in range(40):
            for g in grips.values():g.hook=.08*smooth((i+1)/40)
            carry.track(first,yaw)
        carry.move(origin+[0,0,.12],yaw,seconds=3.,settle=.8)
    else:carry.move(p+[0,0,.12],yaw,seconds=4.,settle=getattr(c,'table_pair_lift_settle',.5))
    p,R,_,state=pose(c,name);forces=side_forces(c,name)
    if R[2,2]<.95 or p[2]<initial_height+.09 or min(forces[s]for s in grips)<.5:
        raise RuntimeError(name+': the balanced table grips did not sustain a level lift')
    c.event('carrier_table_front_lift_probe_success' if single else 'carrier_table_pair_lift_success',position=p.tolist(),forces=forces)
    return grips,carry
