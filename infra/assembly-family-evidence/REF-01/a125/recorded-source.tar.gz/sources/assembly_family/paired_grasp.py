"""Close a receiving pinch only after its measured palm reaches the target."""
import numpy as np
from scipy.spatial.transform import Rotation
from humanoid.g1_gear_assembly.solution.skills import smooth,side_forces,pose


def fit_tilted_frame(c,grip):
    """Fit the flat-frame rail profile to its measured full 3-D orientation."""
    p,R,yaw,_=pose(c,grip.name)
    flat=Rotation.from_euler('z',yaw).as_matrix()@Rotation.from_euler('x',np.pi/2).as_matrix()
    tilt=R@flat.T
    grip.offset=tilt@grip.offset;grip.rotation=tilt@grip.rotation
    local_p=R.T@(Rotation.from_euler('z',yaw).as_matrix()@grip.anchor+grip.offset)
    local_R=R.T@grip.rotation
    def target(height=0.):
        p,R,_,_=pose(c,grip.name)
        return {grip.side:('palm',p+R@local_p+[0,0,height],R@local_R)}
    grip.target=target
    c.event(grip.name+'_fit_measured_rail_tilt',rotation=R.tolist(),palm_local=local_p.tolist())


def acquire(c,grip,protect_other=True,receiver_clearance=False):
    side=grip.side
    screen=None
    if receiver_clearance:
        from .grasp_clearance import ReceivingArm
        screen=ReceivingArm(c,grip.name,side)
    other='right'if side=='left'else 'left';other_R=c.hand_pose(other)[1]
    c.event(grip.name+'_paired_receiver_preshape',side=side)
    c.move_joints(grip.curled(-grip.opening),seconds=.6)
    correction=np.zeros(3);rotation_correction=np.zeros(3)
    def track(height):
        target=grip.target(height);_,p,R=target[side];hp,hR=c.hand_pose(side)
        error=p-hp;rv=Rotation.from_matrix(R@hR.T).as_rotvec()
        correction[:]=np.clip(correction+np.clip(.06*error,-.0004,.0004),-.035,.035)
        rotation_correction[:]=np.clip(rotation_correction+np.clip(.025*rv,-.001,.001),-.12,.12)
        commanded=Rotation.from_rotvec(rotation_correction).as_matrix()@R
        c.reach({side:('palm',p+correction,commanded)},feedback=.5,rotation_feedback=.3,iters=24);c.step()
        return float(np.linalg.norm(error)),float(np.linalg.norm(rv))
    for height,seconds in ((.12,2.5),(0.,2.5)):
        target=grip.target(height);_,p,R=target[side]
        c.event(grip.name+'_paired_receiver_approach',height=height)
        seeds=[c.q.copy()]
        for yaw in (-1.2,0.,1.2):
            for shoulder in (-1.5,1.5):
                seed=c.q.copy();seed[c.index['waist_yaw_joint']]=yaw
                seed[c.index[side+'_shoulder_yaw_joint']]=shoulder
                seeds.append(seed)
        candidates=[];diagnostics=[]
        for seed in seeds:
            solution,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,target,iters=400,damping=.02,w_rot=.5,max_step=.08)
            checked=((side,R),(other,other_R)) if protect_other else ((side,R),)
            angles=[float(np.linalg.norm(Rotation.from_matrix(want@c.ik.d.xmat[c.ik.wrist[s]].reshape(3,3).T).as_rotvec()))for s,want in checked]
            reachable=max(errors.values())<.004 and max(angles)<.04
            clear=screen.clear(solution) if screen is not None and reachable else screen is None
            diagnostics.append(dict(position=errors,rotation=angles,receiving_arm_clear=clear,blocked=screen.blocked if screen is not None else None))
            if reachable and clear:
                distance=float(np.linalg.norm(solution[c.ik.upper]-c.q[c.ik.upper]))
                cost=(-screen.minimum,distance) if screen is not None else (0.,distance)
                candidates.append((cost,solution.copy()))
                if len(diagnostics)==1 and screen is None:break
        c.event(grip.name+'_paired_receiver_endpoint',candidates=diagnostics)
        if not candidates:
            raise RuntimeError(grip.name+': paired receiver endpoint is not jointly reachable')
        solution=min(candidates,key=lambda item:item[0])[1]
        if protect_other:
            # An endpoint IK constraint does not hold the loaded hand along
            # a joint-space chord. Project each small reference step through
            # the caller's loaded-hand constraint before applying it.
            start=c.q.copy();count=max(1,round(seconds/.02))
            c.event(grip.name+'_paired_receiver_loaded_projection',target_q=solution.tolist())
            for i in range(count):
                desired=start+smooth((i+1)/count)*(solution-start)
                seed=c.q.copy();seed[c.ik.upper]+=np.clip(desired[c.ik.upper]-seed[c.ik.upper],-.008,.008)
                projected,_=c.ik.solve(c.env.base_position,(1,0,0,0),seed,{},iters=24,damping=.02,w_rot=.5,max_step=.05)
                c.q[c.ik.upper]=projected[c.ik.upper];c.step()
        else:c.move_joints(solution,seconds=seconds)
        c.move_hands(target,seconds=.6,feedback=.5,rotation_feedback=.3)
        for _ in range(250):
            target=grip.target(height);_,p,R=target[side]
            hp,hR=c.hand_pose(side)
            if np.linalg.norm(hp-p)<.0015 and np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())<.02:break
            track(height)
        hp,hR=c.hand_pose(side)
        c.event(grip.name+'_paired_receiver_pose_check',height=height,position_error=float(np.linalg.norm(hp-p)),rotation_error=float(np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())),position_correction=correction.tolist(),rotation_correction=rotation_correction.tolist(),actual_palm=hp.tolist(),target_palm=p.tolist())
        if np.linalg.norm(hp-p)>.004 or np.linalg.norm(Rotation.from_matrix(R@hR.T).as_rotvec())>.04:
            raise RuntimeError(grip.name+': paired receiver has not physically reached its grasp')
    joints=[grip.joint(j)for j in grip.shape];target=grip.target()
    c.event(grip.name+'_paired_receiver_close')
    for amount in (0.,grip.squeeze_amount):
        start=c.q.copy();goal=grip.curled(amount)
        for i in range(30):
            a=smooth((i+1)/30);c.q[joints]=start[joints]+a*(goal[joints]-start[joints])
            track(0.)
    forces=side_forces(c,grip.name);c.event(grip.name+'_paired_receiver_contact_check',forces=forces)
    if forces[side]<.5:raise RuntimeError(grip.name+': paired receiver established no measured contact')
    if screen is not None:
        clear=screen.clear(c.actual_q())
        c.event(grip.name+'_paired_actual_arm_clearance',clear=clear,minimum_m=screen.minimum,blocked=screen.blocked)
        if not clear:raise RuntimeError(grip.name+': loaded receiver lacks actual non-hand clearance before donor release')
