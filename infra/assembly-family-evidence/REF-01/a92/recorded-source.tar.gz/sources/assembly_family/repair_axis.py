"""Use the existing assembly axis to receive an upright gear before hub regrasp."""
import numpy as np
from humanoid.g1_gear_assembly.solution.skills import pose
from humanoid.g1_gear_assembly.solution.stage_gears import gear_seat,run_medium_held
from .pose_carry import move
from .held_ik import solve as held_solve


def flip_with_receiver(c,grip,receiver,goal):
    """Move the unloaded receiving hand during the physical rim-grasp flip."""
    lo,hi=c.ik.lo.copy(),c.ik.hi.copy()
    c.ik.set_limit('waist_roll_joint',-.46,.46)
    c.ik.set_limit('waist_pitch_joint',-.46,.46)
    solve=c.ik.solve
    receiving_p=np.asarray(goal)+receiver.offset+[0,0,.05]
    def follow(root_pos,root_quat,q,tasks,*args,**kwargs):
        return held_solve(c.ik,root_pos,root_quat,q,
                          dict(tasks,left=('palm',receiving_p,receiver.rotation)),
                          'right',*args,**kwargs)
    c.ik.solve=follow
    try:
        move(c,grip,goal,np.eye(3),6.,'repair_flip_with_receiver_staging')
        for _ in range(3):
            if pose(c,grip.name)[1][2,2]>.99:break
            move(c,grip,goal,np.eye(3),2.,'repair_flip_receiver_measured_trim',
                 stop_when=lambda p,R,s:R[2,2]>.99 and s['robot_contact_force']>5.)
    finally:
        c.ik.solve=solve;c.ik.lo[:],c.ik.hi[:]=lo,hi
    c.event('repair_receiver_staging_measurement',position=c.hand_pose('left')[0].tolist(),target=receiving_p.tolist())


def handoff_upright(c,grip,receiver):
    """Acquire the exposed hub while preserving the measured rim-hand pose."""
    from scipy.spatial.transform import Rotation
    from humanoid.g1_gear_assembly.solution.skills import side_forces
    from humanoid.g1_gear_assembly.solution.stage_gears import Held,insert_held
    name=grip.name;p,R,_,_=pose(c,name)
    if R[2,2]<.97:raise RuntimeError('repair: late receiver requires an upright gear')
    keep_side='right';hp,hR=c.hand_pose(keep_side);solve=c.ik.solve
    def keep(root_pos,root_quat,q,tasks,*args,**kwargs):
        actual_p,actual_R=c.hand_pose(keep_side)
        corrected_p=hp+np.clip(.6*(hp-actual_p),-.015,.015)
        error=Rotation.from_matrix(hR@actual_R.T).as_rotvec()
        corrected_R=Rotation.from_rotvec(.4*error).as_matrix()@hR
        return held_solve(c.ik,root_pos,root_quat,q,dict(tasks,**{keep_side:('palm',corrected_p,corrected_R)}),keep_side,*args,**kwargs)
    c.ik.solve=keep
    try:
        _,errors=c.ik.solve(c.env.base_position,(1,0,0,0),c.q,receiver.target(),iters=300,damping=.02,w_rot=.5,max_step=.08)
        if max(errors.values())>.004:raise RuntimeError('repair: late receiver is not jointly reachable')
        c.event('repair_late_receiver_cartesian_approach',errors=errors)
        # This branch can require several radians of arm motion. The old
        # two-second command ended with a reachable palm still 25 cm away.
        # Give the bounded joint-rate controller time, then check real pose.
        target=receiver.target()['left'][1]
        approach_seconds=float(np.clip(np.linalg.norm(c.hand_pose('left')[0]-target)/.08+1.,2.,8.))
        c.move_hands(receiver.target(),seconds=approach_seconds,feedback=.5,rotation_feedback=.3)
        target=receiver.target();_,desired_p,desired_R=target['left']
        for _ in range(150):
            actual_p,actual_R=c.hand_pose('left')
            position_error=np.linalg.norm(actual_p-desired_p)
            rotation_error=np.linalg.norm(Rotation.from_matrix(desired_R@actual_R.T).as_rotvec())
            if position_error<.006 and rotation_error<.04:break
            if pose(c,name)[3]['robot_contact_force']<.5:
                raise RuntimeError('repair: supporting grasp lost while receiver approached')
            c.reach(target,feedback=.5,rotation_feedback=.3,iters=24);c.step()
        actual_p,_=c.hand_pose('left');_,desired_p,_=receiver.target()['left']
        if np.linalg.norm(actual_p-desired_p)>.015:
            raise RuntimeError('repair: receiver has not physically reached the exposed hub')
        c.event('repair_late_receiver_close');c.move_joints(receiver.curled(.4),seconds=1.)
        current,current_R,_,_=pose(c,name);forces=side_forces(c,name)
        c.event('repair_late_receiver_contact_check',forces=forces)
        if forces['left']<.5 or np.linalg.norm(current-p)>.025 or current_R[2,2]<.95:
            raise RuntimeError('repair: late receiver did not acquire the upright gear')
        keep_side='left';hp,hR=c.hand_pose(keep_side)
        grip.closed=False;q=c.q.copy()
        for j in ('thumb_0','thumb_1','middle_0','index_0'):q[grip.joint(j)]=grip.open[j]
        c.event('repair_late_handoff_release_rim');c.move_joints(q,seconds=1.3)
        right_p,right_R=c.hand_pose('right')
        c.move_hands({'right':('palm',right_p+[0,-.12,-.06],right_R)},seconds=2.)
        c.joint_feedback.pop(grip.key,None)
    finally:c.ik.solve=solve
    held=Held(receiver);start=pose(c,name)[0]
    held.move(start+[0,0,.04],pose(c,name)[2],seconds=2.,settle=.3)
    insert_held(c,name,held);receiver.release(seconds=1.2,rise=.10);c.hold(.8)
    return True


def release_on_table(c,grip):
    """Release the flipped gear before moving the supporting arm again."""
    from humanoid.g1_gear_assembly.solution.skills import smooth
    p,R,_,state=pose(c,grip.name)
    if R[2,2]<.97 or not (.30<p[0]<.45 and -.32<p[1]<-.15 and .97<p[2]<1.08):
        raise RuntimeError('repair: flipped gear is outside the clear table-release envelope')
    hp,hR=c.hand_pose('right');grip.closed=False;start=c.q.copy()
    c.event('repair_release_above_clear_table',position=p.tolist())
    for i in range(30):
        a=smooth((i+1)/30)
        for j in ('thumb_0','thumb_1','middle_0','index_0'):
            k=grip.joint(j);c.q[k]=start[k]+a*(grip.open[j]-start[k])
        c.reach({'right':('palm',hp,hR)},feedback=.5,rotation_feedback=.3);c.step()
    c.joint_feedback.pop(grip.key,None)
    c.move_hands({'right':('palm',hp+[0,0,.12],hR)},seconds=1.5,feedback=.5,rotation_feedback=.3);c.hold(1.)
    p,R,_,state=pose(c,grip.name)
    if R[2,2]<.95 or state['support_forces'].get('table',0)<.05 or state['robot_contact_force']>.05:
        raise RuntimeError('repair: released gear did not settle upright on the table')
    c.event('repair_upright_table_stage_verified',position=p.tolist())
    run_medium_held(c,ready=True)
    return True


def release_with_distals(c,grip):
    """Unhook the loaded fingertips before withdrawing the supporting hand."""
    from humanoid.g1_gear_assembly.solution.skills import smooth
    p,R,_,_=pose(c,grip.name)
    if R[2,2]<.97 or not (.30<p[0]<.45 and -.32<p[1]<-.15 and .97<p[2]<1.08):
        raise RuntimeError('repair: distal release is outside the clear table envelope')
    hp,hR=c.hand_pose('right');start=c.actual_q();target=start.copy()
    # Equal distal angles opened thumb/middle much earlier than index.
    # These mesh-screened joint directions produce comparable pad retreat.
    for finger,j,delta in [('thumb',2,.30),('index',0,-.40),('middle',0,-.20)]:
        k=grip.joint(f'{finger}_{j}');target[k]=np.clip(start[k]+delta,c.lo[k]+.03,c.hi[k]-.03)
    c.joint_feedback.pop(grip.key,None);grip.closed=False
    active=[grip.joint(j)for j in grip.open]
    c.event('repair_unhook_distal_pads',position=p.tolist())
    for i in range(30):
        a=smooth((i+1)/30);c.q[active]=start[active]+a*(target[active]-start[active])
        retreat=min(1.,(i+1)/20)
        c.reach({'right':('palm',hp+[0,.12*retreat,-.03*retreat],hR)},feedback=.5,rotation_feedback=.3);c.step()
    for _ in range(25):
        c.reach({'right':('palm',hp+[0,.12,-.03],hR)},feedback=.5,rotation_feedback=.3);c.step()
    c.event('repair_withdraw_unhooked_hand')
    c.move_hands({'right':('palm',hp+[0,.10,-.04],hR)},seconds=.8,feedback=.5,rotation_feedback=.3)
    c.move_hands({'right':('palm',hp+[0,.14,.12],hR)},seconds=1.5);c.hold(1.)
    p,R,_,state=pose(c,grip.name)
    if R[2,2]<.95 or state['support_forces'].get('table',0)<.05 or state['robot_contact_force']>.05:
        raise RuntimeError('repair: unhooked release did not settle upright on the table')
    c.event('repair_upright_table_stage_verified',position=p.tolist())
    run_medium_held(c,ready=True)
    return True


def pivot_on_base_handle(c,grip):
    """Use the existing raised handle as a real rim fulcrum, then tip outwards."""
    from scipy.spatial.transform import Rotation
    from humanoid.g1_gear_assembly.solution.skills import smooth
    name=grip.name;bp,bR,_,_=pose(c,'base')
    radius=c.env.catalog['parts'][name]['size'][0]/2
    # First complete the known physical flip. Its measured loaded grasp
    # puts the palm above the positive-y handle during a +90-degree tilt;
    # the opposite handle would put that palm below the tabletop.
    edge_local=np.array([0.,-radius,-.025])
    pivot=bp+bR@np.array([0.,.19,.01525+.007])
    vertical=bR@Rotation.from_euler('x',np.pi/2).as_matrix()
    seat=pivot-vertical@edge_local
    c.event('repair_choose_handle_fulcrum',pivot=pivot.tolist(),radius=float(radius))
    move(c,grip,seat+[0,0,.06],vertical,8.,'repair_quarter_turn_to_handle',integrate=False)
    move(c,grip,seat-[0,0,.001],vertical,3.,'repair_lower_rim_to_handle',integrate=False)
    hp,hR=c.hand_pose('right')
    for i in range(60):
        p,R,_,state=pose(c,name)
        if state['support_forces'].get('base',0)>.05:break
        c.reach({'right':('palm',hp-[0,0,.0002*(i+1)],hR)},feedback=.5,rotation_feedback=.3);c.step()
    p,R,_,state=pose(c,name)
    if state['support_forces'].get('base',0)<.05 or np.linalg.norm(p-seat)>.015:
        raise RuntimeError('repair: gear rim did not establish measured support on the handle')
    pivot=p+R@edge_local;hp,hR=c.hand_pose('right')
    local_p=R.T@(hp-p);local_R=R.T@hR
    c.event('repair_handle_supported_pivot',pivot=pivot.tolist())
    for i in range(120):
        a=smooth((i+1)/120);Rd=bR@Rotation.from_euler('x',np.pi/2-a*np.pi/6).as_matrix()
        desired=pivot-Rd@edge_local
        c.reach({'right':('palm',desired+Rd@local_p,Rd@local_R)},feedback=.5,rotation_feedback=.3,iters=16);c.step()
    p,R,_,state=pose(c,name)
    outward=float((bR.T@(p-pivot))[1])
    if outward<.001 or not .25<R[2,2]<.80 or state['support_forces'].get('base',0)<.05:
        raise RuntimeError('repair: rim pivot did not pass the outward gravity-release gate')
    c.event('repair_release_beyond_handle',outward_offset_m=outward)
    hp,hR=c.hand_pose('right');start=c.actual_q();target=start.copy()
    for finger,j,delta in [('thumb',2,.30),('index',0,-.40),('middle',0,-.20)]:
        k=grip.joint(f'{finger}_{j}');target[k]=np.clip(start[k]+delta,c.lo[k]+.03,c.hi[k]-.03)
    active=[grip.joint(j)for j in grip.open];c.joint_feedback.pop(grip.key,None);grip.closed=False
    for i in range(35):
        a=smooth((i+1)/35);c.q[active]=start[active]+a*(target[active]-start[active])
        c.reach({'right':('palm',hp+bR@np.array([0.,.12*a,.08*a]),hR)},feedback=.5,rotation_feedback=.3);c.step()
    c.hold(1.5)
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 or state['robot_contact_force']>.05 or state['support_forces'].get('table',0)<.05:
        raise RuntimeError('repair: handle-assisted turn did not settle upright on the table')
    c.event('repair_handle_flip_table_verified',position=p.tolist())
    run_medium_held(c,ready=True)
    return True


def release_on_axis(c,grip):
    name=grip.name;seat,_=gear_seat(c,name);axis=np.asarray(seat[:2])
    p,R,_,_=pose(c,name)
    if R[2,2]<.97:raise RuntimeError('repair: axis receiver requires an already upright gear')
    move(c,grip,np.r_[axis,1.02],np.eye(3),2.,'repair_align_gravity_seat')
    p,R,_,state=pose(c,name)
    if np.linalg.norm(p[:2]-axis)>.004 or R[2,2]<.99 or not .99<p[2]<1.05:
        raise RuntimeError('repair: gear is outside the bounded axis-release envelope')
    hp,hR=c.hand_pose('right');grip.closed=False
    q=c.q.copy()
    for j in ('thumb_0','thumb_1','middle_0','index_0'):q[grip.joint(j)]=grip.open[j]
    c.event('repair_release_above_axis',position=p.tolist())
    c.move_joints(q,seconds=.8);c.hold(.6)
    c.joint_feedback.pop(grip.key,None)
    c.move_hands({'right':('palm',hp+[0,.12,.10],hR)},seconds=1.5,feedback=.5,rotation_feedback=.3)
    p,R,_,state=pose(c,name)
    if R[2,2]<.95 or p[2]<c.env.cfg.table_height:
        raise RuntimeError('repair: gravity seating did not leave an upright recoverable gear')
    c.hold(1.)
    if 'medium_gear' not in c.env.status.get('completed',[]):
        c.event('repair_regular_hub_reseat_after_axis_support')
        run_medium_held(c,ready=True)
    return True
