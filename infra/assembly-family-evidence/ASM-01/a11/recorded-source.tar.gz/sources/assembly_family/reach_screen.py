"""Kinematic candidate selection before issuing an ordinary joint-space move."""
import numpy as np
from scipy.spatial.transform import Rotation


def goto(c,tasks,seconds=2.5):
    seeds=[c.q.copy()]
    for shoulder_yaw in (-1.5,0.,1.5):
        q=c.q.copy();q[c.index['waist_yaw_joint']]=0.
        for side in tasks:
            q[c.index[side+'_shoulder_yaw_joint']]=shoulder_yaw
            q[c.index[side+'_elbow_joint']]=1.2
        seeds.append(q)
    candidates=[];diagnostics=[]
    for index,seed in enumerate(seeds):
        q,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,tasks,iters=300,damping=.02,w_rot=.5,max_step=.08)
        angles={side:float(np.linalg.norm(Rotation.from_matrix(np.asarray(rot)@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec()))
                for side,(_,_,rot) in tasks.items() if rot is not None}
        diagnostics.append(dict(seed=index,position_errors=errors,rotation_errors=angles))
        if max(errors.values())<.004 and max(angles.values(),default=0.)<.04:
            candidates.append((np.linalg.norm(q[c.ik.upper]-c.q[c.ik.upper]),q))
            if index==0:break
    c.event('screened_approach',candidates=diagnostics)
    if not candidates:raise RuntimeError('No reachable approach within 4 mm / 0.04 rad planning tolerances')
    q=min(candidates,key=lambda x:x[0])[1]
    c.move_joints(q,seconds=seconds)

def approach_from_contact(c,side,point,rotation,height=.12,seconds=2.5):
    """Find a continuous IK branch upwards from an unloaded grasp endpoint."""
    seed=c.q.copy();seed[c.index['waist_yaw_joint']]=0.
    seed[c.index[side+'_shoulder_yaw_joint']]=1.5
    seed[c.index[side+'_elbow_joint']]=1.2
    diagnostics=[]
    for dz in np.linspace(0.,height,7):
        target=np.asarray(point)+[0,0,dz]
        seed,errors=c.ik.solve(c.env.base_position,(1,0,0,0),seed,{side:('palm',target,rotation)},iters=600,damping=.02,w_rot=.5,max_step=.08)
        angle=float(np.linalg.norm(Rotation.from_matrix(rotation@c.ik.d.xmat[c.ik.wrist[side]].reshape(3,3).T).as_rotvec()))
        diagnostics.append(dict(height=float(dz),position_error=errors[side],rotation_error=angle))
        if errors[side]>.004 or angle>.04:
            c.event('unreachable_contact_approach',samples=diagnostics)
            raise RuntimeError('Contact-to-hover path has no continuous reachable IK branch')
    c.event('screened_contact_approach',samples=diagnostics)
    target=c.q.copy();target[c.ik.upper]=seed[c.ik.upper]
    from .approach_path import move
    move(c,target,side)
